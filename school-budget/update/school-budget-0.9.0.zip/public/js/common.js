/* 모든 화면이 같이 쓰는 것 : 서버 부르기 · 로그인 확인 · 상단 막대
   🔴 권한 검사는 서버가 한다. 여기서 메뉴를 숨기는 것은 편의일 뿐이다. */
'use strict';

const App = {
  /** 서버 부르기 — 실패해도 던지지 않고 { ok:false, error } 를 돌려준다(화면이 멈춰 있지 않게) */
  async api(주소, 보낼것) {
    try {
      const r = await fetch(주소, 보낼것 === undefined
        ? { cache: 'no-store' }
        : { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(보낼것) });
      const d = await r.json().catch(() => ({ ok: false, error: '서버 응답을 읽을 수 없습니다 (' + r.status + ')' }));
      if (r.status === 401 && d.error === '로그인이 필요합니다.') { location.href = 'login.html'; }
      return d;
    } catch (e) {
      return { ok: false, error: '서버에 연결하지 못했습니다. 서버가 켜져 있는지 확인해 주세요.' };
    }
  },

  /**
   * 화면에 들어오기 전 확인 — 처음 설정 · 로그인 · 관리자 여부.
   * 통과하면 로그인한 사람을 돌려주고 상단 막대를 그린다.
   */
  /**
   * 관리자만 : 전체 관리자만 · 편성 : 전체 관리자 또는 사업관리자
   * (들어올 수 없으면 지출 입력 화면으로 돌려보낸다)
   */
  async 문지기({ 관리자만 = false, 편성 = false } = {}) {
    const s = await App.api('/api/session');
    if (!s.ok) { document.body.innerHTML = '<p class="bad" style="padding:24px">✖ ' + App.글(s.error) + '</p>'; return null; }
    if (s.설정필요) { location.href = 'setup.html'; return null; }
    if (!s.나) { location.href = 'login.html'; return null; }
    const 관리자 = s.나.role === 'admin';
    if ((관리자만 && !관리자) || (편성 && !관리자 && !s.나.사업관리자)) { location.href = 'expense.html'; return null; }
    App.상단막대(s.나);
    return s.나;
  },

  /* 위쪽 메뉴 — 기존 프로그램 순서(지출 입력 / 잔액 현황 / 지출 목록) + 권한에 따라 예산 편성 · 계정 관리.
     «홈» 은 메뉴에서 빼고, 오른쪽 위 이름을 누르면 내 정보(내 담당 · 비밀번호 바꾸기)로 간다 */
  상단막대(나) {
    const nav = document.getElementById('nav');
    const 관리자 = 나.role === 'admin';
    const 메뉴 = [['expense.html', '지출 입력'], ['status.html', '잔액 현황'], ['list.html', '지출 목록']];
    if (관리자 || 나.사업관리자) 메뉴.push(['budget.html', '예산 편성']);
    if (관리자) 메뉴.push(['admin.html', '계정 관리']);
    const 지금 = location.pathname.split('/').pop() || 'index.html';
    nav.innerHTML = 메뉴.map(([href, 이름]) => `<a href="${href}"${href === 지금 ? ' class="on"' : ''}>${이름}</a>`).join('');
    const who = document.getElementById('who');
    const 구분 = 관리자 ? '전체 관리자' : 나.사업관리자 ? '사업관리자' : '교사';
    who.innerHTML = `<a class="who-link${지금 === 'index.html' ? ' on' : ''}" href="./" title="내 정보 · 비밀번호 바꾸기">${App.글(나.name)} <small>(${구분})</small></a>`
      + (나.새판 ? `<a class="new-ver" href="admin.html#update" title="새 판이 나왔습니다. 눌러서 업그레이드 화면으로 갑니다">⬆ 새 판 ${App.글(나.새판)}</a>` : '')
      + '<button type="button" class="btn-top" id="logout">로그아웃</button>';
    document.getElementById('logout').onclick = async () => {
      await App.api('/api/logout', {});
      location.href = 'login.html';
    };
  },

  /** 화면에 넣을 글 — HTML 로 읽히지 않게 */
  글(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  },

  /** 알림 줄 — 색만으로 구분하지 않게 ✔ ✖ 를 함께 붙인다 */
  알림(el, 말, 좋음) {
    /* 좋음 : true(✔ 됨) · false(✖ 안 됨) · 'warn'(⚠ 됐지만 확인할 것 — 예: 예산 초과로 저장됨) */
    const 주의 = 좋음 === 'warn';
    el.textContent = (주의 ? '⚠ ' : 좋음 ? '✔ ' : '✖ ') + 말;
    el.className = 'note ' + (주의 ? 'warn' : 좋음 ? 'ok' : 'bad');
    el.hidden = false;
  },

  원(n) { return Number(n).toLocaleString('ko-KR') + '원'; },
};
