/**
 * 학교 예산 관리 — 교내망 전용 서버
 * ================================================================
 * 서버 PC 한 대에서 켜고, 업무 담당 선생님들이 학교 내부망에서 브라우저로 들어온다.
 *
 * 🔴 지키는 것
 *   · **외부 패키지 0개** — Node 내장 모듈만 쓴다(`ai-coordinator` 와 같은 판단).
 *     DB 도 Node 내장 `node:sqlite` 라 따로 설치할 것이 없다.
 *   · **교내망(사설망)에서만 받는다.** 바깥에서 온 요청은 답하지 않는다.
 *   · 자료(DB·백업·설정)는 모두 `data/` 에 — 프로그램을 갈아 끼워도 지워지지 않는다.
 *   · **권한은 서버가 검사한다.** 화면에서 메뉴를 숨기는 것은 편의일 뿐이다 —
 *     교사가 주소를 직접 쳐서 API 를 불러도 배정받지 않은 세부항목은 열리지 않아야 한다.
 *   · 처음 관리자 비밀번호는 **서버 PC 에서만**(127.0.0.1) 정할 수 있다.
 *
 * 켜기 :  node server.js                 (포트 9800 · 차 있으면 9801·9802 …)
 *        node server.js --reset-admin   (관리자 비밀번호를 잊었을 때 — 서버 PC 에서 다시 정하게 한다)
 */
'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');

const DB = require('./lib/db.js');
const Net = require('./lib/net.js');
const Auth = require('./lib/auth.js');
const 예산표 = require('./lib/budget-sheet.js');
const { readXlsx } = require('./lib/sheet-read.js');
const Xlsx = require('./lib/xlsx.js');
const 옮기기 = require('./lib/old-import.js');
const 이름들 = require('./lib/names.js');
const Update = require('./lib/update.js');
const 자료백업 = require('./lib/data-backup.js');
const 윈도우 = require('./lib/windows.js');

const APP_VERSION = '0.9.0';

/* ================================================================
 * 학교망이 https 를 가로챌 때 — Windows 인증서를 Node 에 얹는다  (`ai-coordinator` 와 같은 장치)
 * ----------------------------------------------------------------
 * 학교 보안 장비가 자기 인증서로 연결을 다시 묶으면 브라우저는 되는데(Windows 에 그 인증서가 있다)
 * Node 는 `SELF_SIGNED_CERT_IN_CHAIN` 으로 거절해 «새 판 확인» 이 막힌다 — 개발 PC 에서 실제로 막혔다.
 * ⚠ **더하기만 한다**(bundled 를 함께 넣는다) · 인증서 검사를 끄지 않는다 · API 가 없는 낡은 Node 는 그냥 지나간다.
 * ⚠ 그래도 막히면 [계정 관리] → ⬆ 업그레이드 → 📁 파일로 업그레이드 가 있다.
 * ================================================================ */
(function 시스템인증서얹기() {
  try {
    const tls = require('tls');
    if (typeof tls.setDefaultCACertificates !== 'function' || typeof tls.getCACertificates !== 'function') return;
    const 목록 = [...(tls.getCACertificates('bundled') || []), ...(tls.getCACertificates('system') || [])];
    /* 학교가 따로 준 인증서(data/ssl/school-ca.pem)가 있으면 함께 — 예전에는 서버_실행.bat 의 NODE_EXTRA_CA_CERTS 줄이 하던 일 */
    const 학교 = path.join(process.env.SB_DATA_DIR ? path.resolve(process.env.SB_DATA_DIR) : path.join(__dirname, 'data'), 'ssl', 'school-ca.pem');
    if (fs.existsSync(학교)) {
      const pem = fs.readFileSync(학교, 'utf8');
      new (require('crypto').X509Certificate)(pem);   // 인증서가 아니면 여기서 던져 건너뛴다
      목록.push(pem);
    }
    tls.setDefaultCACertificates(목록);
  } catch { /* 서버가 안 켜지는 일은 없어야 한다 */ }
})();

/**
 * 켜지 못하고 멈출 때 — 바로가기로 node.exe 를 직접 켜면 창이 곧바로 닫혀 까닭을 못 본다.
 * 그래서 창에서 켰으면 **Enter 를 누를 때까지 창을 붙잡는다**(예전 서버_실행.bat 의 pause 대신).
 */
function 멈추기(말) {
  console.error('\n  서버를 켜지 못했습니다 : ' + 말 + '\n');
  if (process.stdin.isTTY && !process.env.SB_TEST && process.platform === 'win32') {
    /* 동기로 붙잡는다 — 뒤의 코드가 이어서 돌며 다른 오류로 창을 닫아 버리지 않게 */
    try { require('child_process').spawnSync('cmd', ['/c', 'pause'], { stdio: 'inherit' }); } catch {}
  }
  process.exit(1);
}

/* ================================================================
 * 1. 설정값
 * ================================================================ */
const ROOT = __dirname;
const PORT = Number(process.env.PORT) || 9800;
/* 검사 때는 다른 폴더를 쓰게 한다(진짜 자료를 건드리지 않으려고) */
const DATA_DIR = process.env.SB_DATA_DIR ? path.resolve(process.env.SB_DATA_DIR) : path.join(ROOT, 'data');
const DB_FILE = path.join(DATA_DIR, 'budget.db');
const BACKUP_DIR = path.join(DATA_DIR, 'backup');
/* 업그레이드 꾸러미를 받는 곳(깃허브 페이지). 검사 때는 SB_UPDATE_URL 로 가짜 서버를 가리킨다 */
const UPDATE_BASE_URL = process.env.SB_UPDATE_URL || 'https://dadaschool.github.io/school-budget/update';
const PUBLIC_DIR = path.join(ROOT, 'public');
const 쿠키이름 = 'sb_sid';

fs.mkdirSync(DATA_DIR, { recursive: true });
/* ⚠ `let` 이다 — 자료를 백업에서 되돌릴 때 DB 를 닫고 새 파일로 다시 연다 */
let db;
try { db = DB.열기(DB_FILE); } catch (e) { 멈추기(String((e && e.message) || e)); }
let 지금포트 = 0;

/* ---- 설정은 DB 의 meta 표에 둔다 ---- */
function 설정값(키, 기본) {
  const r = db.prepare('SELECT value FROM meta WHERE key = ?').get(키);
  return r ? r.value : 기본;
}
function 설정쓰기(키, 값) {
  db.prepare('INSERT INTO meta(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value')
    .run(키, String(값));
}

/* ---- 관리자 비밀번호를 잊었을 때 : 표시만 남기고 끝낸다 ----
   비밀번호를 여기서 받지 않는다(검은 창 기록에 남지 않게). 다음에 켜면 서버 PC 의 브라우저에서 새로 정한다. */
if (process.argv.includes('--reset-admin')) {
  설정쓰기('admin_reset', '1');
  console.log('\n  관리자 비밀번호를 다시 정할 수 있게 했습니다.');
  console.log('  서버를 켠 뒤, 이 PC 의 브라우저에서 http://127.0.0.1:' + PORT + '/ 을 열어 새 비밀번호를 정하세요.\n');
  process.exit(0);
}

/* ================================================================
 * [망정책] 어디서 온 요청까지 받는가 — `club-attendance` 와 같은 설정
 * ================================================================
 * `사설망만`(기본) : 10.x · 192.168.x · 172.16~31.x 에서 온 것만.
 * `같은망도`       : 거기에 더해 «이 PC 랜카드와 같은 망» 도 받는다.
 *    그 대역을 쓰지 않는 학교망(예 170.170.x)에서만 켠다. 켜지 않으면 다른 PC 는 모두 403 이다.
 */
let 망정책 = 설정값('net_policy', '사설망만') === '같은망도' ? '같은망도' : '사설망만';
const 들여보낼까 = (ip) => (망정책 === '같은망도' ? Net.교내망인가(ip) : Net.사설망인가(ip));

/** 서버 PC 자신에서 온 요청인가 — 처음 설정은 여기서만 된다 */
const 이PC인가 = (ip) => ip === '127.0.0.1' || ip === '::1';

/* ================================================================
 * 2. 계정 · 권한
 * ================================================================ */
const 계정찾기 = (id) => db.prepare('SELECT id, name, role, active FROM account WHERE id = ?').get(id);
const 이름으로 = (이름) => db.prepare('SELECT * FROM account WHERE name = ?').get(이름);
const 관리자있나 = () => !!db.prepare("SELECT 1 FROM account WHERE role = 'admin' AND active = 1").get();
/** 처음 설정(또는 관리자 다시 정하기)이 열려 있는가 */
const 설정열림 = () => !관리자있나() || 설정값('admin_reset', '0') === '1';

function 기록(accountId, action, target, detail = {}) {
  db.prepare('INSERT INTO audit(at, account_id, action, target, detail) VALUES(?, ?, ?, ?, ?)')
    .run(new Date().toISOString(), accountId, action, target, JSON.stringify(detail));
}

/** 이 사람이 볼 수 있는 세부항목 id 목록 (관리자는 전부) */
function 볼수있는항목(나) {
  if (나.role === 'admin') return db.prepare('SELECT id FROM item').all().map((r) => r.id);
  return db.prepare('SELECT item_id FROM assignment WHERE account_id = ?').all(나.id).map((r) => r.item_id);
}
/** 서버 PC 의 오늘 (YYYY-MM-DD · 이 PC 의 시간대 기준) */
function 오늘() {
  const d = new Date();
  const 두 = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${두(d.getMonth() + 1)}-${두(d.getDate())}`;
}

/** 실제로 있는 날짜인가 — 2026-02-30 같은 것은 거절 */
function 날짜맞나(s) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
  if (!m) return false;
  const [y, mo, d] = m.slice(1).map(Number);
  const t = new Date(Date.UTC(y, mo - 1, d));
  return y >= 2000 && y <= 2100 && t.getUTCMonth() === mo - 1 && t.getUTCDate() === d;
}

/**
 * 화면이 보낸 금액 → 원 단위 정수 (못 읽으면 null)
 * 숫자(1000)도, 쉼표 섞인 글자("1,000" · "-2,500")도 받는다. 소수는 받지 않는다.
 */
function 금액받기(v) {
  if (typeof v === 'number') return Number.isSafeInteger(v) ? v : null;
  const t = String(v == null ? '' : v).replace(/[,\s]/g, '').replace(/원$/, '');
  if (!/^-?\d+$/.test(t)) return null;
  const n = Number(t);
  return Number.isSafeInteger(n) ? n : null;
}

/** 세부항목 하나의 비목 → 산출내역, 각각 예산·지출·잔액 */
function 항목상세(itemId) {
  return db.prepare('SELECT id, name FROM category WHERE item_id = ? ORDER BY id').all(itemId).map((c) => ({
    ...c,
    현황: DB.비목현황(db, c.id),
    산출내역: db.prepare('SELECT id, name, formula FROM line WHERE category_id = ? ORDER BY id').all(c.id)
      .map((l) => ({ ...l, 현황: DB.산출내역현황(db, l.id) })),
  }));
}

function 볼수있나(나, itemId) {
  if (나.role === 'admin') return true;
  return !!db.prepare('SELECT 1 FROM assignment WHERE account_id = ? AND item_id = ?').get(나.id, itemId);
}

/** 이 사람이 사업관리자인 세부항목 id 목록 */
function 관리하는항목(나) {
  return db.prepare('SELECT item_id FROM assignment WHERE account_id = ? AND manager = 1').all(나.id).map((r) => r.item_id);
}

/** 이 세부항목의 예산을 편성할 수 있는가 — 전체 관리자 또는 그 세부항목의 사업관리자 */
function 관리하나(나, itemId) {
  if (나.role === 'admin') return true;
  return !!db.prepare('SELECT 1 FROM assignment WHERE account_id = ? AND item_id = ? AND manager = 1').get(나.id, itemId);
}

/**
 * 이 지출을 고치거나 지울 수 있는가 (사용자 지시 2026-09-30)
 *   · 전체 관리자 → 모두
 *   · 그 세부항목의 사업관리자 → 누가 적었든 모두
 *   · 그 밖의 담당 교사 → 자기가 적은 것만
 */
function 고칠수있나(나, itemId, 적은사람, 관리목록 = null) {
  if (나.role === 'admin') return true;
  if (!볼수있나(나, itemId)) return false;
  if (적은사람 === 나.id) return true;
  return (관리목록 || 관리하는항목(나)).includes(itemId);
}

/* ================================================================
 * 3. 응답 도우미
 * ================================================================ */
const 종류 = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
};

function json(res, code, 몸, 머리 = {}) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...머리 });
  res.end(JSON.stringify(몸));
}
const 오류 = (res, code, 말) => json(res, code, { ok: false, error: 말 });

function 글(res, code, 내용) {
  res.writeHead(code, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end(내용);
}

/** 요청 몸(JSON) 읽기 — 한도(기본 64KB)를 넘으면 거절. 엑셀을 올리는 곳만 한도를 키운다 */
function 몸읽기(req, 한도 = 64 * 1024) {
  return new Promise((resolve, reject) => {
    let 크기 = 0;
    const 조각 = [];
    req.on('data', (c) => {
      크기 += c.length;
      if (크기 > 한도) { reject(new Error('보낸 내용이 너무 큽니다')); req.destroy(); return; }
      조각.push(c);
    });
    req.on('end', () => {
      try { resolve(조각.length ? JSON.parse(Buffer.concat(조각).toString('utf8')) : {}); } catch {
        reject(new Error('보낸 내용을 읽을 수 없습니다'));
      }
    });
    req.on('error', reject);
  });
}

function 세션쿠키(표) {
  return `${쿠키이름}=${표}; HttpOnly; SameSite=Strict; Path=/`;
}
const 쿠키지우기 = `${쿠키이름}=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0`;

/**
 * public/ 안의 파일만 내준다.
 * 🔴 주소를 **정리한 뒤** 검사한다 — `/../data/budget.db` 같은 주소로 DB 가 새어 나가지 않게.
 */
function 정적파일(req, res, 주소) {
  let 이름;
  try { 이름 = decodeURIComponent(주소); } catch { return 글(res, 400, '잘못된 주소'); }
  if (이름.endsWith('/')) 이름 += 'index.html';
  const 파일 = path.normalize(path.join(PUBLIC_DIR, 이름));
  if (!파일.startsWith(PUBLIC_DIR + path.sep)) return 글(res, 404, '없는 파일');
  fs.readFile(파일, (err, 내용) => {
    if (err) return 글(res, 404, '없는 파일');
    res.writeHead(200, {
      'Content-Type': 종류[path.extname(파일).toLowerCase()] || 'application/octet-stream',
      'Cache-Control': 'no-cache',
      'X-Content-Type-Options': 'nosniff',
    });
    res.end(내용);
  });
}

/* ================================================================
 * 4. API
 * ================================================================
 * 모든 쓰기 요청은 POST + JSON 이다. 로그인 쿠키가 SameSite=Strict 라
 * 다른 사이트에서 몰래 보내는 요청에는 쿠키가 붙지 않는다.
 */
async function api(req, res, 주소, ip) {
  const 표 = Auth.쿠키(req, 쿠키이름);
  const 나id = Auth.세션찾기(표);
  let 나 = 나id ? 계정찾기(나id) : null;
  if (나 && !나.active) { Auth.세션지우기(표); 나 = null; }
  const POST = req.method === 'POST';
  /* 엑셀 파일(base64)을 받는 곳만 10MB 까지 */
  const 몸 = POST ? await 몸읽기(req, (주소.startsWith('/api/admin/budget/') || 주소.startsWith('/api/admin/import/')) ? 10 * 1024 * 1024
    : (주소.startsWith('/api/admin/restore/') || 주소 === '/api/admin/update/file') ? 60 * 1024 * 1024 : 64 * 1024) : {};

  /* ---- 누구나 ---- */
  if (주소 === '/api/ping') return json(res, 200, { ok: true, app: 'school-budget', version: APP_VERSION, pid: process.pid });

  if (주소 === '/api/session') {
    return json(res, 200, {
      ok: true, version: APP_VERSION, 설정필요: 설정열림(), 이PC: 이PC인가(ip),
      나: 나 ? { id: 나.id, name: 나.name, role: 나.role, 사업관리자: 관리하는항목(나).length > 0,
        새판: 나.role === 'admin' ? 새판알림() : '' } : null,
      오늘: 오늘(),          // 날짜 칸의 기본값 — 선생님 PC 시계가 아니라 서버의 날짜
    });
  }

  /* 처음 설정 — 관리자 이름·비밀번호. 서버 PC 에서만 */
  if (주소 === '/api/setup' && POST) {
    if (!설정열림()) return 오류(res, 409, '이미 관리자가 있습니다.');
    if (!이PC인가(ip)) return 오류(res, 403, '처음 설정은 서버 PC 에서만 할 수 있습니다.');
    const 이름 = Auth.이름정리(몸.name);
    if (!이름) return 오류(res, 400, '이름을 적어 주세요(30자 이내).');
    const 문제 = Auth.비밀번호검사(몸.password);
    if (문제) return 오류(res, 400, 문제);
    const h = Auth.해시만들기(몸.password);
    const 예전 = db.prepare("SELECT id FROM account WHERE role = 'admin' ORDER BY id LIMIT 1").get();
    let id;
    if (예전) {
      /* 다시 정하기 — 같은 계정을 쓴다(그동안 적은 지출이 그 사람에게 그대로 붙어 있게) */
      const 겹침 = 이름으로(이름);
      if (겹침 && 겹침.id !== 예전.id) return 오류(res, 409, '그 이름은 이미 교사 계정이 쓰고 있습니다.');
      db.prepare('UPDATE account SET name = ?, salt = ?, hash = ?, active = 1 WHERE id = ?').run(이름, h.salt, h.hash, 예전.id);
      id = 예전.id;
      Auth.사람세션모두지우기(id);
    } else {
      if (이름으로(이름)) return 오류(res, 409, '그 이름은 이미 쓰고 있습니다.');
      id = Number(db.prepare("INSERT INTO account(name, role, salt, hash, created_at) VALUES(?, 'admin', ?, ?, ?)")
        .run(이름, h.salt, h.hash, new Date().toISOString()).lastInsertRowid);
    }
    설정쓰기('admin_reset', '0');
    기록(id, 예전 ? '관리자 다시 정함' : '관리자 만듦', '계정:' + id);
    return json(res, 200, { ok: true }, { 'Set-Cookie': 세션쿠키(Auth.세션만들기(id)) });
  }

  /* 관리자 비밀번호를 잊었을 때 — 서버 PC(127.0.0.1)에서 연 로그인 화면의 링크.
     예전 «관리자_다시정하기.bat» 과 같은 수준 : 서버 PC 앞에 앉은 사람만 할 수 있다.
     자료·계정은 그대로이고 «처음 설정» 화면이 다시 열릴 뿐이다(그 화면도 서버 PC 에서만). */
  if (주소 === '/api/reset-admin' && POST) {
    if (!이PC인가(ip)) return 오류(res, 403, '서버 PC 에서만 할 수 있습니다.');
    설정쓰기('admin_reset', '1');
    기록(null, '관리자 다시 정하기 열림', '설정', { 어디서: '서버 PC 로그인 화면' });
    return json(res, 200, { ok: true });
  }

  if (주소 === '/api/login' && POST) {
    const 이름 = Auth.이름정리(몸.name);
    if (!이름 || !몸.password) return 오류(res, 400, '이름과 비밀번호를 적어 주세요.');
    const 남은 = Auth.막힘남은초(이름);
    if (남은) return 오류(res, 429, `비밀번호를 여러 번 틀렸습니다. ${Math.ceil(남은 / 60)}분 뒤에 다시 해 주세요.`);
    const a = 이름으로(이름);
    /* 이름이 없을 때와 비밀번호가 틀릴 때 같은 말을 한다(누가 계정이 있는지 알려 주지 않으려고) */
    if (!a || !Auth.해시맞나(몸.password, a)) {
      Auth.실패적기(이름);
      return 오류(res, 401, '이름 또는 비밀번호가 맞지 않습니다.');
    }
    if (!a.active) return 오류(res, 403, '사용을 멈춘 계정입니다. 관리자에게 문의해 주세요.');
    Auth.실패지우기(이름);
    기록(a.id, '로그인', '계정:' + a.id, { ip });
    return json(res, 200, { ok: true, 나: { id: a.id, name: a.name, role: a.role } },
      { 'Set-Cookie': 세션쿠키(Auth.세션만들기(a.id)) });
  }

  if (주소 === '/api/logout' && POST) {
    if (표) Auth.세션지우기(표);
    return json(res, 200, { ok: true }, { 'Set-Cookie': 쿠키지우기 });
  }

  /* ---- 여기부터는 로그인해야 한다 ---- */
  if (!나) return 오류(res, 401, '로그인이 필요합니다.');

  if (주소 === '/api/me/password' && POST) {
    const a = 이름으로(나.name);
    if (!Auth.해시맞나(몸.old, a)) return 오류(res, 400, '지금 비밀번호가 맞지 않습니다.');
    const 문제 = Auth.비밀번호검사(몸.password);
    if (문제) return 오류(res, 400, 문제);
    const h = Auth.해시만들기(몸.password);
    db.prepare('UPDATE account SET salt = ?, hash = ? WHERE id = ?').run(h.salt, h.hash, 나.id);
    Auth.사람세션모두지우기(나.id, 표);          // 다른 PC 에 로그인해 둔 것은 풀린다
    기록(나.id, '비밀번호 바꿈', '계정:' + 나.id);
    return json(res, 200, { ok: true });
  }

  /* 내가 볼 수 있는 세부항목 */
  if (주소 === '/api/items' && !POST) {
    const ids = new Set(볼수있는항목(나));
    const 관리 = new Set(관리하는항목(나));
    const 목록 = db.prepare('SELECT id, year, name FROM item ORDER BY year DESC, name').all()
      .filter((r) => ids.has(r.id))
      .map((r) => ({ ...r, 사업관리자: 관리.has(r.id) }));
    return json(res, 200, { ok: true, 목록 });
  }

  /* 세부항목 하나 — 비목·산출내역과 예산·지출·잔액 */
  const m항목 = /^\/api\/items\/(\d+)$/.exec(주소);
  if (m항목 && !POST) {
    const itemId = Number(m항목[1]);
    const item = db.prepare('SELECT id, year, name FROM item WHERE id = ?').get(itemId);
    if (!item) return 오류(res, 404, '없는 세부항목입니다.');
    if (!볼수있나(나, itemId)) return 오류(res, 403, '담당으로 배정받지 않은 세부항목입니다.');
    return json(res, 200, { ok: true, 항목: item, 비목: 항목상세(itemId) });
  }

  /* ---- 지출 입력 · 목록 · 수정 · 삭제 ----
     🔴 입력자는 **로그인한 사람**으로 적는다. 화면이 다른 이름을 보내도 쓰지 않는다.
     🔴 금액은 원 단위 정수만. 음수는 반납·환불(사용자 지시), 0원은 안 된다.
     🔴 예산을 넘어도 저장한다(사용자 지시) — 대신 응답의 «초과» 로 화면이 빨갛게 알린다.
     🔴 수정·삭제는 **자기가 적은 것만**(관리자는 전부). 삭제는 지우지 않고 `deleted_at` 만 적는다. */

  /** 보낸 값 검사 → { 오류: [코드, 말] } 또는 { 줄, 날짜, 적요, 금액 } — 입력과 수정이 함께 쓴다 */
  const 지출검사 = (b) => {
    const lineId = Number(b.lineId);
    const 줄 = Number.isSafeInteger(lineId) ? db.prepare(`
      SELECT l.id, l.category_id, c.item_id FROM line l JOIN category c ON c.id = l.category_id WHERE l.id = ?`).get(lineId) : null;
    if (!줄) return { 오류: [400, '산출내역을 골라 주세요.'] };
    if (!볼수있나(나, 줄.item_id)) return { 오류: [403, '담당으로 배정받지 않은 세부항목입니다.'] };
    const 날짜 = String(b.date || '');
    if (!날짜맞나(날짜)) return { 오류: [400, '날짜를 바르게 골라 주세요.'] };
    const 적요 = String(b.memo || '').replace(/\s+/g, ' ').trim();
    if (!적요) return { 오류: [400, '지출 내용(적요)을 적어 주세요.'] };
    if (적요.length > 200) return { 오류: [400, '지출 내용은 200자 이내로 적어 주세요.'] };
    const 금액 = 금액받기(b.amount);
    if (금액 === null) return { 오류: [400, '사용금액은 원 단위 정수로 적어 주세요(소수·글자 안 됨).'] };
    if (금액 === 0) return { 오류: [400, '사용금액이 0원입니다.'] };
    if (Math.abs(금액) > 10_000_000_000) return { 오류: [400, '사용금액이 너무 큽니다.'] };
    return { 줄, 날짜, 적요, 금액 };
  };
  const 현황묶음 = (줄) => ({ 비목: DB.비목현황(db, 줄.category_id), 산출내역: DB.산출내역현황(db, 줄.id) });

  if (주소 === '/api/expenses' && POST) {
    const v = 지출검사(몸);
    if (v.오류) return 오류(res, ...v.오류);
    const 때 = new Date().toISOString();
    const id = Number(db.prepare(`INSERT INTO expense(line_id, date, memo, amount, account_id, writer_name, created_at, updated_at)
      VALUES(?, ?, ?, ?, ?, ?, ?, ?)`).run(v.줄.id, v.날짜, v.적요, v.금액, 나.id, 나.name, 때, 때).lastInsertRowid);
    기록(나.id, '지출 입력', '지출:' + id, { 산출내역: v.줄.id, 날짜: v.날짜, 금액: v.금액 });
    return json(res, 200, { ok: true, id, ...현황묶음(v.줄) });
  }

  /* 목록 — 내가 볼 수 있는 세부항목의 지운 것 뺀 지출. 거르기 : year · from · to · item · cat · line */
  if (주소 === '/api/expenses' && !POST) {
    const q = new URL(req.url, 'http://x').searchParams;
    const 조건 = ['e.deleted_at IS NULL'];
    const 값 = [];
    const 숫자 = (k) => { const n = Number(q.get(k)); return q.get(k) && Number.isSafeInteger(n) ? n : null; };
    if (숫자('year') !== null) { 조건.push('i.year = ?'); 값.push(숫자('year')); }
    if (숫자('item') !== null) { 조건.push('i.id = ?'); 값.push(숫자('item')); }
    if (숫자('cat') !== null) { 조건.push('c.id = ?'); 값.push(숫자('cat')); }
    if (숫자('line') !== null) { 조건.push('l.id = ?'); 값.push(숫자('line')); }
    if (날짜맞나(q.get('from') || '')) { 조건.push('e.date >= ?'); 값.push(q.get('from')); }
    if (날짜맞나(q.get('to') || '')) { 조건.push('e.date <= ?'); 값.push(q.get('to')); }
    const ids = new Set(볼수있는항목(나));
    const 내관리 = 관리하는항목(나);
    const 목록 = db.prepare(`
      SELECT e.id, e.date, e.memo, e.amount, e.writer_name, e.account_id, e.updated_at, e.created_at,
             l.id AS line_id, l.name AS line_name, c.id AS cat_id, c.name AS cat_name, i.id AS item_id, i.name AS item_name, i.year
        FROM expense e JOIN line l ON l.id = e.line_id JOIN category c ON c.id = l.category_id JOIN item i ON i.id = c.item_id
       WHERE ${조건.join(' AND ')}
       ORDER BY e.date DESC, e.id DESC`).all(...값)
      .filter((r) => ids.has(r.item_id))
      .map((r) => ({ ...r, 고침: r.updated_at !== r.created_at, 수정가능: 고칠수있나(나, r.item_id, r.account_id, 내관리) }));
    /* 🔴 합계도 정수 더하기 — 표에 보이는 줄과 똑같은 것을 더한다 */
    const 합계 = 목록.reduce((s, r) => s + r.amount, 0);
    return json(res, 200, { ok: true, 목록, 건수: 목록.length, 합계 });
  }

  /* 수정 · 삭제 */
  const m지출 = /^\/api\/expenses\/(\d+)(\/delete)?$/.exec(주소);
  if (m지출 && POST) {
    const 전 = db.prepare(`SELECT e.*, l.category_id, c.item_id FROM expense e JOIN line l ON l.id = e.line_id
      JOIN category c ON c.id = l.category_id WHERE e.id = ? AND e.deleted_at IS NULL`).get(Number(m지출[1]));
    if (!전) return 오류(res, 404, '없거나 이미 지운 지출입니다.');
    if (!볼수있나(나, 전.item_id)) return 오류(res, 403, '담당으로 배정받지 않은 세부항목입니다.');
    if (!고칠수있나(나, 전.item_id, 전.account_id)) {
      return 오류(res, 403, '자기가 입력한 지출만 고치거나 지울 수 있습니다. 사업관리자나 전체 관리자에게 부탁해 주세요.');
    }
    const 때 = new Date().toISOString();
    const 전모습 = { 산출내역: 전.line_id, 날짜: 전.date, 적요: 전.memo, 금액: 전.amount };
    const 전줄 = { id: 전.line_id, category_id: 전.category_id };

    if (m지출[2]) {
      db.prepare('UPDATE expense SET deleted_at = ? WHERE id = ?').run(때, 전.id);
      기록(나.id, '지출 삭제', '지출:' + 전.id, { 전: 전모습 });
      return json(res, 200, { ok: true, ...현황묶음(전줄) });
    }

    const v = 지출검사(몸);
    if (v.오류) return 오류(res, ...v.오류);
    db.prepare('UPDATE expense SET line_id = ?, date = ?, memo = ?, amount = ?, updated_at = ? WHERE id = ?')
      .run(v.줄.id, v.날짜, v.적요, v.금액, 때, 전.id);
    기록(나.id, '지출 수정', '지출:' + 전.id, { 전: 전모습, 후: { 산출내역: v.줄.id, 날짜: v.날짜, 적요: v.적요, 금액: v.금액 } });
    return json(res, 200, { ok: true, ...현황묶음(v.줄), 전: 현황묶음(전줄) });
  }

  /* ---- 성립전 예산요구 신청서 엑셀 내려받기 (사용자 지시 2026-09-30) ----
     ?item=세부항목 하나 · ?year=그 해의 내가 볼 수 있는 세부항목 전부(시트 여러 장)
     요구자 = 그 세부항목의 사업관리자 이름(사용자 지시) */
  if (주소 === '/api/budget/request-form' && !POST) {
    const q = new URL(req.url, 'http://x').searchParams;
    let 항목들;
    if (q.get('item')) {
      const it = db.prepare('SELECT id, year, name FROM item WHERE id = ?').get(Number(q.get('item')));
      if (!it) return 오류(res, 404, '없는 세부항목입니다.');
      if (!볼수있나(나, it.id)) return 오류(res, 403, '담당으로 배정받지 않은 세부항목입니다.');
      항목들 = [it];
    } else {
      const ids = new Set(볼수있는항목(나));
      항목들 = db.prepare('SELECT id, year, name FROM item WHERE year = ? ORDER BY id').all(Number(q.get('year'))).filter((r) => ids.has(r.id));
      if (!항목들.length) return 오류(res, 404, '내려받을 세부항목이 없습니다.');
    }
    const 시트 = 항목들.map((it) => 예산표.신청서만들기({
      연도: it.year,
      세부항목: it.name,
      요구자: db.prepare(`SELECT a.name FROM assignment s JOIN account a ON a.id = s.account_id
        WHERE s.item_id = ? AND s.manager = 1 AND a.active = 1 ORDER BY a.name`).all(it.id).map((r) => r.name).join('·'),
      오늘: 오늘(),
      비목들: db.prepare('SELECT id, name FROM category WHERE item_id = ? ORDER BY id').all(it.id).map((c) => ({
        name: c.name, 산출내역: db.prepare('SELECT name, formula, budget FROM line WHERE category_id = ? ORDER BY id').all(c.id),
      })),
    }));
    /* 시트 이름이 겹치면(31자에서 잘려 같아지면) 뒤에 번호를 붙인다 */
    const 본 = new Map();
    for (const s of 시트) { const n = (본.get(s.이름) || 0) + 1; 본.set(s.이름, n); if (n > 1) s.이름 = s.이름.slice(0, 28) + ` (${n})`; }
    const 파일 = Xlsx.만들기(시트);
    const 이름 = (항목들.length === 1 ? `${항목들[0].year}_${항목들[0].name}` : `${항목들[0].year}_전체`)
      .replace(/[\\/:*?"<>|]/g, ' ') + '_성립전예산요구신청서.xlsx';
    기록(나.id, '신청서 엑셀 내려받기', 항목들.length === 1 ? 'item:' + 항목들[0].id : 'year:' + 항목들[0].year, { 세부항목: 항목들.map((i) => i.id) });
    res.writeHead(200, {
      'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Disposition': `attachment; filename="request-form.xlsx"; filename*=UTF-8''${encodeURIComponent(이름)}`,
      'Cache-Control': 'no-store',
    });
    return res.end(파일);
  }

  /* 한 해의 예산 전체(내가 볼 수 있는 세부항목만) */
  if (주소 === '/api/budget' && !POST) {
    const 연도들 = db.prepare('SELECT DISTINCT year FROM item ORDER BY year DESC').all().map((r) => r.year);
    const 쿼리연도 = Number(new URL(req.url, 'http://x').searchParams.get('year'));
    const 연도 = 연도들.includes(쿼리연도) ? 쿼리연도 : (연도들[0] || null);
    const ids = new Set(볼수있는항목(나));
    const 항목 = 연도 === null ? [] : db.prepare('SELECT id, year, name FROM item WHERE year = ? ORDER BY id').all(연도)
      .filter((r) => ids.has(r.id))
      .map((r) => ({ ...r, 편성가능: 관리하나(나, r.id), 비목: 항목상세(r.id) }));
    return json(res, 200, { ok: true, 연도, 연도들, 항목 });
  }

  /* ---- 예산 직접 편성 (관리자 · 사업관리자) : 세부항목 · 비목 · 산출내역 을 더하고 · 고치고 · 지운다 ----
     🔴 세부항목 자체(만들기·이름 바꾸기·지우기)는 전체 관리자만. 비목·산출내역은 그 세부항목의 사업관리자도(사용자 지시 2026-09-30).
     🔴 이름 규칙은 엑셀 올리기와 같다 — 같은 자리에 같은 이름·빈칸만 다른 이름은 거절(비목이 둘로 갈라지지 않게).
     🔴 금액은 원 단위 정수(0 이상). 이미 쓴 것보다 적게 고쳐도 저장한다(잔액 음수 → «초과»).
     🔴 지우기는 «비어 있을 때만» — 지출 기록(지운 것 포함)이 걸린 산출내역, 아래에 무엇이 있는 비목·세부항목은 못 지운다. */
  const m편성 = /^\/api\/(?:admin\/)?budget\/(item|cat|line)(?:\/(\d+))?(\/delete)?$/.exec(주소);
  if (m편성 && POST) {
    const 종류 = m편성[1];
    const id = m편성[2] ? Number(m편성[2]) : null;
    const 지우기 = !!m편성[3];
    const 표 = { item: 'item', cat: 'category', line: 'line' }[종류];
    const 부모칸 = { item: null, cat: 'item_id', line: 'category_id' }[종류];
    const 이름말 = { item: '세부항목', cat: '원가통계비목', line: '산출내역' }[종류];
    const 때 = new Date().toISOString();

    /* 권한 — 관리자는 모두. 사업관리자는 맡은 세부항목의 비목·산출내역만 */
    if (나.role !== 'admin') {
      if (종류 === 'item') return 오류(res, 403, '세부항목을 만들거나 바꾸는 것은 전체 관리자만 할 수 있습니다.');
      let 항목id = null;
      if (종류 === 'cat') {
        항목id = id === null ? Number(몸.parentId) : (db.prepare('SELECT item_id FROM category WHERE id = ?').get(id) || {}).item_id;
      } else {
        const 비목id = id === null ? Number(몸.parentId) : (db.prepare('SELECT category_id FROM line WHERE id = ?').get(id) || {}).category_id;
        항목id = (db.prepare('SELECT item_id FROM category WHERE id = ?').get(비목id) || {}).item_id;
      }
      if (!항목id || !관리하나(나, 항목id)) return 오류(res, 403, '사업관리자로 맡은 세부항목만 편성할 수 있습니다.');
    }

    /* 이름 정리 · 형제 사이에서 같은 이름/빈칸만 다른 이름 거절 */
    const 이름검사 = (이름, 형제들, 자기id) => {
      const s = String(이름 || '').replace(/\s+/g, ' ').trim();
      if (!s) return { 오류: `${이름말} 이름을 적어 주세요.` };
      if (s.length > 100) return { 오류: '이름이 너무 깁니다(100자 이내).' };
      const 붙임 = (x) => x.replace(/\s+/g, '');
      const 겹침 = 형제들.find((x) => x.id !== 자기id && 붙임(x.name) === 붙임(s));
      if (겹침) return { 오류: 겹침.name === s ? `같은 이름의 ${이름말}이(가) 이미 있습니다.` : `«${겹침.name}» 과 빈칸만 다릅니다. 같은 것이면 그 이름을 쓰세요.` };
      return { 이름: s };
    };
    const 형제 = (부모id, 연도) => (종류 === 'item'
      ? db.prepare('SELECT id, name FROM item WHERE year = ?').all(연도)
      : db.prepare(`SELECT id, name FROM ${표} WHERE ${부모칸} = ?`).all(부모id));
    const 금액검사 = (v) => {
      const n = 금액받기(v);
      if (n === null) return { 오류: '예산 금액은 원 단위 정수로 적어 주세요(소수·글자 안 됨).' };
      if (n < 0) return { 오류: '예산 금액은 0원 이상이어야 합니다.' };
      if (n > 100_000_000_000) return { 오류: '예산 금액이 너무 큽니다.' };
      return { 금액: n };
    };

    /* ── 더하기 ── */
    if (id === null) {
      if (지우기) return 오류(res, 404, '없는 기능입니다.');
      let 부모id = null;
      let 연도 = null;
      if (종류 === 'item') {
        연도 = Number(몸.year);
        if (!Number.isSafeInteger(연도) || 연도 < 2000 || 연도 > 2100) return 오류(res, 400, '회계연도를 바르게 적어 주세요.');
      } else {
        부모id = Number(몸.parentId);
        const 부모표 = 종류 === 'cat' ? 'item' : 'category';
        if (!Number.isSafeInteger(부모id) || !db.prepare(`SELECT 1 FROM ${부모표} WHERE id = ?`).get(부모id)) {
          return 오류(res, 400, 종류 === 'cat' ? '세부항목을 찾지 못했습니다.' : '원가통계비목을 찾지 못했습니다.');
        }
      }
      const n = 이름검사(몸.name, 형제(부모id, 연도), null);
      if (n.오류) return 오류(res, 400, n.오류);
      let 새id;
      if (종류 === 'item') 새id = db.prepare('INSERT INTO item(year, name) VALUES(?, ?)').run(연도, n.이름).lastInsertRowid;
      else if (종류 === 'cat') 새id = db.prepare('INSERT INTO category(item_id, name) VALUES(?, ?)').run(부모id, n.이름).lastInsertRowid;
      else {
        const g = 금액검사(몸.budget);
        if (g.오류) return 오류(res, 400, g.오류);
        const 식 = String(몸.formula || '').replace(/\s+/g, ' ').trim().slice(0, 200);
        새id = db.prepare('INSERT INTO line(category_id, name, formula, budget, updated_at) VALUES(?, ?, ?, ?, ?)')
          .run(부모id, n.이름, 식, g.금액, 때).lastInsertRowid;
      }
      기록(나.id, `${이름말} 추가`, `${종류}:${새id}`, { 이름: n.이름, 금액: 몸.budget ?? null });
      return json(res, 200, { ok: true, id: Number(새id) });
    }

    const 전 = db.prepare(`SELECT * FROM ${표} WHERE id = ?`).get(id);
    if (!전) return 오류(res, 404, `없는 ${이름말}입니다.`);

    /* ── 지우기 : 비어 있을 때만 ── */
    if (지우기) {
      if (종류 === 'line') {
        const n = db.prepare('SELECT COUNT(*) AS n FROM expense WHERE line_id = ?').get(id).n;
        if (n) return 오류(res, 409, `지출 기록이 ${n}건 있어 지울 수 없습니다. 금액을 0원으로 고쳐 두세요.`);
      } else {
        const 아래 = 종류 === 'item' ? 'category WHERE item_id = ?' : 'line WHERE category_id = ?';
        const n = db.prepare(`SELECT COUNT(*) AS n FROM ${아래}`).get(id).n;
        if (n) return 오류(res, 409, `아래에 ${종류 === 'item' ? '원가통계비목' : '산출내역'}이 ${n}개 있어 지울 수 없습니다. 먼저 그것을 지워 주세요.`);
      }
      db.exec('BEGIN IMMEDIATE');
      try {
        if (종류 === 'item') db.prepare('DELETE FROM assignment WHERE item_id = ?').run(id);   // 담당 배정도 함께
        db.prepare(`DELETE FROM ${표} WHERE id = ?`).run(id);
        db.exec('COMMIT');
      } catch (e) { db.exec('ROLLBACK'); throw e; }
      기록(나.id, `${이름말} 삭제`, `${종류}:${id}`, { 전: 전 });
      return json(res, 200, { ok: true });
    }

    /* ── 고치기 ── */
    const n = 이름검사(몸.name, 형제(부모칸 ? 전[부모칸] : null, 전.year), id);
    if (n.오류) return 오류(res, 400, n.오류);
    if (종류 === 'line') {
      const g = 금액검사(몸.budget);
      if (g.오류) return 오류(res, 400, g.오류);
      const 식 = String(몸.formula || '').replace(/\s+/g, ' ').trim().slice(0, 200);
      db.prepare('UPDATE line SET name = ?, formula = ?, budget = ?, updated_at = ? WHERE id = ?').run(n.이름, 식, g.금액, 때, id);
      기록(나.id, '산출내역 수정', 'line:' + id, { 전: { 이름: 전.name, 산출식: 전.formula, 금액: 전.budget }, 후: { 이름: n.이름, 산출식: 식, 금액: g.금액 } });
      return json(res, 200, { ok: true, 산출내역: DB.산출내역현황(db, id), 비목: DB.비목현황(db, 전.category_id) });
    }
    db.prepare(`UPDATE ${표} SET name = ? WHERE id = ?`).run(n.이름, id);
    기록(나.id, `${이름말} 이름 바꿈`, `${종류}:${id}`, { 전: 전.name, 후: n.이름 });
    return json(res, 200, { ok: true });
  }

  /* ---- 예산 편성 목록 가져오기 (금액 제외) — 전체 관리자 · 사업관리자 ----
     사용자 지시(2026-09-30) : «사업관리자는 기존 사업들의 예산 편성 목록에서 금액을 제외하고 가져오게»
       · 새 회계연도 준비 : 한 세부항목의 비목·산출내역을 다른 해로 통째로 복사(금액 0원) + 담당 배정도 함께
       · 다른 사업에서 골라 오기 : 다른 세부항목의 산출내역을 골라 내 세부항목에 0원으로 더한다
     🔴 금액은 가져오지 않는다 — 산출식도 가져오지 않는다(금액을 계산한 식이라 금액과 함께 새로 적어야 맞다).
     🔴 이미 있는 비목·산출내역(이름 맞추기 규칙으로 같은 것)은 건드리지 않고 건너뛴다. */

  /* 고를 수 있는 원본 — 모든 해의 세부항목과 비목·산출내역 «이름만» (금액 없음) */
  if (주소 === '/api/budget/sources' && !POST) {
    if (나.role !== 'admin' && !관리하는항목(나).length) return 오류(res, 403, '전체 관리자나 사업관리자만 쓸 수 있습니다.');
    const 목록 = db.prepare('SELECT id, year, name FROM item ORDER BY year DESC, name').all().map((i) => ({
      ...i,
      비목: db.prepare('SELECT id, name FROM category WHERE item_id = ? ORDER BY id').all(i.id).map((c) => ({
        ...c, 산출내역: db.prepare('SELECT id, name FROM line WHERE category_id = ? ORDER BY id').all(c.id),
      })),
    }));
    return json(res, 200, { ok: true, 목록, 관리: 나.role === 'admin' ? null : 관리하는항목(나) });
  }

  if (주소 === '/api/budget/copy' && POST) {
    const 원본 = db.prepare('SELECT id, year, name FROM item WHERE id = ?').get(Number(몸.sourceItemId));
    if (!원본) return 오류(res, 400, '가져올 세부항목을 골라 주세요.');
    let 대상;
    let 새로만듦 = false;
    if (몸.targetYear !== undefined && 몸.targetYear !== null && 몸.targetYear !== '') {
      /* 새 회계연도 준비 : 원본을 맡은 사업관리자(또는 관리자)만 */
      const 연도 = Number(몸.targetYear);
      if (!Number.isSafeInteger(연도) || 연도 < 2000 || 연도 > 2100) return 오류(res, 400, '회계연도를 바르게 적어 주세요.');
      if (연도 === 원본.year) return 오류(res, 400, '같은 해로는 복사할 수 없습니다. 다른 회계연도를 적어 주세요.');
      if (!관리하나(나, 원본.id)) return 오류(res, 403, '사업관리자로 맡은 세부항목만 새 회계연도로 복사할 수 있습니다.');
      const 같은해 = db.prepare('SELECT id, name FROM item WHERE year = ?').all(연도);
      const 있 = 이름들.찾기(같은해, 원본.name);
      대상 = 있 ? 있.찾은 : null;
      if (!대상) {
        const id = Number(db.prepare('INSERT INTO item(year, name) VALUES(?, ?)').run(연도, 원본.name).lastInsertRowid);
        대상 = { id, name: 원본.name };
        새로만듦 = true;
      }
    } else {
      /* 다른 사업에서 골라 오기 : 받는 세부항목을 맡은 사업관리자(또는 관리자)만 */
      대상 = db.prepare('SELECT id, name, year FROM item WHERE id = ?').get(Number(몸.targetItemId));
      if (!대상) return 오류(res, 400, '받을 세부항목을 골라 주세요.');
      if (대상.id === 원본.id) return 오류(res, 400, '같은 세부항목에서 가져올 수 없습니다.');
      if (!관리하나(나, 대상.id)) return 오류(res, 403, '사업관리자로 맡은 세부항목에만 가져올 수 있습니다.');
    }

    /* 가져올 산출내역 — 고른 것만(없으면 전부). 고른 것은 반드시 원본의 것이어야 한다 */
    const 원본줄 = db.prepare(`SELECT l.id, l.name, c.name AS cat FROM line l JOIN category c ON c.id = l.category_id
      WHERE c.item_id = ? ORDER BY c.id, l.id`).all(원본.id);
    let 고른 = 원본줄;
    if (Array.isArray(몸.lineIds)) {
      const 번호 = new Set(몸.lineIds.map(Number));
      고른 = 원본줄.filter((l) => 번호.has(l.id));
      if (고른.length !== 번호.size) return 오류(res, 400, '고른 산출내역 가운데 그 세부항목의 것이 아닌 것이 있습니다.');
      if (!고른.length) return 오류(res, 400, '가져올 산출내역을 하나 이상 골라 주세요.');
    }

    const 결과 = { 비목추가: 0, 산출추가: 0, 건너뜀: 0, 새세부항목: 새로만듦, 대상id: 대상.id, 담당복사: 0 };
    const 때 = new Date().toISOString();
    db.exec('BEGIN IMMEDIATE');
    try {
      /* 통째로 가져올 때는 산출내역이 없는 빈 비목도 함께 */
      if (!Array.isArray(몸.lineIds)) {
        for (const c of db.prepare('SELECT name FROM category WHERE item_id = ? ORDER BY id').all(원본.id)) {
          if (!이름들.찾기(db.prepare('SELECT id, name FROM category WHERE item_id = ?').all(대상.id), c.name)) {
            db.prepare('INSERT INTO category(item_id, name) VALUES(?, ?)').run(대상.id, c.name);
            결과.비목추가++;
          }
        }
      }
      for (const l of 고른) {
        const 비목들 = db.prepare('SELECT id, name FROM category WHERE item_id = ?').all(대상.id);
        let c = 이름들.찾기(비목들, l.cat);
        let catId;
        if (c) catId = c.찾은.id;
        else {
          catId = Number(db.prepare('INSERT INTO category(item_id, name) VALUES(?, ?)').run(대상.id, l.cat).lastInsertRowid);
          결과.비목추가++;
        }
        const 산출들 = db.prepare('SELECT id, name FROM line WHERE category_id = ?').all(catId);
        if (이름들.찾기(산출들, l.name)) { 결과.건너뜀++; continue; }
        db.prepare('INSERT INTO line(category_id, name, formula, budget, updated_at) VALUES(?, ?, \'\', 0, ?)').run(catId, l.name, 때);
        결과.산출추가++;
      }
      /* 새 해의 세부항목을 새로 만들었으면 원본의 담당 배정(사업관리자 포함)도 옮긴다 — 그래야 곧바로 금액을 적을 수 있다 */
      if (새로만듦) {
        const 배정 = db.prepare('SELECT account_id, manager FROM assignment WHERE item_id = ?').all(원본.id);
        const 넣기 = db.prepare('INSERT OR IGNORE INTO assignment(account_id, item_id, manager) VALUES(?, ?, ?)');
        for (const b of 배정) { 넣기.run(b.account_id, 대상.id, b.manager); 결과.담당복사++; }
      }
      db.exec('COMMIT');
    } catch (e) { db.exec('ROLLBACK'); throw e; }
    기록(나.id, '예산 목록 가져오기', 'item:' + 대상.id, { 원본: 원본.id, ...결과 });
    return json(res, 200, { ok: true, 결과, 연도: db.prepare('SELECT year FROM item WHERE id = ?').get(대상.id).year });
  }

  /* ---- 여기부터는 관리자만 ---- */
  if (!주소.startsWith('/api/admin/')) return 오류(res, 404, '없는 기능입니다.');
  if (나.role !== 'admin') return 오류(res, 403, '관리자만 할 수 있습니다.');

  if (주소 === '/api/admin/accounts' && !POST) {
    const 배정 = db.prepare('SELECT account_id, item_id, manager FROM assignment').all();
    const 목록 = db.prepare('SELECT id, name, role, active, created_at FROM account ORDER BY role, name').all()
      .map((a) => ({
        ...a,
        항목: 배정.filter((b) => b.account_id === a.id).map((b) => b.item_id),
        관리항목: 배정.filter((b) => b.account_id === a.id && b.manager).map((b) => b.item_id),
      }));
    const 항목 = db.prepare('SELECT id, year, name FROM item ORDER BY year DESC, name').all();
    return json(res, 200, { ok: true, 목록, 항목 });
  }

  if (주소 === '/api/admin/accounts' && POST) {
    const 이름 = Auth.이름정리(몸.name);
    if (!이름) return 오류(res, 400, '이름을 적어 주세요(30자 이내).');
    if (이름으로(이름)) return 오류(res, 409, '같은 이름의 계정이 이미 있습니다.');
    const 문제 = Auth.비밀번호검사(몸.password);
    if (문제) return 오류(res, 400, 문제);
    const h = Auth.해시만들기(몸.password);
    const id = Number(db.prepare("INSERT INTO account(name, role, salt, hash, created_at) VALUES(?, 'teacher', ?, ?, ?)")
      .run(이름, h.salt, h.hash, new Date().toISOString()).lastInsertRowid);
    기록(나.id, '교사 계정 만듦', '계정:' + id, { 이름 });
    return json(res, 200, { ok: true, id });
  }

  const m계정 = /^\/api\/admin\/accounts\/(\d+)\/(password|active|items)$/.exec(주소);
  if (m계정 && POST) {
    const 대상 = 계정찾기(Number(m계정[1]));
    if (!대상) return 오류(res, 404, '없는 계정입니다.');
    const 할일 = m계정[2];

    if (할일 === 'password') {
      const 문제 = Auth.비밀번호검사(몸.password);
      if (문제) return 오류(res, 400, 문제);
      const h = Auth.해시만들기(몸.password);
      db.prepare('UPDATE account SET salt = ?, hash = ? WHERE id = ?').run(h.salt, h.hash, 대상.id);
      Auth.사람세션모두지우기(대상.id, 대상.id === 나.id ? 표 : null);
      기록(나.id, '비밀번호 다시 정함', '계정:' + 대상.id);
      return json(res, 200, { ok: true });
    }

    if (할일 === 'active') {
      if (대상.role === 'admin') return 오류(res, 400, '관리자 계정은 멈출 수 없습니다.');
      const 켬 = 몸.active ? 1 : 0;
      db.prepare('UPDATE account SET active = ? WHERE id = ?').run(켬, 대상.id);
      if (!켬) Auth.사람세션모두지우기(대상.id);
      기록(나.id, 켬 ? '계정 다시 씀' : '계정 멈춤', '계정:' + 대상.id);
      return json(res, 200, { ok: true });
    }

    if (할일 === 'items') {
      if (대상.role === 'admin') return 오류(res, 400, '관리자는 모든 세부항목을 봅니다. 배정할 필요가 없습니다.');
      const ids = Array.isArray(몸.itemIds) ? 몸.itemIds.map(Number) : null;
      if (!ids || ids.some((n) => !Number.isSafeInteger(n))) return 오류(res, 400, '세부항목 목록이 잘못되었습니다.');
      const 있는 = new Set(db.prepare('SELECT id FROM item').all().map((r) => r.id));
      if (ids.some((n) => !있는.has(n))) return 오류(res, 400, '없는 세부항목이 섞여 있습니다.');
      /* 사업관리자는 «담당하는 세부항목» 안에서만 지정할 수 있다 */
      const 관리 = Array.isArray(몸.managerIds) ? 몸.managerIds.map(Number) : [];
      if (관리.some((n) => !ids.includes(n))) return 오류(res, 400, '담당하지 않는 세부항목의 사업관리자로 정할 수 없습니다.');
      /* 지우고 다시 넣기를 한 번에 — 중간에 멈춰도 반쯤 바뀐 채로 남지 않게 */
      db.exec('BEGIN IMMEDIATE');
      try {
        db.prepare('DELETE FROM assignment WHERE account_id = ?').run(대상.id);
        const 넣기 = db.prepare('INSERT INTO assignment(account_id, item_id, manager) VALUES(?, ?, ?)');
        for (const n of new Set(ids)) 넣기.run(대상.id, n, 관리.includes(n) ? 1 : 0);
        db.exec('COMMIT');
      } catch (e) { db.exec('ROLLBACK'); throw e; }
      기록(나.id, '담당 배정', '계정:' + 대상.id, { 항목: [...new Set(ids)], 사업관리자: [...new Set(관리)] });
      return json(res, 200, { ok: true });
    }
  }

  /* ---- 예산 올리기 : 미리보기 → 확정 ----
     🔴 확정할 때도 파일을 **다시 읽고 다시 견준다.** 화면이 보낸 미리보기 결과를 믿지 않는다
     (그 사이 다른 사람이 예산을 고쳤을 수도 있다). */
  if ((주소 === '/api/admin/budget/preview' || 주소 === '/api/admin/budget/apply') && POST) {
    const 이름 = String(몸.fileName || '');
    if (!/\.xlsx$/i.test(이름)) {
      return 오류(res, 400, /\.xls$/i.test(이름)
        ? '예전 형식(.xls)은 읽지 못합니다. 엑셀에서 «다른 이름으로 저장 → Excel 통합 문서(.xlsx)» 로 저장해 올려 주세요.'
        : '엑셀 파일(.xlsx)을 올려 주세요.');
    }
    let 읽은것;
    try {
      const 표 = readXlsx(Buffer.from(String(몸.dataBase64 || ''), 'base64'));
      읽은것 = 예산표.읽기(표);
    } catch (e) {
      return 오류(res, 400, '엑셀 파일을 읽지 못했습니다 : ' + String(e.message || e));
    }
    const 견준것 = 예산표.견주기(db, 읽은것);
    if (주소.endsWith('/preview')) return json(res, 200, { ok: true, 파일: 이름, ...견준것 });

    if (견준것.오류.length) return json(res, 400, { ok: false, error: '오류가 있어 저장하지 않았습니다.', ...견준것 });
    const 결과 = 예산표.저장(db, 견준것, { 없는것지우기: !!몸.없는것지우기 });
    기록(나.id, '예산 올리기', '연도:' + 견준것.연도, {
      파일: 이름, 합계: 견준것.요약.합계, 줄수: 견준것.요약.줄수, ...결과,
      바뀐것: 견준것.줄목록.filter((z) => z.상태 !== '그대로' && z.상태 !== '새 항목')
        .map((z) => ({ 산출내역: z.산출내역, 전: z.지금, 후: z.금액 })),
    });
    return json(res, 200, { ok: true, 연도: 견준것.연도, 결과 });
  }

  /* ---- 기존 자료 · 지출 엑셀 올리기 (관리자) : 미리보기 → 확정 ----
     🔴 확정할 때도 파일을 다시 읽고 다시 견준다(화면이 보낸 미리보기를 믿지 않는다). */
  if ((주소 === '/api/admin/import/preview' || 주소 === '/api/admin/import/apply') && POST) {
    const 이름 = String(몸.fileName || '');
    if (!/\.xlsx$/i.test(이름)) {
      return 오류(res, 400, /\.xls$/i.test(이름)
        ? '예전 형식(.xls)은 읽지 못합니다. 엑셀에서 «다른 이름으로 저장 → Excel 통합 문서(.xlsx)» 로 저장해 올려 주세요.'
        : '엑셀 파일(.xlsx)을 올려 주세요. 구글 시트는 «파일 → 다운로드 → Microsoft Excel» 로 받으면 됩니다.');
    }
    let 시트;
    try { 시트 = Xlsx.시트들(Buffer.from(String(몸.dataBase64 || ''), 'base64')); } catch (e) {
      return 오류(res, 400, '엑셀 파일을 읽지 못했습니다 : ' + String(e.message || e));
    }
    const 견준것 = 옮기기.견주기(db, 시트, { 연도: 몸.year, 같은것건너뛰기: 몸.skipDup !== false, 올린사람: 나.name });
    if (주소.endsWith('/preview')) return json(res, 200, { ok: true, 파일: 이름, ...견준것 });
    if (견준것.오류.length) return json(res, 400, { ok: false, error: '오류가 있어 저장하지 않았습니다.', ...견준것 });
    const 결과 = 옮기기.저장(db, 견준것, { 없는것지우기: !!몸.없는것지우기 });
    기록(나.id, '엑셀 올리기(예산·지출)', '연도:' + 견준것.연도, {
      파일: 이름, 예산: 결과.예산, 지출추가: 결과.지출추가, 지출건너뜀: 결과.지출건너뜀, 지출합계: 견준것.지출.요약.추가합계,
    });
    return json(res, 200, { ok: true, 연도: 견준것.연도, 결과, 요약: 견준것.지출.요약 });
  }

  /* 올리기 양식 내려받기 */
  if (주소 === '/api/admin/import/template' && !POST) {
    const 파일 = Xlsx.만들기(옮기기.양식());
    res.writeHead(200, {
      'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Disposition': `attachment; filename="budget-template.xlsx"; filename*=UTF-8''${encodeURIComponent('예산·지출_올리기_양식.xlsx')}`,
      'Cache-Control': 'no-store',
    });
    return res.end(파일);
  }

  if (주소 === '/api/admin/settings') {
    if (POST) {
      const 새것 = 몸.net_policy === '같은망도' ? '같은망도' : '사설망만';
      설정쓰기('net_policy', 새것);
      망정책 = 새것;
      기록(나.id, '교내망 판정 바꿈', '설정', { net_policy: 새것 });
    }
    return json(res, 200, {
      ok: true, net_policy: 망정책,
      내주소: 내주소들(),
    });
  }

  /* ================================================================
   * 💾 자료 백업 · 되돌리기 / ⬆ 업그레이드 / ↩️ 업그레이드 이전으로  (관리자)
   * ----------------------------------------------------------------
   * `ai-coordinator` 와 같은 세 메뉴. 🔴 프로그램을 바꾸거나 자료를 되돌리는 일은
   * **이 PC 또는 사설망에서만** 한다(«같은 망도 허용» 으로 바꿔 둔 학교라도).
   * ================================================================ */
  const 안에서만 = () => {
    if (이PC인가(ip) || Net.사설망인가(ip)) return true;
    오류(res, 403, '학교 안(서버 PC 또는 교내 사설망)에서만 할 수 있습니다.');
    return false;
  };

  /* ---- 윈도우 연결 : 자동 시작 · 방화벽 (예전 .bat 두 개 대신) ---- */
  if (주소 === '/api/admin/windows' && !POST) {
    return json(res, 200, {
      ok: true, 윈도우: process.platform === 'win32', 이PC: 이PC인가(ip),
      자동시작: 윈도우.자동시작상태(), 방화벽: await 윈도우.방화벽상태(),
    });
  }
  if (주소 === '/api/admin/autostart' && POST) {
    if (!안에서만()) return undefined;
    try {
      if (몸.on) await 윈도우.자동시작켜기(ROOT); else 윈도우.자동시작끄기();
    } catch (e) { return 오류(res, 500, e.message); }
    기록(나.id, 몸.on ? '자동 시작 켬' : '자동 시작 끔', '설정');
    return json(res, 200, { ok: true, 자동시작: 윈도우.자동시작상태() });
  }
  /* 방화벽 허용 — 관리자 확인 창이 **서버 PC 화면에** 뜨므로 서버 PC 에서 누를 때만 */
  if (주소 === '/api/admin/firewall' && POST) {
    if (!이PC인가(ip)) return 오류(res, 403, '방화벽은 서버 PC 에서만 허용할 수 있습니다(관리자 확인 창이 그 PC 화면에 뜹니다).');
    let r;
    try { r = await 윈도우.방화벽허용(); } catch (e) { return 오류(res, 500, e.message); }
    if (r.ok) 기록(나.id, '방화벽 허용', '설정');
    return json(res, 200, { ok: r.ok, 거절: r.거절, error: r.ok ? undefined : (r.거절 ? '관리자 확인 창에서 [아니요] 를 눌러 등록하지 않았습니다.' : '방화벽 규칙을 등록하지 못했습니다. 학교에서 방화벽을 정책으로 관리하는 경우일 수 있습니다 — 정보 담당자에게 «포트 9800 인바운드 허용» 을 요청해 주세요.') });
  }

  if (주소 === '/api/admin/system' && !POST) {
    let 판갈이 = [];
    try { 판갈이 = Update.listBackups(BACKUP_DIR); } catch {}
    return json(res, 200, {
      ok: true, version: APP_VERSION, dbVersion: DB.지금판(db), 개수: 자료백업.세어보기(db),
      자료백업: 자료백업.백업목록(BACKUP_DIR), 판갈이,
      updateUrl: UPDATE_BASE_URL, node: process.version,
      주소: 지금포트 ? `http://127.0.0.1:${지금포트}/` : '',
    });
  }

  /* 지금 자료를 ZIP 으로 내려받기 */
  if (주소 === '/api/admin/backup' && !POST) {
    const zip = 자료백업.꾸러미만들기(db, { 앱판: APP_VERSION });
    설정쓰기('last_backup', new Date().toISOString());
    기록(나.id, '자료 백업 내려받음', '자료', { bytes: zip.length });
    const 이름 = `학교예산_백업_${자료백업.도장().slice(0, 8)}-${자료백업.도장().slice(8, 12)}.zip`;
    res.writeHead(200, {
      'Content-Type': 'application/zip',
      'Content-Disposition': `attachment; filename="school-budget-backup.zip"; filename*=UTF-8''${encodeURIComponent(이름)}`,
      'Cache-Control': 'no-store',
    });
    return res.end(zip);
  }

  /* 서버에 쌓인 백업(자동·되돌리기전·업그레이드전) 하나를 내려받기 */
  if (주소 === '/api/admin/backup/file' && !POST) {
    const 이름 = new URL(req.url, 'http://x').searchParams.get('name') || '';
    if (!자료백업.백업이름인가(이름)) return 오류(res, 400, '백업 파일 이름이 잘못되었습니다.');
    const 파일 = path.join(BACKUP_DIR, 이름);
    if (!fs.existsSync(파일)) return 오류(res, 404, '그 백업 파일이 없습니다.');
    const 내용 = fs.readFileSync(파일);
    res.writeHead(200, {
      'Content-Type': 'application/zip',
      'Content-Disposition': `attachment; filename="school-budget-backup.zip"; filename*=UTF-8''${encodeURIComponent('학교예산_' + 이름)}`,
      'Cache-Control': 'no-store',
    });
    return res.end(내용);
  }

  /* 되돌리기 : 미리보기 → 확정. 파일을 올리거나(dataBase64) 서버에 쌓인 백업 이름(name)을 준다 */
  if ((주소 === '/api/admin/restore/preview' || 주소 === '/api/admin/restore/apply') && POST) {
    if (!안에서만()) return undefined;
    let buf;
    if (몸.name) {
      if (!자료백업.백업이름인가(String(몸.name))) return 오류(res, 400, '백업 파일 이름이 잘못되었습니다.');
      const 파일 = path.join(BACKUP_DIR, String(몸.name));
      if (!fs.existsSync(파일)) return 오류(res, 404, '그 백업 파일이 없습니다.');
      buf = fs.readFileSync(파일);
    } else {
      buf = Buffer.from(String(몸.dataBase64 || '').split(',').pop(), 'base64');
    }
    let 읽음;
    try { 읽음 = 자료백업.꾸러미읽기(buf); } catch (e) { return 오류(res, 400, e.message); }
    if (주소.endsWith('/preview')) {
      자료백업.치우기(읽음.임시파일);
      return json(res, 200, { ok: true, 백업: 읽음.개수, 정보: 읽음.정보, 지금: 자료백업.세어보기(db) });
    }
    /* 🔴 되돌리기 직전의 지금 자료를 먼저 남긴다 — 잘못 되돌린 것도 다시 되돌릴 수 있게 */
    const 도 = 자료백업.도장();
    const 안전 = path.join(BACKUP_DIR, `되돌리기전-${도}.zip`);
    try {
      fs.mkdirSync(BACKUP_DIR, { recursive: true });
      fs.writeFileSync(안전, 자료백업.꾸러미만들기(db, { 앱판: APP_VERSION }));
    } catch (e) {
      자료백업.치우기(읽음.임시파일);
      return 오류(res, 500, '지금 자료를 먼저 백업하지 못해 되돌리기를 멈췄습니다 : ' + e.message);
    }
    try {
      db.close();
      자료백업.제자리에놓기(읽음.임시파일, DB_FILE);
      db = DB.열기(DB_FILE);            // 옛 구조 판이면 여기서 새 판으로 올라간다
    } catch (e) {
      /* 새 DB 가 열리지 않으면 방금 만든 안전 백업으로 되돌린다 */
      try {
        const 되 = 자료백업.꾸러미읽기(fs.readFileSync(안전));
        자료백업.제자리에놓기(되.임시파일, DB_FILE);
        자료백업.치우기(되.임시파일);
      } catch {}
      db = DB.열기(DB_FILE);
      자료백업.치우기(읽음.임시파일);
      return 오류(res, 500, '되돌리는 중 문제가 생겨 원래 자료로 두었습니다 : ' + e.message);
    }
    자료백업.치우기(읽음.임시파일);
    망정책 = 설정값('net_policy', '사설망만') === '같은망도' ? '같은망도' : '사설망만';
    Auth.모든세션지우기();              // 계정 목록이 통째로 바뀌었을 수 있다 — 모두 다시 로그인
    기록(나.id, '자료 되돌림', '자료', { 한사람: 나.name, 백업: 몸.name || '(올린 파일)', 안전백업: path.basename(안전), 개수: 읽음.개수 });
    console.log(`\n  ● 자료를 백업에서 되돌렸습니다. (되돌리기 직전 자료 : ${path.basename(안전)})`);
    return json(res, 200, { ok: true, 개수: 자료백업.세어보기(db), 안전백업: path.basename(안전) }, { 'Set-Cookie': 쿠키지우기 });
  }

  /* ---- ⬆ 업그레이드 ---- */
  if (주소 === '/api/admin/update/check' && !POST) {
    let info;
    try {
      info = await Update.fetchLatest(UPDATE_BASE_URL);
    } catch (e) {
      let diag = null;
      try { diag = await Update.diagnose(UPDATE_BASE_URL); } catch {}
      return json(res, 200, { ok: true, current: APP_VERSION, error: e.message, offline: true, diag });
    }
    return json(res, 200, {
      ok: true, current: APP_VERSION, latest: info.version, date: info.date || '',
      notes: Array.isArray(info.notes) ? info.notes.slice(0, 30) : [],
      size: Number(info.size) || 0,
      newer: Update.compareVersion(info.version, APP_VERSION) > 0,
    });
  }

  /** 받은(또는 올린) 꾸러미를 설치한다 — 자료 백업 → 프로그램 백업 → 덮어쓰기 → 실패하면 되돌리기 */
  const 설치하기 = async (files, 새판) => {
    const 도 = 자료백업.도장();
    let 자료zip = '';
    try {
      fs.mkdirSync(BACKUP_DIR, { recursive: true });
      자료zip = path.join(BACKUP_DIR, `판갈이전자료-${도}.zip`);
      fs.writeFileSync(자료zip, 자료백업.꾸러미만들기(db, { 앱판: APP_VERSION }));
    } catch (e) {
      return 오류(res, 500, '자료를 먼저 백업하지 못해 업그레이드를 멈췄습니다.\n' + (e.message || ''));
    }
    let 프로그램 = '';
    try { 프로그램 = await Update.backupCurrent(ROOT, BACKUP_DIR, 도); } catch (e) {
      return 오류(res, 500, '지금 프로그램을 백업하지 못해 업그레이드를 멈췄습니다.\n' + (e.message || ''));
    }
    try {
      await Update.writeFiles(ROOT, files);
    } catch (e) {
      try { await Update.rollback(ROOT, 프로그램); } catch {}
      return 오류(res, 500, '옮기는 중에 문제가 생겨 예전 판으로 되돌렸습니다.\n' + (e.message || ''));
    }
    기록(나.id, '업그레이드', '프로그램', { 전: APP_VERSION, 후: 새판, 파일수: files.size });
    console.log(`\n  ● 업그레이드 : ${APP_VERSION} -> ${새판} (파일 ${files.size}개) · 되돌리려면 ${path.basename(프로그램)}`);
    return json(res, 200, {
      ok: true, from: APP_VERSION, to: 새판, count: files.size,
      dataBackup: path.basename(자료zip), progBackup: path.basename(프로그램),
    });
  };

  if (주소 === '/api/admin/update/apply' && POST) {
    if (!안에서만()) return undefined;
    let info;
    try { info = await Update.fetchLatest(UPDATE_BASE_URL); } catch (e) { return 오류(res, 400, e.message); }
    if (Update.compareVersion(info.version, APP_VERSION) <= 0) return 오류(res, 400, `이미 최신 판입니다 (지금 ${APP_VERSION}).`);
    let files;
    try {
      files = Update.readPackage(await Update.download(UPDATE_BASE_URL, info));   // 여기서 다 검사한다
    } catch (e) { return 오류(res, 400, e.message); }
    return 설치하기(files, info.version);
  }

  /* 📁 파일로 업그레이드 — 서버 PC 가 github.io 에 닿지 못해도 브라우저로 받아 올리면 된다 */
  if (주소 === '/api/admin/update/file' && POST) {
    if (!안에서만()) return undefined;
    const buf = Buffer.from(String(몸.dataBase64 || '').split(',').pop(), 'base64');
    if (buf.length < 1000) return 오류(res, 400, '파일을 읽지 못했습니다. 내려받은 업데이트 꾸러미(.zip)를 골라 주세요.');
    let files;
    try { files = Update.readPackage(buf); } catch (e) { return 오류(res, 400, e.message); }
    const 새판 = (files.get('server.js').toString('utf8').match(/const APP_VERSION = '([0-9.]+)'/) || [, ''])[1];
    if (!새판) return 오류(res, 400, '꾸러미에서 판 번호를 읽지 못했습니다. 올바른 파일이 아닙니다.');
    const 비교 = Update.compareVersion(새판, APP_VERSION);
    if (비교 <= 0 && !몸.force) {
      return json(res, 400, {
        ok: false,
        error: 비교 === 0 ? `같은 판입니다 (${새판}). 올릴 것이 없습니다.`
          : `고른 파일이 더 예전 판입니다 (${새판} < 지금 ${APP_VERSION}).\n되돌리시려면 그래도 올릴 수 있습니다.`,
        canForce: 비교 !== 0, from: APP_VERSION, to: 새판,
      });
    }
    return 설치하기(files, 새판);
  }

  if (주소 === '/api/admin/update/backups' && !POST) {
    try { return json(res, 200, { ok: true, current: APP_VERSION, backups: Update.listBackups(BACKUP_DIR) }); } catch (e) {
      return 오류(res, 500, '백업 목록을 읽지 못했습니다.\n' + (e.message || ''));
    }
  }

  /* ↩️ 업그레이드 이전으로 — 🔴 프로그램만. 예산·지출 자료(data/)는 그대로 */
  if (주소 === '/api/admin/update/revert' && POST) {
    if (!안에서만()) return undefined;
    const 이름 = String(몸.name || '');
    if (!Update.isBackupName(이름)) return 오류(res, 400, '되돌릴 백업을 골라 주세요.');
    const 폴더 = path.join(BACKUP_DIR, 이름);
    if (!폴더.startsWith(BACKUP_DIR + path.sep)) return 오류(res, 400, '잘못된 백업 이름입니다.');
    let files;
    try { files = Update.readBackup(폴더); } catch (e) { return 오류(res, 400, e.message); }
    const 판 = (files.get('server.js').toString('utf8').match(/const APP_VERSION = '([0-9.]+)'/) || [, ''])[1];
    let 지금백업 = '';
    try { 지금백업 = await Update.backupCurrent(ROOT, BACKUP_DIR, 자료백업.도장()); } catch (e) {
      return 오류(res, 500, '지금 판을 백업하지 못해 되돌리기를 멈췄습니다.\n' + (e.message || ''));
    }
    try { await Update.writeFiles(ROOT, files); } catch (e) {
      try { await Update.rollback(ROOT, 지금백업); } catch {}
      return 오류(res, 500, '되돌리는 중에 문제가 생겨 원래대로 두었습니다.\n' + (e.message || ''));
    }
    기록(나.id, '업그레이드 이전으로 되돌림', '프로그램', { 전: APP_VERSION, 후: 판, 백업: 이름 });
    return json(res, 200, { ok: true, from: APP_VERSION, to: 판, count: files.size, used: 이름, progBackup: path.basename(지금백업) });
  }

  /* 🔄 다시 시작 — 새 판(또는 되돌린 판)으로 갈아탄다 */
  if (주소 === '/api/admin/update/restart' && POST) {
    if (!안에서만()) return undefined;
    json(res, 200, { ok: true, port: 지금포트 });
    다시시작();
    return undefined;
  }

  return 오류(res, 404, '없는 기능입니다.');
}

/* ================================================================
 * 5. 요청 처리
 * ================================================================ */
const server = http.createServer(async (req, res) => {
  const ip = Net.접속IP(req);
  if (!이PC인가(ip) && !들여보낼까(ip)) {
    return 글(res, 403, `학교 안에서만 쓸 수 있습니다. (이 기기 주소 : ${ip})\n`
      + '학교망 주소가 사설망이 아니라면, 관리자가 [계정 관리] → 교내망 판정 에서 «같은 망도 허용» 으로 바꿔 주세요.');
  }
  const 주소 = new URL(req.url, 'http://x').pathname;
  if (주소.startsWith('/api/')) {
    /* 🔴 다른 사이트가 몰래 보내는 요청 막기 — 서버 PC 의 브라우저로 나쁜 사이트를 열어도
       «관리자 다시 정하기» 같은 요청을 대신 보내지 못하게. JSON 이 아니면 브라우저가 다른 사이트에서
       보낼 수 있는 모양이라 거절하고(보내려면 사전 확인이 필요해진다), Origin 이 다른 주인이면 거절한다. */
    if (req.method === 'POST') {
      const 종류 = String(req.headers['content-type'] || '');
      if (!/^application\/json\b/i.test(종류)) return 오류(res, 415, 'JSON 요청만 받습니다.');
      const 출처 = req.headers.origin;
      if (출처 && 출처 !== 'null') {
        let 호스트 = '';
        try { 호스트 = new URL(출처).host; } catch {}
        if (호스트 !== req.headers.host) return 오류(res, 403, '다른 사이트에서 보낸 요청은 받지 않습니다.');
      } else if (출처 === 'null') return 오류(res, 403, '다른 사이트에서 보낸 요청은 받지 않습니다.');
    }
    try {
      return await api(req, res, 주소, ip);
    } catch (e) {
      console.error('   ! 처리 중 오류 : ' + String((e && e.message) || e));
      if (!res.headersSent) return 오류(res, 500, '서버에서 처리하지 못했습니다 : ' + String((e && e.message) || e));
      return undefined;
    }
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') return 글(res, 405, '허용되지 않는 요청');
  return 정적파일(req, res, 주소);
});

/* ================================================================
 * 6. 켜기
 * ================================================================ */

/**
 * 포트가 차 있으면 다음 번호로.
 * ⚠ `listen(포트, 콜백)` 에 콜백을 넘기지 않는다 — 실패한 시도의 콜백이 남아 있다가
 *   함께 불려 **엉뚱한 포트 번호가 찍히는** 버그가 세 앱에서 났다(`club-attendance` 참고).
 */
function 포트찾아열기(포트, 남은 = 10) {
  return new Promise((resolve, reject) => {
    const 해보기 = (p, 남음) => {
      const 치우기 = () => {
        server.removeListener('listening', 됨);
        server.removeListener('error', 안됨);
      };
      const 됨 = () => { 치우기(); resolve(server.address().port); };
      const 안됨 = (err) => {
        치우기();
        if (err.code === 'EADDRINUSE' && 남음 > 0) {
          console.log(`   포트 ${p} 은(는) 이미 쓰이고 있어 ${p + 1} 로 넘어갑니다.`);
          해보기(p + 1, 남음 - 1);
        } else reject(err);
      };
      server.once('listening', 됨);
      server.once('error', 안됨);
      server.listen(p, '0.0.0.0');
    };
    해보기(포트, 남은);
  });
}

function 내주소들() {
  return Net.내망들().map((w) => ({ ip: w.주소, 이름: w.이름, 사설: Net.사설망인가(w.주소) }));
}

/* ================================================================
 * 다시 시작 — 업그레이드·되돌리기 뒤에 새 판으로 갈아탄다
 * ----------------------------------------------------------------
 * 답을 보낸 뒤 **같은 포트**로 새 프로세스를 띄우고(detached) 이 프로세스는 끝낸다.
 * 🔴 새 프로세스는 `SB_RESTART=1` 을 보고 **포트가 빌 때까지 기다린다**(최대 12초).
 *    그러지 않으면 예전 서버가 아직 쥐고 있는 9800 을 피해 9801 로 켜져
 *    선생님들이 알고 있는 주소가 통째로 안 열린다(코디네이터에서 같은 함정을 겪었다).
 * ================================================================ */
function 다시시작() {
  setTimeout(() => {
    try {
      const { spawn } = require('child_process');
      const 자식 = spawn(process.execPath, [path.join(ROOT, 'server.js')], {
        cwd: ROOT, detached: true, stdio: 'ignore', windowsHide: !!process.env.SB_TEST,   // 검사 때만 창을 숨긴다
        env: { ...process.env, PORT: String(지금포트 || PORT), SB_RESTART: '1', SB_NO_OPEN: '1' },
      });
      자식.unref();
    } catch (e) {
      console.log('   ! 다시 켜지 못했습니다 : ' + e.message);
    }
    setTimeout(() => {
      try { db.close(); } catch {}
      process.exit(3);          // 3 = «다시 시작함» (옛 창은 닫히고 새 창에서 서버가 돈다)
    }, 400);
  }, 500);
}

/** 그 포트가 빌 때까지 기다린다(다시 시작할 때만) */
async function 포트빌때까지(포트, 최대ms = 12000) {
  const net = require('net');
  const 끝 = Date.now() + 최대ms;
  while (Date.now() < 끝) {
    const 쓰는중 = await new Promise((r) => {
      const s = net.connect({ host: '127.0.0.1', port: 포트 });
      s.once('connect', () => { s.destroy(); r(true); });
      s.once('error', () => r(false));
    });
    if (!쓰는중) return;
    await new Promise((r) => setTimeout(r, 300));
  }
}

/* ================================================================
 * 하루 한 번 새 판 확인 → 관리자 화면 위에 «⬆ 새 판» 을 띄운다
 * 🔴 로그인·화면이 인터넷을 기다리지 않는다 — 확인은 뒤에서 하고 결과만 meta 에 적어 둔다.
 * 🔴 실패는 조용히 넘긴다(학교망은 막히는 일이 잦다 — 매일 못 고치는 경고를 보이지 않는다).
 * ================================================================ */
async function 업데이트확인() {
  try {
    const info = await Update.fetchLatest(UPDATE_BASE_URL);
    설정쓰기('update_check', JSON.stringify({ at: new Date().toISOString(), latest: info.version }));
  } catch (e) {
    설정쓰기('update_check', JSON.stringify({ at: new Date().toISOString(), error: String(e.message || e).split(/\r?\n/)[0] }));
  }
}
function 새판알림() {
  try {
    const c = JSON.parse(설정값('update_check', '{}'));
    if (c.latest && Update.compareVersion(c.latest, APP_VERSION) > 0) return c.latest;
  } catch {}
  return '';
}

/** 매일 자동 백업 — 켤 때 한 번, 그 뒤 한 시간마다 «오늘 것이 있나» 만 본다 */
function 자동백업하기() {
  try {
    const r = 자료백업.자동백업(db, BACKUP_DIR, { 앱판: APP_VERSION });
    if (r.만듦) console.log(`   · 오늘 자동 백업을 만들었습니다 (data/backup/${r.파일})`);
  } catch (e) {
    console.log('   ! 자동 백업을 만들지 못했습니다 : ' + String((e && e.message) || e));
  }
}

/** 그 포트에 이 프로그램이 이미 켜져 있나 (바탕화면 아이콘을 두 번 눌렀을 때) */
function 이미켜졌나(포트) {
  return new Promise((ok) => {
    const req = http.get({ host: '127.0.0.1', port: 포트, path: '/api/ping', timeout: 1500 }, (res) => {
      let 받은 = '';
      res.on('data', (c) => { 받은 += c; });
      res.on('end', () => { try { ok(JSON.parse(받은).app === 'school-budget'); } catch { ok(false); } });
    });
    req.on('error', () => ok(false));
    req.on('timeout', () => { req.destroy(); ok(false); });
  });
}

/** 창을 띄울까 — 창에서 직접 켰을 때만(실행기·검사·자동 시작은 열지 않는다) */
const 창띄울까 = () => process.stdout.isTTY && !process.env.SB_NO_OPEN && !process.argv.includes('--no-browser');

async function 시작() {
  /* 🔴 이미 켜져 있으면 두 번째 서버를 띄우지 않는다 — 같은 DB 를 두 프로그램이 쥐면 헷갈린다.
     바탕화면 아이콘을 다시 누른 것이므로 **창만 열어 주고** 끝낸다. */
  if (process.env.SB_RESTART !== '1' && await 이미켜졌나(PORT)) {
    console.log('\n  학교 예산 관리는 이미 켜져 있습니다. 화면만 엽니다.  http://127.0.0.1:' + PORT + '/\n');
    if (창띄울까()) 윈도우.창열기('http://127.0.0.1:' + PORT + '/');
    setTimeout(() => process.exit(0), 1500);
    return;
  }
  if (process.env.SB_RESTART === '1') await 포트빌때까지(PORT);
  const 포트 = await 포트찾아열기(PORT);
  지금포트 = 포트;
  자동백업하기();          // 안내를 찍기 전에 — 켜지자마자 오늘 백업이 있게
  const 주소들 = 내주소들();
  console.log('');
  console.log('  ┌────────────────────────────────────────────┐');
  console.log('  │        학교 예산 관리  ' + ('판 ' + APP_VERSION).padEnd(20) + '│');
  console.log('  └────────────────────────────────────────────┘');
  console.log('');
  console.log('   이 PC 에서     :  http://127.0.0.1:' + 포트 + '/');
  for (const a of 주소들) {
    console.log('   선생님들께     :  http://' + a.ip + ':' + 포트 + '/      (' + a.이름 + ')'
      + (a.사설 ? '' : '   <- 사설망 주소가 아님'));
  }
  if (주소들.length && !주소들.some((a) => a.사설) && 망정책 === '사설망만') {
    console.log('');
    console.log('   ! 알림 : 이 망의 주소가 사설망(10.x · 192.168.x · 172.16~31.x)이 아닙니다.');
    console.log('            지금 설정으로는 다른 PC 에서 들어오면 모두 막힙니다.');
    console.log('            [계정 관리] -> 교내망 판정 에서 «같은 망도 허용» 으로 바꾸세요.');
  }
  console.log('');
  if (설정열림()) {
    console.log('   ● 관리자 비밀번호를 정해야 합니다. 이 PC 의 브라우저에서 위 «이 PC 에서» 주소를 여세요.');
    console.log('');
  }
  console.log('   · 이 검은 창을 닫으면 서버도 함께 꺼집니다. 서버 PC 에서는 켜 두세요.');
  console.log('   · 방화벽 창이 뜨면 [허용] 을 눌러 주세요(다른 선생님 PC 에서 들어오려면 필요합니다).');
  console.log('');
  setInterval(자동백업하기, 60 * 60 * 1000).unref();   // unref : 이것 때문에 프로그램이 안 꺼지면 다시 시작이 막힌다
  if (!process.env.SB_NO_UPDATE_CHECK) {
    setTimeout(업데이트확인, Number(process.env.SB_UPDATE_CHECK_MS) || 5000).unref();
    setInterval(업데이트확인, 24 * 60 * 60 * 1000).unref();
  }

  /* 창에서 직접 켰을 때만 화면을 연다 — OS 내장 웹뷰(주소창 없는 창) · 없으면 기본 브라우저 */
  if (창띄울까()) 윈도우.창열기('http://127.0.0.1:' + 포트 + '/');
  if (!process.env.SB_TEST) 윈도우.앱목록판맞추기(ROOT, APP_VERSION);
}

if (db) 시작().catch((e) => 멈추기(String((e && e.message) || e)));
