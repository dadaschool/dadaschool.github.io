﻿# =====================================================================
#  학교 예산 관리 — 프로그램 제거  (예전 «프로그램_제거.bat» 대신)
# ---------------------------------------------------------------------
#  윈도우 [설정 → 앱 → 설치된 앱] 의 «학교 예산 관리 → 제거» 와
#  시작 메뉴의 [프로그램 제거] 가 이 파일을 부른다(설치할 때 등록한다).
#
#  지웁니다 : 프로그램 파일 · 바로가기 · 자동 시작 · 방화벽 규칙 · [설정 → 앱] 등록
#  남깁니다 : data 폴더 (예산·지출 자료와 백업) — 자료를 실수로 잃지 않게
#
#  -Quiet : 묻지 않고 지운다(검사용)
#  ⚠ 이 파일은 UTF-8 BOM 으로 저장한다(PowerShell 5.1 은 BOM 이 없으면 한글이 깨진다).
# =====================================================================
param([switch]$Quiet)
$ErrorActionPreference = 'Continue'

$dir = Split-Path -Parent $PSScriptRoot          # lib 의 위 = 설치 폴더
$rule = '학교예산관리'
$uninstKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\SchoolBudget'

if (-not (Test-Path -LiteralPath (Join-Path $dir 'server.js'))) {
  if (-not $Quiet) {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show("프로그램이 이미 지워져 있습니다.`n`n$dir", '프로그램 제거') | Out-Null
  }
  Remove-Item -LiteralPath $uninstKey -Recurse -Force -ErrorAction SilentlyContinue
  exit 0
}

if (-not $Quiet) {
  Add-Type -AssemblyName System.Windows.Forms
  $r = [System.Windows.Forms.MessageBox]::Show(
    "학교 예산 관리를 지울까요?`n`n지웁니다 : 프로그램 파일 · 바로가기 · 자동 시작 · 방화벽 규칙`n남깁니다 : data 폴더 (예산·지출 자료와 백업)`n`n위치 : $dir",
    '프로그램 제거', 'YesNo', 'Question')
  if ($r -ne 'Yes') { exit 0 }
}

# 1) 이 폴더의 node.exe 로 켜진 서버만 끈다 (다른 Node 프로그램은 건드리지 않는다)
$myNode = Join-Path $dir 'node.exe'
Get-Process -Name node -ErrorAction SilentlyContinue |
  Where-Object { $_.Path -and ($_.Path -ieq $myNode) } |
  Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Milliseconds 800

# 2) 바로가기 · 자동 시작
Remove-Item -LiteralPath (Join-Path ([Environment]::GetFolderPath('Desktop')) '학교 예산 관리.lnk') -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath (Join-Path ([Environment]::GetFolderPath('Programs')) '학교예산관리') -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath (Join-Path ([Environment]::GetFolderPath('Startup')) '학교예산관리 서버.lnk') -Force -ErrorAction SilentlyContinue

# 3) 방화벽 규칙 — 있을 때만, 관리자 확인 창을 한 번 띄운다
$fwNote = ''
& netsh advfirewall firewall show rule name="$rule" *> $null
if ($LASTEXITCODE -eq 0) {
  try {
    Start-Process netsh.exe -Verb RunAs -Wait -WindowStyle Hidden -ArgumentList "advfirewall firewall delete rule name=`"$rule`""
  } catch { $fwNote = "`n※ 방화벽 규칙 «$rule» 은 남았습니다(관리자 확인을 거절함)." }
}

# 4) 프로그램 파일 (data 는 남긴다)
foreach ($f in @('server.js', 'package.json', 'node.exe', '사용설명서.txt', '설치정보.txt',
                 '서버_실행.bat', '방화벽_허용.bat', '자동시작_설정.bat', '프로그램_제거.bat', '관리자_다시정하기.bat')) {
  Remove-Item -LiteralPath (Join-Path $dir $f) -Force -ErrorAction SilentlyContinue
}
foreach ($d in @('public', 'lib')) {
  Remove-Item -LiteralPath (Join-Path $dir $d) -Recurse -Force -ErrorAction SilentlyContinue
}

# 5) [설정 → 앱] 에서 빼기
Remove-Item -LiteralPath $uninstKey -Recurse -Force -ErrorAction SilentlyContinue

$data = Join-Path $dir 'data'
if ($Quiet) { Write-Host '제거 완료'; exit 0 }
if (Test-Path -LiteralPath $data) {
  [System.Windows.Forms.MessageBox]::Show(
    "프로그램을 지웠습니다.$fwNote`n`n자료는 아래 폴더에 그대로 있습니다.`n$data`n`n보관하실 분은 이 폴더를 USB 등으로 복사해 두세요.`n완전히 없애려면 폴더째 삭제하시면 됩니다.",
    '프로그램 제거') | Out-Null
  Start-Process explorer.exe $dir
} else {
  [System.Windows.Forms.MessageBox]::Show("프로그램을 지웠습니다.$fwNote", '프로그램 제거') | Out-Null
  Remove-Item -LiteralPath $dir -Force -ErrorAction SilentlyContinue   # 비어 있으면 폴더도
}
