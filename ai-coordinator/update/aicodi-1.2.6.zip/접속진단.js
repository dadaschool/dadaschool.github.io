/**
 * 접속 진단 도구 — 어느 포트로 들어올 수 있는지 한 번에 확인합니다.
 * ----------------------------------------------------------------
 * "무선에서 접속이 안 된다" 는 문제의 원인이 세 갈래인데 증상이 똑같습니다.
 *   ① 망 사이가 아예 막혀 있다        → 어느 포트로도 안 들어온다
 *   ② 특정 포트만 막혀 있다            → 80 은 되고 4000 은 안 된다
 *   ③ 주소를 잘못 넣었다                → 아무 요청도 도착하지 않는다(①과 구분이 안 된다)
 *
 * 그래서 이 도구는 **여러 포트를 동시에 열어 두고**, 무엇이 도착하는지 화면에 적습니다.
 * 휴대폰에서 주소를 하나씩 열어 보시면 되는 쪽이 어디인지 바로 드러납니다.
 *
 * 실행 : node 접속진단.js      (프로그램 폴더에서)
 * 끝내기 : 창을 닫거나 Ctrl+C
 */
'use strict';

const http = require('node:http');
const os = require('node:os');

const PORTS = [80, 4000, 8080, 443, 3000];

/** 이 PC 의 교내망 주소들 (169.254.x.x = 연결 안 된 임시 주소는 뺀다) */
function localAddresses() {
  const out = [];
  for (const list of Object.values(os.networkInterfaces())) {
    for (const n of list || []) {
      if (n.family === 'IPv4' && !n.internal && !n.address.startsWith('169.254.')) out.push(n.address);
    }
  }
  return out;
}

function stamp() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

/** `::ffff:10.1.2.3` → `10.1.2.3` */
function plainIp(raw) {
  let ip = String(raw || '').trim();
  if (ip.startsWith('::ffff:')) ip = ip.slice(7);
  if (ip === '::1') ip = '127.0.0.1';
  return ip;
}

const addrs = localAddresses();
const my24 = (addrs[0] || '').split('.').slice(0, 3).join('.');
const arrived = new Map(); // "포트 ip" → 횟수
const opened = [];

console.log('');
console.log('  ================================================');
console.log('    접속 진단 — 어느 포트로 들어올 수 있는지 확인');
console.log('  ================================================');
console.log('');

let pending = PORTS.length;
for (const port of PORTS) {
  const srv = http.createServer((req, res) => {
    const ip = plainIp(req.socket.remoteAddress);
    const key = `${port} ${ip}`;
    const first = !arrived.has(key);
    arrived.set(key, (arrived.get(key) || 0) + 1);

    const same = my24 && ip.split('.').slice(0, 3).join('.') === my24;
    const where = ip === '127.0.0.1' ? '이 PC 자신' : same ? '같은 망' : '★ 다른 망(무선일 수 있음)';
    if (first || ip !== '127.0.0.1') {
      console.log(`  [${stamp()}] 도착 : 포트 ${port} ← ${ip}  (${where})`);
    }

    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(`<!doctype html><meta charset="utf-8">
      <meta name="viewport" content="width=device-width,initial-scale=1">
      <title>접속 성공 - 포트 ${port}</title>
      <body style="font-family:system-ui,'Malgun Gothic',sans-serif;padding:24px;line-height:1.7">
      <h1 style="color:#15803d;font-size:28px">✅ 접속 성공</h1>
      <p style="font-size:20px"><b>포트 ${port}</b> 로 들어왔습니다.</p>
      <p style="font-size:18px;color:#374151">이 기기의 주소 : <b>${ip}</b></p>
      <hr>
      <p style="font-size:17px;color:#6b7280">교무실 PC 의 검은 창에도 이 접속이 기록되었습니다.<br>
      이 포트로 프로그램을 켜면 됩니다.</p>
      </body>`);
  });

  srv.once('error', (e) => {
    console.log(`  포트 ${port} : 열지 못했습니다 (${e.code === 'EADDRINUSE' ? '이미 다른 프로그램이 쓰는 중' : e.code})`);
    if (--pending === 0) showGuide();
  });
  srv.once('listening', () => {
    opened.push(port);
    if (--pending === 0) showGuide();
  });
  srv.listen(port);
}

function showGuide() {
  if (!opened.length) {
    console.log('');
    console.log('  [문제] 열 수 있는 포트가 없습니다. 프로그램(서버)이 이미 켜져 있으면 먼저 끄고 다시 실행해 주세요.');
    return;
  }
  console.log(`  열어 둔 포트 : ${opened.join(', ')}`);
  console.log('');
  console.log('  ● 휴대폰(무선)에서 아래 주소를 위에서부터 하나씩 열어 보세요');
  console.log('');
  for (const a of addrs) {
    for (const port of opened) {
      console.log(`      http://${a}${port === 80 ? '' : ':' + port}/`);
    }
  }
  console.log('');
  console.log('  ● 읽는 방법');
  console.log('      · 어떤 포트든 "도착" 줄이 뜨면  → 망 사이는 열려 있습니다.');
  console.log('        그 포트로 프로그램을 켜면 됩니다.');
  console.log('      · 한 줄도 안 뜨면              → 무선망과 이 PC 사이가 막혀 있습니다.');
  console.log('        학교 정보 담당자에게 열어 달라고 요청해야 합니다.');
  console.log('');
  console.log('      ※ 휴대폰이 "모바일 데이터" 로 붙어 있으면 당연히 안 됩니다.');
  console.log('        와이파이에 연결되어 있는지 꼭 확인해 주세요.');
  console.log('');
  console.log('  기다리는 중입니다... (끝내려면 이 창을 닫으세요)');
  console.log('');
}

process.on('SIGINT', () => {
  console.log('');
  console.log(`  진단을 마칩니다. 도착한 접속 ${arrived.size}건`);
  process.exit(0);
});
