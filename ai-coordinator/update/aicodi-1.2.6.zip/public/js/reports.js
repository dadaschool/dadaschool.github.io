/* ================================================================
   ⑤ 문서 출력 — 활동일지 · 출근기록부 · 결과보고서 및 정산서
   서식모음(경상남도교육청 창의인재과)의 표 모양을 그대로 맞췄습니다.
   ================================================================ */
'use strict';

let DOC = 'daily';

start();

async function start() {
  // 근무기록·인건비가 담긴 문서이므로 정보부장·코디네이터만 볼 수 있습니다
  const me = await requireLogin(['manager', 'coordinator'], '문서 출력 — 본인 확인');

  document.getElementById('topbar').innerHTML = renderTopbar(
    '/reports.html',
    `<span class="badge">${escapeHtml(me.name)}</span>
     <button class="small ghost no-print" id="logoutBtn" style="margin-left:8px">나가기</button>`,
  );
  document.getElementById('logoutBtn').addEventListener('click', logout);
  fillSchoolName();

  document.getElementById('month').value = thisMonth();
  document.getElementById('year').value = new Date().getFullYear();

  document.querySelectorAll('.tabs button').forEach((b) =>
    b.addEventListener('click', () => {
      document.querySelectorAll('.tabs button').forEach((x) => x.classList.toggle('on', x === b));
      DOC = b.dataset.doc;
      document.getElementById('monthWrap').hidden = DOC === 'result';
      document.getElementById('yearWrap').hidden = DOC !== 'result';
      make();
    }),
  );
  document.getElementById('make').addEventListener('click', make);
  document.getElementById('print').addEventListener('click', () => window.print());

  make();
}

async function make() {
  clearSay('#msg');
  document.getElementById('tools').innerHTML = '';
  try {
    if (DOC === 'result') {
      const year = document.getElementById('year').value;
      const d = await api(`/api/annual?year=${encodeURIComponent(year)}`);
      document.getElementById('docArea').innerHTML = renderResult(d);
      addCopyButtons([['운영 결과 표 복사', 'tbl-op'], ['예산 집행 표 복사', 'tbl-budget']]);
      if (!d.dayCount) say('#msg', 'warn', `${year}년 활동 기록이 없습니다. 표는 빈 서식으로 나옵니다.`);
    } else {
      const month = document.getElementById('month').value;
      const d = await api(`/api/monthly?month=${encodeURIComponent(month)}`);
      document.getElementById('docArea').innerHTML = DOC === 'daily' ? renderDaily(d) : renderAttend(d);
      addCopyButtons([[DOC === 'daily' ? '활동일지 표 복사' : '출근기록부 표 복사', 'tbl-main']]);
      const unchecked = d.logs.length - d.checkedCount;
      if (!d.logs.length) say('#msg', 'warn', '이 달에는 활동 기록이 없습니다.');
      else if (unchecked > 0) say('#msg', 'warn', `아직 점검(서명)되지 않은 기록이 ${unchecked}건 있습니다. 담당 확인란이 비어 인쇄됩니다.`);
    }
  } catch (e) {
    say('#msg', 'bad', e.message);
  }
}

function addCopyButtons(pairs) {
  const box = document.getElementById('tools');
  box.innerHTML = pairs
    .map(([label, id]) => `<button class="ghost small" data-copy="${id}">📋 ${label}</button>`)
    .join('');
  box.querySelectorAll('[data-copy]').forEach((b) =>
    b.addEventListener('click', () => {
      const t = document.getElementById(b.dataset.copy);
      if (t) copyTable(t, b);
    }),
  );
}

/**
 * 🔴 출근기록부의 「활동시간」 칸 = **유휴(휴게)를 뺀 근무시간** (2026-08-24 사용자 지시)
 *   *"활동시간이 유휴시간이 포함되어 있어. 유휴시간은 빼고 계산되어야 해"*
 *
 * ⚠ 2026-08-22 에는 **체류시간**으로 정했다가 이틀 만에 뒤집은 것이다.
 *   「활동시간」 이라는 칸 이름에 쉬는 시간이 들어가는 것이 맞지 않고,
 *   이렇게 두면 **활동시간과 인건비 숫자가 같아져** 서식 안에서 어긋나지 않는다
 *   (예전에는 활동시간 4.5 · 인건비 4시간 이라 근거를 따로 적어야 했다).
 * ⚠ 대신 «출근 11:30 · 퇴근 16:00 인데 활동시간 4» 가 되므로 표 아래에
 *   **체류 − 유휴 = 활동** 을 반드시 적어 준다. 그 줄이 없으면 셈이 틀린 것처럼 보인다.
 *
 * 예전 기록(2026-08-21 이전)에는 `hours` 가 체류시간이었지만 유휴가 없던 시절이라
 * 체류 = 근무다. 그래서 그냥 `hours` 를 쓰면 된다.
 */
function workOf(l) {
  /* 반드시 한 번 더 반올림한다. 서버는 늘 0.1 단위로 넘겨주지만, 손으로 고친 json 이나
     예전 자료가 섞이면 `0.8333333333333334` 가 **인쇄물에 그대로 찍힌다**(실제로 봤다). */
  return Math.round((Number(l.hours) || 0) * 10) / 10;
}

/** 체류시간(출근~퇴근) — 표 아래 설명에만 쓴다 */
function stayOf(l) {
  const v = l.stayHours === undefined || l.stayHours === null ? l.hours : l.stayHours;
  return Math.round((Number(v) || 0) * 10) / 10;
}

/**
 * 활동일지의 「시간」 칸 — **유휴시간을 뺀 실제 지도 구간**을 적는다.
 * 출근~퇴근 그대로 쓰면 `09:00~16:00`(7시간) 인데 아래 합계는 «총 지도시간 6시간» 이라
 * 한 표 안에서 숫자가 어긋난다. 유휴가 없는 날은 예전과 똑같이 한 줄로 나온다.
 */
function timeCell(l) {
  const t = dayTime(l.clockIn, l.clockOut, l.breakStart, l.breakEnd);
  /* 유휴가 조금이라도 있으면 **근무 구간**을 적는다.
     ⚠ `spans.length < 2` 로 판정하지 말 것 — 유휴를 출근 직후나 퇴근 직전에 붙이면
     구간이 **한 줄**이 되는데(2026-08-24 부터 그렇게 넣을 수 있다), 그때 출퇴근 시각을
     그대로 찍으면 `09:00~13:30`(4.5시간)인데 아래 합계는 4시간이라 한 표에서 어긋난다. */
  if (!t.brkMin || t.error || !t.spans.length) return `${escapeHtml(l.clockIn)}~<br>${escapeHtml(l.clockOut)}`;
  return t.spans.map(([a, b]) => `${escapeHtml(a)}~${escapeHtml(b)}`).join('<br>');
}

function signImg(file, maxH = 34) {
  return file ? `<img src="/files/signs/${encodeURIComponent(file)}" style="max-height:${maxH}px">` : '';
}

/* ================================================================
   ① 활동 일지 (월별)  — 서식모음 p.29
   ================================================================ */
function renderDaily(d) {
  const m = Number(d.month.slice(5, 7));
  const rows = d.logs
    .map((l, i) => {
      const classes = [...new Set((l.items || []).map((x) => x.classes).filter(Boolean))].join(', ');
      const content = (l.items || [])
        .map((x) => `${x.subject ? x.subject + ' : ' : ''}${x.content}`)
        .filter(Boolean)
        .join(' / ');
      const checked = l.check && l.check.status === 'checked';
      return `<tr>
        <td>${i + 1}</td>
        <td>${m}/${Number(l.date.slice(8, 10))}<br>(${l.weekday || ''})</td>
        <td>${escapeHtml(classes || '-')}</td>
        <td>${escapeHtml(l.place || '-')}</td>
        <td>${timeCell(l)}</td>
        <td class="left">${escapeHtml(content || '-')}${l.note ? `<br><span style="font-size:11px">※ ${escapeHtml(l.note)}</span>` : ''}</td>
        <td class="sign">${checked ? signImg(l.check.signFile) : ''}</td>
      </tr>`;
    })
    .join('');

  // 기록이 적어도 서식 모양이 유지되도록 최소 12줄을 만든다
  const blanks = Math.max(0, 12 - d.logs.length);
  const blankRows = Array.from(
    { length: blanks },
    (_, i) => `<tr><td>${d.logs.length + i + 1}</td><td></td><td></td><td></td><td></td><td></td><td></td></tr>`,
  ).join('');

  return `
  <div class="doc">
    <h2 class="doc-title">${d.schoolYear}학년도 AI교육 코디네이터 활동 일지(${m}월)</h2>
    <div class="writer">작성자 : ${escapeHtml(d.school)} AI교육 코디네이터 ${escapeHtml(d.coordinator.name || '　　　')}
      ${signImg(d.coordinator.signFile, 30)} (서명)</div>
    <table id="tbl-main">
      <thead>
        <tr>
          <th style="width:32px">순</th><th style="width:58px">날짜<br>(요일)</th><th style="width:70px">지도반</th>
          <th style="width:80px">장소</th><th style="width:70px">시간</th><th>교과 / 지도 내용</th><th style="width:70px">담당<br>확인</th>
        </tr>
      </thead>
      <tbody>${rows}${blankRows}</tbody>
      <tfoot>
        <tr class="total-row">
          <td colspan="6">${m}월 총 지도시간</td>
          <td>${d.totalHours}시간</td>
        </tr>
      </tfoot>
    </table>
  </div>`;
}

/* ================================================================
   ② 출근 기록부 (월별) — 서식모음 p.30
   ================================================================ */
function renderAttend(d) {
  const m = Number(d.month.slice(5, 7));
  // 결재란(담당)에는 등록된 서명이 있으면 그것을, 없으면 그 달에 실제로 점검한 서명을 쓴다
  const lastChecked = [...d.logs].reverse().find((l) => l.check && l.check.status === 'checked');
  const managerSign = d.manager.signFile || (lastChecked ? lastChecked.check.signFile : '');
  const allChecked = d.logs.length > 0 && d.checkedCount === d.logs.length;
  const rows = d.logs
    .map((l, i) => {
      const checked = l.check && l.check.status === 'checked';
      return `<tr>
        <td>${i + 1}</td>
        <td>${m}/${Number(l.date.slice(8, 10))}<br>(${l.weekday || ''})</td>
        <td>${escapeHtml(l.place || '-')}</td>
        ${/* 출근·퇴근은 **적힌 그대로** 찍는다 — 퇴근시간은 유휴시간을 포함한 마지막 시각이다
             (2026-08-22 사용자 지시). 활동일지처럼 근무 구간으로 쪼개지 않는다.
             `dayTime` 이 «휴게는 근무 도중» 을 강제하므로 이 두 값 사이에 유휴가 늘 들어 있다. */ ''}
        <td>${escapeHtml(l.clockIn)}</td>
        <td>${escapeHtml(l.clockOut)}</td>
        <td>${escapeHtml(l.safetyCheck ? '이상 없음' : l.safetyNote || '-')}</td>
        <td class="sign">${signImg(l.signFile)}</td>
        <td class="sign">${checked ? signImg(l.check.signFile) : ''}</td>
        <td>${workOf(l)}</td>
      </tr>`;
    })
    .join('');

  const blanks = Math.max(0, 12 - d.logs.length);
  const blankRows = Array.from(
    { length: blanks },
    (_, i) =>
      `<tr><td>${d.logs.length + i + 1}</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>`,
  ).join('');

  return `
  <div class="doc">
    <h2 class="doc-title">${d.schoolYear}학년도 AI교육 코디네이터 출근 기록부(${m}월)</h2>
    <div class="writer">작성자 : ${escapeHtml(d.school)} AI교육 코디네이터 ${escapeHtml(d.coordinator.name || '　　　')}
      ${signImg(d.coordinator.signFile, 30)} (서명)</div>
    <table id="tbl-main">
      <thead>
        <tr>
          <th style="width:30px">순</th><th style="width:54px">날짜<br>(요일)</th><th>활동장소</th>
          <th style="width:52px">출근<br>시간</th><th style="width:52px">퇴근<br>시간</th><th style="width:64px">안전<br>점검</th>
          <th style="width:74px">강사날인<br>(서명)</th><th style="width:74px">담당자<br>(확인)</th><th style="width:52px">활동<br>시간</th>
        </tr>
      </thead>
      <tbody>${rows}${blankRows}</tbody>
      <tfoot>
        <tr class="total-row"><td colspan="8">${m}월 총 활동시간</td><td>${d.totalHours}</td></tr>
      </tfoot>
    </table>

    <table class="approve">
      <thead><tr><th colspan="2">결　재</th></tr></thead>
      <tbody>
        <tr><th style="width:50%">담당</th><th>교감</th></tr>
        <tr>
          <td class="sign">${allChecked ? signImg(managerSign, 44) : ''}</td>
          <td></td>
        </tr>
      </tbody>
    </table>

    <div style="margin-top:10px;font-size:11.5px;color:#333">
      ${
        /* 🔴 이 줄이 없으면 «출근 11:30 · 퇴근 16:00 인데 활동시간 4» 가 셈이 틀린 것처럼 보인다.
           유휴가 있는 달에는 반드시 찍는다(2026-08-24). */
        d.totalBreak > 0
          ? `※ 활동시간은 <b>유휴(휴게) 시간을 뺀 근무시간</b>입니다 —
             체류(출근~퇴근) ${d.totalStay}시간 − 유휴 ${d.totalBreak}시간 = <b>${d.totalHours}시간</b>.
             휴게시간은 근로시간에서 제외합니다(근로기준법 제54조).<br>`
          : ''
      }
      ※ 인건비 : ${d.totalHours}시간 × ${won(d.coordinator.hourlyWage)} = <b>${won(d.pay)}</b>
      <br>　　(주당 계약시간 ${d.coordinator.weeklyHours}시간 · 계약기간 ${escapeHtml(d.coordinator.contractStart || '')} ~ ${escapeHtml(d.coordinator.contractEnd || '')})
    </div>
  </div>`;
}

/* ================================================================
   ③ 결과보고서 및 정산서 (연간) — 서식모음 p.31~33
   ================================================================ */
function renderResult(d) {
  const AREA_ROLE = {
    A: '①학생 참여형 AI교육 활동 지원',
    B: '②교원 AI 수업 및 역량강화 지원',
    C: '③학부모·지역사회 연계 대외협력·성과 지원',
  };
  const th = (n) => Math.round((Number(n) || 0) / 1000).toLocaleString('ko-KR'); // 천원 단위

  const opRows = d.groups.length
    ? d.groups
        .map(
          (g) => `<tr>
        <td>${escapeHtml(g.subject)}</td>
        <td>${escapeHtml(g.operationType)}</td>
        <td class="left">${escapeHtml(g.contents.slice(0, 3).join(' / ') || '-')}</td>
        <td class="left" style="font-size:11px">${escapeHtml(AREA_ROLE[g.area] || '-')}</td>
        <td>${g.hours}H</td>
        <td></td></tr>`,
        )
        .join('')
    : '<tr><td>-</td><td>-</td><td class="left">-</td><td>-</td><td>-</td><td></td></tr>';

  const monthRows = Object.entries(d.monthly)
    .sort()
    .map(([m, h]) => `<tr><td>${Number(m.slice(5, 7))}월</td><td>${h}시간</td></tr>`)
    .join('');

  // 예산 줄은 **서버가 확정해 준 값**을 쓴다(자동 줄의 집행액까지 채워져 온다).
  // 화면과 문서가 각각 계산하면 합계가 어긋난다 — 계산은 서버 한 곳에서만 한다.
  const budgetRows = (d.budgetRows || [])
    .map(
      (r) => `<tr>
        <td>${escapeHtml(r.item)}</td><td>${escapeHtml(r.detail)}</td>
        <td>${th(r.planned)}</td><td>${th(r.spent)}</td><td>${th(r.remain)}</td>
        <td class="left">${escapeHtml(r.note || '')}</td></tr>`,
    )
    .join('');

  const photos = d.photos.slice(0, 4);
  const photoBox = photos.length
    ? `<div class="photos">${photos
        .map(
          (p, i) =>
            `<figure><img src="/files/photos/${encodeURIComponent(p.file)}"><figcaption>사진(${i + 1}) ${escapeHtml(p.date)}</figcaption></figure>`,
        )
        .join('')}</div>`
    : '<div class="fill-area" style="min-height:50mm">사진(1)　　　　　　　　사진(2)</div>';

  return `
  <div class="doc">
    <h2 class="doc-title">${d.year}년 AI교육 코디네이터 결과보고서 및 정산서</h2>
    <div style="text-align:right;font-size:11.5px">※ 3페이지 이내로 작성</div>

    <h3 class="doc-sec">Ⅰ. 추진 배경 및 목적</h3>
    <table>
      <thead><tr>
        <th>학교명</th><th>담당자명<br>(이메일, 연락처)</th><th>채용<br>인원</th><th>계약기간</th><th>예산</th><th>집행액</th><th>비고</th>
      </tr></thead>
      <tbody><tr>
        <td>${escapeHtml(d.school)}</td>
        <td>${escapeHtml(d.manager.name || '')}<br><span style="font-size:11px">(${escapeHtml(d.manager.position || '정보부장')})</span></td>
        <td>1</td>
        <td>${escapeHtml((d.coordinator.contractStart || '').replace(/-/g, '.'))}~<br>${escapeHtml((d.coordinator.contractEnd || '').replace(/-/g, '.'))}</td>
        <td>${th(d.budgetPlanned)}천원</td>
        <td>${th(d.budgetSpent)}천원</td>
        <td></td>
      </tr></tbody>
    </table>

    <div style="margin-top:10px"><b>1. 추진 배경</b></div>
    <div class="fill-area">${escapeHtml(d.report.background || '◦ ')}</div>
    <div style="margin-top:8px"><b>2. 추진 목적</b></div>
    <div class="fill-area">${escapeHtml(d.report.purpose || '◦ ')}</div>

    <h3 class="doc-sec">Ⅱ. 사업 추진 결과</h3>
    <div><b>1. AI교육 코디네이터 채용</b></div>
    <table style="margin-top:6px">
      <thead><tr><th style="width:36px">구분</th><th>코디네이터 업무</th><th style="width:52px">채용<br>인원</th><th style="width:70px">운영과정</th><th style="width:90px">근무시간</th><th style="width:110px">계약기간</th></tr></thead>
      <tbody><tr>
        <td>1</td>
        <td class="left">수업 협력, 학생 활동 지원, 행사·행정 지원 등</td>
        <td>1</td><td>정규</td>
        <td>주당 ${d.coordinator.weeklyHours}시간<br>(15시간 미만)</td>
        <td>${escapeHtml((d.coordinator.contractStart || '').replace(/-/g, '.'))}~${escapeHtml((d.coordinator.contractEnd || '').replace(/-/g, '.'))}</td>
      </tr></tbody>
    </table>

    <div style="margin-top:12px"><b>2. AI교육 코디네이터 운영 결과</b>
      <span style="font-size:11.5px">(총 ${d.dayCount}일 · ${d.totalHours}시간)</span></div>
    <table style="margin-top:6px" id="tbl-op">
      <thead><tr>
        <th style="width:60px">과목명</th><th style="width:66px">운영과정</th><th>운영 주제 및 코디네이터 역할(요약)</th>
        <th style="width:132px">운영형태</th><th style="width:66px">운영시간<br>(총시수)</th><th style="width:50px">비고</th>
      </tr></thead>
      <tbody>${opRows}</tbody>
      <tfoot><tr class="total-row"><td colspan="4">계</td><td>${Math.round(d.groups.reduce((s, g) => s + g.hours, 0) * 10) / 10}H</td>
        <td></td></tr></tfoot>
    </table>
    <div style="font-size:11.5px;margin-top:4px">
      ※ 위 ‘운영시간’은 실제 지도·지원에 투입된 시간이며, 출근기록부상 <b>총 활동(근무) 시간은 ${d.totalHours}시간(${d.dayCount}일)</b>입니다.
      (수업 준비·자료 정리 등 포함)
    </div>

    <div style="margin-top:12px"><b>수업 주요 산출물</b></div>
    <div class="fill-area">${escapeHtml(d.report.outputs || '◦ ')}</div>

    <div style="margin-top:12px"><b>운영 결과 사진</b></div>
    ${photoBox}
  </div>

  <div class="doc">
    <h3 class="doc-sec">Ⅲ. 예산 집행 결과</h3>
    <div style="text-align:right;font-size:11.5px">(단위 : 천원)</div>
    <table id="tbl-budget">
      <thead>
        <tr>
          <th colspan="2">구분</th>
          <th rowspan="2" style="width:80px">편성액<br>(A)</th>
          <th rowspan="2" style="width:80px">집행액<br>(B)</th>
          <th rowspan="2" style="width:80px">잔액<br>(A-B)</th>
          <th rowspan="2" style="width:150px">비고</th>
        </tr>
        <tr><th style="width:90px">비목</th><th style="width:150px">세목</th></tr>
      </thead>
      <tbody>${budgetRows}</tbody>
      <tfoot><tr class="total-row">
        <td colspan="2">합계</td><td>${th(d.budgetPlanned)}</td><td>${th(d.budgetSpent)}</td><td>${th(d.budgetRemain)}</td>
        <td class="left">${escapeHtml(d.budget.note || '')}</td>
      </tr></tfoot>
    </table>

    <h3 class="doc-sec">참고. 월별 활동 시간</h3>
    <table style="max-width:280px">
      <thead><tr><th>월</th><th>활동시간</th></tr></thead>
      <tbody>${monthRows || '<tr><td>-</td><td>-</td></tr>'}</tbody>
      <tfoot><tr class="total-row"><td>합계</td><td>${d.totalHours}시간</td></tr></tfoot>
    </table>

    <div style="margin-top:24px;text-align:center;font-size:14px">
      ${d.year}.　　.　　.<br><br>
      ${escapeHtml(d.school)}장　　　　　(직인)
    </div>
  </div>`;
}
