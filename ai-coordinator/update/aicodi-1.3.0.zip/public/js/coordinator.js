/* ================================================================
   ②③ 코디네이터 화면 — 요청 처리 + 활동 기록
   ================================================================ */
'use strict';

let PUB = null;
let CAT = null;
let signPad = null;
let currentPhotos = []; // 서버에 이미 저장된 사진 파일명
let newPhotos = []; // 이번에 새로 올릴 사진 (data URL)

/* 서버(교무실 PC)의 오늘 날짜. 활동 기록은 이 날짜만 쓸 수 있다.
   내 PC 시계가 틀려도 기준이 흔들리지 않도록 브라우저의 todayStr() 대신 이 값을 쓴다. */
let SERVER_TODAY = todayStr();
let canWriteLog = true; // 지금 고른 날짜에 저장할 수 있는가
let breakOk = true; // 유휴(휴게) 시간이 법정 기준을 채웠는가 — 못 채우면 저장 단추를 잠근다

/* 저장 단추를 여닫는 **유일한 곳**.
   예전에는 updateLogHours()·loadLog() 가 각자 만져, 뒤에 부른 쪽이 앞의 판단을 지웠다
   (유휴가 모자라 잠갔는데 loadLog() 가 다시 열어 버리는 식). */
function syncSaveButton() {
  const btn = document.getElementById('saveLog');
  if (btn) btn.disabled = !(canWriteLog && breakOk);
}

start();

async function start() {
  const me = await requireLogin(['coordinator'], '코디네이터 확인');

  document.getElementById('topbar').innerHTML = renderTopbar(
    '/coordinator.html',
    `<span class="badge">${escapeHtml(me.name)}</span>
     <button class="small ghost" id="logoutBtn" style="margin-left:8px">나가기</button>`,
  );
  document.getElementById('logoutBtn').addEventListener('click', logout);

  PUB = await fillSchoolName();
  CAT = await api('/api/catalog');
  if (PUB && PUB.serverDate) SERVER_TODAY = PUB.serverDate;

  document.getElementById('placeList2').innerHTML = (PUB.places || [])
    .map((p) => `<option value="${escapeHtml(p)}">`)
    .join('');

  // 탭
  document.querySelectorAll('.tabs button').forEach((b) =>
    b.addEventListener('click', () => {
      document.querySelectorAll('.tabs button').forEach((x) => x.classList.toggle('on', x === b));
      for (const name of ['inbox', 'log', 'cal']) {
        document.getElementById('tab-' + name).hidden = name !== b.dataset.tab;
      }
      if (b.dataset.tab === 'cal') renderCalendar();
      if (b.dataset.tab === 'log') {
        if (signPad) signPad.resize(); // 숨어 있던 캔버스 크기를 맞춘다(ResizeObserver 없는 브라우저 대비)
        loadLog();
      }
    }),
  );

  // 활동 기록 기본값 — 항상 서버의 오늘 날짜에서 시작한다
  const logDate = document.getElementById('logDate');
  logDate.value = SERVER_TODAY;
  logDate.max = SERVER_TODAY; // 앞날은 날짜 고르기 창에서 아예 고를 수 없다
  document.getElementById('calDate').value = SERVER_TODAY;
  applyDayScheduleToLog();

  signPad = makeSignPad(document.getElementById('signPad'));
  document.getElementById('signClear').addEventListener('click', () => signPad.clear());

  document.getElementById('clockIn').addEventListener('change', updateLogHours);
  document.getElementById('clockOut').addEventListener('change', updateLogHours);
  document.getElementById('breakStart').addEventListener('change', updateLogHours);
  document.getElementById('breakEnd').addEventListener('change', updateLogHours);
  document.getElementById('logDate').addEventListener('change', loadLog);
  document.getElementById('addRow').addEventListener('click', () => addItemRow({}));
  document.getElementById('pullRequests').addEventListener('click', () => pullDayRequests(true));
  document.getElementById('saveLog').addEventListener('click', saveLog);
  document.getElementById('loadLog').addEventListener('click', loadLog);
  document.getElementById('photoInput').addEventListener('change', onPhotoPick);
  document.getElementById('calDate').addEventListener('change', renderCalendar);

  updateLogHours();
  await refreshWeek();
  await loadRequests();
  await loadLog();
  await loadMonthTable();
}

/* ---------------- 서버 날짜 (활동 기록의 기준) ---------------- */

/**
 * 서버의 오늘 날짜를 다시 받아온다. 날짜가 바뀌었으면 true.
 * 화면을 켜 둔 채 자정을 넘기는 경우가 있어 기록을 읽고 쓸 때마다 확인한다.
 */
async function refreshServerDate() {
  try {
    const s = await api('/api/public-settings');
    if (!s || !s.serverDate) return false;
    const changed = s.serverDate !== SERVER_TODAY;
    SERVER_TODAY = s.serverDate;
    PUB = s; // 시간표·장소가 바뀌었을 수도 있으니 함께 갱신한다
    document.getElementById('logDate').max = SERVER_TODAY;
    return changed;
  } catch {
    return false; // 잠깐 못 받아와도 화면은 그대로 쓴다
  }
}

/** 오늘이 아닌 날짜를 골랐을 때 보여 줄 안내 */
function dateLockNotice(date, open, stillReturned) {
  if (open) {
    return `<div class="notice warn"><b>반송된 기록이라 지난 날짜도 고칠 수 있습니다</b>
      고른 날짜 ${dateKo(date)} · 오늘은 ${dateKo(SERVER_TODAY)} 입니다.<br>
      <span style="font-size:15px">${
        stillReturned
          ? '고쳐서 저장하면 다시 점검 대기로 올라갑니다.'
          : '이미 한 번 고쳐 올리셨습니다. <b>시스템관리자님이 점검을 끝내기 전까지 몇 번이든 더 고칠 수 있습니다.</b>'
      }</span></div>`;
  }
  const kind = date > SERVER_TODAY ? '아직 오지 않은 날' : '이미 지난 날';
  return `<div class="notice bad"><b>🔒 ${dateKo(date)} 은(는) 기록할 수 없습니다 — ${kind}입니다</b>
    활동 기록은 <b>오늘(${dateKo(SERVER_TODAY)})</b> 것만 쓸 수 있습니다. 다른 날짜는 <b>보기만</b> 됩니다.<br>
    <span style="font-size:15px">지난 기록을 고쳐야 하면 시스템관리자님께 <b>반송</b>을 요청해 주세요.
    반송된 기록은 지난 날짜라도 고쳐서 다시 저장할 수 있습니다.</span>
    <div style="margin-top:10px"><button type="button" class="small" id="goToday">오늘(${SERVER_TODAY}) 기록으로 이동</button></div></div>`;
}

/** 기록 칸을 쓸 수 있게/못 쓰게 한다 (날짜 칸과 [기록 불러오기]는 늘 쓸 수 있다) */
function setLogEditable(on) {
  for (const id of ['clockIn', 'clockOut', 'breakStart', 'breakEnd', 'logPlace', 'safetyCheck', 'safetyNote', 'logNote', 'addRow', 'pullRequests', 'photoInput', 'signClear']) {
    const el = document.getElementById(id);
    if (el) el.disabled = !on;
  }
  document
    .querySelectorAll('#itemRows input, #itemRows select, #itemRows textarea, #itemRows button, #photoPreview button')
    .forEach((el) => {
      el.disabled = !on;
    });
  const pad = document.getElementById('signPad'); // 손글씨 서명판은 그림판이라 disabled 가 없다
  if (pad) {
    pad.style.pointerEvents = on ? '' : 'none';
    pad.style.opacity = on ? '' : '0.45';
  }
}

/** 고른 날짜(요일)의 근무 시간표를 출퇴근 기본값으로 넣는다 */
function applyDayScheduleToLog() {
  const date = document.getElementById('logDate').value;
  const sc = date ? scheduleFor(PUB, date) : null;
  if (sc && sc.on && sc.stayHours > 0) {
    document.getElementById('clockIn').value = sc.start;
    document.getElementById('clockOut').value = sc.end;
    // 계약 시간표에 정해 둔 유휴시간을 기본으로 넣는다 (그날 달랐으면 고치면 된다)
    document.getElementById('breakStart').value = sc.breakStart || '';
    document.getElementById('breakEnd').value = sc.breakEnd || '';
  }
  return sc;
}

/* ---------------- 주간 시간 게이지 ---------------- */
async function refreshWeek(dateStr) {
  const w = await api(`/api/week?date=${encodeURIComponent(dateStr || SERVER_TODAY)}`);
  const pct = Math.min(100, (w.total / 15) * 100);
  const msg =
    w.level === 'over'
      ? '⛔ 주 15시간을 넘었습니다. 추가 요청은 받지 마시고 시스템관리자님과 조정해 주세요.'
      : w.level === 'danger'
        ? '⚠️ 15시간에 매우 가깝습니다. 추가 요청은 다음 주로 조절하세요.'
        : w.level === 'warn'
          ? '남은 시간이 얼마 없습니다. 새 요청을 받을 때 확인해 주세요.'
          : '여유가 있습니다.';

  document.getElementById('weekBox').innerHTML = `
    <div class="gauge">
      <div class="bar"><div class="fill ${w.level}" style="width:${pct}%"></div></div>
      <div class="txt">
        <span><b>${w.total}시간</b> / 15시간 미만</span>
        <span>${w.range.start} ~ ${w.range.end}</span>
      </div>
    </div>
    <div class="notice ${w.level === 'over' ? 'bad' : w.level === 'ok' ? 'info' : 'warn'}">
      ${msg}<br>
      <span style="font-size:16px">기록된 활동 ${w.recorded}시간 · 확정 예정 ${w.plannedOnly}시간${w.otherSchoolHours ? ` · 타 학교 ${w.otherSchoolHours}시간` : ''} · 이 주 예정 근무 ${w.weeklyHours}시간</span>
      ${w.isOverride ? `<br><span style="font-size:16px">📌 이 주는 업무 시간이 따로 정해진 주입니다 (기본 ${w.baseWeeklyHours}시간 → 이 주 ${w.weeklyHours}시간)${w.overrideNote ? ` — ${escapeHtml(w.overrideNote)}` : ''}</span>` : ''}
    </div>`;
  return w;
}

/* ---------------- 요청함 ---------------- */

/** 날짜별 '확정된 일정' 모음 — 수락하기 전에 겹치는지 알려 주려고 미리 만들어 둔다 */
let BUSY = {};

async function loadRequests() {
  const all = await api('/api/requests');
  const today = SERVER_TODAY;

  // 확정된 일정만 모은다(시간조절 제안은 아직 확정이 아니다)
  BUSY = {};
  for (const r of all) {
    if (r.status !== 'accepted' && r.status !== 'done') continue;
    (BUSY[r.date] = BUSY[r.date] || []).push(r);
  }

  const news = all.filter((r) => r.status === 'requested');
  const accepted = all.filter((r) => r.status === 'accepted' && r.date >= today);
  const past = all.filter((r) => !news.includes(r) && !accepted.includes(r)).reverse();

  document.getElementById('newList').innerHTML =
    news.length ? news.map((r) => renderRequest(r, true)).join('') : '<div class="empty">새 요청이 없습니다.</div>';
  document.getElementById('acceptedList').innerHTML =
    accepted.length ? accepted.map((r) => renderRequest(r, false)).join('') : '<div class="empty">확정된 일정이 없습니다.</div>';
  document.getElementById('pastList').innerHTML =
    past.length ? past.slice(0, 30).map((r) => renderRequest(r, false)).join('') : '<div class="empty">기록이 없습니다.</div>';

  wireRequestButtons();
}

function renderRequest(r, actionable) {
  const areaName = (CAT.areas.find((a) => a.code === r.area) || {}).name || '';
  const actions = actionable
    ? `
    <div class="btnbar" style="margin-top:12px">
      <button class="ok small" data-act="accept" data-id="${r.id}">✅ 수락</button>
      <button class="warn small" data-act="reschedule" data-id="${r.id}">🕘 시간조절 제안</button>
      <button class="ghost small" data-act="coordinate" data-id="${r.id}">🤝 조율 요청</button>
    </div>
    <div id="form-${r.id}"></div>`
    : '';

  const reply = r.reply || {};
  const replyBox =
    r.status === 'rescheduled'
      ? `<div class="notice warn" style="margin:10px 0 0;font-size:16px">제안한 시간 ${dateKo(reply.newDate)} ${escapeHtml(reply.newStartTime)}~${escapeHtml(reply.newEndTime)} — 선생님 동의 대기 중</div>`
      : r.status === 'coordinating'
        ? `<div class="notice warn" style="margin:10px 0 0;font-size:16px">🤝 시스템관리자님께 조율을 요청했습니다 — 결정을 기다리는 중입니다.${reply.reason ? `<br>올린 내용 : ${escapeHtml(reply.reason)}` : ''}</div>`
        : r.status === 'closed' || r.status === 'rejected'
          ? `<div class="notice" style="margin:10px 0 0;font-size:16px">조율 결과 : 이번에는 진행하지 않기로 했습니다.${reply.reason ? `<br>${escapeHtml(reply.reason)}` : ''}</div>`
          : '';

  // 같은 시간에 다른 일정이 있으면 미리 알려 준다 (수락 전에 알아야 한다)
  const clash = (BUSY[r.date] || []).filter(
    (x) => x.id !== r.id && overlaps(r.startTime, r.endTime, x.startTime, x.endTime),
  );
  const clashBox = clash.length
    ? `<div class="notice bad" style="margin:10px 0 0;font-size:16px"><b>⚠️ 이 시간에 이미 확정된 일정이 있습니다</b><br>
        ${clash.map((x) => `${escapeHtml(x.startTime)}~${escapeHtml(x.endTime)} ${escapeHtml(x.teacherName)} 선생님 · ${escapeHtml(x.taskType)}`).join('<br>')}<br>
        <span style="color:var(--gray-700)">수락하면 겹칩니다. [시간조절 제안] 하시거나 [조율 요청]으로 시스템관리자님께 넘겨 주세요.</span></div>`
    : '';

  return `
  <div class="item ${actionable ? 'hi' : ''}">
    <h3>${dateKo(r.date)} ${escapeHtml(r.startTime)}~${escapeHtml(r.endTime)} (${r.hours}시간)
      <span class="tag ${r.status}">${STATUS_KO[r.status] || r.status}</span></h3>
    <dl>
      <dt>요청 선생님</dt><dd>${escapeHtml(r.teacherName)}${r.subject ? ` (${escapeHtml(r.subject)})` : ''}</dd>
      <dt>업무</dt><dd>${escapeHtml(r.taskType)}${areaName ? ` <span style="color:var(--gray-500)">· ${escapeHtml(areaName)}</span>` : ''}</dd>
      <dt>장소·형태</dt><dd>${escapeHtml(r.place || '-')} · ${escapeHtml(r.operationType)}</dd>
      <dt>내용</dt><dd>${escapeHtml(r.content)}</dd>
      ${r.materials ? `<dt>준비물</dt><dd>${escapeHtml(r.materials)}</dd>` : ''}
      <dt>요청번호</dt><dd>${escapeHtml(r.id)} · ${escapeHtml(r.createdAt)}</dd>
    </dl>
    ${replyBox}
    ${actionable ? clashBox : ''}
    ${actions}
  </div>`;
}

/** 두 시간대가 겹치는가 (서버의 timeOverlaps 와 같은 규칙) */
function overlaps(aStart, aEnd, bStart, bEnd) {
  const m = (t) => {
    const x = /^(\d{1,2}):(\d{2})$/.exec(String(t || ''));
    return x ? Number(x[1]) * 60 + Number(x[2]) : null;
  };
  const a1 = m(aStart);
  const a2 = m(aEnd);
  const b1 = m(bStart);
  const b2 = m(bEnd);
  if ([a1, a2, b1, b2].some((v) => v === null)) return false;
  return a1 < b2 && b1 < a2;
}

function wireRequestButtons() {
  document.querySelectorAll('[data-act]').forEach((btn) =>
    btn.addEventListener('click', () => openReplyForm(btn.dataset.id, btn.dataset.act)),
  );
}

function openReplyForm(id, act) {
  const box = document.getElementById('form-' + id);
  if (!box) return;

  if (act === 'accept') {
    box.innerHTML = `
      <div class="notice info" style="margin-top:10px">
        <label style="margin-top:0">전할 말 <span class="hint">(선택)</span></label>
        <input type="text" id="acc-${id}" placeholder="예) 10분 먼저 가서 컴퓨터실 준비하겠습니다.">
        <div class="btnbar" style="margin-top:10px">
          <button class="ok small" id="do-${id}">수락 확정</button>
        </div>
      </div>`;
    document.getElementById('do-' + id).addEventListener('click', () =>
      sendReply(id, { action: 'accept', reason: document.getElementById('acc-' + id).value }),
    );
  } else if (act === 'coordinate') {
    box.innerHTML = `
      <div class="notice warn" style="margin-top:10px">
        <b>시스템관리자님께 조율을 요청합니다</b>
        <div style="font-size:16px;color:var(--gray-700);margin:4px 0 8px">
          코디네이터가 직접 거절하지 않습니다. 어떤 점이 어려운지만 적어 주시면
          <b>시스템관리자님이 결정</b>해 선생님께 알려 드립니다.
        </div>
        <label style="margin-top:0">어떤 점이 어려운가요? <span class="hint">(필수 · 시스템관리자님께 그대로 전달됩니다)</span></label>
        <input type="text" id="co-${id}" placeholder="예) 같은 시간에 2학년 행사 지원이 이미 확정되어 있어 둘 다는 어렵습니다.">
        <div class="btnbar" style="margin-top:10px">
          <button class="warn small" id="do-${id}">조율 요청 보내기</button>
        </div>
      </div>`;
    document.getElementById('do-' + id).addEventListener('click', () =>
      sendReply(id, { action: 'coordinate', reason: document.getElementById('co-' + id).value }),
    );
  } else {
    box.innerHTML = `
      <div class="notice warn" style="margin-top:10px">
        <div class="row">
          <div><label style="margin-top:0">바꿀 날짜</label><input type="date" id="rd-${id}"></div>
          <div><label style="margin-top:0">시작</label><input type="time" step="300" id="rs-${id}"></div>
          <div><label style="margin-top:0">끝</label><input type="time" step="300" id="re-${id}"></div>
        </div>
        <label>사유 <span class="hint">(선택)</span></label>
        <input type="text" id="rr-${id}" placeholder="예) 그 시간에는 1학년 수업 지원이 있어 1교시 뒤로 옮기고 싶습니다.">
        <div class="btnbar" style="margin-top:10px">
          <button class="warn small" id="do-${id}">시간조절 제안 보내기</button>
        </div>
      </div>`;
    document.getElementById('do-' + id).addEventListener('click', () =>
      sendReply(id, {
        action: 'reschedule',
        newDate: document.getElementById('rd-' + id).value,
        newStartTime: document.getElementById('rs-' + id).value,
        newEndTime: document.getElementById('re-' + id).value,
        reason: document.getElementById('rr-' + id).value,
      }),
    );
  }
}

async function sendReply(id, body) {
  clearSay('#msgInbox');
  const label = { accept: '수락', coordinate: '조율 요청', reschedule: '시간조절 제안' }[body.action] || '처리';
  const eul = josa(label, '을', '를');
  try {
    await api(`/api/requests/${encodeURIComponent(id)}/reply`, { method: 'POST', body });
    await refreshWeek();
    await loadRequests();
    await showDialog({
      kind: 'ok',
      title: `${label}${eul} 보냈습니다`,
      message:
        body.action === 'coordinate'
          ? '시스템관리자님 [점검·설정] 화면에 조율 대기로 올라갑니다.'
          : '요청한 선생님 화면에 바로 표시됩니다.',
      detail:
        body.action === 'reschedule'
          ? '선생님이 동의하면 그 시간으로 확정됩니다.'
          : body.action === 'coordinate'
            ? '시스템관리자님이 결정하시면 선생님과 코디네이터 화면에 함께 표시됩니다.'
            : '',
    });
  } catch (e) {
    await showDialog({ kind: 'bad', title: `${label}${eul} 보내지 못했습니다`, message: e.message });
  }
}

/* ---------------- 활동 기록 ---------------- */
/**
 * 체류 · 유휴 · 근무 시간을 한 줄로 보여 준다.
 * `근무 시간` 칸에는 **인건비 기준인 근무시간**(체류 − 유휴)을 넣는다.
 * 근로기준법 제54조 : 4시간 근무 시 30분 이상을 근무 도중에 준다.
 */
function updateLogHours() {
  const t = dayTime(
    document.getElementById('clockIn').value,
    document.getElementById('clockOut').value,
    document.getElementById('breakStart').value,
    document.getElementById('breakEnd').value,
  );
  const box = document.getElementById('logHours');
  box.value = t.stay > 0 ? (t.brk > 0 ? `${t.work}시간 (체류 ${t.stay} − 유휴 ${brkText(t)})` : `${t.work}시간`) : '—';
  box.style.color = t.error ? 'var(--red)' : '';

  const warn = document.getElementById('restWarn');
  if (t.error) {
    warn.innerHTML = `<div class="notice bad" style="font-size:16px">${escapeHtml(t.error)}</div>`;
    breakOk = false;
    syncSaveButton();
    return;
  }
  /* 법정 휴게가 모자라면 **저장을 막는다**(2026-08-22 사용자 지시 — 경고만으로는 그냥 지나쳤다).
     판정은 `breakShortage()` 한 곳에서 하고 서버도 같은 함수를 쓴다. */
  const shortage = breakShortage(t);
  if (shortage) {
    warn.innerHTML = `<div class="notice bad" style="font-size:16px">
      <b>⛔ 유휴(휴게) 시간을 넣어야 저장됩니다</b>
      ${escapeHtml(shortage).replace(/\n/g, '<br>')}</div>`;
    box.style.color = 'var(--red)';
    breakOk = false;
    syncSaveButton();
    return;
  }
  breakOk = true;
  syncSaveButton();
  if (t.brk > 0) {
    warn.innerHTML = `<div class="notice info" style="font-size:16px">
      실제 근무 구간 : <b>${escapeHtml(spanText(t.spans))}</b> — 인건비는 ${t.work}시간으로 계산됩니다.</div>`;
  } else {
    warn.innerHTML = '';
  }
}

function addItemRow(data) {
  const box = document.getElementById('itemRows');
  const idx = box.children.length;
  const opts = CAT.operationTypes.map(
    (v) => `<option ${v === (data.operationType || '정규수업') ? 'selected' : ''}>${escapeHtml(v)}</option>`,
  ).join('');
  // 결과보고서 '운영형태' 칸에 찍히는 3대 영역 — 요청에서 넘어온 값을 기본으로 두고 고칠 수 있게 한다
  const areaOpts = CAT.areas
    .map((a) => `<option value="${a.code}" ${a.code === (data.area || 'A') ? 'selected' : ''}>${escapeHtml(a.name)}</option>`)
    .join('');
  const div = document.createElement('div');
  div.className = 'act-row';
  div.dataset.row = idx;
  div.innerHTML = `
    <div class="act-head">
      <span class="act-no">활동 ${idx + 1}</span>
      ${data.requestId ? `<span class="act-from">요청 ${escapeHtml(data.requestId)} 에서 불러옴</span>` : '<span class="act-from">직접 추가</span>'}
      <button class="ghost small delRow" type="button">삭제</button>
    </div>
    <div class="act-body">
      <div class="act-grid">
        <div><label class="f-lab">지도반</label>
          <input class="f-classes" type="text" value="${escapeHtml(data.classes || '')}" placeholder="2-3"></div>
        <div><label class="f-lab">교과</label>
          <input class="f-subject" type="text" value="${escapeHtml(data.subject || '')}" placeholder="정보"></div>
        <div class="f-op-wrap"><label class="f-lab">운영형태</label>
          <select class="f-op">${opts}</select></div>
        <div><label class="f-lab">시간</label>
          <input class="f-hours" type="number" min="0" step="0.5" value="${Number(data.hours) || ''}" placeholder="1.5"></div>
      </div>

      <div class="act-full">
        <label class="f-lab">지도 내용 <span class="hint">— 활동일지에 그대로 들어갑니다</span></label>
        <input class="f-content" type="text" value="${escapeHtml(data.content || '')}" placeholder="예) 엔트리 AI 블록 실습 보조, 모둠별 카메라 인식 지원">
      </div>

      <div class="act-full">
        <label class="f-lab">업무 영역 <span class="hint">— 연말 결과보고서에 들어갑니다</span></label>
        <select class="f-area">${areaOpts}</select>
      </div>
      <input type="hidden" class="f-reqid" value="${escapeHtml(data.requestId || '')}">
    </div>`;
  box.appendChild(div);
  div.querySelector('.delRow').addEventListener('click', () => {
    div.remove();
    renumberItemRows();
  });
}

/** 줄을 지웠을 때 '활동 1, 2, 3…' 번호를 다시 매긴다 */
function renumberItemRows() {
  document.querySelectorAll('#itemRows > .act-row').forEach((row, i) => {
    row.querySelector('.act-no').textContent = `활동 ${i + 1}`;
    row.dataset.row = i;
  });
}

function collectItems() {
  return [...document.querySelectorAll('#itemRows > .act-row')].map((row) => ({
    requestId: row.querySelector('.f-reqid').value,
    classes: row.querySelector('.f-classes').value.trim(),
    subject: row.querySelector('.f-subject').value.trim(),
    area: row.querySelector('.f-area').value,
    operationType: row.querySelector('.f-op').value,
    hours: row.querySelector('.f-hours').value,
    content: row.querySelector('.f-content').value.trim(),
  }));
}

/** 그 날짜의 확정 요청을 활동 줄로 자동 채워 준다 */
async function pullDayRequests(force) {
  const date = document.getElementById('logDate').value;
  if (!date) return;
  const list = await api(`/api/requests?from=${date}&to=${date}`);
  const usable = list.filter((r) => r.status === 'accepted' || r.status === 'done');
  const box = document.getElementById('itemRows');
  const existing = new Set([...box.querySelectorAll('.f-reqid')].map((i) => i.value).filter(Boolean));

  let added = 0;
  for (const r of usable) {
    if (existing.has(r.id) && !force) continue;
    if (existing.has(r.id)) continue;
    addItemRow({
      requestId: r.id,
      classes: r.classes,
      subject: r.subject,
      area: r.area,
      operationType: r.operationType,
      hours: r.hours,
      content: `${r.taskType} — ${r.content}`.slice(0, 200),
    });
    added++;
  }
  if (force) {
    say('#msgLog', added ? 'ok' : 'info', added ? `확정 요청 ${added}건을 불러왔습니다.` : '새로 불러올 확정 요청이 없습니다.');
  }
}

async function loadLog() {
  const date = document.getElementById('logDate').value;
  if (!date) return;
  clearSay('#msgLog');
  document.getElementById('itemRows').innerHTML = '';
  currentPhotos = [];
  newPhotos = [];
  document.getElementById('photoPreview').innerHTML = '';
  document.getElementById('checkState').innerHTML = '';
  document.getElementById('signSaved').textContent = '';

  await refreshServerDate(); // 자정을 넘겼는지 먼저 확인
  const notes = []; // 이 날짜에 대한 안내를 모아 한 번에 보여 준다

  const logs = await api(`/api/logs?month=${date.slice(0, 7)}`);
  const l = logs.find((x) => x.date === date);

  if (l) {
    document.getElementById('clockIn').value = l.clockIn;
    document.getElementById('clockOut').value = l.clockOut;
    document.getElementById('breakStart').value = l.breakStart || '';
    document.getElementById('breakEnd').value = l.breakEnd || '';
    document.getElementById('logPlace').value = l.place || '';
    document.getElementById('safetyCheck').checked = !!l.safetyCheck;
    document.getElementById('safetyNote').value = l.safetyNote || '';
    document.getElementById('logNote').value = l.note || '';
    for (const it of l.items || []) addItemRow(it);
    currentPhotos = [...(l.photos || [])];
    renderPhotoPreview();
    if (l.signFile) document.getElementById('signSaved').textContent = '✅ 서명이 저장되어 있습니다 (다시 쓰면 새 서명으로 바뀝니다)';

    if (l.check && l.check.status === 'checked') {
      notes.push(`<div class="notice ok"><b>점검 완료</b>${escapeHtml(l.check.by)} · ${escapeHtml(l.check.at)}${l.check.comment ? '<br>' + escapeHtml(l.check.comment) : ''}<br><span style="font-size:15px">점검이 끝난 날은 수정할 수 없습니다. 고쳐야 하면 시스템관리자님께 반송을 요청해 주세요.</span></div>`);
    } else if (l.check && l.check.status === 'returned') {
      notes.push(`<div class="notice bad"><b>반송되었습니다 — 고쳐서 다시 저장해 주세요</b>${escapeHtml(l.check.comment)}<br><span style="font-size:15px">${escapeHtml(l.check.by)} · ${escapeHtml(l.check.at)}</span></div>`);
    } else {
      notes.push('<div class="notice info">저장되었습니다. 시스템관리자님의 점검을 기다리는 중입니다.</div>');
    }
  } else {
    // 새로 쓰는 날 : 그 요일의 근무 시간표를 기본값으로
    const sc = applyDayScheduleToLog();
    document.getElementById('logPlace').value = PUB.places && PUB.places[0] ? PUB.places[0] : '';
    document.getElementById('logNote').value = '';
    document.getElementById('safetyCheck').checked = true;
    document.getElementById('safetyNote').value = '이상 없음';
    if (sc && (!sc.on || sc.hours <= 0)) {
      notes.push(`<div class="notice warn">${sc.weekday}요일은 근무일이 아닙니다. (이 주 근무일 : ${escapeHtml(scheduleSummary(PUB, date))})<br>
        <span style="font-size:15px">그래도 근무한 날이면 기록할 수 있습니다. 주 15시간 미만인지 위 게이지를 확인해 주세요.</span></div>`);
    } else if (sc && sc.isOverride) {
      notes.push(`<div class="notice info">📌 이 주는 업무 시간이 따로 정해진 주입니다 — ${sc.weekday}요일 ${escapeHtml(sc.start)}~${escapeHtml(sc.end)}${sc.weekNote ? ` (${escapeHtml(sc.weekNote)})` : ''}</div>`);
    }
    await pullDayRequests(false);
  }

  /* 저장할 수 있는 날인지 판정한다 (최종 판단은 서버가 한 번 더 한다)
     ① 점검이 끝난 날은 못 고친다  ② 오늘이면 쓸 수 있다  ③ 반송된 기록은 지난 날짜라도 고칠 수 있다 */
  const checked = !!(l && l.check && l.check.status === 'checked');
  const returned = !!(l && l.check && l.check.status === 'returned');
  /* `reopened` 는 «반송으로 열렸고 아직 점검 전» 이라는 뜻이다.
     한 번 고쳐 올리면 반송 표시는 지워지지만 이 문패는 남으므로 **또 고칠 수 있다.**
     (예전에는 반송 표시만 봐서 두 번째 수정이 막혔다 — 2026-08-22 사용자 지적) */
  const reopened = !!(l && l.reopened);
  canWriteLog = !checked && (date === SERVER_TODAY || returned || reopened);
  if (date !== SERVER_TODAY) notes.unshift(dateLockNotice(date, (returned || reopened) && !checked, returned));

  document.getElementById('checkState').innerHTML = notes.join('');
  setLogEditable(canWriteLog);
  syncSaveButton();

  const go = document.getElementById('goToday'); // 안내문을 새로 그렸으니 매번 다시 연결한다
  if (go) {
    go.addEventListener('click', () => {
      document.getElementById('logDate').value = SERVER_TODAY;
      loadLog();
    });
  }
  updateLogHours();
}

async function onPhotoPick(e) {
  const files = [...e.target.files].slice(0, 6);
  for (const f of files) {
    try {
      newPhotos.push(await shrinkImage(f));
    } catch (err) {
      say('#msgLog', 'warn', err.message);
    }
  }
  e.target.value = '';
  renderPhotoPreview();
}

function renderPhotoPreview() {
  const box = document.getElementById('photoPreview');
  const saved = currentPhotos.map(
    (f, i) => `
    <figure style="flex:0 0 150px;margin:0">
      <img src="/files/photos/${encodeURIComponent(f)}" style="width:100%;height:100px;object-fit:cover;border-radius:8px">
      <button type="button" class="ghost small" data-delsaved="${i}" style="width:100%;margin-top:4px">삭제</button>
    </figure>`,
  );
  const fresh = newPhotos.map(
    (d, i) => `
    <figure style="flex:0 0 150px;margin:0">
      <img src="${d}" style="width:100%;height:100px;object-fit:cover;border-radius:8px;outline:3px solid var(--blue)">
      <button type="button" class="ghost small" data-delnew="${i}" style="width:100%;margin-top:4px">취소</button>
    </figure>`,
  );
  box.innerHTML = [...saved, ...fresh].join('') || '<div style="color:var(--gray-500);font-size:16px">첨부된 사진이 없습니다.</div>';
  box.querySelectorAll('[data-delsaved]').forEach((b) =>
    b.addEventListener('click', () => {
      currentPhotos.splice(Number(b.dataset.delsaved), 1);
      renderPhotoPreview();
    }),
  );
  box.querySelectorAll('[data-delnew]').forEach((b) =>
    b.addEventListener('click', () => {
      newPhotos.splice(Number(b.dataset.delnew), 1);
      renderPhotoPreview();
    }),
  );
}

async function saveLog() {
  clearSay('#msgLog');

  // 오늘이 아닌 날짜는 저장할 수 없다 (서버도 한 번 더 막는다)
  if (!canWriteLog) {
    await showDialog({
      kind: 'warn',
      title: '이 날짜는 기록할 수 없습니다',
      message: `활동 기록은 오늘(${SERVER_TODAY}) 것만 쓸 수 있습니다.`,
      detail:
        '지난 기록을 고쳐야 하면 시스템관리자님께 반송을 요청해 주세요.\n' +
        '반송된 기록은 점검이 끝나기 전까지 지난 날짜라도 몇 번이든 고칠 수 있습니다.',
    });
    return;
  }
  // 화면을 켜 둔 채 자정을 넘겼을 수 있다 — 보내기 직전에 서버 날짜를 다시 확인한다
  if (await refreshServerDate()) {
    await loadLog();
    await showDialog({
      kind: 'warn',
      title: '날짜가 바뀌었습니다',
      message: `서버 날짜가 ${SERVER_TODAY} 로 넘어갔습니다.\n화면을 새 날짜에 맞춰 다시 불러왔습니다.`,
      detail: '내용을 확인하신 뒤 다시 [기록 저장]을 눌러 주세요.',
    });
    return;
  }

  const body = {
    date: document.getElementById('logDate').value,
    clockIn: document.getElementById('clockIn').value,
    clockOut: document.getElementById('clockOut').value,
    breakStart: document.getElementById('breakStart').value,
    breakEnd: document.getElementById('breakEnd').value,
    place: document.getElementById('logPlace').value.trim(),
    safetyCheck: document.getElementById('safetyCheck').checked,
    safetyNote: document.getElementById('safetyNote').value.trim(),
    items: collectItems(),
    note: document.getElementById('logNote').value.trim(),
    newPhotos,
    keepPhotos: currentPhotos,
    sign: signPad.isEmpty() ? null : signPad.toDataUrl(),
  };
  if (!body.safetyCheck && !body.safetyNote) {
    await showDialog({ kind: 'warn', title: '안전 점검 결과를 적어 주세요', message: '출근기록부의 필수 항목입니다.' });
    return document.getElementById('safetyNote').focus();
  }
  /* 지도반이 비면 활동일지의 지도반 칸이 빈칸으로 나간다 — 미리 확인을 받는다.
     ⚠ 예전에는 브라우저의 `confirm()` 을 썼는데, 브라우저가 "이 사이트의 추가 대화 상자 차단" 을
        걸면 **묻지도 않고 취소로 처리되어 저장이 조용히 실패**했다(2026-08-19 실제 발생).
        요청에서 불러온 줄은 지도반이 늘 비어 있어 이 창이 매번 떠서 차단되기 쉬웠다.
        그래서 앱의 다른 확인창과 같은 `showDialog` 를 쓰고, **취소하면 반드시 흔적을 남긴다.** */
  const emptyRows = [...document.querySelectorAll('#itemRows > .act-row')].filter(
    (row) => !row.querySelector('.f-classes').value.trim(),
  );
  if (emptyRows.length) {
    const go = await showDialog({
      kind: 'warn',
      title: `지도반이 비어 있는 활동이 ${emptyRows.length}건 있습니다`,
      message: '요청에서 불러온 활동은 지도반이 비어 있습니다.\n비워 두면 활동일지의 지도반 칸도 비게 됩니다.',
      detail: '지금 채우시려면 [지도반 채우기] 를 눌러 주세요.',
      button: '비워 둔 채 저장',
      cancel: '지도반 채우기',
    });
    if (!go) {
      // 빈 칸을 눈에 띄게 표시하고 첫 칸으로 데려간다
      for (const row of emptyRows) {
        const el = row.querySelector('.f-classes');
        el.style.outline = '3px solid var(--red)';
        el.addEventListener('input', () => { el.style.outline = ''; }, { once: true });
      }
      emptyRows[0].querySelector('.f-classes').focus();
      say('#msgLog', 'warn', `저장하지 않았습니다. 빨갛게 표시된 지도반 ${emptyRows.length}칸을 채운 뒤 다시 [기록 저장] 을 눌러 주세요.`);
      return;
    }
  }

  const btn = document.getElementById('saveLog');
  btn.disabled = true;
  try {
    const r = await api('/api/logs', { method: 'POST', body });
    newPhotos = [];
    signPad.clear();
    await refreshWeek();
    await loadLog();
    await loadMonthTable();
    await loadRequests();
    await showDialog({
      kind: 'ok',
      title: '기록을 저장했습니다',
      message: `${dateKo(r.item.date)} ${r.item.clockIn}~${r.item.clockOut} · ${r.item.hours}시간\n활동 ${r.item.items.length}건`,
      detail: '시스템관리자님 [점검·설정] 화면에 점검 대기로 올라갑니다.',
    });
  } catch (e) {
    await showDialog({ kind: 'bad', title: '저장하지 못했습니다', message: e.message });
  } finally {
    syncSaveButton(); // 날짜 잠금·유휴 잠금을 되살린다 (무조건 켜면 잠금이 풀린다)
  }
}

/* ---------------- 이번 달 기록 현황 ---------------- */
async function loadMonthTable() {
  const month = document.getElementById('logDate').value.slice(0, 7) || thisMonth();
  const logs = await api(`/api/logs?month=${month}`);
  const rows = logs
    .map((l) => {
      const st = l.check
        ? l.check.status === 'checked'
          ? '<span class="tag checked">점검 완료</span>'
          : '<span class="tag returned">반송</span>'
        : l.reopened
          ? '<span class="tag unchecked">점검 대기</span> <span class="tag returned">고칠 수 있음</span>'
          : '<span class="tag unchecked">점검 대기</span>';
      /* 반송·고칠 수 있음 인 날은 **날짜를 눌러 바로 갈 수 있게** 한다.
         날짜 칸을 손으로 맞춰야 하면 지난 기록을 찾아가기가 번거롭다. */
      const open = !!(l.reopened || (l.check && l.check.status === 'returned'));
      const dcell = open
        ? `<td><a href="#" class="go-date" data-date="${l.date}"><b>${dateKo(l.date)}</b> ✏️</a></td>`
        : `<td>${dateKo(l.date)}</td>`;
      return `<tr>
        ${dcell}<td>${escapeHtml(l.clockIn)}~${escapeHtml(l.clockOut)}</td>
        <td>${l.hours}</td><td>${escapeHtml(l.place || '')}</td>
        <td>${(l.items || []).length}건</td><td>${l.safetyCheck ? '이상 없음' : escapeHtml(l.safetyNote || '-')}</td>
        <td>${st}</td></tr>`;
    })
    .join('');
  const total = Math.round(logs.reduce((t, l) => t + (Number(l.hours) || 0), 0) * 10) / 10;
  document.getElementById('monthTable').innerHTML = `
    <thead><tr><th>날짜</th><th>출근~퇴근</th><th>시간</th><th>장소</th><th>활동</th><th>안전점검</th><th>점검</th></tr></thead>
    <tbody>${rows || '<tr><td colspan="7">기록이 없습니다.</td></tr>'}</tbody>
    <tfoot><tr><th colspan="2">${month} 총 활동시간</th><th>${total}</th><th colspan="4"></th></tr></tfoot>`;

  // 고칠 수 있는 날의 날짜를 누르면 그 날짜로 옮겨 간다
  document.querySelectorAll('#monthTable .go-date').forEach((a) =>
    a.addEventListener('click', (e) => {
      e.preventDefault();
      document.getElementById('logDate').value = a.dataset.date;
      loadLog();
      document.getElementById('logDate').scrollIntoView({ behavior: 'smooth', block: 'center' });
    }),
  );
}

/* ---------------- 주간 일정 ---------------- */
async function renderCalendar() {
  const base = document.getElementById('calDate').value || SERVER_TODAY;
  const w = await refreshWeek(base);
  const all = await api(`/api/requests?from=${w.range.start}&to=${w.range.end}`);
  const days = [];
  const d0 = new Date(w.range.start + 'T00:00:00');
  for (let i = 0; i < 7; i++) {
    const d = new Date(d0);
    d.setDate(d0.getDate() + i);
    days.push(todayStr(d));
  }

  const cells = days
    .map((d) => {
      const items = all.filter((r) => r.date === d && ['accepted', 'done', 'requested', 'rescheduled'].includes(r.status));
      const isWork = (PUB.workDays || []).includes(new Date(d + 'T00:00:00').getDay());
      const inner = items.length
        ? items
            .map(
              (r) =>
                `<div style="margin:4px 0;padding:6px;border-radius:8px;background:${
                  r.status === 'accepted' || r.status === 'done' ? 'var(--green-soft)' : 'var(--amber-soft)'
                };text-align:left;font-size:14px">
              <b>${escapeHtml(r.startTime)}~${escapeHtml(r.endTime)}</b><br>${escapeHtml(r.teacherName)} · ${escapeHtml(r.classes || '')}<br>
              <span style="color:var(--gray-500)">${escapeHtml(r.taskType.slice(0, 22))}</span></div>`,
            )
            .join('')
        : '<span style="color:var(--gray-300)">—</span>';
      return `<td style="vertical-align:top;min-width:130px;background:${isWork ? '#fff' : 'var(--gray-50)'}">${inner}</td>`;
    })
    .join('');

  document.getElementById('calTable').innerHTML = `
    <thead><tr>${days
      .map((d) => {
        const dd = new Date(d + 'T00:00:00');
        const today = d === SERVER_TODAY;
        return `<th style="${today ? 'background:var(--blue-soft);color:#1e40af' : ''}">${dd.getMonth() + 1}/${dd.getDate()}<br>${WEEK_KO[dd.getDay()]}</th>`;
      })
      .join('')}</tr></thead>
    <tbody><tr>${cells}</tr></tbody>`;
}
