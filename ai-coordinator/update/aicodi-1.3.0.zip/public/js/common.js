/* ================================================================
   공통 도우미 — 모든 화면이 함께 쓰는 함수들
   ================================================================ */
'use strict';

const WEEK_KO = ['일', '월', '화', '수', '목', '금', '토'];
/* 요청의 상태 이름.
   코디네이터는 요청을 거절하지 않는다 — 어려우면 '조율' 로 올리고 시스템관리자가 결정한다.
   `rejected` 는 예전 자료에만 남아 있는 값이라 표시만 해 준다. */
const STATUS_KO = {
  requested: '요청 접수',
  accepted: '수락 · 확정',
  coordinating: '조율 중 · 시스템관리자 확인',
  rescheduled: '시간조절 제안',
  done: '활동 완료',
  closed: '조율 종료 · 진행 안 함',
  cancelled: '취소',
  rejected: '조율 종료 · 진행 안 함', // 예전 자료 호환
};

/** 서버와 이야기하는 창구. 로그인 토큰을 자동으로 붙여 보낸다. */
async function api(path, options = {}) {
  const headers = { 'Content-Type': 'application/json' };
  // 토큰은 16진수 문자열이지만, 혹시 이상한 값이 들어 있으면 헤더 자체가 만들어지지 않아
  // 영문 브라우저 오류가 나므로 미리 걸러 낸다
  const token = sessionStorage.getItem('token');
  if (token && /^[A-Za-z0-9._-]+$/.test(token)) headers['X-Auth'] = token;

  let res;
  try {
    res = await fetch(path, {
      method: options.method || 'GET',
      headers,
      body: options.body ? JSON.stringify(options.body) : undefined,
    });
  } catch {
    // 서버가 꺼졌거나 네트워크가 끊긴 경우 — 영문 오류 대신 알아들을 수 있게 알려 준다
    const err = new Error(
      '서버에 연결할 수 없습니다.\n교무실 PC의 검은 창(서버)이 켜져 있는지 확인해 주세요.\n학교 밖에서는 접속되지 않습니다.',
    );
    err.offline = true;
    throw err;
  }
  let data = null;
  try {
    data = await res.json();
  } catch {
    data = {};
  }
  if (!res.ok) {
    const err = new Error(data.error || `문제가 생겼습니다 (${res.status})`);
    err.status = res.status;
    err.data = data;
    throw err;
  }
  return data;
}

/** 화면 위쪽에 안내 문구를 띄운다. kind: info | ok | warn | bad */
/* 로그인할 때 받은 «새 판» 알림을 잠깐 두는 자리 (아래 `takeUpdateNotice()` 가 꺼내 간다) */
const UPDATE_NOTICE_KEY = 'aicodi.updateNotice';

/**
 * 로그인할 때 받아 둔 «새 판» 알림을 **꺼내면서 지운다**.
 * 지우기 때문에 **로그인할 때 한 번만** 뜬다 — 화면을 오갈 때마다 다시 뜨지 않는다.
 * @returns {object|null}
 */
function takeUpdateNotice() {
  try {
    const t = sessionStorage.getItem(UPDATE_NOTICE_KEY);
    if (!t) return null;
    sessionStorage.removeItem(UPDATE_NOTICE_KEY);
    const j = JSON.parse(t);
    return j && j.latest ? j : null;
  } catch {
    return null;
  }
}

/**
 * 접혀 있는 <details> 안에 있으면 **모두 펼친다**.
 * 🔴 이것이 없으면 «접힌 항목 안에 그려진 안내» 를 아무도 못 본다 —
 *    거부 사유가 접힌 채로 그려져 «눌렀는데 아무 일도 안 일어난다» 가 된다
 *    (브라우저 confirm 사고와 같은 종류의 «조용히 끝나는 길» 이다).
 */
function openFolds(el) {
  let p = el && el.parentElement;
  while (p) {
    if (p.tagName === 'DETAILS' && !p.open) p.open = true;
    p = p.parentElement;
  }
}
function say(target, kind, message) {
  const box = typeof target === 'string' ? document.querySelector(target) : target;
  if (!box) return;
  box.innerHTML = `<div class="notice ${kind}">${escapeHtml(message).replace(/\n/g, '<br>')}</div>`;
  openFolds(box);
  box.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}
function clearSay(target) {
  const box = typeof target === 'string' ? document.querySelector(target) : target;
  if (box) box.innerHTML = '';
}

/**
 * 알림 창을 띄운다 (요청 결과처럼 꼭 확인해야 하는 메시지용)
 * kind : ok | bad | warn | info
 * 닫으면 약속(Promise)이 끝나므로 `await showDialog(...)` 로 쓸 수 있다.
 *
 * `cancel` 을 주면 **예/아니오를 묻는 창**이 된다 — 확인이면 `true`, 취소면 `false` 를 돌려준다.
 * (`cancel` 이 없으면 알리기만 하는 창이라 늘 `true` 를 돌려준다. 기존 호출은 그대로 동작한다)
 */
function showDialog({ kind = 'info', title = '', message = '', detail = '', button = '확인', cancel = '' } = {}) {
  return new Promise((resolve) => {
    const icons = { ok: '✅', bad: '⚠️', warn: '⚠️', info: 'ℹ️' };
    const back = document.createElement('div');
    back.className = 'modal-back';
    back.innerHTML = `
      <div class="modal-card ${kind}" role="alertdialog" aria-modal="true" aria-labelledby="mTitle">
        <div class="m-icon">${icons[kind] || 'ℹ️'}</div>
        <h3 id="mTitle">${escapeHtml(title)}</h3>
        <div class="m-msg">${escapeHtml(message)}</div>
        ${detail ? `<div class="m-sub">${escapeHtml(detail)}</div>` : ''}
        <div class="btnbar" style="justify-content:center">
          ${cancel ? `<button type="button" class="ghost" data-no>${escapeHtml(cancel)}</button>` : ''}
          <button type="button" class="${kind === 'ok' ? 'ok' : kind === 'bad' ? 'danger' : ''}" data-yes>${escapeHtml(button)}</button>
        </div>
      </div>`;
    document.body.appendChild(back);

    const yes = back.querySelector('[data-yes]');
    const no = back.querySelector('[data-no]');
    const close = (v) => {
      document.removeEventListener('keydown', onKey);
      back.remove();
      resolve(v);
    };
    const onKey = (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        close(true);
      } else if (e.key === 'Escape') {
        e.preventDefault();
        // 묻는 창에서 Esc 는 '취소'다. 알리기만 하는 창은 그냥 닫힌다
        close(!cancel);
      }
    };
    yes.addEventListener('click', () => close(true));
    if (no) no.addEventListener('click', () => close(false));
    // 바깥을 눌러도 닫히게 (카드 안쪽 클릭은 무시)
    back.addEventListener('click', (e) => {
      if (e.target === back) close(!cancel);
    });
    document.addEventListener('keydown', onKey);
    yes.focus();
  });
}

/**
 * 한글 조사를 낱말에 맞게 고른다 — "결과 안내를" / "진행 결정을"
 * 마지막 글자에 받침이 있으면 앞것(을·이·은), 없으면 뒷것(를·가·는).
 */
function josa(word, withBatchim, withoutBatchim) {
  const ch = String(word || '').trim().slice(-1);
  const code = ch.charCodeAt(0);
  // 한글 음절 영역이 아니면(숫자·영문 등) 받침 없는 쪽으로 둔다
  if (!(code >= 0xac00 && code <= 0xd7a3)) return withoutBatchim;
  return (code - 0xac00) % 28 === 0 ? withoutBatchim : withBatchim;
}

function escapeHtml(s) {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function todayStr(d = new Date()) {
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

function thisMonth() {
  return todayStr().slice(0, 7);
}

/** 2026-08-20 → 8/20(목) */
function dateKo(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr + 'T00:00:00');
  if (Number.isNaN(d.getTime())) return dateStr;
  return `${d.getMonth() + 1}/${d.getDate()}(${WEEK_KO[d.getDay()]})`;
}

function hoursBetween(a, b) {
  const toMin = (t) => {
    if (!/^\d{1,2}:\d{2}$/.test(String(t || ''))) return null;
    const [h, m] = String(t).split(':').map(Number);
    return h * 60 + m;
  };
  const s = toMin(a);
  const e = toMin(b);
  if (s === null || e === null || e <= s) return 0;
  return Math.round(((e - s) / 60) * 10) / 10;
}

function won(n) {
  return (Number(n) || 0).toLocaleString('ko-KR') + '원';
}

/* ---------------------------------------------------------------
   파일을 더블클릭해서 열었을 때 보여 주는 안내
   (이 앱은 여러 사람이 자료를 함께 쓰므로 서버가 반드시 필요합니다)
   --------------------------------------------------------------- */
function showServerNeededHelp() {
  // 스타일시트도 file:// 에서는 안 불러와지므로 여기서 직접 입혀 준다
  const style = document.createElement('style');
  style.textContent = `
    body{margin:0;font-family:'Malgun Gothic',sans-serif;background:#f1f5f9;color:#0f172a;font-size:18px;line-height:1.65}
    .hbox{max-width:760px;margin:40px auto;padding:0 20px}
    .hcard{background:#fff;border-radius:14px;padding:28px;box-shadow:0 2px 10px rgba(15,23,42,.1)}
    .hcard h1{margin:0 0 6px;font-size:26px;color:#b91c1c}
    .hcard h2{font-size:20px;color:#1f3a5f;margin:26px 0 8px}
    .hbad{background:#fef2f2;border-left:6px solid #b91c1c;padding:14px 18px;border-radius:10px;margin:16px 0}
    .hok{background:#ecfdf5;border-left:6px solid #15803d;padding:14px 18px;border-radius:10px;margin:16px 0}
    code{background:#0f172a;color:#fff;padding:3px 9px;border-radius:6px;font-size:17px;
         font-family:Consolas,monospace;display:inline-block;margin:2px 0}
    ol{padding-left:26px} li{margin:10px 0}
    .addr{font-size:22px;font-weight:700;color:#1d4ed8}`;
  document.head.appendChild(style);

  document.body.innerHTML = `
    <div class="hbox"><div class="hcard">
      <h1>⚠️ 서버를 먼저 켜 주세요</h1>
      <p>지금 이 화면은 <b>파일을 직접 열어서(<code>file://</code>)</b> 보고 있습니다.
         그래서 화면 디자인도 나오지 않고 버튼도 작동하지 않습니다.</p>

      <div class="hbad">
        <b>왜 그런가요?</b><br>
        이 프로그램은 선생님·코디네이터·시스템관리자가 <b>같은 자료를 함께 보고 쓰는</b> 방식입니다.
        그 자료는 교무실 PC의 서버가 보관하므로, 서버를 켠 뒤 <b>http:// 주소</b>로 들어가야 합니다.<br>
        <span style="font-size:16px">(2진수 변환기 같은 앱은 혼자 쓰는 것이라 더블클릭으로 열렸지만, 이 앱은 구조가 다릅니다.)</span>
      </div>

      <h2>해결 방법</h2>
      <ol>
        <li><b><code>ai-coordinator\\서버_실행.bat</code></b> 을 더블클릭합니다.<br>
            <span style="font-size:16px;color:#64748b">검은 창이 열리고 브라우저가 자동으로 뜹니다. 이 창은 닫지 마세요 — 닫으면 서버가 꺼집니다.</span></li>
        <li>아래 주소로 들어갑니다.
            <div style="margin-top:8px">
              <div class="addr">http://localhost:4000/</div>
              <span style="font-size:16px;color:#64748b">
                작업 요청 → <code>/</code> &nbsp;·&nbsp; 코디네이터 → <code>/coordinator.html</code><br>
                점검·설정 → <code>/manager.html</code> &nbsp;·&nbsp; 문서 출력 → <code>/reports.html</code>
              </span>
            </div></li>
        <li>다른 선생님 PC에서는 <b>검은 창에 표시된 주소</b>로 들어갑니다.
            (생김새는 <code>http://10.1.2.3:4000/</code> 처럼 생겼고, <b>숫자는 학교마다 다릅니다</b>)</li>
      </ol>

      <div class="hok">
        <b>터미널에서 켜고 싶다면</b><br>
        <code>cd C:\\project_AI\\ai-coordinator</code><br>
        <code>node server.js</code><br>
        <span style="font-size:16px">Node.js 가 없다면 nodejs.org 에서 LTS 버전을 설치하세요.</span>
      </div>

      <p style="margin-top:22px">
        <button onclick="location.href='http://localhost:4000/'"
          style="font-size:18px;font-weight:700;padding:13px 22px;border:0;border-radius:10px;background:#2563eb;color:#fff;cursor:pointer">
          서버가 켜졌다면 여기를 누르세요 →
        </button>
      </p>
    </div></div>`;
  document.title = '서버를 먼저 켜 주세요 · AI교육 코디네이터 업무 관리';
}

/* ---------------------------------------------------------------
   로그인 — 명단에서 이름을 고르고 자기 인증코드를 넣는다
   인증코드와 구분(시스템관리자·교사·코디네이터)은 시스템관리자가 올린
   엑셀 명단 파일에서 옵니다.
   --------------------------------------------------------------- */
const ROLE_KO = { manager: '시스템관리자', teacher: '교사', coordinator: '코디네이터' };

/**
 * 구분별로 들어가는 화면이 다르다.
 * 코디네이터가 선생님용 주소(/)로 들어오면 목록에 자기 이름이 없어 막히므로,
 * 로그인 화면마다 이 목록을 보여 주어 맞는 화면으로 갈 수 있게 한다.
 */
const SCREENS = [
  { path: '/', label: '교사 · 작업 요청' },
  { path: '/coordinator.html', label: '코디네이터' },
  { path: '/manager.html', label: '시스템관리자 · 점검·설정' },
];

async function requireLogin(roles, screenLabel) {
  // 파일을 더블클릭해서 열면(file://) 서버와 이야기할 수 없어 아무것도 작동하지 않는다.
  // 조용히 멈추지 않고 무엇을 해야 하는지 알려 준다.
  if (location.protocol === 'file:') {
    showServerNeededHelp();
    return new Promise(() => {});
  }

  const allow = Array.isArray(roles) ? roles : [roles];
  const me = await api('/api/me').catch(() => ({ role: null }));
  if (me.role && allow.includes(me.role)) return me;

  const pub = await api('/api/public-settings').catch(() => null);
  // 비상 코드 통로는 '시스템관리자 전용' 화면(점검·설정)에서만 보여 준다
  const canEmergency = allow.length === 1 && allow[0] === 'manager';
  const people = pub ? pub.members.filter((m) => allow.includes(m.role)) : [];
  // 지금 보고 있는 화면 (index.html 로 들어와도 '/' 로 본다)
  const here = location.pathname === '/index.html' ? '/' : location.pathname;

  const options = people.length
    ? people
        .map(
          (m) =>
            `<option value="${escapeHtml(m.id)}">${escapeHtml(m.name)}${m.subject ? ` (${escapeHtml(m.subject)})` : ''} — ${ROLE_KO[m.role] || m.role}</option>`,
        )
        .join('')
    : '';

  const rosterMissing = !pub || !pub.hasRoster;
  const noneForThisScreen = pub && pub.hasRoster && !people.length;
  /* 처음 설치한 직후 — 명단도 없고 관리자 코드도 없는 상태.
     ⚠ 예전에는 "시스템관리자님이 [점검·설정] 화면에서 명단을 올려 주셔야 합니다" 라고만 띄웠는데,
        보고 있는 화면이 바로 그 [점검·설정] 이라 **막다른 길**이었다. 게다가 앞으로 갈 수 있는
        유일한 통로(관리자 코드)가 접힌 `<details>` 안에 회색으로 숨어 있어 찾지 못했다.
        (2026-08-19 사용자 지적 : "처음 인스톨하는 사람들은 관리자 비상코드를 어떻게 알지?")
     → 처음이면 **코드를 정하는 칸을 펼친 채 크게** 보여 주고, 문구도 "정하세요" 로 바꾼다. */
  const firstSetup = rosterMissing && canEmergency;

  document.body.innerHTML = `
    <div class="topbar"><h1>AI교육 코디네이터 업무 관리</h1>
      <span class="badge">${escapeHtml(pub ? pub.school : '')}</span>
      ${
        /* 로그인 화면에서부터 판 번호가 보이게 한다 — «이 PC 는 어느 판인가» 를
           들어가기 전에 알 수 있어야 한다. 예전 판은 appVersion 을 안 내려보내므로 비어 있다. */
        pub && pub.appVersion
          ? `<span style="font-size:14px;color:var(--gray-500);align-self:center">판 ${escapeHtml(pub.appVersion)}</span>`
          : ''
      }</div>
    <div class="wrap narrow">
      <div class="card">
        <h2>${firstSetup ? '🎉 처음 설치하셨습니다 — 여기서 시작합니다' : `🔒 ${escapeHtml(screenLabel)}`}</h2>
        <p class="sub">${
          firstSetup
            ? '이 프로그램은 <b>미리 정해진 비밀번호가 없습니다.</b> 앞으로 쓰실 관리자 코드를 지금 직접 정합니다.'
            : '명단에서 본인 이름을 고르고 인증코드를 입력해 주세요.'
        }</p>
        <div id="msg"></div>

        ${
          firstSetup
            ? `<div class="notice ok">
                 <b>아래에 쓰고 싶은 숫자 4~12자리를 넣고 [시작하기] 를 누르세요</b>
                 <div style="font-size:17px">
                   <b>지금 넣은 숫자가 그대로 관리자 코드가 됩니다.</b> 어디서 받아 오는 코드가 아닙니다.<br>
                   <span style="color:var(--red);font-weight:700">꼭 기억해 두거나 적어 두세요.</span>
                   나중에 명단 파일을 잃어버렸을 때 들어오는 통로입니다.
                 </div>
               </div>
               <label for="emcode">관리자 코드 정하기 <span class="hint">숫자 4~12자리</span></label>
               <input id="emcode" type="password" inputmode="numeric" autocomplete="off" placeholder="예) 20261234">
               <div class="btnbar"><button id="emgo">시작하기</button></div>
               <div class="notice info" style="margin-top:18px">
                 <b>다음에 할 일</b>
                 <div style="font-size:16px">
                   들어가시면 [설정] 탭에서 ① 명단 엑셀 올리기 ② 학교명·계약정보·업무시간
                   ③ 예산 편성 순서로 넣으시면 됩니다. 자세한 순서는 프로그램 폴더의
                   <b>사용설명서.txt</b> 5번에 적어 두었습니다.
                 </div>
               </div>`
            : rosterMissing
              ? `<div class="notice warn"><b>아직 명단이 등록되지 않았습니다</b>
                   시스템관리자님이 <b>[시스템관리자 · 점검·설정]</b> 화면에서 <b>명단 엑셀 파일</b>을 먼저 올려 주셔야 합니다.
                   <br><span style="font-size:16px">아래 [시스템관리자 · 점검·설정] 단추로 가시면 처음 설정을 시작할 수 있습니다.</span></div>`
              : noneForThisScreen
                ? `<div class="notice warn"><b>이 화면을 쓸 수 있는 사람이 명단에 없습니다</b>
                     엑셀 명단의 <b>구분</b> 칸을 확인해 주세요. (필요한 구분 : ${allow.map((r) => ROLE_KO[r] || r).join(' 또는 ')})</div>`
                : `<label for="who">이름</label>
                   <select id="who">${options}</select>
                   <label for="code">인증코드</label>
                   <input id="code" type="password" inputmode="numeric" autocomplete="off" placeholder="명단 파일에 적힌 코드">
                   <div class="btnbar">
                     <button id="go">들어가기</button>
                   </div>`
        }

        ${
          canEmergency && !firstSetup
            ? `<details style="margin-top:18px">
                 <summary style="cursor:pointer;font-weight:700;color:var(--gray-500)">관리자 비상 코드로 들어가기</summary>
                 <div class="notice info" style="margin-top:10px">
                   명단 파일을 잃어버렸을 때 쓰는 통로입니다.
                   <label for="emcode" style="margin-top:10px">비상 코드 (숫자 4~12자리)</label>
                   <input id="emcode" type="password" inputmode="numeric" autocomplete="off">
                   <div class="btnbar" style="margin-top:10px"><button class="ghost" id="emgo">비상 코드로 들어가기</button></div>
                 </div>
               </details>`
            : ''
        }        <div class="notice info" style="margin-top:20px">
          <b>목록에 본인 이름이 없나요?</b>
          구분(시스템관리자 · 교사 · 코디네이터)에 따라 들어가는 화면이 다릅니다. 아래에서 골라 주세요.
          <div class="btnbar" style="margin-top:10px">
            ${SCREENS.map(
              (s) =>
                `<a class="btn ${s.path === here ? '' : 'ghost'}" href="${s.path}" style="text-decoration:none">${
                  s.path === here ? '● ' : ''
                }${escapeHtml(s.label)}</a>`,
            ).join('')}
          </div>
        </div>
      </div>
    </div>`;

  const submit = async (body, btn, codeInput) => {
    clearSay('#msg');
    btn.disabled = true;
    try {
      const r = await api('/api/login', { method: 'POST', body });
      sessionStorage.setItem('token', r.token);
      /* 🔴 «새 판이 나왔습니다» 알림을 **새로고침 너머로** 넘긴다 (2026-08-25 사용자 지시).
         바로 아래에서 `location.reload()` 를 하므로 로그인 응답(`r`)은 여기서 사라진다.
         `sessionStorage` 에 잠깐 두었다가 화면이 다시 뜰 때 꺼내 쓴다 —
         **꺼낸 쪽이 지우므로 로그인할 때 딱 한 번만** 뜬다.
         ⚠ 개인정보가 아니고(판 번호와 바뀐 내용뿐) 창을 닫으면 사라진다. */
      if (r.update) {
        try {
          sessionStorage.setItem(UPDATE_NOTICE_KEY, JSON.stringify(r.update));
        } catch {
          /* 저장이 막혀 있어도 로그인은 그대로 진행한다 */
        }
      }
      location.reload();
    } catch (e) {
      btn.disabled = false;
      if (codeInput) codeInput.value = '';
      say('#msg', 'bad', e.message);
    }
  };

  const go = document.getElementById('go');
  if (go) {
    const who = document.getElementById('who');
    const code = document.getElementById('code');
    const run = () => {
      if (!who.value) return say('#msg', 'warn', '이름을 골라 주세요.');
      if (!code.value.trim()) return say('#msg', 'warn', '인증코드를 입력해 주세요.');
      submit({ memberId: who.value, code: code.value.trim() }, go, code);
    };
    go.addEventListener('click', run);
    code.addEventListener('keydown', (e) => e.key === 'Enter' && run());
    // 같은 사람이 계속 쓰기 편하도록 이 브라우저에 명단 번호만 기억(이름·코드는 저장하지 않음)
    const last = localStorage.getItem('lastMemberId');
    if (last && people.some((m) => m.id === last)) who.value = last;
    who.addEventListener('change', () => localStorage.setItem('lastMemberId', who.value));
    if (who.value) localStorage.setItem('lastMemberId', who.value);
    code.focus();
  }

  const emgo = document.getElementById('emgo');
  if (emgo) {
    const emcode = document.getElementById('emcode');
    const run = () => {
      if (!/^\d{4,12}$/.test(emcode.value.trim())) return say('#msg', 'warn', '비상 코드는 숫자 4~12자리입니다.');
      submit({ emergency: true, code: emcode.value.trim() }, emgo, emcode);
    };
    emgo.addEventListener('click', run);
    emcode.addEventListener('keydown', (e) => e.key === 'Enter' && run());
  }

  return new Promise(() => {}); // 로그인 전에는 나머지 화면을 그리지 않는다
}

/** 그 날짜가 속한 주의 월요일 (YYYY-MM-DD) */
function weekMondayOf(dateStr) {
  const d = new Date(dateStr + 'T00:00:00');
  if (Number.isNaN(d.getTime())) return null;
  const back = d.getDay() === 0 ? 6 : d.getDay() - 1;
  d.setDate(d.getDate() - back);
  return todayStr(d);
}

/**
 * 그 주에 실제로 적용되는 시간표를 고른다.
 * 주마다 근무 시간이 다를 수 있어, 그 주만의 예외(weekOverrides)가 있으면 그것을 쓴다.
 */
/* ----------------------------------------------------------------
 * 유휴(휴게) 시간 계산 — 서버의 dayTime() 과 **같은 규칙**이어야 한다
 *   stay 체류(출근~퇴근) · brk 휴게 · work 근무(= 체류 − 휴게)
 *   spans : 휴게를 뺀 실제 근무 구간 — 선생님 화면에 이것을 보여 준다
 * ⚠ 규칙을 고치면 server.js 의 dayTime() 도 함께 고칠 것. 어긋나면 인건비가 틀어진다.
 * ---------------------------------------------------------------- */
function dayTime(start, end, breakStart, breakEnd) {
  const m = (t) => (/^\d{1,2}:\d{2}$/.test(String(t || '')) ? Number(String(t).split(':')[0]) * 60 + Number(String(t).split(':')[1]) : null);
  const stay = hoursBetween(start, end);
  const out = { stay, brk: 0, brkMin: 0, work: stay, spans: stay > 0 ? [[start, end]] : [], error: '' };
  if (stay <= 0) return out;

  const hasS = m(breakStart) !== null;
  const hasE = m(breakEnd) !== null;
  if (!hasS && !hasE) return out;
  if (hasS !== hasE) {
    out.error = '휴게 시간은 시작과 끝을 모두 넣어 주세요.';
    return out;
  }
  const s = m(start);
  const e = m(end);
  const bs = m(breakStart);
  const be = m(breakEnd);
  if (be <= bs) {
    out.error = '휴게 끝 시각이 시작 시각보다 늦어야 합니다.';
    return out;
  }
  if (bs < s || be > e) {
    out.error = `휴게 시간(${breakStart}~${breakEnd})이 근무 시간(${start}~${end}) 밖입니다.`;
    return out;
  }
  /* 🔴 유휴시간을 출근 직후·퇴근 직전에 붙여도 된다(2026-08-24 사용자 지시).
     server.js 의 dayTime() 에 같은 설명이 있다 — «근무 도중» 검사를 다시 넣지 말 것. */
  out.brkMin = be - bs; //  화면에 «분» 으로 보여 줄 때 쓴다
  out.brk = Math.round((out.brkMin / 60) * 10) / 10; //  인건비 계산용(0.1시간 단위)
  //  ⚠ `brk * 60` 으로 분을 되돌리지 말 것 — 20분이 0.3시간으로 반올림되어 «18분» 이라고 찍힌다.
  out.work = Math.round((stay - out.brk) * 10) / 10;
  if (out.work <= 0) {
    out.error = '휴게 시간이 근무 시간과 같거나 더 깁니다.';
    out.work = 0;
  }
  const spans = [];
  if (bs > s) spans.push([start, breakStart]);
  if (be < e) spans.push([breakEnd, end]);
  out.spans = spans;
  return out;
}

/** 근무 구간을 글로 — 예 "09:30~12:00, 12:30~13:30" */
function spanText(spans) {
  return (spans || []).map(([a, b]) => `${a}~${b}`).join(', ');
}

/* ----------------------------------------------------------------
 * 법정 휴게 — 4시간 근무 시 30분 이상, 8시간 근무 시 1시간 이상
 *   근로기준법 제54조 · 업무편람 Ⅳ-2-마
 * ⚠ server.js 의 requiredBreakMin()·breakShortage() 와 **같은 규칙**이어야 한다.
 * ⚠ 기준은 반드시 분(`brkMin`)으로 본다 — 반올림한 시간으로 재면 29분이 통과한다.
 * ---------------------------------------------------------------- */
function requiredBreakMin(stayHours) {
  if (stayHours >= 8) return 60;
  if (stayHours >= 4) return 30;
  return 0;
}

/** 법정 휴게가 모자라면 안내 문장, 넉넉하면 '' */
function breakShortage(t) {
  const need = requiredBreakMin(t.stay);
  if (!need || t.brkMin >= need) return '';
  const 기준 = need === 60 ? '8시간' : '4시간';
  return (
    `${t.stay}시간 근무하는 날은 유휴(휴게) 시간을 ${need}분 이상 넣어야 합니다` +
    `${t.brkMin ? ` (지금 ${t.brkMin}분)` : ' (지금 없음)'}.\n` +
    `${기준} 이상 근무하면 휴게시간을 근무 도중에 주어야 합니다 — 근로기준법 제54조 · 업무편람 Ⅳ-2-마.`
  );
}

/**
 * 유휴시간을 사람이 읽기 좋게. 1시간 미만은 **분**으로 쓴다.
 * `0.3` 처럼 반올림한 시간을 보여 주면 20분인지 18분인지 알 수 없다.
 */
function brkText(t) {
  const min = t && t.brkMin ? t.brkMin : 0;
  if (!min) return '0';
  if (min < 60) return `${min}분`;
  return min % 60 === 0 ? `${min / 60}시간` : `${Math.floor(min / 60)}시간 ${min % 60}분`;
}

/** 그 주에 적용되는 시간표 (주별 예외 반영). hours 는 **근무시간**(휴게 제외) */
function weekScheduleFor(pub, dateStr) {
  if (!pub) return null;
  const monday = weekMondayOf(dateStr);
  const ov = monday ? (pub.weekOverrides || {})[monday] : null;
  const schedule = ov && ov.schedule ? ov.schedule : pub.schedule || {};
  let hours = 0;
  let stay = 0;
  let brk = 0;
  for (let d = 0; d <= 6; d++) {
    const v = schedule[d] || schedule[String(d)];
    if (!v || !v.on) continue;
    const t = dayTime(v.start, v.end, v.breakStart, v.breakEnd);
    hours += t.work;
    stay += t.stay;
    brk += t.brk;
  }
  return {
    monday,
    schedule,
    hours: Math.round(hours * 10) / 10, // 근무시간 (휴게 제외)
    stayHours: Math.round(stay * 10) / 10,
    breakHours: Math.round(brk * 10) / 10,
    isOverride: !!(ov && ov.schedule),
    note: ov ? ov.note || '' : '',
  };
}

/** 그 날짜의 근무 시간표 */
function scheduleFor(pub, dateStr) {
  const d = new Date(dateStr + 'T00:00:00');
  if (!pub || Number.isNaN(d.getTime())) return null;
  const week = weekScheduleFor(pub, dateStr);
  const dow = d.getDay();
  const sc = week.schedule[dow] || week.schedule[String(dow)] || { on: false, start: '', end: '', breakStart: '', breakEnd: '' };
  const t = sc.on ? dayTime(sc.start, sc.end, sc.breakStart, sc.breakEnd) : { stay: 0, brk: 0, work: 0, spans: [] };
  return {
    dow,
    weekday: WEEK_KO[dow],
    ...sc,
    hours: t.work, // 근무시간 (휴게 제외) — 이름을 그대로 두어 쓰는 곳이 안 깨지게
    stayHours: t.stay,
    breakHours: t.brk,
    spans: t.spans,
    isOverride: week.isOverride,
    weekNote: week.note,
    weekHours: week.hours,
  };
}

/** 시간표 하나를 사람이 읽는 문장으로 — 휴게를 뺀 **근무 구간**으로 적는다 */
function describeSchedule(schedule, totalHours) {
  const parts = [];
  let brk = 0;
  for (let d = 0; d <= 6; d++) {
    const v = (schedule || {})[d] || (schedule || {})[String(d)];
    if (!v || !v.on) continue;
    const t = dayTime(v.start, v.end, v.breakStart, v.breakEnd);
    if (t.work <= 0) continue;
    brk += t.brk;
    parts.push(`${WEEK_KO[d]} ${spanText(t.spans) || `${v.start}~${v.end}`}`);
  }
  if (!parts.length) return '근무 시간이 아직 설정되지 않았습니다';
  const tail = brk > 0 ? ` (주 ${totalHours}시간 · 유휴 ${Math.round(brk * 10) / 10}시간 제외)` : ` (주 ${totalHours}시간)`;
  return `${parts.join(' · ')}${tail}`;
}

/** 근무요일·근무시간 안내 — 날짜를 주면 그 주에 적용되는 시간표로 알려 준다 */
function scheduleSummary(pub, dateStr) {
  if (!pub || !pub.schedule) return '';
  if (!dateStr) return describeSchedule(pub.schedule, pub.weeklyHours);
  const week = weekScheduleFor(pub, dateStr);
  const text = describeSchedule(week.schedule, week.hours);
  return week.isOverride ? `${text} ← 이 주만 다른 시간${week.note ? ` (${week.note})` : ''}` : text;
}

async function logout() {
  await api('/api/logout', { method: 'POST' }).catch(() => {});
  sessionStorage.removeItem('token');
  location.href = '/';
}

/* ---------------------------------------------------------------
   손글씨 서명판 — 마우스·손가락·전자펜 모두 됩니다
   --------------------------------------------------------------- */
/**
 * 손글씨 서명판 (마우스·손가락·펜 모두)
 *
 * ⚠ 탭에 숨어 있는 동안 만들면 `getBoundingClientRect()` 가 0 을 돌려주어
 *   캔버스 크기가 0×0 이 되고, **그림이 아무리 그려도 남지 않는다.**
 *   (활동 기록·업무 점검 탭은 처음에 `hidden` 이라 실제로 이 문제가 났다)
 *   그래서 ① 숨어 있으면 크기를 건드리지 않고 ② 보이게 되는 순간
 *   `ResizeObserver` 가 알아서 다시 맞춘다. 탭을 여닫는 코드가 신경 쓸 필요가 없다.
 */
function makeSignPad(canvas) {
  const ctx = canvas.getContext('2d');
  let drawing = false;
  let dirty = false;

  /** 선 모양 — 캔버스 크기를 바꾸면 초기화되므로 그때마다 다시 지정한다 */
  const applyStyle = () => {
    ctx.lineWidth = 2.6;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = '#111827';
  };
  applyStyle();

  // 화면 해상도에 맞춰 또렷하게
  const resize = () => {
    const rect = canvas.getBoundingClientRect();
    // 숨어 있으면(0×0) 아무것도 하지 않는다 — 여기서 0 을 넣으면 그림이 사라진다
    if (rect.width < 1 || rect.height < 1) return;
    const ratio = window.devicePixelRatio || 1;
    const w = Math.round(rect.width * ratio);
    const h = Math.round(rect.height * ratio);
    if (canvas.width === w && canvas.height === h) return; // 이미 맞으면 그대로 (그림 보존)

    const data = dirty ? canvas.toDataURL() : null;
    canvas.width = w;
    canvas.height = h;
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    applyStyle();
    if (data) {
      const img = new Image();
      img.onload = () => ctx.drawImage(img, 0, 0, rect.width, rect.height);
      img.src = data;
    }
  };
  resize();
  window.addEventListener('resize', resize);
  // 숨어 있던 탭이 열리는 순간을 잡아 준다 (창 크기가 안 바뀌어도 알 수 있다)
  if (window.ResizeObserver) new ResizeObserver(resize).observe(canvas);

  const pos = (e) => {
    const r = canvas.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  };

  canvas.addEventListener('pointerdown', (e) => {
    resize(); // 이제 막 보이게 되었을 수도 있다
    e.preventDefault(); // 마우스로 끌 때 글자 선택.이미지 끌기가 끼어들지 않게
    drawing = true;
    dirty = true;
    try {
      canvas.setPointerCapture(e.pointerId);
    } catch {
      /* 오래된 브라우저 — 캡처가 없어도 그리기는 된다 */
    }
    const { x, y } = pos(e);
    ctx.beginPath();
    ctx.moveTo(x, y);
    // 점 하나만 찍어도 보이도록
    ctx.lineTo(x, y);
    ctx.stroke();
  });
  canvas.addEventListener('pointermove', (e) => {
    if (!drawing) return;
    e.preventDefault();
    const { x, y } = pos(e);
    ctx.lineTo(x, y);
    ctx.stroke();
  });
  const stop = () => {
    drawing = false;
  };
  canvas.addEventListener('pointerup', stop);
  canvas.addEventListener('pointercancel', stop);
  // 판 밖에서 단추를 떼도 확실히 멈춘다.
  // `pointerleave` 로 멈추면 판 가장자리를 지날 때 선이 끊어져서 쓰지 않는다.
  window.addEventListener('pointerup', stop);

  return {
    /** 탭을 열었을 때 등 바깥에서 크기를 다시 맞추고 싶을 때 (ResizeObserver 없는 브라우저 대비) */
    resize,
    clear() {
      ctx.save();
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.restore();
      dirty = false;
    },
    isEmpty() {
      return !dirty;
    },
    /** 흰 배경을 깐 PNG data URL (투명 배경이면 인쇄물에서 안 보일 수 있어서) */
    toDataUrl() {
      if (!dirty || !canvas.width || !canvas.height) return null;
      const out = document.createElement('canvas');
      out.width = canvas.width;
      out.height = canvas.height;
      const octx = out.getContext('2d');
      octx.fillStyle = '#ffffff';
      octx.fillRect(0, 0, out.width, out.height);
      octx.drawImage(canvas, 0, 0);
      return out.toDataURL('image/png');
    },
  };
}
/* ---------------------------------------------------------------
   사진 첨부 — 브라우저에서 미리 줄여서 올린다(용량 절약)
   --------------------------------------------------------------- */
function shrinkImage(file, maxSide = 1400, quality = 0.82) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('사진을 읽을 수 없습니다.'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('사진 형식을 알 수 없습니다.'));
      img.onload = () => {
        const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
        const w = Math.round(img.width * scale);
        const h = Math.round(img.height * scale);
        const c = document.createElement('canvas');
        c.width = w;
        c.height = h;
        c.getContext('2d').drawImage(img, 0, 0, w, h);
        resolve(c.toDataURL('image/jpeg', quality));
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

/* ---------------------------------------------------------------
   표 복사 — 한글(HWP)·엑셀에 표 모양 그대로 붙여넣기
   --------------------------------------------------------------- */
async function copyTable(tableEl, btn) {
  const rows = [...tableEl.querySelectorAll('tr')].map((tr) =>
    [...tr.querySelectorAll('th,td')].map((td) => td.innerText.replace(/\s+/g, ' ').trim()).join('\t'),
  );
  const text = rows.join('\n');
  const html = `<table border="1" style="border-collapse:collapse">${tableEl.innerHTML}</table>`;
  try {
    if (window.ClipboardItem && navigator.clipboard.write) {
      await navigator.clipboard.write([
        new ClipboardItem({
          'text/html': new Blob([html], { type: 'text/html' }),
          'text/plain': new Blob([text], { type: 'text/plain' }),
        }),
      ]);
    } else {
      await navigator.clipboard.writeText(text);
    }
    if (btn) {
      const old = btn.textContent;
      btn.textContent = '✅ 복사했습니다';
      setTimeout(() => (btn.textContent = old), 1800);
    }
  } catch {
    alert('복사가 막혔습니다. 표를 마우스로 끌어서 선택한 뒤 Ctrl+C를 눌러 주세요.');
  }
}

/** 위쪽 메뉴를 그린다 */
function renderTopbar(active, extra = '') {
  const links = [
    ['/', '작업 요청'],
    ['/coordinator.html', '코디네이터'],
    ['/manager.html', '점검·설정'],
    ['/reports.html', '문서 출력'],
  ];
  return `
  <div class="topbar">
    <h1>AI교육 코디네이터 업무 관리</h1>
    <span class="badge" id="schoolName">　</span>
    <span id="appVer" style="font-size:14px;color:var(--gray-500);align-self:center"></span>
    ${extra}
    <nav>${links
      .map(([href, name]) => `<a href="${href}" class="${href === active ? 'on' : ''}">${name}</a>`)
      .join('')}</nav>
  </div>`;
}

async function fillSchoolName() {
  try {
    const s = await api('/api/public-settings');
    const el = document.getElementById('schoolName');
    if (el) el.textContent = s.school;
    /* 판 번호를 학교 이름 옆에 조그맣게 띄운다.
       «설정에 유휴시간 칸이 없다» 는 물음의 원인이 «예전 판» 이었는데,
       화면 어디에도 판 번호가 없어 알 수 없었다(2026-08-24 사용자 신고).
       예전 판은 appVersion 을 내려보내지 않으므로 그때는 아무것도 그리지 않는다. */
    const v = document.getElementById('appVer');
    if (v && s.appVersion) v.textContent = '판 ' + s.appVersion;
    return s;
  } catch {
    return null;
  }
}
