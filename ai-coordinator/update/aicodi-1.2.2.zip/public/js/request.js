/* ================================================================
   ① 선생님 화면 — 작업 요청
   엑셀 명단의 인증코드로 본인을 확인한 뒤, 본인 이름으로만 요청합니다.
   ================================================================ */
'use strict';

let SETTINGS = null;
let CATALOG = null;
let ME = null;

start();

async function start() {
  // 교사·정보부장 구분이면 요청할 수 있습니다 (코디네이터 본인은 요청 대상이 아닙니다)
  ME = await requireLogin(['teacher', 'manager'], '작업 요청 — 본인 확인');

  document.getElementById('topbar').innerHTML = renderTopbar(
    '/',
    `<span class="badge">${escapeHtml(ME.name)} 선생님</span>
     <button class="small ghost" id="logoutBtn" style="margin-left:8px">나가기</button>`,
  );
  document.getElementById('logoutBtn').addEventListener('click', logout);

  SETTINGS = await fillSchoolName();
  CATALOG = await api('/api/catalog');

  const my = (SETTINGS.members || []).find((m) => m.id === ME.memberId);
  document.getElementById('teacherName').value = ME.name + (my && my.subject ? ` (${my.subject})` : '');
  document.getElementById('subject').value = my ? my.subject || '' : '';

  // 코디네이터 근무 시간 안내
  document.getElementById('workInfo').innerHTML =
    `<div class="notice info" style="font-size:16px"><b>코디네이터 근무 시간</b>${escapeHtml(scheduleSummary(SETTINGS))}</div>`;

  // 업무 목록 — 다섯 가지
  const taskType = document.getElementById('taskType');
  for (const t of CATALOG.taskTypes) {
    const o = document.createElement('option');
    o.value = t.name;
    o.textContent = t.name;
    o.dataset.hint = t.hint;
    taskType.appendChild(o);
  }
  taskType.addEventListener('change', showTaskHint);

  // 요청할 수 없는 업무 안내
  document.getElementById('blockedList').innerHTML = CATALOG.blocked
    .map((b) => `<li><b>${escapeHtml(b.task)}</b> — ${escapeHtml(b.why)}</li>`)
    .join('');
  document.getElementById('legalNote').textContent = CATALOG.legalNote;

  // 운영 형태 · 장소
  const op = document.getElementById('operationType');
  for (const v of CATALOG.operationTypes) {
    const o = document.createElement('option');
    o.value = v;
    o.textContent = v;
    op.appendChild(o);
  }
  document.getElementById('placeList').innerHTML = (SETTINGS.places || [])
    .map((p) => `<option value="${escapeHtml(p)}">`)
    .join('');

  // 기본값 — 코디네이터가 다음에 근무하는 날로 맞춰 준다
  fillDurationPickers(); // 걸리는 시간 고르는 칸 (기본 1시간 0분)
  document.getElementById('date').value = nextWorkDay();
  applyDaySchedule();

  document.getElementById('date').addEventListener('change', applyDaySchedule);
  document.getElementById('startTime').addEventListener('change', updateHours);
  document.getElementById('durH').addEventListener('change', updateHours);
  document.getElementById('durM').addEventListener('change', updateHours);
  document.getElementById('submit').addEventListener('click', submitRequest);
  document.getElementById('reset').addEventListener('click', resetForm);

  loadMyList();
}

/** 오늘 이후로 코디네이터가 근무하는 가장 이른 날 (그 주 예외 시간표까지 반영) */
function nextWorkDay() {
  const d = new Date();
  for (let i = 0; i < 21; i++) {
    const sc = scheduleFor(SETTINGS, todayStr(d));
    if (sc && sc.on && sc.hours > 0) return todayStr(d);
    d.setDate(d.getDate() + 1);
  }
  return todayStr();
}

/** 고른 날짜의 요일 근무시간을 기본값으로 넣고, 근무일이 아니면 알려 준다 */
function applyDaySchedule() {
  const v = document.getElementById('date').value;
  const box = document.getElementById('dayWarn');
  box.innerHTML = '';
  if (!v || !SETTINGS) return;

  const sc = scheduleFor(SETTINGS, v);
  // 그 주만 시간이 다르게 정해져 있으면 함께 알려 준다
  const ovTag = sc.isOverride
    ? `<br><span style="font-size:15px">📌 이 주는 시간이 따로 정해져 있습니다${sc.weekNote ? ` — ${escapeHtml(sc.weekNote)}` : ''}</span>`
    : '';
  if (!sc.on || sc.hours <= 0) {
    box.innerHTML = `<div class="notice bad" style="margin:8px 0 0;font-size:16px">
      <b>${sc.weekday}요일은 코디네이터 근무일이 아닙니다.</b>
      이 주 근무일 : ${escapeHtml(scheduleSummary(SETTINGS, v))}<br>
      요청은 보낼 수 있지만 코디네이터가 다른 날로 조절할 수 있습니다.${ovTag}</div>`;
  } else {
    /* 기본값은 **첫 근무 구간**으로 채운다.
       출근~퇴근 전체(09:00~16:00)를 넣으면 유휴시간을 통째로 걸쳐,
       선생님이 아무것도 만지지 않았는데 «유휴와 겹칩니다» 경고가 먼저 뜬다. */
    const first = sc.spans && sc.spans.length ? sc.spans[0] : [sc.start, sc.end];
    document.getElementById('startTime').value = first[0];
    /* 걸리는 시간은 손대지 않는다 — 선생님이 정하는 값이고 기본은 1시간이다.
       예전에는 근무 구간 전체(예 3시간)를 넣었는데, 그러면 «3시간 요청» 이 기본이 되어
       선생님이 줄이는 것을 잊기 쉽다. */
    syncEndTime();
    /* 유휴(휴게) 시간대를 뺀 **실제 근무 구간**을 보여 준다(2026-08-21 사용자 지시).
       예 : 09:30~12:00, 12:30~13:30 — 언제 쉬는지 보이니 그 시간을 피해 요청하게 된다. */
    const spanTxt = sc.breakHours > 0 ? spanText(sc.spans) : `${sc.start}~${sc.end}`;
    box.innerHTML = `<div class="notice ok" style="margin:8px 0 0;font-size:16px">
      ${sc.weekday}요일 근무 시간 : <b>${escapeHtml(spanTxt)}</b> (${sc.hours}시간)${ovTag}
      ${sc.breakHours > 0 ? `<br><span style="font-size:15px;color:var(--gray-700)">${escapeHtml(sc.breakStart)}~${escapeHtml(sc.breakEnd)} 는 유휴(휴게) 시간이라 지원이 어렵습니다.</span>` : ''}</div>`;
  }
  updateHours();
  loadDayBusy(v);
}

/* ----------------------------------------------------------------
 * 그날 이미 잡힌 시간 — 요청하기 전에 보여 준다
 * 코디네이터는 한 사람이라 같은 시간에 두 곳에 갈 수 없다.
 * ---------------------------------------------------------------- */
let DAY_BUSY = { firm: [], pending: [] };

async function loadDayBusy(date) {
  const box = document.getElementById('busyBox');
  if (!box) return;
  DAY_BUSY = { firm: [], pending: [] };
  if (!date) {
    box.innerHTML = '';
    return;
  }
  try {
    DAY_BUSY = await api(`/api/day-busy?date=${encodeURIComponent(date)}`);
  } catch {
    box.innerHTML = '';
    return;
  }
  const line = (x) =>
    `${escapeHtml(x.startTime)}~${escapeHtml(x.endTime)} · ${escapeHtml(x.teacherName)} 선생님 · ${escapeHtml(x.taskType)}${x.place ? ` (${escapeHtml(x.place)})` : ''}`;

  const parts = [];
  if (DAY_BUSY.firm.length) {
    parts.push(`<b>확정된 일정</b><br>${DAY_BUSY.firm.map((x) => '· ' + line(x)).join('<br>')}`);
  }
  if (DAY_BUSY.pending.length) {
    parts.push(
      `<b style="color:var(--gray-700)">아직 처리 중인 요청</b><br>${DAY_BUSY.pending.map((x) => '· ' + line(x)).join('<br>')}`,
    );
  }
  box.innerHTML = parts.length
    ? `<div class="notice info" style="margin:8px 0 0;font-size:16px">📅 이 날 코디네이터 일정<br>${parts.join('<br>')}</div>`
    : `<div class="notice ok" style="margin:8px 0 0;font-size:16px">📅 이 날은 아직 잡힌 일정이 없습니다.</div>`;
  updateHours();
}

/* ----------------------------------------------------------------
 * 걸리는 시간(시간·분) → 마무리 시간
 *   2026-08-24 사용자 지시 : "시작 시간과 걸리는 시간을 입력받으면
 *   마무리 시간은 자동으로 기록되게 해. 걸리는 시간은 *시간 *분으로 입력받아."
 *   서버는 예전처럼 startTime·endTime 을 받는다 — 화면이 계산해서 보낸다.
 *   ⚠ 그래서 endTime 은 이제 **입력칸이 아니라 읽기 전용 표시칸**이다.
 *     .value 에 시각을 넣어 두어야 다른 코드(겹침 검사·보내기)가 그대로 읽는다.
 * ---------------------------------------------------------------- */

/** 걸리는 시간을 분으로. 못 고르면 0 */
function durMinutes() {
  const h = Number(document.getElementById('durH').value) || 0;
  const m = Number(document.getElementById('durM').value) || 0;
  return h * 60 + m;
}

/** 시작 + 걸리는 시간 → 마무리 시각(HH:MM). 못 구하면 '' */
function endFromDuration() {
  const start = document.getElementById('startTime').value;
  if (!/^\d{1,2}:\d{2}$/.test(start)) return '';
  const need = durMinutes();
  if (need <= 0) return '';
  const total = toMinutes(start) + need;
  if (total > 24 * 60) return ''; // 자정을 넘기는 요청은 만들지 않는다
  const p2 = (n) => String(n).padStart(2, '0');
  return `${p2(Math.floor(total / 60))}:${p2(total % 60)}`;
}

/** 마무리 시간 칸을 다시 그린다. 다른 코드가 읽는 값이라 늘 먼저 맞춰 둔다. */
function syncEndTime() {
  const box = document.getElementById('endTime');
  const e = endFromDuration();
  box.value = e;
  box.placeholder = '—';
  return e;
}

/** 걸리는 시간 고르는 칸을 채운다 */
function fillDurationPickers() {
  const H = document.getElementById('durH');
  const M = document.getElementById('durM');
  H.innerHTML = Array.from({ length: 9 }, (_, i) => `<option value="${i}">${i}</option>`).join('');
  // 5분 단위로 고른다 — 45분·50분 수업이 많다
  M.innerHTML = Array.from({ length: 12 }, (_, i) => i * 5)
    .map((m) => `<option value="${m}">${String(m).padStart(2, '0')}</option>`)
    .join('');
  H.value = '1'; // 가장 흔한 요청이 «1시간» 이다
  M.value = '0';
}

/** 분을 «1시간 30분» 처럼 */
function durText(min) {
  if (!min) return '—';
  const h = Math.floor(min / 60);
  const m = min % 60;
  if (h && m) return `${h}시간 ${m}분`;
  return h ? `${h}시간` : `${m}분`;
}

/** 지금 고른 시간이 확정된 일정과 겹치는가 */
function clashingNow() {
  const s = document.getElementById('startTime').value;
  const e = document.getElementById('endTime').value;
  const m = (t) => (/^\d{1,2}:\d{2}$/.test(String(t || '')) ? Number(String(t).split(':')[0]) * 60 + Number(String(t).split(':')[1]) : null);
  const a1 = m(s);
  const a2 = m(e);
  if (a1 === null || a2 === null || a2 <= a1) return [];
  return (DAY_BUSY.firm || []).filter((x) => {
    const b1 = m(x.startTime);
    const b2 = m(x.endTime);
    return b1 !== null && b2 !== null && a1 < b2 && b1 < a2;
  });
}

function updateHours() {
  const start = document.getElementById('startTime').value;
  const end = syncEndTime(); // 걸리는 시간에서 마무리 시각을 먼저 계산해 둔다
  const h = hoursBetween(start, end);

  // 근무 시간 밖으로 벗어나면 미리 알려 준다
  const v = document.getElementById('date').value;
  const sc = v ? scheduleFor(SETTINGS, v) : null;
  const warn = document.getElementById('timeWarn');
  if (warn) warn.remove();
  const bw = document.getElementById('breakWarn');
  if (bw) bw.remove();

  // 확정된 일정과 겹치면 가장 먼저 알려 준다 (근무시간 경고보다 중요하다)
  const clashBox = document.getElementById('clashBox');
  if (clashBox) {
    const clash = clashingNow();
    clashBox.innerHTML = clash.length
      ? `<div class="notice bad" style="margin:8px 0 0;font-size:16px">
          <b>⛔ 이 시간에는 이미 확정된 일정이 있습니다</b><br>
          ${clash.map((x) => `· ${escapeHtml(x.startTime)}~${escapeHtml(x.endTime)} ${escapeHtml(x.teacherName)} 선생님 · ${escapeHtml(x.taskType)}`).join('<br>')}<br>
          <span style="color:var(--gray-700)">다른 시간을 골라 주세요. 꼭 이 시간이어야 하면 아래에서
          <b>[조율 요청으로 보내기]</b> 를 누르시면 정보부장님이 결정해 주십니다.</span>
        </div>`
      : '';
    const btn = document.getElementById('submit');
    if (btn) btn.textContent = clash.length ? '🤝 조율 요청으로 보내기' : '요청 보내기';
  }

  /* 유휴(휴게) 시간과 겹치면 알려 준다. 막지는 않는다 —
     실제로 그 시간에 꼭 필요한 일이 있을 수 있고, 그때는 코디네이터가 조절한다. */
  if (sc && sc.on && h > 0 && sc.breakHours > 0) {
    const bs = toMinutes(sc.breakStart);
    const be = toMinutes(sc.breakEnd);
    if (toMinutes(start) < be && bs < toMinutes(end)) {
      const div = document.createElement('div');
      div.id = 'breakWarn';
      div.className = 'notice warn';
      div.style.fontSize = '16px';
      div.innerHTML = `요청한 시간이 <b>유휴(휴게) 시간 ${escapeHtml(sc.breakStart)}~${escapeHtml(sc.breakEnd)}</b> 과 겹칩니다.
        그 시간은 쉬는 시간이라 지원이 어렵습니다. 되도록 <b>${escapeHtml(spanText(sc.spans))}</b> 안에서 골라 주세요.`;
      document.getElementById('endTime').closest('.row').after(div);
    }
  }

  if (sc && sc.on && h > 0) {
    const outside = toMinutes(start) < toMinutes(sc.start) || toMinutes(end) > toMinutes(sc.end);
    if (outside) {
      const div = document.createElement('div');
      div.id = 'timeWarn';
      div.className = 'notice warn';
      div.style.fontSize = '16px';
      div.innerHTML = `요청한 시간이 ${sc.weekday}요일 근무 시간(${escapeHtml(sc.start)}~${escapeHtml(sc.end)}) 밖입니다.
        코디네이터가 시간조절을 제안할 수 있습니다.`;
      document.getElementById('endTime').closest('.row').after(div);
    }
  }
}

/** 고른 업무가 어떤 일인지 한 줄로 알려 준다 */
function showTaskHint() {
  const sel = document.getElementById('taskType');
  const hint = sel.selectedOptions[0] ? sel.selectedOptions[0].dataset.hint : '';
  document.getElementById('taskHint').innerHTML = hint
    ? `<div class="notice info" style="margin:8px 0 0;font-size:16px">${escapeHtml(hint)}</div>`
    : '';
}

function toMinutes(t) {
  if (!/^\d{1,2}:\d{2}$/.test(String(t || ''))) return 0;
  const [h, m] = String(t).split(':').map(Number);
  return h * 60 + m;
}

async function submitRequest() {
  clearSay('#msg');
  syncEndTime(); // 걸리는 시간 → 마무리 시각. 칸을 한 번도 만지지 않은 경우를 대비한다
  const body = {
    subject: document.getElementById('subject').value.trim(),
    taskType: document.getElementById('taskType').value,
    date: document.getElementById('date').value,
    startTime: document.getElementById('startTime').value,
    endTime: document.getElementById('endTime').value,
    place: document.getElementById('place').value.trim(),
    operationType: document.getElementById('operationType').value,
    content: document.getElementById('content').value.trim(),
    materials: document.getElementById('materials').value.trim(),
  };

  // 빠진 것이 있으면 알림 창으로 확실히 알려 준 뒤 그 칸으로 데려간다
  if (!body.taskType) {
    await showDialog({ kind: 'warn', title: '업무를 골라 주세요', message: '어떤 도움이 필요한지 먼저 고르셔야 요청을 보낼 수 있습니다.' });
    document.getElementById('taskType').focus();
    return;
  }
  if (!body.content) {
    await showDialog({ kind: 'warn', title: '요청 내용을 적어 주세요', message: '무엇을 도와드려야 하는지 적어 주시면 코디네이터가 준비할 수 있습니다.' });
    document.getElementById('content').focus();
    return;
  }
  /* 걸리는 시간이 0 이면 마무리 시각을 만들 수 없다.
     서버도 endTime 없이는 거부하지만, 화면에서 먼저 알려 주는 편이 낫다. */
  if (durMinutes() <= 0) {
    await showDialog({
      kind: 'warn',
      title: '걸리는 시간을 골라 주세요',
      message: '몇 시간 몇 분쯤 걸릴지 골라 주시면 마무리 시간이 저절로 계산됩니다.',
    });
    document.getElementById('durH').focus();
    return;
  }
  if (!body.startTime || !body.endTime) {
    await showDialog({
      kind: 'warn',
      title: '시작 시간을 확인해 주세요',
      message: '시작 시간을 넣으면 마무리 시간이 저절로 계산됩니다.',
      detail: '자정을 넘기는 시간은 넣을 수 없습니다.',
    });
    document.getElementById('startTime').focus();
    return;
  }

  /* 확정된 일정과 겹치면 서버가 409 로 막는다.
     그래도 그 시간이 꼭 필요하면 **조율 요청**으로 다시 보낸다 —
     누구를 먼저 도울지는 코디네이터가 아니라 정보부장이 정한다. */
  const clash = clashingNow();
  if (clash.length) {
    const ok = await showDialog({
      kind: 'warn',
      title: '이 시간에는 이미 확정된 일정이 있습니다',
      message:
        clash.map((x) => `· ${x.startTime}~${x.endTime} ${x.teacherName} 선생님 · ${x.taskType}`).join('\n') +
        '\n\n그래도 이 시간이 꼭 필요하시면 조율 요청으로 보낼 수 있습니다.',
      detail: '조율 요청은 정보부장님이 보시고 어느 쪽을 먼저 할지 결정해 알려 주십니다.',
      button: '조율 요청으로 보내기',
      cancel: '시간 다시 고르기',
    });
    if (!ok) return document.getElementById('startTime').focus();
    body.coordinate = true;
  }

  const btn = document.getElementById('submit');
  btn.disabled = true;
  try {
    const r = await api('/api/requests', { method: 'POST', body });
    clearSay('#msg');
    document.getElementById('content').value = '';
    document.getElementById('materials').value = '';
    loadMyList();
    loadDayBusy(body.date);
    const coordinating = r.item && r.item.status === 'coordinating';
    await showDialog({
      kind: 'ok',
      title: coordinating ? '조율 요청을 보냈습니다' : '요청을 보냈습니다',
      message: `${dateKo(body.date)} ${body.startTime}~${body.endTime} (${durText(durMinutes())})\n${body.taskType}`,
      detail: coordinating
        ? `요청번호 ${r.id}\n정보부장님이 결정하시면 아래 [내 요청 진행 상황]의 상태가 바뀝니다.`
        : `요청번호 ${r.id}\n코디네이터가 확인하면 아래 [내 요청 진행 상황]의 상태가 바뀝니다.`,
    });
  } catch (e) {
    await showDialog({
      kind: 'bad',
      title: '요청을 보내지 못했습니다',
      message: e.message,
      detail: '고친 뒤 다시 [요청 보내기]를 눌러 주세요. 계속 안 되면 정보부장님께 알려 주세요.',
    });
  } finally {
    btn.disabled = false;
  }
}

function resetForm() {
  for (const id of ['place', 'content', 'materials']) document.getElementById(id).value = '';
  document.getElementById('taskType').value = '';
  document.getElementById('durH').value = '1'; // 걸리는 시간도 기본값으로
  document.getElementById('durM').value = '0';
  updateHours();
  showTaskHint();
  clearSay('#msg');
}

/* ---------------- 내 요청 진행 상황 ---------------- */
async function loadMyList() {
  const box = document.getElementById('myList');
  const list = await api(`/api/requests?teacherId=${encodeURIComponent(ME.memberId)}`);
  if (!list.length) {
    box.innerHTML = '<div class="empty">아직 보낸 요청이 없습니다.</div>';
    return;
  }
  list.reverse(); // 최근 것이 위로
  box.innerHTML = list.map(renderMyItem).join('');

  box.querySelectorAll('[data-agree]').forEach((btn) =>
    btn.addEventListener('click', () => respondReschedule(btn.dataset.agree, true)),
  );
  box.querySelectorAll('[data-cancel]').forEach((btn) =>
    btn.addEventListener('click', () => respondReschedule(btn.dataset.cancel, false)),
  );
}

function renderMyItem(r) {
  const reply = r.reply || {};
  let extra = '';

  if (r.status === 'rescheduled') {
    extra = `
      <div class="notice warn" style="margin:12px 0 0">
        <b>코디네이터가 시간조절을 제안했습니다</b>
        바꾼 시간 : <b>${dateKo(reply.newDate)} ${escapeHtml(reply.newStartTime)}~${escapeHtml(reply.newEndTime)}</b>
        ${reply.reason ? `<br>사유 : ${escapeHtml(reply.reason)}` : ''}
      </div>
      <div class="btnbar" style="margin-top:10px">
        <button class="ok small" data-agree="${r.id}">이 시간으로 좋습니다</button>
        <button class="ghost small" data-cancel="${r.id}">요청을 취소합니다</button>
      </div>`;
  } else if (r.status === 'coordinating') {
    // 시간이 겹치거나 처리가 어려워 정보부장님이 결정을 기다리는 상태
    extra = `
      <div class="notice warn" style="margin:12px 0 0">
        <b>🤝 정보부장님이 조율 중입니다</b>
        ${
          (r.conflictWith || []).length
            ? `<br>같은 시간에 이미 확정된 일정이 있어 어느 쪽을 먼저 할지 정하고 있습니다.<br>
               ${r.conflictWith.map((c) => `· ${escapeHtml(c.startTime)}~${escapeHtml(c.endTime)} ${escapeHtml(c.teacherName)} 선생님`).join('<br>')}`
            : reply.reason
              ? `<br>${escapeHtml(reply.reason)}`
              : ''
        }
        <br><span style="font-size:15px">결정되면 이 자리에 결과가 표시됩니다.</span>
      </div>`;
  } else if (r.status === 'closed' || r.status === 'rejected') {
    extra = `<div class="notice" style="margin:12px 0 0"><b>이번에는 진행하지 못했습니다</b>
      ${reply.reason ? `<br>${escapeHtml(reply.reason)}` : ''}
      ${reply.by ? `<br><span style="font-size:15px">${escapeHtml(reply.by)}</span>` : ''}</div>`;
  } else if (r.status === 'accepted') {
    extra = `<div class="notice ok" style="margin:12px 0 0">확정되었습니다. ${reply.reason ? escapeHtml(reply.reason) : '그 시간에 지원해 드립니다.'}</div>`;
  }

  return `
  <div class="item ${r.status === 'rescheduled' || r.status === 'coordinating' ? 'hi' : ''}">
    <h3>${dateKo(r.date)} ${escapeHtml(r.startTime)}~${escapeHtml(r.endTime)}
      <span class="tag ${r.status}">${STATUS_KO[r.status] || r.status}</span></h3>
    <dl>
      <dt>업무</dt><dd>${escapeHtml(r.taskType)}</dd>
      <dt>장소</dt><dd>${escapeHtml(r.place || '-')} · ${escapeHtml(r.operationType || '')}</dd>
      <dt>요청 내용</dt><dd>${escapeHtml(r.content)}</dd>
      <dt>요청번호</dt><dd>${escapeHtml(r.id)} · ${escapeHtml(r.createdAt)}</dd>
    </dl>
    ${extra}
  </div>`;
}

async function respondReschedule(id, agree) {
  if (!agree) {
    const ok = await showDialog({
      kind: 'warn',
      title: '요청을 취소할까요?',
      message: '이 요청을 취소하면 코디네이터에게 취소로 표시됩니다.',
      detail: '필요하면 새로 요청하실 수 있습니다.',
      button: '요청 취소',
      cancel: '그만두기',
    });
    if (!ok) return;
  }
  try {
    await api(`/api/requests/${encodeURIComponent(id)}/confirm`, { method: 'POST', body: { agree } });
    loadMyList();
    await showDialog(
      agree
        ? { kind: 'ok', title: '확정되었습니다', message: '코디네이터가 제안한 시간으로 확정했습니다.' }
        : { kind: 'info', title: '요청을 취소했습니다', message: '필요하면 새로 요청해 주세요.' },
    );
  } catch (e) {
    await showDialog({ kind: 'bad', title: '처리하지 못했습니다', message: e.message });
  }
}
