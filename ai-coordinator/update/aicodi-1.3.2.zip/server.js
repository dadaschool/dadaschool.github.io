/**
 * AI교육 코디네이터 업무 관리 서버
 * ----------------------------------------------------------------
 * 학교 내부망(교무실 PC) 전용 웹 서버입니다.
 * Node.js 내장 모듈만 사용하므로 `npm install` 이 필요하지 않습니다.
 * (학교 PC에서 패키지 설치가 막혀도 그냥 돌아가게 하려는 의도입니다)
 *
 * 실행 :  node server.js      또는  서버_실행.bat 더블클릭
 * 접속 :  선생님 → http://<교무실PC주소>:4000/
 */
'use strict';

const http = require('node:http');
const fs = require('node:fs');
const fsp = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const os = require('node:os');
const dns = require('node:dns/promises');
const { execFile } = require('node:child_process');
const net = require('node:net');
const tls = require('node:tls');
const { readTable, unzip } = require('./lib/sheet-read');
const { parseRoster, ROLE_LABEL } = require('./lib/roster');
const { makeZip } = require('./lib/backup');
const Update = require('./lib/update');

/* ================================================================
 * 🔴 학교망이 https 를 가로챌 때 — 윈도우가 믿는 인증서를 함께 쓴다
 * ----------------------------------------------------------------
 * 학교·교육청 망에는 오가는 https 를 열어 보는 장비(방화벽·프록시)가 있고
 * 그 장비가 **자기 인증서로 연결을 다시 묶는다.** 그 인증서는 Windows 에
 * 깔려 있어 브라우저는 멀쩡하지만, Node 는 자기 목록만 보므로 거절한다 :
 *
 *     SELF_SIGNED_CERT_IN_CHAIN
 *
 * 그러면 **「하루 한 번 업데이트 확인」이 조용히 실패한다** — 실패를 일부러
 * 조용히 넘기도록 만들어 두었기 때문에(매일 아침 못 고치는 경고를 보여 주지
 * 않으려는 것) 학교에서는 **새 판 알림이 영영 안 뜬다.**
 *
 * 👉 켤 때 Windows 인증서 저장소를 **기본 목록에 얹는다.**
 *    브라우저가 믿는 것과 같은 인증서라 안전하고, 이러면 `fetch` 를 쓰는
 *    확인·내려받기가 모두 그대로 살아난다(실제로 재서 확인 : 실패 → 200).
 *
 * ⚠ 절대 지키는 것 :
 *   · **더하기만 한다.** 원래 목록(bundled)을 함께 넣어 잃는 것이 없게 한다.
 *   · **인증서 검사를 끄지 않는다.** rejectUnauthorized 를 건드리지 않는다.
 *   · 이 API 는 Node 22.15+ / 24 부터다(이 앱은 node>=20). **없으면 그냥 지나간다.**
 *   · 무슨 일이 있어도 **서버가 안 켜지는 일은 없어야 한다** — 통째로 try 로 감쌌다.
 * ================================================================ */
const SSL_DIR = path.join(__dirname, 'data', 'ssl');
const SSL_CA_FILE = path.join(SSL_DIR, 'school-ca.pem'); // 시스템관리자가 [설정] 에서 올린 학교 보안 인증서

/* 학교가 올린 인증서를 읽는다(없으면 null). 못 읽는 파일이면 던지므로 null.
   ⚠ 폴더·파일 이름을 영문으로 둔 이유는 lib/update.js 와 같다 — 기계가 읽고,
   `서버_실행.bat` 의 `NODE_EXTRA_CA_CERTS` 줄이 이 경로를 그대로 가리킨다. */
function 학교인증서읽기() {
  try {
    if (!fs.existsSync(SSL_CA_FILE)) return null;
    const pem = fs.readFileSync(SSL_CA_FILE, 'utf8');
    new crypto.X509Certificate(pem); // 인증서가 아니면 여기서 던진다
    return pem;
  } catch {
    return null;
  }
}

/* 👉 켤 때 Windows 인증서 저장소 + (있으면) 학교가 올린 인증서를 기본 목록에 얹는다.
   ⚠ 절대 지키는 것 : 더하기만 한다(bundled 를 함께 넣는다) · rejectUnauthorized 를 건드리지 않는다 ·
      setDefaultCACertificates 가 없는 낡은 Node 에서는 그냥 지나간다(그 PC 는 `NODE_EXTRA_CA_CERTS` 로 푼다). */
function 보안인증서준비() {
  const 학교 = 학교인증서읽기();
  const auto = typeof tls.setDefaultCACertificates === 'function' &&
               typeof tls.getCACertificates === 'function';
  if (!auto) return { ok: false, why: 'node가 낡음', auto: false, 학교있음: !!학교, 수: 0 };
  try {
    const 시스템 = tls.getCACertificates('system') || [];
    const 원래 = tls.getCACertificates('bundled') || [];
    const list = [...원래, ...시스템];
    if (학교) list.push(학교);
    tls.setDefaultCACertificates(list);
    return { ok: true, 수: 시스템.length, auto: true, 학교있음: !!학교 };
  } catch (e) {
    return { ok: false, why: String((e && e.message) || e), auto: true, 학교있음: !!학교, 수: 0 };
  }
}
let 인증서결과 = 보안인증서준비();

const PORT = Number(process.env.PORT) || 4000;
const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const DATA_DIR = path.join(ROOT, 'data');
const PHOTO_DIR = path.join(DATA_DIR, 'photos');
const SIGN_DIR = path.join(DATA_DIR, 'signs');
const BACKUP_DIR = path.join(DATA_DIR, 'backup');

/* ================================================================
 * 1. 업무 목록 — 「AI교육 코디네이터 업무편람 가이드」에 근거
 *    taskTypes : 선생님이 고르는 업무 5가지 (각각 업무편람 3대 영역으로 이어진다)
 *    areas     : 결과보고서에 찍는 3대 영역 이름
 *    blocked   : 수행 제한 범위 (업무편람 II-2) → 접수 자체를 막는다
 * ================================================================ */
const CATALOG = {
  /**
   * 선생님이 고르는 업무 — 다섯 가지로 단순하게 (2026-07-29 사용자 지시)
   * `area` 는 결과보고서 '운영형태' 칸에 찍히는 업무편람 3대 영역이다.
   * 실제 영역이 다르면 코디네이터가 활동 기록에서 고칠 수 있다.
   */
  taskTypes: [
    { name: '수업 지원', area: 'A', hint: '수업 중 학생 활동·실습 보조, 모둠 활동 지원, 질의응답' },
    { name: '수업자료 제작 지원', area: 'B', hint: '데이터 수집·가공, 예제·활동자료 제작, 사례 조사' },
    { name: '기기 활용 지원', area: 'A', hint: '태블릿·PC·AI 도구 준비와 활용 안내, 기자재·공간 관리' },
    { name: '플랫폼 관리', area: 'A', hint: 'AI 플랫폼·디지털교과서 계정 발급과 학급 편성, 접속 문제 확인' },
    { name: '행사 지원', area: 'A', hint: '공모전·경진대회·캠프·발표회·체험부스 운영 보조' },
    { name: '기타', area: 'C', hint: '위에 없는 업무 — 요청 내용에 자세히 적어 주세요' },
  ],
  // 결과보고서 표기용 3대 영역 이름 (업무편람 Ⅲ장)
  areas: [
    { code: 'A', name: '학생 참여형 AI교육 활동 지원' },
    { code: 'B', name: '교원의 AI 수업 및 역량 강화 지원' },
    { code: 'C', name: '대외 협력 및 성과 관리 행정 지원' },
  ],
  // 요청하면 안 되는 업무 + 그 근거 (선생님 화면에 그대로 보여 준다)
  blocked: [
    { task: '교사 없이 단독으로 수업 진행', why: '코디네이터는 교사를 대체하는 인력이 아닙니다. 교사가 함께 있어야 합니다.' },
    { task: '교사 없이 단독으로 동아리 운영', why: '동아리 단독 운영은 수행 제한 범위입니다.' },
    { task: '학생 평가 및 성적 처리', why: '평가·성적 처리는 교원의 고유 업무로 대신할 수 없습니다.' },
    { task: '평가 산출물 정리·관리', why: '평가 산출물의 정리·관리도 수행 제한 범위입니다.' },
    { task: '학생 생활지도', why: '생활지도는 교원의 고유 업무입니다.' },
    { task: '학생의 AI 결과물을 대신 제작', why: '결과물은 학생이 직접 만들도록 지원만 합니다.' },
    { task: '학부모 상담 및 민원 대응', why: '학부모 상담·민원 대응은 수행 제한 범위입니다.' },
    { task: '학교 행정업무 전담', why: 'AI교육 관련 행정 "지원"은 가능하지만 학교 행정업무를 전담할 수 없습니다.' },
  ],
  operationTypes: ['정규수업', '방과후', '행사', '교사 연수', '기타'],
  legalNote: '근거: AI교육 코디네이터 업무편람 가이드 Ⅱ-2(수행 제한 범위), Ⅲ(주요 업무)',
};

/* ================================================================
 * 2. 기본 설정값 — data/settings.json 이 없을 때 만들어 주는 뼈대
 * ================================================================ */
/**
 * 코디네이터 업무 시간은 '요일별'로 정합니다.
 * 근로계약서 서식의 "주4일 일 3시간, 주1일 일 2시간" 같은 형태를 그대로 담기 위한 구조입니다.
 * 키는 요일 번호(0=일 … 6=토)입니다.
 */
/* 요일별 근무 시간표.
   `breakStart`·`breakEnd` 는 **유휴(휴게) 시간대**다. 비워 두면 휴게 없음.
   근로기준법 제54조 : 4시간 근무 시 30분 이상, 8시간 시 1시간 이상을 근무 도중에 준다.
   휴게시간은 근로시간이 아니라 **인건비와 주 15시간 판정에서 빠진다**(2026-08-21 사용자 결정). */
const DEFAULT_SCHEDULE = {
  0: { on: false, start: '', end: '', breakStart: '', breakEnd: '' },
  1: { on: true, start: '08:30', end: '11:30', breakStart: '', breakEnd: '' },
  2: { on: true, start: '08:30', end: '11:30', breakStart: '', breakEnd: '' },
  3: { on: true, start: '08:30', end: '11:30', breakStart: '', breakEnd: '' },
  4: { on: true, start: '08:30', end: '11:30', breakStart: '', breakEnd: '' },
  5: { on: true, start: '08:30', end: '10:30', breakStart: '', breakEnd: '' },
  6: { on: false, start: '', end: '', breakStart: '', breakEnd: '' },
};

/** 이 프로그램의 판. 업그레이드할 때 이 값과 깃허브의 값을 비교한다.
 *  ⚠ 새 판을 낼 때 **이 숫자를 올려야** 학교 PC 가 «새 판이 있다» 고 알아본다.
 *     tools/업데이트_만들기.js 가 이 값을 읽어 파일 이름에 쓴다. */
const APP_VERSION = '1.3.2';

/** 업그레이드를 받아 오는 곳. 시험할 때는 UPDATE_URL 로 바꿔 쓴다. */
const UPDATE_BASE_URL = process.env.UPDATE_URL || 'https://dadaschool.github.io/ai-coordinator/update';

const DEFAULT_SETTINGS = {
  school: '○○중학교',
  schoolYear: new Date().getFullYear(),
  lastBackupAt: '', // 마지막으로 백업 파일을 내려받은 때
  manager: { name: '', position: '시스템관리자', pinHash: '', signFile: '' },
  coordinator: {
    name: '',
    signFile: '',
    contractStart: '',
    contractEnd: '',
    hourlyWage: 0,
    schedule: structuredClone(DEFAULT_SCHEDULE),
    // 그 주만 다르게 쓰는 시간표 : { "2026-08-17"(그 주 월요일) : { schedule: {...}, note: "" } }
    weekOverrides: {},
    otherSchoolHours: 0, // 타 학교 근무시간(주당) — 15시간 미만 판단에 합산
    // 아래 두 값은 schedule 에서 자동으로 계산해 채웁니다(화면에서 직접 고치지 않습니다)
    weeklyHours: 0,
    workDays: [],
  },
  budget: { planned: 0, note: '' },
  // 선생님들께 알려 줄 주소 이름.
  // 비워 두면 **설치된 PC의 컴퓨터 이름을 처음 켤 때 자동으로 넣는다**(그 이름은 학교망에서 바로 풀린다).
  // 더 짧은 이름으로 바꾸고 싶으면 설정 화면에서 고칠 수 있고, 그때는 그 이름이 풀리는지 확인한다.
  shareHost: '',
  places: ['컴퓨터1실', '컴퓨터2실', '도서관', '시청각실', '교실'],
  /**
   * 예산 편성 기본값 — 교육청 지원비 신청 서식을 그대로 옮긴 것.
   * 설정 화면에서는 **금액만 고치면 되도록** 처음부터 이 줄들이 들어가 있다.
   * 집행액은 여기 없다 — 집행은 [예산 집행] 탭에서 **건별로** 적고, 정산서가 그 합을 쓴다.
   */
  report: {
    background: '',
    purpose: '',
    outputs: '',
    budgetRows: [
      { id: 'b1', item: '보조인력 인건비', detail: 'AI교육 코디네이터 인건비', planned: 11200000, note: '' },
      { id: 'b2', item: '보조인력 인건비', detail: '고용보험·산재보험·국민연금', planned: 400000, note: '' },
      { id: 'b3', item: '보조인력 인건비', detail: '주휴수당', planned: 2300000, note: '' },
      { id: 'b4', item: '운영비', detail: '교구구입', planned: 3000000, note: '' },
      { id: 'b5', item: '운영비', detail: '행사진행', planned: 1000000, note: '' },
    ],
  },
  rosterInfo: null, // 마지막으로 올린 명단 파일 정보
  updatedAt: '',
};

/* ================================================================
 * 3. 작은 도우미들
 * ================================================================ */
const WEEK_KO = ['일', '월', '화', '수', '목', '금', '토'];

function ensureDirs() {
  for (const d of [DATA_DIR, PHOTO_DIR, SIGN_DIR, BACKUP_DIR, SSL_DIR]) {
    fs.mkdirSync(d, { recursive: true });
  }
}

/** 오늘 날짜를 YYYY-MM-DD 로 (학교 PC의 지역 시간 = 한국 시간 기준) */
function todayStr(d = new Date()) {
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

function nowStamp() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${todayStr(d)} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

/** "HH:MM" → 분 */
function toMin(hhmm) {
  if (!/^\d{1,2}:\d{2}$/.test(String(hhmm || ''))) return null;
  const [h, m] = String(hhmm).split(':').map(Number);
  return h * 60 + m;
}

/** 출근~퇴근 시간(시간 단위, 소수 1자리) */
function hoursBetween(start, end) {
  const a = toMin(start);
  const b = toMin(end);
  if (a === null || b === null || b <= a) return 0;
  return Math.round(((b - a) / 60) * 10) / 10;
}

/** 그 날짜가 속한 주(월요일 시작)의 월요일·일요일 날짜 */
function weekRange(dateStr) {
  const d = new Date(dateStr + 'T00:00:00');
  if (Number.isNaN(d.getTime())) return null;
  const dow = d.getDay(); // 0=일
  const backToMon = dow === 0 ? 6 : dow - 1;
  const mon = new Date(d);
  mon.setDate(d.getDate() - backToMon);
  const sun = new Date(mon);
  sun.setDate(mon.getDate() + 6);
  return { start: todayStr(mon), end: todayStr(sun) };
}

/** 파일에서 JSON 읽기 (없으면 기본값) */
async function readJson(file, fallback) {
  try {
    const raw = await fsp.readFile(file, 'utf8');
    return JSON.parse(raw);
  } catch {
    return structuredClone(fallback);
  }
}

/** 원자적 쓰기 + 하루 1회 자동 백업 (덮어쓰기 사고 방지) */
async function writeJson(file, data) {
  const tmp = file + '.tmp';
  await fsp.writeFile(tmp, JSON.stringify(data, null, 2), 'utf8');
  await fsp.rename(tmp, file);
  const backup = path.join(BACKUP_DIR, `${todayStr()}-${path.basename(file)}`);
  try {
    await fsp.access(backup);
  } catch {
    await fsp.copyFile(file, backup).catch(() => {});
  }
}

/* ================================================================
   ⏰ 하루 한 번 업데이트 서버 확인 (2026-08-25 사용자 지시)
   ----------------------------------------------------------------
   *"하루에 한번씩 업데이터 서버 상태 점검해서 시스템관리자가 로그인하면
     업데이트 내용이 있다고 안내하는 메세지를 띄우는 기능을 추가해"*

   🔴 **로그인을 늦추지 않는다.** 로그인할 때 인터넷을 다녀오면
      학교망이 막힌 곳에서는 **로그인이 몇십 초씩 멈춘다**(실제로 `fetch failed` 까지
      오래 걸리는 것을 봤다). 그래서 확인은 **뒤에서 따로** 하고,
      로그인은 **마지막에 확인해 둔 결과**를 그대로 돌려준다.
   🔴 **실패는 조용히 넘긴다.** 학교망은 프록시·SSL 가로채기·차단으로 막히는 일이 잦다
      (이 문서의 [«fetch failed»] 참고). 그때마다 시스템관리자에게 오류를 띄우면
      **매일 아침 못 고치는 경고를 보게 된다.** 못 받으면 그냥 «모른다» 로 둔다.
   ⚠ 이 파일은 **`FILES` 에 넣지 않는다** — 근무기록이 아니라 «마지막으로 확인한 값» 이라
      백업에 담을 것이 아니다(되돌려도 다시 확인하면 그만이다).
   ================================================================ */
const UPDATE_CACHE = path.join(DATA_DIR, 'update-check.json');
const 하루 = 24 * 60 * 60 * 1000;

/** 마지막 확인 결과 (없거나 깨졌으면 빈 값) */
async function loadUpdateCache() {
  try {
    const t = await fsp.readFile(UPDATE_CACHE, 'utf8');
    const j = JSON.parse(t);
    return j && typeof j === 'object' ? j : {};
  } catch {
    return {};
  }
}

/**
 * 업데이트 서버를 확인해 결과를 적어 둔다.
 * @param {boolean} force  하루가 안 지났어도 다시 확인할지
 * @returns {object} 적어 둔 결과
 */
async function checkUpdateDaily(force = false) {
  const 이전 = await loadUpdateCache();
  const 지난때 = Date.parse(이전.checkedAt || '') || 0;
  if (!force && Date.now() - 지난때 < 하루) return 이전; // 아직 하루가 안 지났다

  const 결과 = { checkedAt: new Date().toISOString(), current: APP_VERSION };
  try {
    const info = await Update.fetchLatest(UPDATE_BASE_URL);
    결과.latest = info.version;
    결과.date = info.date || '';
    결과.notes = Array.isArray(info.notes) ? info.notes.slice(0, 30) : [];
    결과.size = Number(info.size) || 0;
    결과.newer = Update.compareVersion(info.version, APP_VERSION) > 0;
    결과.ok = true;
  } catch (e) {
    /* 못 받았다 — 조용히 «모른다» 로 둔다. 이유만 적어 둔다(진단용) */
    결과.ok = false;
    결과.error = String((e && e.message) || e);
    결과.newer = false;
  }
  try {
    await fsp.mkdir(DATA_DIR, { recursive: true });
    await writeJson(UPDATE_CACHE, 결과);
  } catch {
    /* 못 적어도 앱은 그대로 돌아간다 */
  }
  if (결과.newer) {
    console.log(`\n  ● 새 판이 나왔습니다 : ${APP_VERSION} → ${결과.latest}`);
    console.log('     [점검·설정] → ⬆ 업그레이드 에서 받으실 수 있습니다.\n');
  }
  return 결과;
}

/** 로그인 응답에 붙일 «알림» — 새 판이 있을 때만 만든다 */
async function updateNotice() {
  const c = await loadUpdateCache();
  const 지난때 = Date.parse(c.checkedAt || '') || 0;
  /* 하루가 지났으면 **뒤에서** 새로 확인한다(로그인은 기다리지 않는다) */
  if (Date.now() - 지난때 >= 하루) {
    checkUpdateDaily().catch(() => {});
  }
  if (!c.newer || !c.latest) return null;
  /* 지금 돌고 있는 판과 다시 견준다 — 확인해 둔 뒤에 업그레이드했을 수 있다 */
  if (Update.compareVersion(c.latest, APP_VERSION) <= 0) return null;
  return {
    current: APP_VERSION,
    latest: c.latest,
    date: c.date || '',
    notes: Array.isArray(c.notes) ? c.notes : [],
    size: c.size || 0,
    checkedAt: c.checkedAt || '',
  };
}

const FILES = {
  settings: path.join(DATA_DIR, 'settings.json'),
  requests: path.join(DATA_DIR, 'requests.json'),
  logs: path.join(DATA_DIR, 'logs.json'),
  members: path.join(DATA_DIR, 'members.json'),
  spending: path.join(DATA_DIR, 'spending.json'), // 예산 집행 내역 (건별)
};

const loadRequests = () => readJson(FILES.requests, []);
const loadLogs = () => readJson(FILES.logs, []);
const loadMembers = () => readJson(FILES.members, []);
const loadSpending = () => readJson(FILES.spending, []);

/** 설정을 읽을 때 요일별 시간에서 주당 시간·근무요일을 다시 계산해 둔다 */
/**
 * 설정 파일에 빠진 항목을 기본값으로 채운다.
 *
 * **왜 필요한가** : 설정 파일이 온전하지 않을 수 있다 —
 * 예전 판으로 만든 백업을 되돌렸거나, 파일을 손으로 고쳤거나, 저장 중에 PC가 꺼졌을 때.
 * 예전에는 `coordinator` 만 채워서, `manager` 가 없는 파일을 만나면
 * `manager.pinHash` 를 읽다가 서버가 통째로 멈추고 **로그인조차 되지 않았다**(2026-08-08 확인).
 * 한 칸이라도 비면 앱 전체가 멈추므로 **모든 칸을 여기서 채운다.**
 */
function withDefaults(raw) {
  const s = raw && typeof raw === 'object' ? raw : {};
  const d = DEFAULT_SETTINGS;

  if (typeof s.school !== 'string' || !s.school) s.school = d.school;
  if (!Number.isFinite(Number(s.schoolYear))) s.schoolYear = d.schoolYear;
  if (typeof s.lastBackupAt !== 'string') s.lastBackupAt = '';
  if (typeof s.shareHost !== 'string') s.shareHost = d.shareHost;
  if (!Array.isArray(s.places)) s.places = [...d.places];

  // 객체로 된 칸들은 안쪽 항목까지 채운다
  for (const key of ['manager', 'coordinator', 'budget', 'report']) {
    if (!s[key] || typeof s[key] !== 'object' || Array.isArray(s[key])) s[key] = structuredClone(d[key]);
    else for (const [k, v] of Object.entries(d[key])) if (s[key][k] === undefined) s[key][k] = structuredClone(v);
  }
  if (!s.coordinator.schedule || typeof s.coordinator.schedule !== 'object') {
    s.coordinator.schedule = structuredClone(DEFAULT_SCHEDULE);
  }
  /* 예산 편성 줄 — **비어 있으면 서식 기본값을 채운다.**
     "설정 화면에서 금액만 고치면 되게" 하려는 것이고, 예전 판에서 올라온 설치본
     (`budgetRows: []`)도 저장을 한 번 하지 않아도 [예산 집행] 탭이 바로 동작한다. */
  if (!Array.isArray(s.report.budgetRows) || !s.report.budgetRows.length) {
    s.report.budgetRows = structuredClone(DEFAULT_SETTINGS.report.budgetRows);
  }
  if (!s.coordinator.weekOverrides || typeof s.coordinator.weekOverrides !== 'object') {
    s.coordinator.weekOverrides = {};
  }
  return s;
}

async function loadSettings() {
  const s = withDefaults(await readJson(FILES.settings, DEFAULT_SETTINGS));
  applySchedule(s);
  return s;
}

/** 시간표 하나(요일 7칸) → { hours: 주당 합계, days: 근무 요일 목록 } */
/* ----------------------------------------------------------------
 * 유휴(휴게) 시간을 뺀 근무시간 계산 — **여기 한 곳에서만 한다**
 *
 * 세 가지 숫자를 구분해야 한다. 섞으면 인건비가 틀어진다.
 *   stay : 체류시간   출근~퇴근 (출근기록부에 찍는 값)
 *   brk  : 휴게시간   근로시간이 아니다
 *   work : 근무시간   stay - brk  (인건비 · 주 15시간 판정에 쓰는 값)
 *
 * 근로기준법 제54조 · 업무편람 Ⅳ-2-마 : 4시간 근무 시 30분 이상을 **근무 도중에** 준다.
 * 그래서 휴게는 시각 범위로 받는다 — 선생님 화면에 "언제 쉬는지" 를 보여 줘야 하기 때문이다.
 * ---------------------------------------------------------------- */

/**
 * @returns {{stay:number, brk:number, work:number, spans:Array<[string,string]>, error:string}}
 *   spans : 휴게를 뺀 실제 근무 구간 (예 [['09:30','12:00'],['12:30','13:30']])
 */
function dayTime(start, end, breakStart, breakEnd) {
  const stay = hoursBetween(start, end);
  const out = { stay, brk: 0, brkMin: 0, work: stay, spans: stay > 0 ? [[start, end]] : [], error: '' };
  if (stay <= 0) return out;

  // 휴게를 비워 두면 휴게 없음 (한쪽만 넣은 것은 실수이므로 알려 준다)
  const hasS = /^\d{1,2}:\d{2}$/.test(String(breakStart || ''));
  const hasE = /^\d{1,2}:\d{2}$/.test(String(breakEnd || ''));
  if (!hasS && !hasE) return out;
  if (hasS !== hasE) {
    out.error = '휴게 시간은 시작과 끝을 모두 넣어 주세요.';
    return out;
  }

  const s = toMin(start);
  const e = toMin(end);
  const bs = toMin(breakStart);
  const be = toMin(breakEnd);
  if (be <= bs) {
    out.error = '휴게 끝 시각이 시작 시각보다 늦어야 합니다.';
    return out;
  }
  // 휴게는 **근무 시간 안에** 있어야 한다. 밖이면 조용히 빼지 않고 알려 준다
  if (bs < s || be > e) {
    out.error = `휴게 시간(${breakStart}~${breakEnd})이 근무 시간(${start}~${end}) 밖입니다.`;
    return out;
  }
  /* 🔴 유휴시간을 **출근 직후·퇴근 직전에 붙여도 된다**(2026-08-24 사용자 지시).
     한때 «근무 도중이어야 한다»(근로기준법 제54조 제2항)로 막았는데 되돌렸다 —
     *"서류상으로 남기는 기록이라 출근기록부 인쇄시만 출퇴근 시간 기록되면 됨"*.
     ⚠ 그래서 **출근~퇴근 사이에 유휴가 없는 경우가 생긴다.**
       예) 09:00~13:30 · 유휴 13:00~13:30 → 실제 근무는 09:00~13:00
       출근기록부는 그래도 `09:00 / 13:30` 을 찍는다(체류시간 문서이므로 의도한 것).
     ⚠ 이 검사를 «법 때문에» 다시 넣지 말 것 — 사용자가 알고 정한 것이다. */

  out.brkMin = be - bs; //  화면에 «분» 으로 보여 줄 때 쓴다
  out.brk = Math.round((out.brkMin / 60) * 10) / 10; //  인건비 계산용(0.1시간 단위)
  //  ⚠ `brk * 60` 으로 분을 되돌리지 말 것 — 20분이 0.3시간으로 반올림되어 «18분» 이라고 찍힌다.
  out.work = Math.round((stay - out.brk) * 10) / 10;
  if (out.work <= 0) {
    out.error = '휴게 시간이 근무 시간과 같거나 더 깁니다.';
    out.work = 0;
  }
  // 휴게가 딱 앞이나 뒤에 붙으면 구간이 하나만 남는다
  const spans = [];
  if (bs > s) spans.push([start, breakStart]);
  if (be < e) spans.push([breakEnd, end]);
  out.spans = spans.length ? spans : [];
  return out;
}

/** 시각 범위를 사람이 읽는 글로 — 예 "09:30~12:00, 12:30~13:30" */
function spanText(spans) {
  return (spans || []).map(([a, b]) => `${a}~${b}`).join(', ');
}

/* ----------------------------------------------------------------
 * 법정 휴게 — 4시간 근무 시 30분 이상, 8시간 근무 시 1시간 이상
 *   근로기준법 제54조 · 업무편람 Ⅳ-2-마
 * 2026-08-22 사용자 지시로 **경고에서 «막기» 로 올렸다** —
 * "4시간 이상이면 무조건 유휴시간 있어야 해".
 * ⚠ 기준은 반드시 **분(`brkMin`)** 으로 본다. 반올림한 시간(`brk`)으로 재면
 *   29분이 0.5시간이 되어 검사를 그대로 통과한다.
 * ---------------------------------------------------------------- */
function requiredBreakMin(stayHours) {
  if (stayHours >= 8) return 60;
  if (stayHours >= 4) return 30;
  return 0;
}

/**
 * 유휴시간이 없는 기록을 «퇴근을 늦춰» 고칠 때, 몇 분을 붙여야 하는가.
 * 근무시간(인건비)은 그대로 두고 체류시간만 늘리는 방식이다.
 *
 * ⚠ 늘린 뒤의 체류시간으로 기준이 한 칸 올라가는 경우가 있다 —
 *   체류 7.5시간에 30분을 붙이면 8시간이 되어 **60분이 필요**해진다.
 *   그래서 한 번 더 확인해 큰 쪽을 쓴다.
 */
function extendMinutesFor(stayHours) {
  let need = requiredBreakMin(stayHours);
  if (!need) return 0;
  for (let i = 0; i < 3; i++) {
    const again = requiredBreakMin(stayHours + need / 60);
    if (again <= need) break;
    need = again;
  }
  return need;
}

/** 법정 휴게가 모자라면 안내 문장, 넉넉하면 '' */
function breakShortage(t) {
  const need = requiredBreakMin(t.stay);
  if (!need || t.brkMin >= need) return '';
  const 기준 = need === 60 ? '8시간' : '4시간';
  return (
    `${t.stay}시간 근무하는 날은 유휴(휴게) 시간을 ${need}분 이상 넣어야 합니다` +
    `${t.brkMin ? ` (지금 ${t.brkMin}분)` : ' (지금 없음)'}.\n` +
    `${기준} 이상 근무하면 휴게시간을 근무 도중에 주어야 합니다 — 근로기준법 제54조 · 업무편람 Ⅳ-2-마.`
  );
}

/**
 * 예전 활동 기록에는 휴게 칸이 없다(2026-08-21 이전).
 * 그때는 `hours` 가 체류시간이었으므로 **체류 = 근무, 휴게 0** 으로 본다.
 * 이걸 빼먹으면 예전 기록의 출근기록부 활동시간이 빈칸으로 나온다.
 */
function withStay(l) {
  const hours = Number(l.hours) || 0;
  return {
    ...l,
    hours,
    stayHours: Number.isFinite(Number(l.stayHours)) && l.stayHours !== undefined ? Number(l.stayHours) : hours,
    breakHours: Number(l.breakHours) || 0,
    breakStart: l.breakStart || '',
    breakEnd: l.breakEnd || '',
  };
}

function sumSchedule(sc) {
  let total = 0;
  let stay = 0;
  let brk = 0;
  const days = [];
  for (let d = 0; d <= 6; d++) {
    const v = (sc || {})[d] || (sc || {})[String(d)];
    if (!v || !v.on) continue;
    // 휴게를 뺀 **근무시간**을 더한다 (주 15시간 판정의 기준)
    const t2 = dayTime(v.start, v.end, v.breakStart, v.breakEnd);
    if (t2.work > 0) {
      total += t2.work;
      stay += t2.stay;
      brk += t2.brk;
      days.push(d);
    }
  }
  return {
    hours: Math.round(total * 10) / 10, // 근무시간 (휴게 제외)
    stayHours: Math.round(stay * 10) / 10, // 체류시간
    breakHours: Math.round(brk * 10) / 10, // 휴게시간
    days,
  };
}

/** 기본(계약) 시간표에서 주당 시간·근무요일을 다시 계산해 설정에 채운다 */
function applySchedule(s) {
  const { hours, days } = sumSchedule(s.coordinator.schedule);
  s.coordinator.weeklyHours = hours;
  s.coordinator.workDays = days;
  return hours;
}

/**
 * 그 주에 실제로 적용되는 시간표를 고른다.
 * 주마다 근무 시간이 달라질 수 있어(근로계약서 제3조 ③ : 상호 협의하에 변경 가능),
 * `weekOverrides` 에 그 주(월요일 날짜)만의 시간표를 따로 둘 수 있다. 없으면 기본 시간표를 쓴다.
 */
function scheduleForWeek(settings, dateStr) {
  const range = weekRange(dateStr);
  const monday = range ? range.start : null;
  const ov = monday ? (settings.coordinator.weekOverrides || {})[monday] : null;
  const sc = ov && ov.schedule ? ov.schedule : settings.coordinator.schedule || {};
  const { hours, days } = sumSchedule(sc);
  return { monday, schedule: sc, hours, days, isOverride: !!(ov && ov.schedule), note: ov ? ov.note || '' : '' };
}

/** 그 날짜(요일)의 근무 시간표를 꺼낸다 — 주별 예외를 반영한다 */
function scheduleOf(settings, dateStr) {
  const week = scheduleForWeek(settings, dateStr);
  const dow = new Date(dateStr + 'T00:00:00').getDay();
  const v = week.schedule[dow] || week.schedule[String(dow)] || { on: false, start: '', end: '', breakStart: '', breakEnd: '' };
  const t = v.on ? dayTime(v.start, v.end, v.breakStart, v.breakEnd) : { stay: 0, brk: 0, work: 0, spans: [] };
  return {
    dow,
    ...v,
    hours: t.work, // 근무시간 (휴게 제외) — 예전 이름을 그대로 두어 쓰는 곳이 안 깨지게
    stayHours: t.stay,
    breakHours: t.brk,
    spans: t.spans, // 휴게를 뺀 실제 근무 구간
    isOverride: week.isOverride,
  };
}

/* ---- 인증코드 : pbkdf2 해시로 저장(평문은 어디에도 남기지 않는다) ----
   명단을 한 번에 200명까지 올릴 수 있어, 서버가 멈추지 않도록 비동기로 처리합니다. */
const KDF_ITER = 120000;

function hashCode(code) {
  return new Promise((resolve, reject) => {
    const salt = crypto.randomBytes(16).toString('hex');
    crypto.pbkdf2(String(code), salt, KDF_ITER, 32, 'sha256', (err, key) => {
      if (err) reject(err);
      else resolve(`pbkdf2$${KDF_ITER}$${salt}$${key.toString('hex')}`);
    });
  });
}

function verifyCode(code, stored) {
  return new Promise((resolve) => {
    const parts = String(stored || '').split('$');
    if (parts.length !== 4 || parts[0] !== 'pbkdf2') return resolve(false);
    const [, iter, salt, key] = parts;
    crypto.pbkdf2(String(code), salt, Number(iter), 32, 'sha256', (err, test) => {
      if (err) return resolve(false);
      try {
        resolve(crypto.timingSafeEqual(Buffer.from(key, 'hex'), test));
      } catch {
        resolve(false);
      }
    });
  });
}

/* ---- 로그인 토큰 : 서버 메모리에만 둔다(재시작하면 다시 로그인) ---- */
const sessions = new Map(); // token → { role, name, memberId, expires }
const SESSION_MS = 8 * 60 * 60 * 1000;

function issueToken(role, name, memberId = '') {
  const token = crypto.randomBytes(24).toString('hex');
  sessions.set(token, { role, name, memberId, expires: Date.now() + SESSION_MS });
  return token;
}
function sessionOf(req) {
  const token = req.headers['x-auth'];
  if (!token) return null;
  const s = sessions.get(token);
  if (!s) return null;
  if (s.expires < Date.now()) {
    sessions.delete(token);
    return null;
  }
  return s;
}

/**
 * 접속해 온 곳이 '같은 학교 안(사설망)' 인가.
 *
 * 이 프로그램은 교내망 전용이다. 그런데 처음 설치한 직후에는
 * **아무나 관리자 비상 코드를 정할 수 있는 상태**(firstRun)가 되므로,
 * 실수로 인터넷에 열어 두면 외부에서 먼저 들어와 관리자가 되어 버린다.
 * 그래서 최초 설정만은 사설망·같은 PC 에서만 되도록 막는다.
 */
function isPrivateAddress(raw) {
  let ip = String(raw || '').trim();
  if (ip.startsWith('::ffff:')) ip = ip.slice(7); // IPv6 로 감싼 IPv4
  if (ip === '::1' || ip === '127.0.0.1' || ip.startsWith('127.')) return true; // 같은 PC
  if (/^10\./.test(ip)) return true; // 10.0.0.0/8
  if (/^192\.168\./.test(ip)) return true; // 192.168.0.0/16
  if (/^169\.254\./.test(ip)) return true; // 링크 로컬
  const m = /^172\.(\d+)\./.exec(ip);
  if (m && Number(m[1]) >= 16 && Number(m[1]) <= 31) return true; // 172.16.0.0/12
  if (/^f[cd]/i.test(ip)) return true; // IPv6 사설 (fc00::/7)
  if (/^fe[89ab]/i.test(ip)) return true; // IPv6 링크 로컬
  return false;
}

/* ---- PIN 시도 횟수 제한 (IP 기준 10분에 7회) ---- */
const attempts = new Map();
function tooManyAttempts(ip) {
  const a = attempts.get(ip);
  if (!a) return false;
  if (Date.now() > a.until) {
    attempts.delete(ip);
    return false;
  }
  return a.count >= 7;
}
function noteAttempt(ip, ok) {
  if (ok) {
    attempts.delete(ip);
    return;
  }
  const a = attempts.get(ip) || { count: 0, until: Date.now() + 10 * 60 * 1000 };
  a.count += 1;
  attempts.set(ip, a);
}

/* ================================================================
 * 4. 응답 도우미
 * ================================================================ */
function sendJson(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}

async function readBody(req, limitBytes = 12 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > limitBytes) {
        reject(new Error('요청 크기가 너무 큽니다(최대 12MB).'));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')));
      } catch {
        reject(new Error('요청 형식이 올바르지 않습니다.'));
      }
    });
    req.on('error', reject);
  });
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  '.csv': 'text/csv; charset=utf-8',
};

/**
 * 로그인 없이 내려보내면 안 되는 확장자.
 * public/ 폴더에 명단 엑셀을 두면 교내망 누구나 인증코드를 내려받을 수 있어 막는다.
 * (실제로 샘플 파일을 실명 명단으로 덮어써 둔 사고가 있었다 — 2026-07-29)
 */
const BLOCKED_STATIC_EXT = new Set(['.xlsx', '.xlsm', '.xls', '.csv', '.json', '.bak', '.userbak']);

/** public/ 과 data/photos, data/signs 만 정적 제공 (경로 탈출 차단) */
async function serveStatic(req, res, urlPath) {
  let baseDir = PUBLIC_DIR;
  let rel = urlPath;

  if (urlPath.startsWith('/files/photos/')) {
    baseDir = PHOTO_DIR;
    rel = urlPath.slice('/files/photos'.length);
  } else if (urlPath.startsWith('/files/signs/')) {
    baseDir = SIGN_DIR;
    rel = urlPath.slice('/files/signs'.length);
  } else if (urlPath === '/') {
    rel = '/index.html';
  }

  const target = path.join(baseDir, decodeURIComponent(rel));
  if (!target.startsWith(baseDir)) {
    return sendJson(res, 403, { error: '허용되지 않은 경로입니다.' });
  }
  if (BLOCKED_STATIC_EXT.has(path.extname(target).toLowerCase())) {
    return sendJson(res, 403, {
      error:
        '이 형식의 파일은 로그인 없이 내려받을 수 없습니다.\n' +
        '명단 엑셀에는 인증코드가 들어 있어 교내망에 그대로 공개할 수 없습니다.\n' +
        '샘플 서식은 [점검·설정] 화면의 내려받기 단추로 받으세요.',
    });
  }
  try {
    const stat = await fsp.stat(target);
    if (stat.isDirectory()) throw new Error('dir');
    const ext = path.extname(target).toLowerCase();
    res.writeHead(200, {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Content-Length': stat.size,
      'Cache-Control': ext === '.html' ? 'no-store' : 'no-cache',
    });
    fs.createReadStream(target).pipe(res);
  } catch {
    res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end('<h1>404 – 페이지를 찾을 수 없습니다</h1><p><a href="/">처음으로</a></p>');
  }
}

/** data URL(base64 이미지)을 파일로 저장 */
async function saveDataUrl(dataUrl, dir, prefix) {
  const m = /^data:image\/(png|jpeg|jpg|webp);base64,([A-Za-z0-9+/=]+)$/.exec(String(dataUrl || ''));
  if (!m) return null;
  const ext = m[1] === 'jpeg' ? 'jpg' : m[1];
  const buf = Buffer.from(m[2], 'base64');
  if (buf.length > 6 * 1024 * 1024) return null;
  const name = `${prefix}-${crypto.randomBytes(4).toString('hex')}.${ext}`;
  await fsp.writeFile(path.join(dir, name), buf);
  return name;
}

/* ================================================================
 * 5. 업무 시간 집계 — 주 15시간 미만 원칙 점검용
 *    (업무편람 Ⅳ-2-다 : 동일 교육청 내 타 학교 근무시간까지 합산)
 * ================================================================ */
function requestHours(r) {
  return hoursBetween(r.startTime, r.endTime);
}

/* ----------------------------------------------------------------
 * 시간이 겹치는지 — 코디네이터는 한 사람이므로 같은 시간에 두 곳에 갈 수 없다
 * ---------------------------------------------------------------- */

/** 이미 자리를 차지한 것으로 보는 상태 (확정된 일정) */
const FIRM_STATUS = new Set(['accepted', 'done']);
/** 아직 확정은 아니지만 그 시간을 노리고 있는 상태 (알려만 준다) */
const PENDING_STATUS = new Set(['requested', 'rescheduled', 'coordinating']);

/* 선생님이 **자기 요청을 취소**할 수 있는 상태 (2026-08-25 사용자 지시).
   🔴 `done` 은 뺐다 — 그 요청은 **이미 활동 기록에 들어가 있다**
      (활동 기록을 저장하면 그 날짜의 `accepted` 가 모두 `done` 이 된다).
      지우면 활동일지·출근기록부의 근거가 사라져 복무 증빙이 어긋난다.
   ⚠ `accepted` 는 **넣었다.** 수업이 취소되는 일은 실제로 있고, 늦게 알수록 나쁘다.
      대신 화면이 «코디네이터가 이미 준비하고 있을 수 있다» 고 한 번 더 묻는다.
   ⚠ 취소하면 그 시간은 **저절로 빈다** — `FIRM_STATUS` 에 `cancelled` 가 없으므로
      다른 선생님이 바로 그 시간에 요청할 수 있다. */
const CANCELLABLE = new Set(['requested', 'rescheduled', 'coordinating', 'accepted']);

/* 기록(history)에 남길 상태 이름. `public/js/common.js` 의 `STATUS_KO` 와 같은 표다 —
   ⚠ 한쪽만 고치면 화면과 기록의 말이 달라진다. 고칠 때 둘 다 볼 것. */
const STATUS_KO_SERVER = {
  requested: '요청 접수',
  accepted: '수락 · 확정',
  coordinating: '조율 중',
  rescheduled: '시간조절 제안',
  done: '활동 완료',
  closed: '진행 안 함',
  cancelled: '취소',
};

/** 이 요청을 이 사람이 취소할 수 있는가 → 안 되면 그 이유(문장)를 돌려준다 */
function 취소못하는이유(r, ses) {
  if (ses.role !== 'manager' && ses.memberId && r.teacherId !== ses.memberId) {
    return '본인이 요청한 건만 취소할 수 있습니다.';
  }
  if (r.status === 'done') {
    return '이미 활동 기록에 들어간 요청이라 취소할 수 없습니다.\n잘못된 기록이면 코디네이터에게 말씀해 주세요.';
  }
  if (r.status === 'cancelled') return '이미 취소된 요청입니다.';
  if (r.status === 'closed' || r.status === 'rejected') return '이미 끝난 요청입니다.';
  if (!CANCELLABLE.has(r.status)) return '지금은 취소할 수 없는 상태입니다.';
  return '';
}

/** 같은 날 두 시간대가 겹치는가 (끝시각과 시작시각이 맞닿는 것은 겹침이 아니다) */
function timeOverlaps(aStart, aEnd, bStart, bEnd) {
  const a1 = toMin(aStart);
  const a2 = toMin(aEnd);
  const b1 = toMin(bStart);
  const b2 = toMin(bEnd);
  if (a1 === null || a2 === null || b1 === null || b2 === null) return false;
  return a1 < b2 && b1 < a2;
}

/**
 * 그 시간에 이미 잡혀 있는 요청을 찾는다.
 *   firm    : 확정된 일정 — 그대로는 요청을 받지 않는다
 *   pending : 아직 처리 전인 요청 — 화면에 알려만 준다
 * `시간조절 제안(rescheduled)` 은 제안된 새 시간으로 본다(원래 시간이 아니라).
 */
function findConflicts(requests, date, startTime, endTime, excludeId = '') {
  const firm = [];
  const pending = [];
  for (const r of requests) {
    if (r.id === excludeId) continue;
    const slot = r.status === 'rescheduled' && r.reply ? { date: r.reply.newDate, start: r.reply.newStartTime, end: r.reply.newEndTime } : { date: r.date, start: r.startTime, end: r.endTime };
    if (slot.date !== date) continue;
    if (!timeOverlaps(startTime, endTime, slot.start, slot.end)) continue;
    const brief = {
      id: r.id,
      status: r.status,
      teacherName: r.teacherName,
      taskType: r.taskType,
      date: slot.date,
      startTime: slot.start,
      endTime: slot.end,
      place: r.place || '',
    };
    if (FIRM_STATUS.has(r.status)) firm.push(brief);
    else if (PENDING_STATUS.has(r.status)) pending.push(brief);
  }
  return { firm, pending };
}

/** 겹친 일정을 사람이 읽는 한 줄로 */
function conflictLine(c) {
  return `${c.startTime}~${c.endTime} ${c.teacherName} 선생님 · ${c.taskType}${c.place ? ` (${c.place})` : ''}`;
}

async function weekSummary(dateStr) {
  const range = weekRange(dateStr);
  if (!range) return null;
  const [settings, requests, logs] = await Promise.all([loadSettings(), loadRequests(), loadLogs()]);

  // 확정된 요청(수락 완료)의 예정 시간
  const planned = requests
    .filter((r) => r.status === 'accepted' && r.date >= range.start && r.date <= range.end)
    .reduce((s, r) => s + requestHours(r), 0);

  // 이미 기록된 실제 활동 시간
  const recorded = logs
    .filter((l) => l.date >= range.start && l.date <= range.end)
    .reduce((s, l) => s + (Number(l.hours) || 0), 0);

  // 같은 날에 기록이 있으면 예정 시간은 중복 계산하지 않는다
  const recordedDates = new Set(logs.filter((l) => l.date >= range.start && l.date <= range.end).map((l) => l.date));
  const plannedOnly = requests
    .filter(
      (r) =>
        r.status === 'accepted' && r.date >= range.start && r.date <= range.end && !recordedDates.has(r.date),
    )
    .reduce((s, r) => s + requestHours(r), 0);

  const other = Number(settings.coordinator.otherSchoolHours) || 0;
  const total = Math.round((recorded + plannedOnly + other) * 10) / 10;

  // 이 주에 실제로 적용되는 시간표(주별 예외가 있으면 그것)
  const week = scheduleForWeek(settings, range.start);

  return {
    range,
    recorded: Math.round(recorded * 10) / 10,
    planned: Math.round(planned * 10) / 10,
    plannedOnly: Math.round(plannedOnly * 10) / 10,
    otherSchoolHours: other,
    total,
    limit: 15,
    weeklyHours: week.hours, // 이 주의 계약 시간 (예외가 있으면 예외 시간)
    baseWeeklyHours: Number(settings.coordinator.weeklyHours) || 0,
    isOverride: week.isOverride, // 이 주가 예외로 설정된 주인가
    overrideNote: week.note,
    level: total >= 15 ? 'over' : total >= 14 ? 'danger' : total >= 12 ? 'warn' : 'ok',
  };
}

/* ================================================================
 * 6. API
 * ================================================================ */
async function handleApi(req, res, url) {
  const p = url.pathname;
  const method = req.method;
  const ip = req.socket.remoteAddress || 'unknown';
  const ses = sessionOf(req);

  const needRole = (...roles) => {
    if (!ses || !roles.includes(ses.role)) {
      sendJson(res, 401, { error: '인증이 필요합니다. 이름과 인증코드를 다시 입력해 주세요.' });
      return false;
    }
    return true;
  };
  /** 명단에 있는 사람이면 누구나 (교사·코디네이터·시스템관리자) */
  const needAnyone = () => needRole('manager', 'teacher', 'coordinator');
  /** 근무기록·인건비를 볼 수 있는 사람 */
  const needStaff = () => needRole('manager', 'coordinator');

  /* ---------- 공통 정보 ---------- */
  if (p === '/api/catalog' && method === 'GET') {
    return sendJson(res, 200, CATALOG);
  }

  // 모든 화면이 쓰는 "공개해도 되는" 정보만 골라 보낸다 (인증코드 해시는 절대 내려보내지 않는다)
  if (p === '/api/public-settings' && method === 'GET') {
    const [s, members] = await Promise.all([loadSettings(), loadMembers()]);
    return sendJson(res, 200, {
      school: s.school,
      schoolYear: s.schoolYear,
      places: s.places,
      coordinatorName: s.coordinator.name,
      schedule: s.coordinator.schedule,
      weekOverrides: s.coordinator.weekOverrides, // 그 주만 다른 시간표
      workDays: s.coordinator.workDays,
      weeklyHours: s.coordinator.weeklyHours,
      // 이름을 고르는 목록 — 이름·과목·구분만 (인증코드는 없음)
      members: members.map((m) => ({ id: m.id, name: m.name, subject: m.subject, role: m.role })),
      roleLabel: ROLE_LABEL,
      hasRoster: members.length > 0,
      needsSetup: members.length === 0,
      // 서버(교무실 PC)의 오늘 날짜 — 활동 기록은 이 날짜만 쓸 수 있다.
      // 접속한 PC의 시계가 틀려 있어도 기준이 흔들리지 않게 서버 값을 내려보낸다.
      serverDate: todayStr(),
      serverTime: nowStamp().slice(11),
      /* 이 프로그램의 판. 화면에 보여 준다 —
         «설정에 유휴시간 칸이 없다» 는 물음이 실제로 있었고, 원인이 «예전 판» 이었는데
         화면 어디에도 판 번호가 없어 알 수 없었다(2026-08-24). */
      appVersion: APP_VERSION,
      // 선생님들께 알려 줄 주소 (localhost 가 아니라 서버가 정한 실제 주소)
      shareUrl: SHARE.url,
      shareAltUrl: SHARE.altUrl,
      shareHostWanted: SHARE.wantedHost, // 쓰고 싶다고 설정한 이름
      shareHostOk: SHARE.hostOk, // 그 이름이 실제로 쓰이는가
      shareUsingIp: SHARE.usingIp, // 이름을 못 써서 IP 를 쓰는가
      shareIp: SHARE.altUrl || SHARE.url,
      // 이 PC 의 모든 교내망 IP — 무선·다른 망에서 접속하는 분께 드릴 주소
      // (컴퓨터 이름은 라우터를 넘지 못해 같은 망에서만 통한다)
      shareAddresses: localAddresses()
        .filter((a) => !a.startsWith('169.254.'))
        .map((a) => `http://${a}:${SHARE.port}/`),
      /* 🔴 컴퓨터 이름(`os.hostname()`)을 여기에 넣지 말 것 (2026-08-24 사용자 지시).
         **이 API 는 로그인 없이 누구나 읽는다.** 학교 PC 의 컴퓨터 이름은 사람 이름인
         경우가 많아(예 «홍길동») 성명이 그대로 나간다. 예전에는
         `shareComputerName`·`shareIsComputerName`·`shareNameUrlSafe` 세 칸이 있었다.
         주소 안내는 이름 없이 `shareUsingIp`·`shareHostOk` 로만 한다. */
    });
  }

  /* ---------- 로그인 ---------- */
  /* 로그인 : 명단에서 이름을 고르고 자기 인증코드를 넣는다.
     명단이 아직 없을 때만 '비상용 관리자 코드'로 들어올 수 있다(처음 설치할 때 필요). */
  if (p === '/api/login' && method === 'POST') {
    if (tooManyAttempts(ip)) {
      return sendJson(res, 429, { error: '인증코드를 여러 번 틀렸습니다. 10분 후에 다시 시도해 주세요.' });
    }
    const body = await readBody(req);
    const s = await loadSettings();
    const members = await loadMembers();

    // (1) 비상용 관리자 코드 — 명단이 없거나, 명단 파일을 잃어버렸을 때 쓰는 통로
    if (body.emergency) {
      const pin = String(body.code || body.pin || '');
      if (!s.manager.pinHash) {
        // 최초 설정은 같은 학교 안(사설망)에서만 — 인터넷에 열려 있어도 외부인이 관리자가 되지 못하게
        if (!isPrivateAddress(ip)) {
          return sendJson(res, 403, {
            error:
              '최초 설정은 학교 내부망에서만 할 수 있습니다.\n' +
              '교무실 PC 또는 같은 학교 네트워크의 컴퓨터에서 접속해 주세요.\n' +
              '(이 프로그램은 인터넷에 공개해서 쓰는 프로그램이 아닙니다)',
          });
        }
        if (!/^\d{4,12}$/.test(pin)) {
          return sendJson(res, 400, {
            error: '처음 사용입니다. 관리자용 비상 코드(숫자 4~12자리)를 정해 입력해 주세요.\n이 코드는 명단 파일을 잃어버렸을 때 쓰는 통로입니다.',
            firstRun: true,
          });
        }
        s.manager.pinHash = await hashCode(pin);
        s.updatedAt = nowStamp();
        await writeJson(FILES.settings, s);
        /* 처음 설치할 때는 알림을 붙이지 않는다 — 아직 확인해 둔 것이 없고,
         «처음 설치하셨습니다» 화면에 다른 창이 겹치면 헷갈린다. */
      return sendJson(res, 200, { token: issueToken('manager', s.manager.name || '시스템관리자'), role: 'manager', firstRun: true });
      }
      const ok = await verifyCode(pin, s.manager.pinHash);
      noteAttempt(ip, ok);
      if (!ok) return sendJson(res, 401, { error: '비상 코드가 맞지 않습니다.' });
      return sendJson(res, 200, {
      token: issueToken('manager', s.manager.name || '시스템관리자'),
      role: 'manager',
      update: await updateNotice(),
    });
    }

    // (2) 보통의 로그인
    if (!members.length) {
      return sendJson(res, 400, {
        error: '아직 명단이 등록되지 않았습니다. 시스템관리자님이 먼저 명단 엑셀 파일을 올려 주셔야 합니다.',
        needsRoster: true,
      });
    }
    const m = members.find((x) => x.id === body.memberId);
    if (!m) return sendJson(res, 400, { error: '명단에서 이름을 골라 주세요.' });

    const ok = await verifyCode(String(body.code || ''), m.codeHash);
    noteAttempt(ip, ok);
    if (!ok) return sendJson(res, 401, { error: '인증코드가 맞지 않습니다. 명단 파일에 적힌 코드를 확인해 주세요.' });

    /* 🔴 시스템관리자에게만 «새 판이 있다» 를 붙인다 (2026-08-25 사용자 지시).
       **마지막에 확인해 둔 값**이라 로그인이 느려지지 않는다 —
       하루가 지났으면 `updateNotice()` 가 뒤에서 새로 확인만 걸어 둔다.
       새 판이 없거나 못 받았으면 `null` 이라 화면이 아무것도 띄우지 않는다. */
    return sendJson(res, 200, {
      token: issueToken(m.role, m.name, m.id),
      role: m.role,
      name: m.name,
      subject: m.subject,
      memberId: m.id,
      update: m.role === 'manager' ? await updateNotice() : null,
    });
  }

  if (p === '/api/logout' && method === 'POST') {
    const token = req.headers['x-auth'];
    if (token) sessions.delete(token);
    return sendJson(res, 200, { ok: true });
  }

  if (p === '/api/me' && method === 'GET') {
    return sendJson(res, 200, ses ? { role: ses.role, name: ses.name, memberId: ses.memberId } : { role: null });
  }

  /* ---------- 설정 (시스템관리자) ---------- */
  if (p === '/api/settings' && method === 'GET') {
    if (!needRole('manager')) return;
    const s = await loadSettings();
    // 해시는 화면으로 내려보내지 않는다
    const safe = structuredClone(s);
    safe.manager.pinHash = safe.manager.pinHash ? '설정됨' : '';
    return sendJson(res, 200, safe);
  }

  if (p === '/api/settings' && method === 'POST') {
    if (!needRole('manager')) return;
    const body = await readBody(req);
    const s = await loadSettings();

    const c = body.coordinator || {};
    const m = body.manager || {};

    s.school = String(body.school ?? s.school).slice(0, 40);
    s.schoolYear = Number(body.schoolYear) || s.schoolYear;
    s.manager.name = String(m.name ?? s.manager.name).slice(0, 20);
    s.manager.position = String(m.position ?? s.manager.position).slice(0, 20);

    s.coordinator.name = String(c.name ?? s.coordinator.name).slice(0, 20);
    s.coordinator.contractStart = String(c.contractStart ?? s.coordinator.contractStart);
    s.coordinator.contractEnd = String(c.contractEnd ?? s.coordinator.contractEnd);
    s.coordinator.hourlyWage = Math.max(0, Number(c.hourlyWage) || 0);
    s.coordinator.otherSchoolHours = Math.max(0, Number(c.otherSchoolHours) || 0);

    /** 들어온 시간표를 다듬고 검사한다 → { schedule } 또는 { error } */
    const cleanSchedule = (raw) => {
      const next = {};
      for (let d = 0; d <= 6; d++) {
        const v = raw[d] || raw[String(d)] || {};
        const on = !!v.on;
        const start = String(v.start || '');
        const end = String(v.end || '');
        const breakStart = String(v.breakStart || '');
        const breakEnd = String(v.breakEnd || '');
        if (on && hoursBetween(start, end) <= 0) {
          return { error: `${WEEK_KO[d]}요일의 출근·퇴근 시간이 올바르지 않습니다. 퇴근 시간이 출근 시간보다 늦어야 합니다.` };
        }
        // 유휴(휴게) 시간이 이상하면 조용히 넘기지 않고 막는다 — 인건비가 걸린 값이다
        if (on) {
          const t = dayTime(start, end, breakStart, breakEnd);
          if (t.error) return { error: `${WEEK_KO[d]}요일 — ${t.error}` };
          // 4시간 이상 근무일에는 유휴시간이 **반드시** 있어야 한다(2026-08-22 사용자 지시)
          const shortage = breakShortage(t);
          if (shortage) return { error: `${WEEK_KO[d]}요일 — ${shortage}` };
        }
        next[d] = { on, start, end, breakStart, breakEnd };
      }
      return { schedule: next };
    };

    /** 주 15시간 미만 원칙 (업무편람 Ⅳ-2-다) — 넘으면 저장을 막는다 */
    const checkFifteen = (weekly, whatWeek) => {
      const other = s.coordinator.otherSchoolHours;
      const withOther = Math.round((weekly + other) * 10) / 10;
      if (withOther < 15) return null;
      return (
        `${whatWeek} 주당 근무시간 합계가 ${withOther}시간입니다. AI교육 코디네이터는 15시간 미만이어야 합니다.\n` +
        `(요일별 합계 ${weekly}시간 + 타 학교 ${other}시간)\n` +
        `근거 : AI교육 코디네이터 업무편람 가이드 Ⅳ-2-다 — 동일 교육청 내 타 학교 근무시간까지 합산해 판단합니다.\n` +
        `요일별 시간을 줄여 주세요.`
      );
    };

    // 기본(계약) 요일별 업무 시간
    if (c.schedule) {
      const r = cleanSchedule(c.schedule);
      if (r.error) return sendJson(res, 400, { error: r.error });
      s.coordinator.schedule = r.schedule;
    }

    // 그 주만 다르게 — 지우기 / 등록
    if (body.removeWeekOverride) {
      delete s.coordinator.weekOverrides[String(body.removeWeekOverride)];
    }
    if (body.weekOverride && body.weekOverride.week) {
      const wk = String(body.weekOverride.week);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(wk)) return sendJson(res, 400, { error: '주를 고르는 날짜가 올바르지 않습니다.' });
      const monday = weekRange(wk).start; // 그 주의 아무 날을 골라도 월요일로 맞춘다
      const r = cleanSchedule(body.weekOverride.schedule || {});
      if (r.error) return sendJson(res, 400, { error: r.error });
      const { hours } = sumSchedule(r.schedule);
      const bad = checkFifteen(hours, `${monday} 주의`);
      if (bad) return sendJson(res, 400, { error: bad });
      if (!s.coordinator.weekOverrides[monday] && Object.keys(s.coordinator.weekOverrides).length >= 120) {
        return sendJson(res, 400, { error: '주별 예외는 120주까지 둘 수 있습니다. 지난 예외를 정리해 주세요.' });
      }
      s.coordinator.weekOverrides[monday] = {
        schedule: r.schedule,
        note: String(body.weekOverride.note || '').slice(0, 100),
        hours,
        at: nowStamp(),
      };
    }

    // 기본 시간표 검사
    const weekly = applySchedule(s);
    const overBase = checkFifteen(weekly, '기본(계약) 시간표의');
    // 타 학교 시간을 늘리면 이미 등록된 예외 주도 15시간을 넘을 수 있어 함께 확인한다
    const overWeek = overBase
      ? null
      : Object.entries(s.coordinator.weekOverrides)
          .map(([wk, ov]) => checkFifteen(sumSchedule(ov.schedule).hours, `${wk} 주(예외)의`))
          .find(Boolean);
    if (overBase || overWeek) {
      return sendJson(res, 400, {
        error: overBase || overWeek,
      });
    }

    if (body.budget) {
      s.budget.planned = Math.max(0, Number(body.budget.planned) || 0);
      s.budget.note = String(body.budget.note || '').slice(0, 200);
    }
    // 선생님들께 알려 줄 짧은 주소 이름 (영문·숫자·하이픈만 — 브라우저 주소로 쓰이므로)
    if (body.shareHost !== undefined) {
      const h = String(body.shareHost).trim().toLowerCase();
      if (h && !/^[a-z0-9][a-z0-9-]{0,30}$/.test(h)) {
        return sendJson(res, 400, {
          error: '주소 이름은 영문 소문자·숫자·하이픈(-)만 쓸 수 있습니다. (예: aicodi)\n한글이나 공백은 주소로 쓸 수 없습니다.',
        });
      }
      s.shareHost = h;
    }

    if (Array.isArray(body.places)) {
      s.places = body.places.map((v) => String(v).trim().slice(0, 30)).filter(Boolean).slice(0, 60);
    }
    if (body.report) {
      s.report.background = String(body.report.background || '').slice(0, 4000);
      s.report.purpose = String(body.report.purpose || '').slice(0, 4000);
      s.report.outputs = String(body.report.outputs || '').slice(0, 4000);
      if (Array.isArray(body.report.budgetRows)) {
        /* 예산 **편성** 줄 (결과보고서 Ⅲ 의 비목·세목·편성액).
           집행액은 여기 저장하지 않는다 — [예산 집행] 탭의 건별 내역을 합해서 쓴다.
           `id` 는 집행 내역이 어느 편성 줄에 달렸는지 가리키는 열쇠라 **바뀌면 안 된다.** */
        const used = new Set();
        s.report.budgetRows = body.report.budgetRows.slice(0, 30).map((r, i) => {
          let id = String(r.id || '').slice(0, 20);
          if (!id || used.has(id)) id = `b${Date.now().toString(36)}${i}`;
          used.add(id);
          return {
            id,
            item: String(r.item || '').slice(0, 40),
            detail: String(r.detail || '').slice(0, 40),
            planned: Math.max(0, Number(r.planned) || 0),
            note: String(r.note || '').slice(0, 40),
          };
        });
        // 줄이 있으면 총 편성액은 줄 합계다. 따로 두면 합계 줄과 어긋난다.
        if (s.report.budgetRows.length) {
          s.budget.planned = s.report.budgetRows.reduce((n, r) => n + r.planned, 0);
        }
      }
    }

    // 비상용 관리자 코드 변경 (입력했을 때만)
    if (/^\d{4,12}$/.test(String(body.newManagerPin || ''))) s.manager.pinHash = await hashCode(body.newManagerPin);

    // 서명 등록 (한 번 등록해 두면 점검할 때 클릭 한 번으로 찍힌다)
    if (body.managerSign) {
      const f = await saveDataUrl(body.managerSign, SIGN_DIR, 'manager');
      if (f) s.manager.signFile = f;
    }
    if (body.coordinatorSign) {
      const f = await saveDataUrl(body.coordinatorSign, SIGN_DIR, 'coordinator');
      if (f) s.coordinator.signFile = f;
    }

    s.updatedAt = nowStamp();
    await writeJson(FILES.settings, s);
    // 주소 이름을 고쳤으면 화면에 바로 반영되도록 다시 계산한다
    if (body.shareHost !== undefined) await refreshShare();
    return sendJson(res, 200, { ok: true, updatedAt: s.updatedAt });
  }

  /** 명단 샘플 서식 내려받기 — 시스템관리자만. public/ 밖(template/)에 두어 공개되지 않게 한다 */
  if (p === '/api/roster-template' && method === 'GET') {
    if (!needRole('manager')) return;
    const file = path.join(ROOT, 'template', '교사명단_샘플.xlsx');
    try {
      const buf = await fsp.readFile(file);
      res.writeHead(200, {
        'Content-Type': MIME['.xlsx'],
        'Content-Length': buf.length,
        // 한글 파일 이름이 깨지지 않도록 RFC 5987 형식으로 함께 보낸다
        'Content-Disposition': `attachment; filename="roster-template.xlsx"; filename*=UTF-8''${encodeURIComponent('교사명단_샘플.xlsx')}`,
        'Cache-Control': 'no-store',
      });
      return res.end(buf);
    } catch {
      return sendJson(res, 404, { error: '샘플 서식 파일(template/교사명단_샘플.xlsx)을 찾을 수 없습니다.' });
    }
  }

  /* ================================================================
   * 자료 백업 · 되돌리기 (시스템관리자만)
   *
   * `data/backup/` 의 자동 백업은 **같은 폴더 안**에 있어서, 폴더째 잃어버리면 함께 사라진다.
   * 그래서 **파일 하나로 뽑아 내는 길**을 따로 둔다 — USB·클라우드에 옮겨 두시라는 뜻이다.
   * 되돌릴 때는 **되돌리기 직전 상태를 먼저 백업**해 둔다(잘못 되돌린 사고를 되돌릴 수 있게).
   * ================================================================ */

  /** 백업에 담을 것들을 모은다 → [{ name, data }] */
  async function collectBackup() {
    const entries = [];
    // ① 자료 파일 네 개 (없으면 건너뛴다)
    for (const [key, file] of Object.entries(FILES)) {
      try {
        entries.push({ name: `${key}.json`, data: await fsp.readFile(file) });
      } catch {
        /* 아직 만들어지지 않은 파일은 백업할 것이 없다 */
      }
    }
    // ② 사진·서명 (서명이 없으면 출근기록부의 강사날인·담당확인 칸이 빈다)
    for (const [dir, folder] of [
      [PHOTO_DIR, 'photos'],
      [SIGN_DIR, 'signs'],
    ]) {
      let names = [];
      try {
        names = await fsp.readdir(dir);
      } catch {
        names = [];
      }
      for (const n of names) {
        // ZIP 안의 이름은 영문·숫자만 (한글 이름은 압축 프로그램마다 다르게 읽는다)
        if (!/^[A-Za-z0-9._-]+$/.test(n)) continue;
        try {
          entries.push({ name: `${folder}/${n}`, data: await fsp.readFile(path.join(dir, n)) });
        } catch {
          /* 읽지 못한 파일은 건너뛴다 */
        }
      }
    }
    return entries;
  }

  /** 백업 파일 안을 들여다보고 요약한다 (되돌리기 전에 보여 줄 내용) */
  function describeBackup(files) {
    const readJson = (n) => {
      const b = files.get(n);
      if (!b) return null;
      try {
        return JSON.parse(b.toString('utf8'));
      } catch {
        return null;
      }
    };
    const s = readJson('settings.json');
    const members = readJson('members.json') || [];
    const requests = readJson('requests.json') || [];
    const logs = readJson('logs.json') || [];
    const info = readJson('_info.json') || {};
    const count = (pre) => [...files.keys()].filter((k) => k.startsWith(pre + '/')).length;
    return {
      school: (s && s.school) || '(알 수 없음)',
      managerName: (s && s.manager && s.manager.name) || '',
      coordinatorName: (s && s.coordinator && s.coordinator.name) || '',
      hasSettings: !!s,
      members: members.length,
      requests: requests.length,
      logs: logs.length,
      photos: count('photos'),
      signs: count('signs'),
      madeAt: info.madeAt || '(알 수 없음)',
      appVersion: info.appVersion || '',
    };
  }

  /** 백업 파일 내려받기 */
  if (p === '/api/backup' && method === 'GET') {
    if (!needRole('manager')) return;
    const entries = await collectBackup();
    const s = await loadSettings();
    // 되돌릴 때 무엇인지 알아볼 수 있게 안내문을 함께 넣는다
    entries.push({
      name: '_info.json',
      data: Buffer.from(
        JSON.stringify(
          {
            madeAt: nowStamp(),
            school: s.school,
            appVersion: APP_VERSION,
            안내: 'AI교육 코디네이터 업무 관리 자료 백업입니다. [설정] → [자료 백업] → [백업에서 되돌리기] 로 복원합니다. 개인정보가 들어 있으니 외부에 공유하지 마세요.',
          },
          null,
          2,
        ),
        'utf8',
      ),
    });
    const zip = makeZip(entries);
    // 언제 마지막으로 받아 갔는지 남긴다 (오래되면 설정 화면이 알려 준다)
    s.lastBackupAt = nowStamp();
    await writeJson(FILES.settings, s);

    const fname = `AI코디네이터_백업_${todayStr()}.zip`;
    res.writeHead(200, {
      'Content-Type': 'application/zip',
      'Content-Length': zip.length,
      'Content-Disposition': `attachment; filename="aicoordinator-backup-${todayStr()}.zip"; filename*=UTF-8''${encodeURIComponent(fname)}`,
      'Cache-Control': 'no-store',
    });
    return res.end(zip);
  }

  /** 백업 상태 (마지막으로 언제 받아 갔는지 + 지금 자료 크기) */
  if (p === '/api/backup/status' && method === 'GET') {
    if (!needRole('manager')) return;
    const [s, members, requests, logs] = await Promise.all([loadSettings(), loadMembers(), loadRequests(), loadLogs()]);
    const entries = await collectBackup();
    return sendJson(res, 200, {
      lastBackupAt: s.lastBackupAt || '',
      dataDir: DATA_DIR,
      members: members.length,
      requests: requests.length,
      logs: logs.length,
      files: entries.length,
      bytes: entries.reduce((n, e) => n + e.data.length, 0),
    });
  }

  /** 어느 기기에서 접속했는지 (진단용) — "무선에서 요청이 도착하는가" 를 눈으로 확인하는 곳 */
  if (p === '/api/visitors' && method === 'GET') {
    if (!needRole('manager')) return;
    const mine = localAddresses();
    const my24 = (mine[0] || '').split('.').slice(0, 3).join('.');
    const list = [...VISITORS.entries()]
      .map(([addr, v]) => ({
        ip: addr,
        first: v.first,
        last: v.last,
        count: v.count,
        // 앞 세 자리가 같으면 같은 망 — 다르면 무선이나 다른 망에서 온 것이다
        sameSubnet: !!my24 && addr.split('.').slice(0, 3).join('.') === my24,
      }))
      .sort((a, b) => b.last.localeCompare(a.last));
    return sendJson(res, 200, { myAddresses: mine, visitors: list });
  }

  /** 백업에서 되돌리기 — apply:false 면 미리보기만 */
  if (p === '/api/restore' && method === 'POST') {
    if (!needRole('manager')) return;
    const b = await readBody(req);
    const b64 = String(b.dataBase64 || '').replace(/^data:[^,]*,/, '');
    if (!b64) return sendJson(res, 400, { error: '백업 파일을 골라 주세요.' });

    let files;
    try {
      files = unzip(Buffer.from(b64, 'base64'));
    } catch {
      return sendJson(res, 400, { error: '백업 파일을 읽을 수 없습니다. 이 프로그램이 만든 .zip 파일이 맞는지 확인해 주세요.' });
    }
    if (!files.get('settings.json') && !files.get('members.json')) {
      return sendJson(res, 400, {
        error: '이 프로그램의 백업 파일이 아닌 것 같습니다.\n(settings.json · members.json 이 들어 있어야 합니다)',
      });
    }
    const summary = describeBackup(files);

    if (!b.apply) return sendJson(res, 200, { preview: true, summary });

    // 되돌리기 직전 상태를 먼저 따로 저장한다 — 잘못 되돌렸을 때 돌아올 자리
    const safety = path.join(BACKUP_DIR, `되돌리기전-${todayStr()}-${Date.now()}.zip`);
    try {
      await fsp.writeFile(safety, makeZip(await collectBackup()));
    } catch {
      return sendJson(res, 500, { error: '되돌리기 전 백업을 만들지 못해 중단했습니다. 디스크 여유 공간을 확인해 주세요.' });
    }

    /* 먼저 전부 읽어 확인한 뒤에 쓴다 — 절반만 바뀐 상태로 끝나지 않게.
       설정은 빠진 칸을 기본값으로 채워 넣는다(예전 판 백업에는 없는 칸이 있을 수 있다). */
    const toWrite = [];
    for (const [key, file] of Object.entries(FILES)) {
      const buf = files.get(`${key}.json`);
      if (!buf) continue;
      let parsed;
      try {
        parsed = JSON.parse(buf.toString('utf8'));
      } catch {
        return sendJson(res, 400, { error: `백업 안의 ${key}.json 이 깨져 있어 중단했습니다. 되돌리기 전 자료는 그대로입니다.` });
      }
      // 명단·요청·기록은 목록이어야 한다
      if (key !== 'settings' && !Array.isArray(parsed)) {
        return sendJson(res, 400, { error: `백업 안의 ${key}.json 의 모양이 올바르지 않아 중단했습니다. 되돌리기 전 자료는 그대로입니다.` });
      }
      toWrite.push([file, key === 'settings' ? withDefaults(parsed) : parsed]);
    }
    for (const [file, value] of toWrite) {
      const tmp = file + '.tmp';
      await fsp.writeFile(tmp, JSON.stringify(value, null, 2));
      await fsp.rename(tmp, file);
    }
    // 사진·서명 (덮어쓰되 지금 있는 것을 지우지는 않는다)
    for (const [dir, folder] of [
      [PHOTO_DIR, 'photos'],
      [SIGN_DIR, 'signs'],
    ]) {
      for (const [name, buf] of files) {
        if (!name.startsWith(folder + '/')) continue;
        const base = name.slice(folder.length + 1);
        if (!/^[A-Za-z0-9._-]+$/.test(base)) continue; // 경로 탈출 차단
        await fsp.writeFile(path.join(dir, base), buf);
      }
    }

    // 명단이 통째로 바뀌었으므로 지금 들어와 있는 사람을 모두 내보낸다
    sessions.clear();
    return sendJson(res, 200, { ok: true, summary, safetyBackup: path.basename(safety) });
  }

  /* ----------------------------------------------------------------
   * 업그레이드 — 깃허브에 올려 둔 새 판을 받아 이 폴더를 갱신한다
   *   2026-08-24 사용자 지시. 자세한 규칙은 lib/update.js 머리글 참고.
   * ⚠ 시스템관리자만, 그리고 **학교 안(사설망)에서만** 할 수 있다.
   *   인터넷에 노출된 상태에서 밖에서 프로그램을 갈아치우게 하면 안 된다.
   * ---------------------------------------------------------------- */
  if (p === '/api/update/check' && method === 'GET') {
    if (!needRole('manager')) return;
    let info;
    try {
      info = await Update.fetchLatest(UPDATE_BASE_URL);
    } catch (e) {
      /* 왜 못 받았는지 단계별로 가려내 함께 보낸다 —
         «fetch failed» 만 보여 주면 사람이 할 수 있는 것이 없다(2026-08-24 사용자 신고). */
      let diag = null;
      try {
        diag = await Update.diagnose(UPDATE_BASE_URL);
      } catch {}
      /* 켤 때 Windows 인증서를 얹었는지도 함께 보낸다.
         얹지 못한 채 «인증서» 가 원인이면 그것이 진짜 이유다 — 이 줄이 없으면
         화면만 보고는 «왜 아직도 막히지?» 를 알 수 없다. */
      if (diag) {
        const 학교 = 인증서결과 && 인증서결과.학교있음 ? ' + 학교가 올린 인증서 1개' : '';
        if (인증서결과 && !인증서결과.ok) {
          diag.인증서얹기 = '못 얹음 : ' + 인증서결과.why +
            (인증서결과.auto === false
              ? ' — 이 PC 의 Node 가 낡았습니다. [설정] → 🔐 학교 보안 인증서 에서 인증서를 올린 뒤 서버_실행.bat 안내대로 하시면 됩니다.'
              : '');
        } else if (인증서결과) {
          diag.인증서얹기 = 'Windows 인증서 ' + 인증서결과.수 + '개' + 학교 + ' 를 얹은 상태' +
            (인증서결과.학교있음 ? '' : ' — 그래도 막히면 [설정] → 🔐 학교 보안 인증서 에서 학교 인증서를 올려 보세요.');
        }
      }
      return sendJson(res, 200, { current: APP_VERSION, error: e.message, offline: true, diag });
    }
    const newer = Update.compareVersion(info.version, APP_VERSION) > 0;
    return sendJson(res, 200, {
      current: APP_VERSION,
      latest: info.version,
      date: info.date || '',
      notes: Array.isArray(info.notes) ? info.notes.slice(0, 30) : [],
      size: Number(info.size) || 0,
      newer,
    });
  }

  if (p === '/api/update/apply' && method === 'POST') {
    if (!needRole('manager')) return;
    if (!isPrivateAddress(ip)) {
      return sendJson(res, 403, {
        error:
          '업그레이드는 학교 안에서만 할 수 있습니다.\n' +
          '교무실 PC 또는 같은 학교 네트워크의 컴퓨터에서 해 주세요.',
      });
    }
    let info;
    try {
      info = await Update.fetchLatest(UPDATE_BASE_URL);
    } catch (e) {
      return sendJson(res, 400, { error: e.message });
    }
    if (Update.compareVersion(info.version, APP_VERSION) <= 0) {
      return sendJson(res, 400, { error: `이미 최신 판입니다 (지금 ${APP_VERSION}).` });
    }

    let files;
    try {
      const buf = await Update.download(UPDATE_BASE_URL, info);
      files = Update.readPackage(buf); // 여기서 다 검사한다 — 통과 못 하면 아무것도 안 바꿨다
    } catch (e) {
      return sendJson(res, 400, { error: e.message });
    }

    /* 자료 백업을 먼저 만든다. 프로그램만 바뀌지만, 새 판이 설정 모양을 바꿀 수도 있다. */
    const stamp = nowStamp().replace(/[^0-9]/g, '').slice(0, 14);
    let dataBackup = '';
    try {
      const entries = await collectBackup();
      const zip = makeZip(entries);
      await fsp.mkdir(BACKUP_DIR, { recursive: true });
      dataBackup = path.join(BACKUP_DIR, `판갈이전자료-${stamp}.zip`);
      await fsp.writeFile(dataBackup, zip);
    } catch (e) {
      return sendJson(res, 500, { error: '자료를 먼저 백업하지 못해 업그레이드를 멈췄습니다.\n' + (e.message || '') });
    }

    /* 지금 프로그램 파일을 되돌릴 수 있게 둔다 → 덮어쓴다 → 실패하면 되돌린다 */
    let progBackup = '';
    try {
      progBackup = await Update.backupCurrent(ROOT, BACKUP_DIR, stamp);
    } catch (e) {
      return sendJson(res, 500, { error: '지금 프로그램을 백업하지 못해 업그레이드를 멈췄습니다.\n' + (e.message || '') });
    }
    try {
      await Update.writeFiles(ROOT, files);
    } catch (e) {
      try {
        await Update.rollback(ROOT, progBackup);
      } catch {}
      return sendJson(res, 500, {
        error: '옮기는 중에 문제가 생겨 **예전 판으로 되돌렸습니다**.\n' + (e.message || ''),
      });
    }

    console.log(`\n  ● 업그레이드 : ${APP_VERSION} → ${info.version} (파일 ${files.size}개)`);
    console.log(`    되돌리려면 : ${progBackup}`);
    return sendJson(res, 200, {
      ok: true,
      from: APP_VERSION,
      to: info.version,
      count: files.size,
      dataBackup: path.basename(dataBackup),
      progBackup: path.basename(progBackup),
    });
  }

  /* ----------------------------------------------------------------
   * 파일로 업그레이드 — 브라우저로 받은 꾸러미를 올려서 갱신한다
   *   2026-08-24 : 학교망에서 프로그램이 github.io 에 닿지 못하는 일이 있다
   *   (프록시·SSL 가로채기·차단). **그런데 이 화면을 보는 브라우저는 인터넷이 된다.**
   *   그러니 사람이 브라우저로 zip 을 받아 올리면 된다 — 가장 확실한 길이다.
   * ⚠ 검사는 인터넷으로 받을 때와 **똑같이** 한다. 다만 크기·해시를 대조할
   *   latest.json 이 없으므로 그 둘은 건너뛴다 — 사람이 고른 파일이라는 점과
   *   나머지 검사(경로·필수 파일·js 파싱)로 지킨다.
   * ---------------------------------------------------------------- */
  if (p === '/api/update/file' && method === 'POST') {
    if (!needRole('manager')) return;
    if (!isPrivateAddress(ip)) {
      return sendJson(res, 403, { error: '업그레이드는 학교 안에서만 할 수 있습니다.' });
    }
    const b = await readBody(req);
    let buf = null;
    try {
      buf = Buffer.from(String(b.dataBase64 || '').split(',').pop(), 'base64');
    } catch {
      buf = null;
    }
    if (!buf || buf.length < 1000) {
      return sendJson(res, 400, { error: '파일을 읽지 못했습니다. 내려받은 zip 파일을 골라 주세요.' });
    }
    if (buf.length > 30 * 1024 * 1024) {
      return sendJson(res, 400, { error: '파일이 너무 큽니다(30MB 넘음). 업데이트 꾸러미가 맞는지 확인해 주세요.' });
    }

    let files;
    try {
      files = Update.readPackage(buf); // 경로·필수 파일·js 파싱 검사를 모두 거친다
    } catch (e) {
      return sendJson(res, 400, { error: e.message });
    }

    /* 꾸러미 안의 server.js 에서 판을 읽는다 */
    let 새판 = '';
    try {
      const m = files.get('server.js').toString('utf8').match(/const APP_VERSION = '([0-9.]+)'/);
      새판 = m ? m[1] : '';
    } catch {}
    if (!새판) return sendJson(res, 400, { error: '꾸러미에서 판 번호를 읽지 못했습니다. 올바른 파일이 아닙니다.' });

    const 비교 = Update.compareVersion(새판, APP_VERSION);
    if (비교 <= 0 && !b.force) {
      const 같음 = 비교 === 0;
      return sendJson(res, 400, {
        error: 같음
          ? '같은 판입니다 (' + 새판 + '). 올릴 것이 없습니다.'
          : '고른 파일이 더 예전 판입니다 (' + 새판 + ' < 지금 ' + APP_VERSION + ').\n되돌리시려면 그래도 올릴 수 있습니다.',
        canForce: !같음,
        from: APP_VERSION,
        to: 새판,
      });
    }

    /* 자료 백업 → 프로그램 백업 → 덮어쓰기 → 실패하면 되돌리기 (인터넷 길과 같다) */
    const stamp = nowStamp().replace(/[^0-9]/g, '').slice(0, 14);
    let dataBackup = '';
    try {
      const entries = await collectBackup();
      const zip = makeZip(entries);
      await fsp.mkdir(BACKUP_DIR, { recursive: true });
      dataBackup = path.join(BACKUP_DIR, '판갈이전자료-' + stamp + '.zip');
      await fsp.writeFile(dataBackup, zip);
    } catch (e) {
      return sendJson(res, 500, { error: '자료를 먼저 백업하지 못해 업그레이드를 멈췄습니다.\n' + (e.message || '') });
    }
    let progBackup = '';
    try {
      progBackup = await Update.backupCurrent(ROOT, BACKUP_DIR, stamp);
    } catch (e) {
      return sendJson(res, 500, { error: '지금 프로그램을 백업하지 못해 멈췄습니다.\n' + (e.message || '') });
    }
    try {
      await Update.writeFiles(ROOT, files);
    } catch (e) {
      try {
        await Update.rollback(ROOT, progBackup);
      } catch {}
      return sendJson(res, 500, { error: '옮기는 중에 문제가 생겨 예전 판으로 되돌렸습니다.\n' + (e.message || '') });
    }

    console.log('\n  ● 파일로 업그레이드 : ' + APP_VERSION + ' → ' + 새판 + ' (파일 ' + files.size + '개)');
    return sendJson(res, 200, {
      ok: true,
      from: APP_VERSION,
      to: 새판,
      count: files.size,
      dataBackup: path.basename(dataBackup),
      progBackup: path.basename(progBackup),
    });
  }

  /* 새 판으로 다시 켠다. 지금 프로세스를 끄고 같은 폴더에서 새로 띄운다. */
  /* ----------------------------------------------------------------
   * 업그레이드 전으로 되돌리기 (2026-08-25 사용자 지시)
   *   업그레이드할 때마다 그때의 프로그램이 `data/backup/판갈이전-…` 에 남는다.
   *   그 폴더를 골라 다시 올린다.
   *
   * 🔴 되돌리는 것은 **프로그램뿐**이다. `data/` 는 건드리지 않는다 —
   *    되돌린다고 그동안 쌓인 근무기록까지 사라지면 안 된다.
   *    자료를 되돌리는 것은 [💾 자료 백업] 의 «되돌리기» 가 하는 다른 일이다.
   * 🔴 되돌리기 **직전에 지금 판도 백업한다.** 그래야 «되돌렸다가 다시 앞으로» 갈 수 있다.
   *    그 백업이 없으면 인터넷이 막힌 학교에서는 새 판으로 돌아갈 길이 없어진다.
   * ---------------------------------------------------------------- */
  /* ----------------------------------------------------------------
   * 🔐 학교 보안 인증서 — SSL 을 가로채는 학교망에서 «업데이트 확인» 을 살린다
   *   (2026-09-09 사용자 지시 — "경고 안뜨게 하는거 처리해")
   *
   * 학교 보안 장비가 https 를 자기 인증서로 다시 묶으면, 그 인증서가
   * Windows 에는 깔려 있어 브라우저는 되는데 Node 는 거부한다
   * (SELF_SIGNED_CERT_IN_CHAIN). 그러면 하루 한 번 업데이트 확인이 조용히
   * 실패해 **새 판 알림이 영영 안 뜬다.**
   *
   * 시스템관리자가 그 인증서 파일(.cer/.crt/.pem, DER·PEM 다 됨)을 여기 올리면
   *   ① data/ssl/school-ca.pem 로 저장(PEM 으로 통일)
   *   ② 최신 Node(22.15+) : 지금 바로 기본 인증서 목록에 얹는다(재시작하면 확실)
   *   ③ 낡은 Node : 서버_실행.bat 에 NODE_EXTRA_CA_CERTS 한 줄을 넣고 다시 켜면 된다
   *      (그 줄이 이 파일 경로를 가리킨다 — GET /api/ssl-cert/bat 이 고친 .bat 을 내려준다)
   * 🔴 인증서 검사를 끄지 않는다. 믿을 인증서를 «더할» 뿐이다.
   * ---------------------------------------------------------------- */
  if (p === '/api/ssl-cert' && method === 'GET') {
    if (!needRole('manager')) return;
    let cert = null;
    const pem = 학교인증서읽기();
    if (pem) {
      try {
        const x = new crypto.X509Certificate(pem);
        cert = { subject: x.subject, issuer: x.issuer, validTo: x.validTo, validFrom: x.validFrom };
      } catch {
        cert = { subject: '(읽을 수 없는 파일)', issuer: '', validTo: '', validFrom: '' };
      }
    }
    return sendJson(res, 200, {
      hasCert: !!pem,
      cert,
      autoSupported: !!(인증서결과 && 인증서결과.auto),     // Node 가 스스로 얹을 수 있나
      applied: !!(인증서결과 && 인증서결과.ok && 인증서결과.학교있음),
      nodeVersion: process.version,
      batLine: 'if exist "%~dp0data\\ssl\\school-ca.pem" set NODE_EXTRA_CA_CERTS=%~dp0data\\ssl\\school-ca.pem',
      batAvailable: fs.existsSync(path.join(ROOT, '서버_실행.bat')),
    });
  }

  if (p === '/api/ssl-cert' && method === 'POST') {
    if (!needRole('manager')) return;
    if (!isPrivateAddress(ip)) {
      return sendJson(res, 403, { error: '학교 안(교무실 PC·같은 네트워크)에서만 올릴 수 있습니다.' });
    }
    const b = await readBody(req);
    let buf = null;
    try {
      buf = Buffer.from(String(b.dataBase64 || '').split(',').pop(), 'base64');
    } catch {
      buf = null;
    }
    if (!buf || buf.length < 100) {
      return sendJson(res, 400, { error: '파일을 읽지 못했습니다. 내려받은 인증서 파일(.cer/.crt/.pem)을 골라 주세요.' });
    }
    if (buf.length > 512 * 1024) {
      return sendJson(res, 400, { error: '파일이 너무 큽니다. 인증서 하나만 올려 주세요.' });
    }
    /* PEM 이든 DER 이든 X509Certificate 가 읽어 준다. 읽히면 PEM 으로 통일해 저장한다. */
    let x;
    try {
      x = new crypto.X509Certificate(buf);
    } catch (e) {
      return sendJson(res, 400, {
        error:
          '인증서 파일이 아닌 것 같습니다.\n' +
          '브라우저 주소창의 자물쇠 → 인증서 → «인증 경로» 맨 위(루트)를 «Base64» 로 내보낸 .cer 파일을 올려 주세요.',
      });
    }
    /* CA(발급) 인증서인지 가볍게 확인 — 서버 인증서(leaf)를 잘못 올리는 것을 막는다.
       ca 확장이 없으면 경고만 하고 막지는 않는다(학교 장비가 확장을 안 넣기도 한다). */
    let 경고 = '';
    try {
      if (x.ca === false) 경고 = '이 인증서는 발급용(CA)이 아닌 것 같습니다. 그래도 저장했지만, 안 되면 «인증 경로» 맨 위 인증서를 올려 주세요.';
    } catch {}
    try {
      fs.mkdirSync(SSL_DIR, { recursive: true });
      fs.writeFileSync(SSL_CA_FILE, x.toString()); // toString() = PEM
    } catch (e) {
      return sendJson(res, 500, { error: '저장하지 못했습니다.\n' + (e.message || '') });
    }
    인증서결과 = 보안인증서준비(); // 최신 Node 면 지금 바로 얹는다(재시작하면 확실)
    return sendJson(res, 200, {
      ok: true,
      subject: x.subject,
      issuer: x.issuer,
      validTo: x.validTo,
      applied: !!(인증서결과 && 인증서결과.ok && 인증서결과.학교있음),
      autoSupported: !!(인증서결과 && 인증서결과.auto),
      경고,
    });
  }

  if (p === '/api/ssl-cert' && method === 'DELETE') {
    if (!needRole('manager')) return;
    try {
      if (fs.existsSync(SSL_CA_FILE)) fs.unlinkSync(SSL_CA_FILE);
    } catch (e) {
      return sendJson(res, 500, { error: '지우지 못했습니다.\n' + (e.message || '') });
    }
    인증서결과 = 보안인증서준비();
    return sendJson(res, 200, { ok: true });
  }

  /* 고친 서버_실행.bat 을 내려준다 — 낡은 Node 를 쓰는 PC 가 NODE_EXTRA_CA_CERTS 로 풀 때.
     ⚠ CP949+CRLF 원본에 **ASCII 한 줄만 끼워** 넣는다(다시 인코딩하지 않는다 — 한글이 깨진다). */
  if (p === '/api/ssl-cert/bat' && method === 'GET') {
    if (!needRole('manager')) return;
    const src = path.join(ROOT, '서버_실행.bat');
    if (!fs.existsSync(src)) return sendJson(res, 404, { error: '서버_실행.bat 을 찾지 못했습니다.' });
    let raw = fs.readFileSync(src); // Buffer (CP949)
    const LINE = Buffer.from('if exist "%~dp0data\\ssl\\school-ca.pem" set NODE_EXTRA_CA_CERTS=%~dp0data\\ssl\\school-ca.pem\r\n', 'latin1');
    if (raw.includes('NODE_EXTRA_CA_CERTS')) {
      // 이미 고쳐진 파일 — 그대로 준다
    } else {
      const anchor = Buffer.from('%NODE_EXE% server.js', 'latin1');
      const at = raw.indexOf(anchor);
      if (at < 0) return sendJson(res, 500, { error: '서버_실행.bat 안에서 넣을 자리를 찾지 못했습니다. 아래 한 줄을 손으로 넣어 주세요.' });
      // 그 줄이 시작하는 곳(직전 개행 다음)을 찾는다
      let ls = raw.lastIndexOf(0x0a, at);
      ls = ls < 0 ? 0 : ls + 1;
      raw = Buffer.concat([raw.slice(0, ls), LINE, raw.slice(ls)]);
    }
    res.writeHead(200, {
      'Content-Type': 'application/octet-stream',
      'Content-Disposition': 'attachment; filename="server_run.bat"',
      'Content-Length': raw.length,
    });
    return res.end(raw);
  }

  /* 마지막으로 «하루 한 번» 확인한 결과. 인터넷을 다녀오지 않으므로 빠르다.
     `force=1` 을 붙이면 지금 다시 확인한다(화면의 [🔎 새 판이 있는지 확인] 과는 다른 길이다 —
     이쪽은 결과를 파일에 적어 두어 다음 로그인 알림에 쓰인다). */
  if (p === '/api/update/daily' && method === 'GET') {
    if (!needRole('manager')) return;
    const 다시 = url.searchParams.get('force') === '1';
    const c = 다시 ? await checkUpdateDaily(true) : await loadUpdateCache();
    return sendJson(res, 200, {
      current: APP_VERSION,
      checkedAt: c.checkedAt || '',
      ok: !!c.ok,
      latest: c.latest || '',
      newer: !!(c.latest && Update.compareVersion(c.latest, APP_VERSION) > 0),
      date: c.date || '',
      notes: Array.isArray(c.notes) ? c.notes : [],
      error: c.ok ? '' : c.error || '',
    });
  }

  if (p === '/api/update/backups' && method === 'GET') {
    if (!needRole('manager')) return;
    let list = [];
    try {
      list = Update.listBackups(BACKUP_DIR);
    } catch (e) {
      return sendJson(res, 500, { error: '백업 목록을 읽지 못했습니다.\n' + (e.message || '') });
    }
    return sendJson(res, 200, { current: APP_VERSION, backups: list });
  }

  if (p === '/api/update/revert' && method === 'POST') {
    if (!needRole('manager')) return;
    if (!isPrivateAddress(ip)) {
      return sendJson(res, 403, {
        error:
          '되돌리기는 학교 안에서만 할 수 있습니다.\n' +
          '교무실 PC 또는 같은 학교 네트워크의 컴퓨터에서 해 주세요.',
      });
    }
    const b = await readBody(req);
    const name = String(b.name || '');
    /* 이름은 사람이 보낸 값이다 — 모양부터 확인해 폴더 밖으로 나가지 못하게 한다 */
    if (!Update.isBackupName(name)) return sendJson(res, 400, { error: '되돌릴 백업을 골라 주세요.' });
    const dir = path.join(BACKUP_DIR, name);
    if (!dir.startsWith(BACKUP_DIR + path.sep)) return sendJson(res, 400, { error: '잘못된 백업 이름입니다.' });

    /* 꾸러미를 설치할 때와 **똑같이 검사한다.** 통과 못 하면 아무것도 안 바꿨다. */
    let files;
    try {
      files = Update.readBackup(dir);
    } catch (e) {
      return sendJson(res, 400, { error: e.message });
    }
    const to = (files.get('server.js').toString('utf8').match(/const APP_VERSION = '([0-9.]+)'/) || [, ''])[1];

    /* 되돌아올 길을 먼저 만든다 — 지금 판을 백업한다 */
    const stamp = nowStamp().replace(/[^0-9]/g, '').slice(0, 14);
    let progBackup = '';
    try {
      progBackup = await Update.backupCurrent(ROOT, BACKUP_DIR, stamp);
    } catch (e) {
      return sendJson(res, 500, { error: '지금 판을 백업하지 못해 되돌리기를 멈췄습니다.\n' + (e.message || '') });
    }

    try {
      await Update.writeFiles(ROOT, files);
    } catch (e) {
      try {
        await Update.rollback(ROOT, progBackup);
      } catch {}
      return sendJson(res, 500, {
        error: '되돌리는 중에 문제가 생겨 **원래대로 두었습니다**.\n' + (e.message || ''),
      });
    }

    console.log(`\n  ● 되돌리기 : ${APP_VERSION} → ${to || '?'} (${name} · 파일 ${files.size}개)`);
    console.log(`    다시 앞으로 가려면 : ${progBackup}`);
    return sendJson(res, 200, {
      ok: true,
      from: APP_VERSION,
      to,
      count: files.size,
      used: name,
      progBackup: path.basename(progBackup),
    });
  }

  if (p === '/api/update/restart' && method === 'POST') {
    if (!needRole('manager')) return;
    if (!isPrivateAddress(ip)) return sendJson(res, 403, { error: '학교 안에서만 할 수 있습니다.' });
    sendJson(res, 200, { ok: true, port: SHARE.port || PORT });
    /* 답을 보낸 뒤에 갈아탄다. detached 로 띄우고 이 프로세스는 끝낸다 —
       그래야 새 프로세스가 부모와 함께 죽지 않는다. */
    setTimeout(() => {
      try {
        const { spawn } = require('child_process');
        const child = spawn(process.execPath, [path.join(ROOT, 'server.js'), '--no-browser'], {
          cwd: ROOT,
          detached: true,
          stdio: 'ignore',
          env: { ...process.env, PORT: String(SHARE.port || PORT), AICODI_RESTART: '1' },
        });
        child.unref();
      } catch (e) {
        console.log('  ⚠ 다시 켜지 못했습니다 : ' + e.message);
      }
      setTimeout(() => process.exit(0), 400);
    }, 600);
    return;
  }

  /* ---------- 명단 (엑셀·CSV 업로드) ---------- */
  if (p === '/api/members' && method === 'GET') {
    if (!needRole('manager')) return;
    const [members, s] = await Promise.all([loadMembers(), loadSettings()]);
    return sendJson(res, 200, {
      // 인증코드는 해시로만 저장되어 있어 다시 보여 줄 수 없습니다(설정된 여부만 알려 줍니다)
      members: members.map((m) => ({ id: m.id, name: m.name, subject: m.subject, role: m.role, hasCode: !!m.codeHash })),
      rosterInfo: s.rosterInfo,
      roleLabel: ROLE_LABEL,
    });
  }

  /**
   * 명단 파일 올리기
   *  apply 가 false 면 '미리보기'만 하고 저장하지 않습니다.
   *  body : { fileName, dataBase64, apply }
   */
  if (p === '/api/members/import' && method === 'POST') {
    if (!needRole('manager')) return;
    const body = await readBody(req);
    const b64 = String(body.dataBase64 || '').replace(/^data:[^,]*,/, '');
    if (!b64) return sendJson(res, 400, { error: '파일을 고르지 않았습니다.' });

    let rows;
    try {
      rows = readTable(Buffer.from(b64, 'base64'), body.fileName || '');
    } catch (e) {
      return sendJson(res, 400, { error: e.message });
    }
    if (!rows.length) return sendJson(res, 400, { error: '파일이 비어 있습니다.' });

    const { members, errors, counts } = parseRoster(rows);
    if (!members.length) {
      return sendJson(res, 400, {
        error: '읽어 들일 수 있는 사람이 없습니다. 아래 문제를 고쳐 주세요.',
        errors,
        counts,
      });
    }
    if (members.length > 200) return sendJson(res, 400, { error: '한 번에 200명까지만 올릴 수 있습니다.' });

    // 미리보기 : 저장하지 않고 결과만 돌려준다
    if (!body.apply) {
      return sendJson(res, 200, {
        preview: true,
        counts,
        errors,
        members: members.map((m) => ({ name: m.name, subject: m.subject, role: m.role, codeLen: m.code.length })),
      });
    }

    // 저장 : 인증코드를 해시로 바꿔 저장한다(평문은 남기지 않는다)
    const prev = await loadMembers();
    const saved = await Promise.all(
      members.map(async (m, i) => {
        const old = prev.find((x) => x.name === m.name);
        return {
          id: old ? old.id : `m${Date.now().toString(36)}${i}`,
          name: m.name,
          subject: m.subject,
          role: m.role,
          codeHash: await hashCode(m.code),
        };
      }),
    );
    await writeJson(FILES.members, saved);

    // 시스템관리자·코디네이터 이름을 설정에도 반영해 서식에 그대로 찍히게 한다
    const s = await loadSettings();
    const mgr = saved.find((m) => m.role === 'manager');
    const co = saved.find((m) => m.role === 'coordinator');
    if (mgr && !s.manager.name) s.manager.name = mgr.name;
    if (co) s.coordinator.name = co.name;
    s.rosterInfo = {
      fileName: String(body.fileName || '').slice(0, 100),
      at: nowStamp(),
      counts,
    };
    s.updatedAt = nowStamp();
    await writeJson(FILES.settings, s);

    // 명단이 바뀌면 기존 로그인은 무효로 한다(지금 올린 사람만 그대로 유지)
    const keep = req.headers['x-auth'];
    for (const t of [...sessions.keys()]) if (t !== keep) sessions.delete(t);

    return sendJson(res, 200, { ok: true, counts, errors, rosterInfo: s.rosterInfo });
  }

  /* ---------- 작업 요청 ---------- */
  if (p === '/api/requests' && method === 'GET') {
    if (!needAnyone()) return;
    const requests = await loadRequests();
    const from = url.searchParams.get('from');
    const to = url.searchParams.get('to');
    const status = url.searchParams.get('status');
    const teacherId = url.searchParams.get('teacherId');
    let list = requests;
    if (from) list = list.filter((r) => r.date >= from);
    if (to) list = list.filter((r) => r.date <= to);
    if (status) list = list.filter((r) => r.status === status);
    if (teacherId) list = list.filter((r) => r.teacherId === teacherId);
    list = [...list].sort((a, b) => (a.date + a.startTime).localeCompare(b.date + b.startTime));
    return sendJson(res, 200, list);
  }

  if (p === '/api/requests' && method === 'POST') {
    const b = await readBody(req);
    const s = await loadSettings();

    // 수행 제한 범위(금지 업무)는 서버에서도 한 번 더 막는다
    const blocked = CATALOG.blocked.find((x) => x.task === b.taskType);
    if (blocked) {
      return sendJson(res, 400, {
        error: `요청할 수 없는 업무입니다 : ${blocked.task}\n${blocked.why}\n${CATALOG.legalNote}`,
      });
    }

    // 정해진 다섯 가지 중에서만 고를 수 있다. 영역(area)은 서버가 붙인다.
    const picked = CATALOG.taskTypes.find((t) => t.name === b.taskType);
    if (!picked) {
      return sendJson(res, 400, { error: '어떤 도움이 필요한지 목록에서 골라 주세요.' });
    }

    // 인증코드로 확인된 본인 이름으로만 요청할 수 있다(남의 이름으로 요청 불가)
    if (!needRole('teacher', 'manager')) return;
    const members = await loadMembers();
    const teacher = members.find((m) => m.id === ses.memberId);
    if (!teacher) return sendJson(res, 400, { error: '명단에서 이름을 찾을 수 없습니다. 시스템관리자님께 문의해 주세요.' });

    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(b.date || ''))) {
      return sendJson(res, 400, { error: '희망 날짜를 골라 주세요.' });
    }
    const hrs = hoursBetween(b.startTime, b.endTime);
    if (hrs <= 0) return sendJson(res, 400, { error: '시작 시간과 끝나는 시간을 올바르게 입력해 주세요.' });
    if (!String(b.content || '').trim()) return sendJson(res, 400, { error: '요청 내용을 적어 주세요.' });

    const requests = await loadRequests();

    /* 이미 확정된 일정과 시간이 겹치는지 본다.
       코디네이터는 한 사람이라 같은 시간에 두 곳에 갈 수 없다.
       - 그냥은 받지 않는다(409). 선생님 화면에 누구와 겹치는지 보여 준다.
       - 그래도 꼭 필요하면 `coordinate: true` 로 다시 보내 **조율 요청**으로 접수한다.
         이때는 코디네이터가 아니라 **시스템관리자가 결정**한다(누구 수업을 우선할지는 학교가 정할 일이다). */
    const conflicts = findConflicts(requests, b.date, b.startTime, b.endTime);
    const wantsCoordination = b.coordinate === true;
    if (conflicts.firm.length && !wantsCoordination) {
      return sendJson(res, 409, {
        error:
          `그 시간에는 이미 확정된 일정이 있습니다.\n\n` +
          conflicts.firm.map((c) => `· ${conflictLine(c)}`).join('\n') +
          `\n\n다른 시간을 골라 주시거나, 꼭 그 시간이어야 하면 [조율 요청]으로 보내 주세요.`,
        conflicts: conflicts.firm,
        canCoordinate: true,
      });
    }

    const seq = String(requests.length + 1).padStart(3, '0');
    const item = {
      id: `R-${todayStr().replace(/-/g, '')}-${seq}`,
      createdAt: nowStamp(),
      teacherId: teacher.id,
      teacherName: teacher.name,
      subject: String(b.subject || teacher.subject || '').slice(0, 20),
      area: picked.area, // 결과보고서 영역 — 고른 업무에 따라 서버가 정한다
      taskType: picked.name,
      date: b.date,
      startTime: b.startTime,
      endTime: b.endTime,
      hours: hrs,
      place: String(b.place || '').slice(0, 30),
      // 지도반은 코디네이터가 활동 기록에 적는다. 학생수는 아예 다루지 않는다(2026-07-29 사용자 지시)
      classes: '',
      operationType: String(b.operationType || '정규수업').slice(0, 20),
      content: String(b.content).slice(0, 1000),
      materials: String(b.materials || '').slice(0, 500),
      // 확정된 일정과 겹치는데도 보낸 요청은 곧바로 '조율' 로 들어간다 → 시스템관리자가 결정
      status: conflicts.firm.length ? 'coordinating' : 'requested',
      reply: null,
      // 무엇과 겹쳤는지 남겨 둔다. 시스템관리자가 결정할 때 근거가 된다
      conflictWith: conflicts.firm,
      coordinateReason: conflicts.firm.length ? String(b.coordinateReason || '').slice(0, 300) : '',
      history: [{ at: nowStamp(), who: teacher.name, what: '요청 등록' }],
    };
    if (conflicts.firm.length) {
      item.history.push({
        at: nowStamp(),
        who: teacher.name,
        what: `시간이 겹쳐 조율 요청 (${conflicts.firm.map((c) => `${c.startTime}~${c.endTime} ${c.teacherName}`).join(', ')})`,
      });
    }
    requests.push(item);
    await writeJson(FILES.requests, requests);
    return sendJson(res, 200, { ok: true, id: item.id, item, conflicts });
  }

  /* ---------- 그날 이미 잡힌 시간 (요청 화면에서 미리 보여 준다) ---------- */
  if (p === '/api/day-busy' && method === 'GET') {
    if (!needAnyone()) return;
    const date = url.searchParams.get('date') || '';
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return sendJson(res, 400, { error: '날짜가 올바르지 않습니다.' });
    // 하루 전체(00:00~24:00)와 겹치는 것 = 그날의 모든 일정
    const all = findConflicts(await loadRequests(), date, '00:00', '23:59');
    return sendJson(res, 200, { date, firm: all.firm, pending: all.pending });
  }

  /* 코디네이터 응답 : 수락 / 조율 요청 / 시간조절 제안
   *
   * **코디네이터는 요청을 거절하지 않는다**(2026-08-07 사용자 지시).
   * 코디네이터는 학교가 채용한 지원 인력이라, 선생님의 요청을 스스로 물리치는 자리에 두면
   * 서로 곤란해진다. 어려운 요청은 **조율**로 올리고 **시스템관리자가 결정**한다.
   * 예전 `reject` 도 계속 받아 `coordinate` 와 같게 처리한다(옛 화면 호환).
   */
  const replyMatch = /^\/api\/requests\/([A-Za-z0-9-]+)\/reply$/.exec(p);
  if (replyMatch && method === 'POST') {
    if (!needRole('coordinator')) return;
    const b = await readBody(req);
    const requests = await loadRequests();
    const r = requests.find((x) => x.id === replyMatch[1]);
    if (!r) return sendJson(res, 404, { error: '요청을 찾을 수 없습니다.' });

    const action = b.action === 'reject' ? 'coordinate' : b.action;
    if (action === 'accept') {
      // 수락하려는데 그 사이 다른 요청이 확정되어 겹칠 수 있다 — 그러면 조율로 넘긴다
      const c = findConflicts(requests, r.date, r.startTime, r.endTime, r.id);
      if (c.firm.length) {
        return sendJson(res, 409, {
          error:
            `그 시간에는 이미 확정된 일정이 있어 수락할 수 없습니다.\n\n` +
            c.firm.map((x) => `· ${conflictLine(x)}`).join('\n') +
            `\n\n[조율 요청]으로 올리시면 시스템관리자님이 결정해 주십니다.`,
          conflicts: c.firm,
        });
      }
      r.status = 'accepted';
      r.reply = { at: nowStamp(), action, reason: String(b.reason || '').slice(0, 300) };
      r.history.push({ at: nowStamp(), who: '코디네이터', what: '수락' });
    } else if (action === 'coordinate') {
      if (!String(b.reason || '').trim()) return sendJson(res, 400, { error: '어떤 점이 어려운지 적어 주세요. 시스템관리자님께 그대로 전달됩니다.' });
      r.status = 'coordinating';
      r.reply = { at: nowStamp(), action: 'coordinate', reason: String(b.reason).slice(0, 300) };
      r.coordinateReason = r.reply.reason;
      r.history.push({ at: nowStamp(), who: '코디네이터', what: `조율 요청 (${r.reply.reason})` });
    } else if (action === 'reschedule') {
      const hrs = hoursBetween(b.newStartTime, b.newEndTime);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(String(b.newDate || '')) || hrs <= 0) {
        return sendJson(res, 400, { error: '조절할 날짜와 시간을 올바르게 입력해 주세요.' });
      }
      r.status = 'rescheduled';
      r.reply = {
        at: nowStamp(),
        action,
        reason: String(b.reason || '').slice(0, 300),
        newDate: b.newDate,
        newStartTime: b.newStartTime,
        newEndTime: b.newEndTime,
        newHours: hrs,
      };
      r.history.push({
        at: nowStamp(),
        who: '코디네이터',
        what: `시간조절 제안 → ${b.newDate} ${b.newStartTime}~${b.newEndTime}`,
      });
    } else {
      return sendJson(res, 400, { error: '알 수 없는 처리입니다.' });
    }
    await writeJson(FILES.requests, requests);
    return sendJson(res, 200, { ok: true, item: r });
  }

  // 시간조절 제안에 대한 선생님의 응답 (동의 / 취소)
  const confirmMatch = /^\/api\/requests\/([A-Za-z0-9-]+)\/confirm$/.exec(p);
  if (confirmMatch && method === 'POST') {
    if (!needRole('teacher', 'manager')) return;
    const b = await readBody(req);
    const requests = await loadRequests();
    const r = requests.find((x) => x.id === confirmMatch[1]);
    if (!r) return sendJson(res, 404, { error: '요청을 찾을 수 없습니다.' });
    if (r.status !== 'rescheduled') return sendJson(res, 400, { error: '시간조절 제안이 없는 요청입니다.' });
    // 본인이 낸 요청만 확정·취소할 수 있다 (시스템관리자는 예외)
    if (ses.role !== 'manager' && ses.memberId && r.teacherId !== ses.memberId) {
      return sendJson(res, 403, { error: '본인이 요청한 건만 확정하거나 취소할 수 있습니다.' });
    }

    if (b.agree) {
      // 제안을 받는 사이 그 시간이 다른 요청으로 채워졌을 수 있다
      const c = findConflicts(requests, r.reply.newDate, r.reply.newStartTime, r.reply.newEndTime, r.id);
      if (c.firm.length) {
        return sendJson(res, 409, {
          error:
            `그 사이 그 시간에 다른 일정이 확정되었습니다.\n\n` +
            c.firm.map((x) => `· ${conflictLine(x)}`).join('\n') +
            `\n\n코디네이터에게 다른 시간을 다시 제안해 달라고 알려 주세요.`,
          conflicts: c.firm,
        });
      }
      r.date = r.reply.newDate;
      r.startTime = r.reply.newStartTime;
      r.endTime = r.reply.newEndTime;
      r.hours = r.reply.newHours;
      r.status = 'accepted';
      r.history.push({ at: nowStamp(), who: r.teacherName, what: '조절된 시간에 동의 → 확정' });
    } else {
      r.status = 'cancelled';
      r.history.push({ at: nowStamp(), who: r.teacherName, what: '요청 취소' });
    }
    await writeJson(FILES.requests, requests);
    return sendJson(res, 200, { ok: true, item: r });
  }

  /* ---------- 요청 취소 (선생님 본인 · 시스템관리자) ----------
   *
   * 2026-08-25 사용자 지시로 넣었다 — *"요청화면에서 요청취소 기능 넣어줘. 어느 순간 없어졌네"*.
   * 예전에는 «시간조절 제안을 물리는» 길(`/confirm` 에 `agree:false`)뿐이라,
   * 정작 흔한 «보내 놓고 보니 필요 없어졌다» 를 취소할 방법이 없었다.
   *
   * ⚠ 무엇을 취소할 수 있는지는 `취소못하는이유()` 한 곳에서만 판단한다.
   *   화면도 같은 규칙을 쓰지만 **최종 판단은 여기**다(화면을 우회해 보내도 막힌다).
   */
  const cancelMatch = /^\/api\/requests\/([A-Za-z0-9-]+)\/cancel$/.exec(p);
  if (cancelMatch && method === 'POST') {
    if (!needRole('teacher', 'manager')) return;
    const requests = await loadRequests();
    const r = requests.find((x) => x.id === cancelMatch[1]);
    if (!r) return sendJson(res, 404, { error: '요청을 찾을 수 없습니다.' });
    const 이유 = 취소못하는이유(r, ses);
    if (이유) return sendJson(res, 400, { error: 이유 });

    const 전 = r.status;
    r.status = 'cancelled';
    r.history.push({
      at: nowStamp(),
      who: ses.role === 'manager' && r.teacherId !== ses.memberId ? '시스템관리자' : r.teacherName,
      /* 어느 상태에서 취소했는지 남긴다 — «확정까지 됐던 건이 왜 없어졌나» 를 설명할 근거다 */
      what: `요청 취소 (${STATUS_KO_SERVER[전] || 전} 상태에서)`,
    });
    await writeJson(FILES.requests, requests);
    return sendJson(res, 200, { ok: true, item: r });
  }

  /* ---------- 조율 건 결정 (시스템관리자 전용) ----------
   *
   * 조율로 올라오는 두 가지 경우
   *   ① 시간이 이미 찬 자리에 선생님이 [조율 요청]으로 보낸 요청
   *   ② 코디네이터가 "이건 제가 판단하기 어렵습니다" 하고 올린 요청
   * 둘 다 **누구를 먼저 도울지 정하는 일**이라 학교가 결정할 몫이다.
   * 시스템관리자는 셋 중 하나를 고른다 : 그대로 진행 / 시간을 바꿔 제안 / 이번에는 어려움.
   */
  const decideMatch = /^\/api\/requests\/([A-Za-z0-9-]+)\/decide$/.exec(p);
  if (decideMatch && method === 'POST') {
    if (!needRole('manager')) return;
    const b = await readBody(req);
    const s = await loadSettings();
    const who = s.manager.name || '시스템관리자';
    const requests = await loadRequests();
    const r = requests.find((x) => x.id === decideMatch[1]);
    if (!r) return sendJson(res, 404, { error: '요청을 찾을 수 없습니다.' });
    if (r.status !== 'coordinating') {
      return sendJson(res, 400, { error: '조율 중인 요청이 아닙니다. 화면을 새로 고쳐 주세요.' });
    }
    const note = String(b.reason || '').slice(0, 300);

    if (b.action === 'approve') {
      // 시스템관리자가 "이걸 먼저 하라"고 정한 것이므로, 겹치더라도 진행시킨다.
      // 대신 무엇과 겹치는지 기록에 남겨 나중에 확인할 수 있게 한다.
      const c = findConflicts(requests, r.date, r.startTime, r.endTime, r.id);
      r.status = 'accepted';
      r.reply = { at: nowStamp(), action: 'approve', reason: note, by: who };
      r.history.push({
        at: nowStamp(),
        who,
        what: `조율 결정 : 이대로 진행${note ? ` (${note})` : ''}${c.firm.length ? ` ※ ${c.firm.map((x) => `${x.startTime}~${x.endTime} ${x.teacherName}`).join(', ')} 와 시간이 겹칩니다` : ''}`,
      });
    } else if (b.action === 'reschedule') {
      const hrs = hoursBetween(b.newStartTime, b.newEndTime);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(String(b.newDate || '')) || hrs <= 0) {
        return sendJson(res, 400, { error: '바꿀 날짜와 시간을 올바르게 입력해 주세요.' });
      }
      const c = findConflicts(requests, b.newDate, b.newStartTime, b.newEndTime, r.id);
      if (c.firm.length) {
        return sendJson(res, 409, {
          error: `바꾸려는 시간에도 이미 확정된 일정이 있습니다.\n\n` + c.firm.map((x) => `· ${conflictLine(x)}`).join('\n'),
          conflicts: c.firm,
        });
      }
      // 선생님 동의를 받아야 확정된다(기존 시간조절 흐름과 같다)
      r.status = 'rescheduled';
      r.reply = {
        at: nowStamp(),
        action: 'reschedule',
        by: who,
        reason: note,
        newDate: b.newDate,
        newStartTime: b.newStartTime,
        newEndTime: b.newEndTime,
        newHours: hrs,
      };
      r.history.push({ at: nowStamp(), who, what: `조율 결정 : 시간 변경 제안 → ${b.newDate} ${b.newStartTime}~${b.newEndTime}${note ? ` (${note})` : ''}` });
    } else if (b.action === 'close') {
      if (!note) return sendJson(res, 400, { error: '선생님께 전할 말씀을 적어 주세요.' });
      r.status = 'closed';
      r.reply = { at: nowStamp(), action: 'close', reason: note, by: who };
      r.history.push({ at: nowStamp(), who, what: `조율 결정 : 이번에는 어려움 (${note})` });
    } else {
      return sendJson(res, 400, { error: '알 수 없는 결정입니다.' });
    }
    await writeJson(FILES.requests, requests);
    return sendJson(res, 200, { ok: true, item: r });
  }

  /* ================================================================
   * 예산 집행 내역 (시스템관리자)
   *
   * 편성(설정 탭)과 집행(이 탭)을 **따로 둔다.**
   *   편성 : 비목·세목·편성액 — 학년도 초에 한 번 정하고 거의 안 바뀐다
   *   집행 : 언제·어디에·얼마를 썼는지 **건별로** 쌓인다
   * 정산서(결과보고서 Ⅲ)의 집행액은 **이 건별 내역의 합**이다.
   * 그래서 집행을 적으면 정산서가 저절로 맞는다 — 두 곳에 같은 숫자를 넣을 일이 없다.
   * ================================================================ */

  /** 집행 내역 + 편성 줄별 집계 */
  if (p === '/api/spending' && method === 'GET') {
    if (!needStaff()) return;
    const year = Number(url.searchParams.get('year')) || new Date().getFullYear();
    const [s, all, logs] = await Promise.all([loadSettings(), loadSpending(), loadLogs()]);
    const items = all
      .filter((x) => String(x.date || '').startsWith(String(year)))
      .sort((a, b) => String(b.date).localeCompare(String(a.date)));

    // 편성 줄별로 얼마 썼는지
    const byRow = {};
    for (const x of items) byRow[x.rowId] = (byRow[x.rowId] || 0) + (Number(x.amount) || 0);

    const rows = (s.report.budgetRows || []).map((r) => {
      const spent = byRow[r.id] || 0;
      return { ...r, spent, remain: (Number(r.planned) || 0) - spent, count: items.filter((x) => x.rowId === r.id).length };
    });

    // 활동기록 기준 인건비 — 인건비 줄에 아직 안 넣었으면 알려 주려고 함께 보낸다
    const wage = Number(s.coordinator.hourlyWage) || 0;
    const byMonth = {};
    for (const l of logs) {
      if (!String(l.date).startsWith(String(year))) continue;
      const m = String(l.date).slice(0, 7);
      byMonth[m] = Math.round(((byMonth[m] || 0) + (Number(l.hours) || 0)) * 10) / 10;
    }
    const wageByMonth = Object.entries(byMonth)
      .sort()
      .map(([month, hours]) => ({ month, hours, amount: Math.round(hours * wage) }));

    return sendJson(res, 200, {
      year,
      items,
      rows,
      planned: rows.reduce((n, r) => n + (Number(r.planned) || 0), 0),
      spent: rows.reduce((n, r) => n + r.spent, 0),
      hourlyWage: wage,
      wageByMonth, // 활동기록에서 계산한 월별 인건비
    });
  }

  /** 집행 한 건 추가·수정 (시스템관리자만 — 예산은 학교 돈이다) */
  if (p === '/api/spending' && method === 'POST') {
    if (!needRole('manager')) return;
    const b = await readBody(req);
    const s = await loadSettings();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(b.date || ''))) return sendJson(res, 400, { error: '집행한 날짜를 골라 주세요.' });
    const row = (s.report.budgetRows || []).find((r) => r.id === String(b.rowId || ''));
    if (!row) return sendJson(res, 400, { error: '어느 예산(비목·세목)에서 집행했는지 골라 주세요.' });
    const amount = Math.round(Number(b.amount) || 0);
    if (amount <= 0) return sendJson(res, 400, { error: '집행 금액을 넣어 주세요. (0원보다 커야 합니다)' });

    const list = await loadSpending();
    const now = nowStamp();
    if (b.id) {
      const x = list.find((v) => v.id === String(b.id));
      if (!x) return sendJson(res, 404, { error: '고치려는 집행 내역을 찾을 수 없습니다.' });
      Object.assign(x, {
        date: b.date,
        rowId: row.id,
        amount,
        content: String(b.content || '').slice(0, 200),
        proof: String(b.proof || '').slice(0, 60),
        updatedAt: now,
      });
      await writeJson(FILES.spending, list);
      return sendJson(res, 200, { ok: true, item: x });
    }
    const item = {
      id: `S-${Date.now().toString(36)}-${crypto.randomBytes(2).toString('hex')}`,
      date: b.date,
      rowId: row.id,
      amount,
      content: String(b.content || '').slice(0, 200),
      proof: String(b.proof || '').slice(0, 60),
      at: now,
    };
    list.push(item);
    await writeJson(FILES.spending, list);
    return sendJson(res, 200, { ok: true, item });
  }

  /** 집행 한 건 지우기 */
  const spendDel = /^\/api\/spending\/([A-Za-z0-9-]+)$/.exec(p);
  if (spendDel && method === 'DELETE') {
    if (!needRole('manager')) return;
    const list = await loadSpending();
    const i = list.findIndex((x) => x.id === spendDel[1]);
    if (i < 0) return sendJson(res, 404, { error: '집행 내역을 찾을 수 없습니다.' });
    const [gone] = list.splice(i, 1);
    await writeJson(FILES.spending, list);
    return sendJson(res, 200, { ok: true, removed: gone });
  }

  /** 활동기록의 월별 인건비를 집행 내역으로 한꺼번에 넣기 (같은 달은 건너뛴다) */
  if (p === '/api/spending/from-logs' && method === 'POST') {
    if (!needRole('manager')) return;
    const b = await readBody(req);
    const s = await loadSettings();
    const row = (s.report.budgetRows || []).find((r) => r.id === String(b.rowId || ''));
    if (!row) return sendJson(res, 400, { error: '인건비를 넣을 예산 줄을 골라 주세요.' });
    const year = Number(b.year) || new Date().getFullYear();
    const wage = Number(s.coordinator.hourlyWage) || 0;
    if (wage <= 0) return sendJson(res, 400, { error: '시급이 설정되어 있지 않습니다. [코디네이터 계약 정보]에서 시급을 먼저 넣어 주세요.' });

    const logs = await loadLogs();
    const byMonth = {};
    for (const l of logs) {
      if (!String(l.date).startsWith(String(year))) continue;
      const m = String(l.date).slice(0, 7);
      byMonth[m] = Math.round(((byMonth[m] || 0) + (Number(l.hours) || 0)) * 10) / 10;
    }
    const list = await loadSpending();
    const added = [];
    const skipped = [];
    for (const [month, hours] of Object.entries(byMonth).sort()) {
      const amount = Math.round(hours * wage);
      if (amount <= 0) continue;
      // 같은 달·같은 예산 줄에 이미 넣었으면 다시 넣지 않는다(두 번 세어지면 정산이 틀어진다)
      if (list.some((x) => x.rowId === row.id && String(x.date).slice(0, 7) === month && x.fromLogs)) {
        skipped.push(month);
        continue;
      }
      const last = `${month}-${new Date(Number(month.slice(0, 4)), Number(month.slice(5, 7)), 0).getDate()}`;
      const item = {
        id: `S-${Date.now().toString(36)}-${crypto.randomBytes(2).toString('hex')}`,
        date: last, // 그 달의 마지막 날로 넣는다(급여 지급 기준)
        rowId: row.id,
        amount,
        content: `${Number(month.slice(5, 7))}월 활동 ${hours}시간 × ${wage.toLocaleString('ko-KR')}원`,
        proof: '활동기록',
        fromLogs: true,
        at: nowStamp(),
      };
      list.push(item);
      added.push(item);
    }
    if (added.length) await writeJson(FILES.spending, list);
    return sendJson(res, 200, { ok: true, added: added.length, skipped, items: added });
  }

  /* ---------- 활동 기록 (활동일지 + 출근기록부) ---------- */
  if (p === '/api/logs' && method === 'GET') {
    if (!needStaff()) return;
    const logs = await loadLogs();
    const month = url.searchParams.get('month'); // YYYY-MM
    let list = logs;
    if (month) list = list.filter((l) => String(l.date).startsWith(month));
    list = [...list].sort((a, b) => a.date.localeCompare(b.date));
    return sendJson(res, 200, list);
  }

  if (p === '/api/logs' && method === 'POST') {
    if (!needRole('coordinator')) return;
    const b = await readBody(req);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(b.date || ''))) {
      return sendJson(res, 400, { error: '날짜를 골라 주세요.' });
    }
    /* 세 숫자를 나눠 저장한다 — 섞으면 인건비가 틀어진다.
       stayHours 체류(출근~퇴근) · breakHours 유휴(휴게) · hours 근무(= 체류 − 휴게)
       `hours` 를 **근무시간**으로 두는 이유 : 인건비·주 15시간·정산서가 이미 `hours` 를 쓰고 있어
       이름을 그대로 두면 그쪽 코드를 건드리지 않아도 법대로(휴게 무급) 계산된다. */
    const t = dayTime(b.clockIn, b.clockOut, b.breakStart, b.breakEnd);
    if (t.stay <= 0) return sendJson(res, 400, { error: '출근·퇴근 시간을 올바르게 입력해 주세요.' });
    if (t.error) return sendJson(res, 400, { error: t.error });
    /* 4시간 이상 근무한 날은 유휴시간 없이 저장할 수 없다(2026-08-22 사용자 지시).
       예전에는 경고만 띄웠는데, 경고는 그냥 지나칠 수 있어 법정 휴게가 빠진 기록이 남았다. */
    const shortage = breakShortage(t);
    if (shortage) return sendJson(res, 400, { error: shortage });
    const hours = t.work;

    const s = await loadSettings();
    const logs = await loadLogs();
    const idx = logs.findIndex((l) => l.date === b.date);
    const prev = idx >= 0 ? logs[idx] : null;

    // 점검이 끝난 기록은 코디네이터가 고칠 수 없다(시스템관리자가 반송해야 수정 가능)
    if (prev && prev.check && prev.check.status === 'checked') {
      return sendJson(res, 400, { error: '이미 점검이 완료된 날입니다. 시스템관리자님께 반송을 요청해 주세요.' });
    }

    /* 활동 기록은 '오늘' 만 쓸 수 있다 — 기준은 접속한 PC 가 아니라 이 서버의 날짜다.
       복무 증빙 문서(활동일지·출근기록부)이므로 지난 날짜를 나중에 몰아 쓰거나
       앞날을 미리 써 두는 일을 막는다(업무편람 Ⅳ-2 근로시간 관리).
       예외 : 시스템관리자가 반송한 기록은 고쳐 달라는 뜻이므로 지난 날짜라도 다시 저장할 수 있다.

       ⚠ 「반송되었는가」로만 보면 **한 번만** 고칠 수 있다 — 다시 저장하는 순간 반송 표시가
       지워져 두 번째 수정이 막혔다(2026-08-22 사용자 지적). 고쳐 올린 뒤 또 틀린 것을
       발견하면 시스템관리자께 다시 반송을 부탁해야 했다.
       그래서 `reopened` 문패를 둔다 — **시스템관리자가 점검을 완료할 때까지 계속 열려 있다.** */
    const today = todayStr();
    const isReturned = !!(prev && ((prev.check && prev.check.status === 'returned') || prev.reopened));
    if (b.date !== today && !isReturned) {
      const kind = b.date > today ? '앞으로 올 날짜' : '지난 날짜';
      return sendJson(res, 400, {
        error:
          `활동 기록은 오늘(${today}) 것만 쓸 수 있습니다.\n` +
          `고르신 ${b.date} 은(는) ${kind}입니다.\n\n` +
          '· 근무한 날 당일에 기록해 주세요.\n' +
          '· 이미 지난 날을 고쳐야 한다면 시스템관리자님께 반송을 요청하세요.\n' +
          '  (반송된 기록은 지난 날짜라도 고쳐서 다시 저장할 수 있습니다)',
        serverDate: today,
      });
    }

    const photos = prev ? [...(prev.photos || [])] : [];
    for (const dataUrl of (b.newPhotos || []).slice(0, 6)) {
      const f = await saveDataUrl(dataUrl, PHOTO_DIR, b.date);
      if (f) photos.push(f);
    }
    if (Array.isArray(b.keepPhotos)) {
      for (let i = photos.length - 1; i >= 0; i--) {
        if (!b.keepPhotos.includes(photos[i]) && prev && (prev.photos || []).includes(photos[i])) {
          photos.splice(i, 1);
        }
      }
    }

    // 강사 서명 : 이번에 그린 것이 있으면 그걸, 없으면 설정에 등록된 서명을 쓴다
    let signFile = prev ? prev.signFile : '';
    if (b.sign) {
      const f = await saveDataUrl(b.sign, SIGN_DIR, `co-${b.date}`);
      if (f) signFile = f;
    } else if (!signFile && s.coordinator.signFile) {
      signFile = s.coordinator.signFile;
    }

    const item = {
      id: `L-${b.date}`,
      date: b.date,
      weekday: WEEK_KO[new Date(b.date + 'T00:00:00').getDay()],
      clockIn: b.clockIn,
      clockOut: b.clockOut,
      breakStart: b.breakStart ? String(b.breakStart) : '',
      breakEnd: b.breakEnd ? String(b.breakEnd) : '',
      hours, // 근무시간 (휴게 제외) — 인건비.15시간에 쓰는 값
      stayHours: t.stay, // 체류시간 (출근기록부에 찍는 값)
      breakHours: t.brk, // 유휴(휴게)시간
      place: String(b.place || '').slice(0, 40),
      safetyCheck: !!b.safetyCheck,
      safetyNote: String(b.safetyNote || (b.safetyCheck ? '이상 없음' : '')).slice(0, 40),
      items: (b.items || []).slice(0, 12).map((it) => ({
        requestId: String(it.requestId || '').slice(0, 30),
        classes: String(it.classes || '').slice(0, 30),
        subject: String(it.subject || '').slice(0, 20),
        area: String(it.area || '').slice(0, 2),
        operationType: String(it.operationType || '').slice(0, 20),
        content: String(it.content || '').slice(0, 300),
        hours: Math.max(0, Number(it.hours) || 0),
      })),
      note: String(b.note || '').slice(0, 1000),
      photos,
      signFile,
      check: prev && prev.check && prev.check.status === 'returned' ? prev.check : prev ? prev.check : null,
      updatedAt: nowStamp(),
    };
    // 수정해서 다시 올리면 '반송' 상태는 지우고 미점검으로 되돌린다
    if (item.check && item.check.status === 'returned') item.check = null;
    /* 다만 «열려 있다» 는 사실은 남긴다 — 점검이 끝날 때까지 지난 날짜라도 또 고칠 수 있다.
       (이 문패는 시스템관리자가 [점검 완료] 를 누를 때 지워진다) */
    if (isReturned) item.reopened = true;

    if (idx >= 0) logs[idx] = item;
    else logs.push(item);
    await writeJson(FILES.logs, logs);

    // 이 날짜의 확정 요청은 '완료'로 표시
    const requests = await loadRequests();
    let touched = false;
    for (const r of requests) {
      if (r.date === b.date && r.status === 'accepted') {
        r.status = 'done';
        r.history.push({ at: nowStamp(), who: '코디네이터', what: '활동 기록 작성 완료' });
        touched = true;
      }
    }
    if (touched) await writeJson(FILES.requests, requests);

    return sendJson(res, 200, { ok: true, item });
  }

  // 시스템관리자 점검(서명) / 반송
  const checkMatch = /^\/api\/logs\/([A-Za-z0-9-]+)\/check$/.exec(p);
  if (checkMatch && method === 'POST') {
    if (!needRole('manager')) return;
    const b = await readBody(req);
    const s = await loadSettings();
    const logs = await loadLogs();
    const l = logs.find((x) => x.id === checkMatch[1]);
    if (!l) return sendJson(res, 404, { error: '기록을 찾을 수 없습니다.' });

    if (b.action === 'return') {
      if (!String(b.comment || '').trim()) return sendJson(res, 400, { error: '반송 사유를 적어 주세요.' });
      l.check = { status: 'returned', by: s.manager.name || '시스템관리자', at: nowStamp(), comment: String(b.comment).slice(0, 300), signFile: '' };
      /* 반송하면 그 기록은 «열린다» — 지난 날짜라도 **점검이 끝날 때까지 몇 번이고** 고칠 수 있다.
         이 문패 없이 반송 상태만 보면, 한 번 고쳐 올리는 순간 다시 잠긴다. */
      l.reopened = true;
    } else {
      let signFile = s.manager.signFile || '';
      if (b.sign) {
        const f = await saveDataUrl(b.sign, SIGN_DIR, `mgr-${l.date}`);
        if (f) signFile = f;
      }
      if (!signFile) {
        return sendJson(res, 400, { error: '서명이 없습니다. 이 화면에서 직접 서명하거나 설정에서 서명을 등록해 주세요.' });
      }
      l.check = {
        status: 'checked',
        by: s.manager.name || '시스템관리자',
        position: s.manager.position || '시스템관리자',
        at: nowStamp(),
        comment: String(b.comment || '').slice(0, 300),
        signFile,
      };
      delete l.reopened; // 점검이 끝나면 다시 잠근다
    }
    await writeJson(FILES.logs, logs);
    return sendJson(res, 200, { ok: true, item: l });
  }

  /* ----------------------------------------------------------------
   * 지난 기록에 유휴시간 채우기 — 퇴근을 늦춰 적어 근무시간을 지킨다
   *   2026-08-24 사용자 지시 : *"이미 8월 19일부터 24일까지 일지가 기록되어 버렸어.
   *   퇴근시간을 유휴시간 포함한 시간으로 계산해서 출근부와 일지를 수정할 수 없나?"*
   *
   *   유휴시간이 없던 판으로 저장한 기록은 «체류 4 = 근무 4» 다. 그것을
   *   «체류 4.5 · 유휴 0.5 · 근무 4» 로 바꾼다 — **근무시간과 인건비는 그대로**다.
   *   유휴는 **예전 퇴근시각 뒤에** 붙인다. 그래야 활동일지의 지도 구간이 하나도 바뀌지 않는다.
   *
   * ⚠ apply:false 면 **미리보기만** 한다. 무엇이 어떻게 바뀌는지 다 보여 준 뒤에 고친다.
   * ⚠ 서명(점검)은 **그대로 둔다.** 이 단추를 누르는 사람이 바로 그 서명한 시스템관리자이고,
   *   4~5건을 다시 서명하게 하는 것은 실효가 없다. 대신 무엇을 바꿨는지 기록에 남긴다.
   * ⚠ **이미 유휴가 조금이라도 있는 기록은 건드리지 않는다.** 어디를 어떻게 고쳐야 할지
   *   기계가 정할 수 없다 — 목록으로만 알려 주고 사람이 고치게 한다.
   * ---------------------------------------------------------------- */
  if (p === '/api/logs/fix-break' && method === 'POST') {
    if (!needRole('manager')) return;
    const b = await readBody(req);
    const month = /^\d{4}-\d{2}$/.test(String(b.month || '')) ? String(b.month) : '';
    const logs = await loadLogs();

    const 고칠것 = [];
    const 손으로 = [];
    for (const l of logs) {
      if (month && !String(l.date).startsWith(month)) continue;
      const t = dayTime(l.clockIn, l.clockOut, l.breakStart, l.breakEnd);
      if (t.error || t.stay <= 0) continue;
      if (!breakShortage(t)) continue; // 이미 넉넉하다
      if (t.brkMin > 0) {
        손으로.push({ date: l.date, why: `유휴가 ${t.brkMin}분 들어 있습니다 — 어디를 늘릴지 사람이 정해야 합니다` });
        continue;
      }
      const need = extendMinutesFor(t.stay);
      const endMin = toMin(l.clockOut) + need;
      if (endMin >= 24 * 60) {
        손으로.push({ date: l.date, why: '퇴근을 늦추면 자정을 넘습니다 — 출근시각을 당기는 편이 낫습니다' });
        continue;
      }
      const hhmm = (m) => String(Math.floor(m / 60)).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0');
      const 새퇴근 = hhmm(endMin);
      const t2 = dayTime(l.clockIn, 새퇴근, l.clockOut, 새퇴근);
      if (t2.error || breakShortage(t2)) {
        손으로.push({ date: l.date, why: '고친 값도 기준에 모자랍니다 — 사람이 정해 주세요' });
        continue;
      }
      고칠것.push({
        date: l.date,
        checked: !!(l.check && l.check.status === 'checked'),
        before: { clockIn: l.clockIn, clockOut: l.clockOut, stay: t.stay, brk: 0, work: t.work },
        after: { clockIn: l.clockIn, clockOut: 새퇴근, breakStart: l.clockOut, breakEnd: 새퇴근, stay: t2.stay, brk: t2.brk, work: t2.work },
      });
    }

    const summary = {
      month: month || '전체',
      고칠건수: 고칠것.length,
      손으로건수: 손으로.length,
      /* 근무시간 합계는 **바뀌지 않아야** 한다. 이 값이 다르면 인건비가 달라진 것이니 멈춘다. */
      근무합_전: Math.round(고칠것.reduce((n, x) => n + x.before.work, 0) * 10) / 10,
      근무합_후: Math.round(고칠것.reduce((n, x) => n + x.after.work, 0) * 10) / 10,
      체류합_전: Math.round(고칠것.reduce((n, x) => n + x.before.stay, 0) * 10) / 10,
      체류합_후: Math.round(고칠것.reduce((n, x) => n + x.after.stay, 0) * 10) / 10,
    };

    if (!b.apply) return sendJson(res, 200, { preview: true, summary, items: 고칠것, manual: 손으로 });
    if (!고칠것.length) return sendJson(res, 400, { error: '고칠 기록이 없습니다.' });
    if (summary.근무합_전 !== summary.근무합_후) {
      return sendJson(res, 500, {
        error: `셈이 맞지 않아 멈췄습니다 — 근무시간 합계가 ${summary.근무합_전} → ${summary.근무합_후} 로 달라집니다.`,
      });
    }

    /* 고치기 전에 자료를 통째로 백업한다 */
    let backup = '';
    try {
      const entries = await collectBackup();
      const zip = makeZip(entries);
      await fsp.mkdir(BACKUP_DIR, { recursive: true });
      backup = path.join(BACKUP_DIR, `유휴채우기전-${nowStamp().replace(/[^0-9]/g, '').slice(0, 14)}.zip`);
      await fsp.writeFile(backup, zip);
    } catch (e) {
      return sendJson(res, 500, { error: '먼저 백업하지 못해 멈췄습니다.\n' + (e.message || '') });
    }

    const s2 = await loadSettings();
    for (const it of 고칠것) {
      const l = logs.find((x) => x.date === it.date);
      if (!l) continue;
      l.clockOut = it.after.clockOut;
      l.breakStart = it.after.breakStart;
      l.breakEnd = it.after.breakEnd;
      l.hours = it.after.work;
      l.stayHours = it.after.stay;
      l.breakHours = it.after.brk;
      /* 무엇을 바꿨는지 남긴다. 서식에는 찍히지 않는다 — 나중에 «왜 퇴근이 늦나» 를 설명할 근거다. */
      l.breakFixed = {
        at: nowStamp(),
        by: s2.manager.name || '시스템관리자',
        from: { clockOut: it.before.clockOut, hours: it.before.work },
        to: { clockOut: it.after.clockOut, breakStart: it.after.breakStart, breakEnd: it.after.breakEnd },
        why: '유휴(휴게)시간이 없던 판으로 저장한 기록에 법정 휴게를 채웠습니다. 근무시간은 그대로입니다.',
      };
      l.updatedAt = nowStamp();
    }
    await writeJson(FILES.logs, logs);
    console.log(`\n  ● 지난 기록에 유휴시간 채움 : ${고칠것.length}건 (근무시간·인건비는 그대로)`);
    return sendJson(res, 200, { ok: true, summary, items: 고칠것, manual: 손으로, backup: path.basename(backup) });
  }

  /* ---------- 주간 시간 점검 ---------- */
  if (p === '/api/week' && method === 'GET') {
    if (!needAnyone()) return;
    const date = url.searchParams.get('date') || todayStr();
    const sum = await weekSummary(date);
    if (!sum) return sendJson(res, 400, { error: '날짜가 올바르지 않습니다.' });
    return sendJson(res, 200, sum);
  }

  /* ---------- 월별 집계 (문서 출력용) ---------- */
  if (p === '/api/monthly' && method === 'GET') {
    if (!needStaff()) return;
    const month = url.searchParams.get('month') || todayStr().slice(0, 7);
    const [s, logs, requests] = await Promise.all([loadSettings(), loadLogs(), loadRequests()]);
    const monthLogs = logs.filter((l) => String(l.date).startsWith(month)).sort((a, b) => a.date.localeCompare(b.date)).map(withStay);
    // 인건비는 **근무시간**(휴게 제외), 출근기록부의 활동시간 칸은 **체류시간** 을 쓴다(사용자 결정)
    const totalHours = Math.round(monthLogs.reduce((t, l) => t + l.hours, 0) * 10) / 10;
    const totalStay = Math.round(monthLogs.reduce((t, l) => t + l.stayHours, 0) * 10) / 10;
    const totalBreak = Math.round(monthLogs.reduce((t, l) => t + l.breakHours, 0) * 10) / 10;
    const wage = Number(s.coordinator.hourlyWage) || 0;

    return sendJson(res, 200, {
      month,
      school: s.school,
      schoolYear: s.schoolYear,
      coordinator: {
        name: s.coordinator.name,
        signFile: s.coordinator.signFile,
        hourlyWage: wage,
        contractStart: s.coordinator.contractStart,
        contractEnd: s.coordinator.contractEnd,
        weeklyHours: s.coordinator.weeklyHours,
      },
      manager: { name: s.manager.name, position: s.manager.position, signFile: s.manager.signFile },
      logs: monthLogs,
      totalHours, // 근무시간 합계 (인건비 기준)
      totalStay, // 체류시간 합계 (출근기록부 활동시간 칸)
      totalBreak, // 유휴(휴게) 합계
      pay: Math.round(totalHours * wage),
      checkedCount: monthLogs.filter((l) => l.check && l.check.status === 'checked').length,
      requestCount: requests.filter((r) => String(r.date).startsWith(month)).length,
    });
  }

  /* ---------- 결과보고서용 연간 집계 ---------- */
  if (p === '/api/annual' && method === 'GET') {
    if (!needStaff()) return;
    const year = url.searchParams.get('year') || String(new Date().getFullYear());
    const [s, logs] = await Promise.all([loadSettings(), loadLogs()]);
    const yearLogs = logs.filter((l) => String(l.date).startsWith(year));

    // 결과보고서 "운영 결과" 표 : 교과 × 운영형태 × 영역 별로 묶어 총시수 집계
    // (수혜학생수는 앱에서 다루지 않는다 — 인쇄물의 그 칸은 비워 두고 손으로 적는다)
    const groups = new Map();
    let totalHours = 0;
    const monthly = {};
    for (const l of yearLogs) {
      totalHours += Number(l.hours) || 0;
      const m = l.date.slice(0, 7);
      monthly[m] = Math.round(((monthly[m] || 0) + (Number(l.hours) || 0)) * 10) / 10;
      for (const it of l.items || []) {
        const key = `${it.subject || '기타'}|${it.operationType || '정규수업'}|${it.area || ''}`;
        const g =
          groups.get(key) ||
          { subject: it.subject || '기타', operationType: it.operationType || '정규수업', area: it.area || '', hours: 0, contents: [] };
        g.hours = Math.round((g.hours + (Number(it.hours) || 0)) * 10) / 10;
        if (it.content && g.contents.length < 8) g.contents.push(it.content);
        groups.set(key, g);
      }
    }

    const wage = Number(s.coordinator.hourlyWage) || 0;
    totalHours = Math.round(totalHours * 10) / 10;
    const spent = Math.round(totalHours * wage); // 실제 인건비 (자동 줄에 들어간다)

    /* 예산 표를 확정해 내려보낸다 — 화면과 문서가 같은 값을 쓰도록 **서버에서 한 번만** 계산한다.
       집행액은 [예산 집행] 탭의 **건별 내역 합**이다. 그래서 집행을 적으면 정산서가 저절로 맞는다.
       편성 줄이 없으면 인건비 한 줄로 본다(설정을 안 한 학교도 문서가 나와야 한다). */
    const spendList = (await loadSpending()).filter((x) => String(x.date || '').startsWith(String(year)));
    const spentByRow = {};
    for (const x of spendList) spentByRow[x.rowId] = (spentByRow[x.rowId] || 0) + (Number(x.amount) || 0);

    const rawRows = (s.report.budgetRows || []).length
      ? s.report.budgetRows
      : [{ id: 'b1', item: '인력운영비', detail: 'AI교육 코디네이터 인건비', planned: Number(s.budget.planned) || 0, note: `${totalHours}시간 × ${wage.toLocaleString('ko-KR')}원` }];
    const budgetRows = rawRows.map((r) => {
      const rowSpent = spentByRow[r.id] || 0;
      return {
        id: r.id,
        item: r.item,
        detail: r.detail,
        planned: Number(r.planned) || 0,
        spent: rowSpent,
        remain: (Number(r.planned) || 0) - rowSpent,
        note: r.note || '',
      };
    });
    const budgetPlanned = budgetRows.reduce((n, r) => n + r.planned, 0);
    const budgetSpent = budgetRows.reduce((n, r) => n + r.spent, 0);

    return sendJson(res, 200, {
      year,
      school: s.school,
      // 비상 코드 해시가 섞여 나가지 않도록 필요한 값만 골라 보낸다
      manager: { name: s.manager.name, position: s.manager.position, signFile: s.manager.signFile },
      coordinator: {
        name: s.coordinator.name,
        signFile: s.coordinator.signFile,
        contractStart: s.coordinator.contractStart,
        contractEnd: s.coordinator.contractEnd,
        hourlyWage: s.coordinator.hourlyWage,
        weeklyHours: s.coordinator.weeklyHours,
        schedule: s.coordinator.schedule,
      },
      budget: s.budget,
      report: s.report,
      groups: [...groups.values()].sort((a, b) => b.hours - a.hours),
      monthly,
      totalHours,
      spent, // 실제 인건비 (활동시간 × 시급)
      remain: Math.max(0, (Number(s.budget.planned) || 0) - spent),
      // 예산 표에 그대로 쓰는 값 — 합계는 반드시 줄 합계와 같다
      budgetRows,
      budgetPlanned,
      budgetSpent,
      budgetRemain: budgetPlanned - budgetSpent,
      dayCount: yearLogs.length,
      photos: yearLogs.flatMap((l) => (l.photos || []).map((f) => ({ file: f, date: l.date }))),
    });
  }

  return sendJson(res, 404, { error: '없는 기능입니다.' });
}

/* ================================================================
 * 7. 서버 시작
 * ================================================================ */
ensureDirs();

/* ================================================================
 * 접속 기록 (진단용)
 *
 * "무선에서 접속이 안 된다" 는 문제는 원인이 두 갈래인데 증상이 똑같아 구분이 안 된다.
 *   ① 요청이 이 PC까지 오지도 못한다 (망 사이가 막혀 있음 → 학교 정보 담당자가 열어 줘야 한다)
 *   ② 요청은 왔는데 주소·화면 문제다 (컴퓨터 이름으로 접속했다거나)
 * 그래서 **어느 기기에서 요청이 왔는지** 기록해 둔다. 목록에 무선 주소가 보이면 ②, 없으면 ①이다.
 *
 * 메모리에만 두고 파일에 쓰지 않는다(서버를 끄면 사라진다). 최근 30대까지.
 * ================================================================ */
const VISITORS = new Map(); // ip → { first, last, count }
const VISITOR_MAX = 30;

/** `::ffff:10.1.2.3` · `::1` 같은 형태를 사람이 읽는 주소로 */
function plainIp(raw) {
  let ip = String(raw || '').trim();
  if (ip.startsWith('::ffff:')) ip = ip.slice(7);
  if (ip === '::1') ip = '127.0.0.1';
  return ip;
}

function noteVisitor(req) {
  const ip = plainIp(req.socket.remoteAddress);
  if (!ip || ip === '127.0.0.1') return; // 이 PC 자신은 세지 않는다
  const seen = VISITORS.get(ip);
  if (seen) {
    seen.last = nowStamp();
    seen.count++;
    return;
  }
  VISITORS.set(ip, { first: nowStamp(), last: nowStamp(), count: 1 });
  // 처음 보는 기기는 콘솔에도 한 줄 남긴다 — 검은 창만 보고도 도착 여부를 알 수 있다
  const mine = localAddresses()[0] || '';
  const sameSubnet = mine && ip.split('.').slice(0, 3).join('.') === mine.split('.').slice(0, 3).join('.');
  console.log(`  ● 접속 : ${ip} ${sameSubnet ? '(같은 망)' : '(다른 망 · 무선일 수 있음)'} — ${nowStamp()}`);
  // 너무 쌓이면 오래된 것부터 버린다
  while (VISITORS.size > VISITOR_MAX) VISITORS.delete(VISITORS.keys().next().value);
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  noteVisitor(req);
  try {
    if (url.pathname.startsWith('/api/')) {
      await handleApi(req, res, url);
    } else {
      await serveStatic(req, res, url.pathname);
    }
  } catch (err) {
    if (!res.headersSent) sendJson(res, 400, { error: err.message || '처리 중 문제가 생겼습니다.' });
  }
});

/**
 * 선생님들께 알려 줄 주소 — 서버가 켜질 때 정해서 여기에 담아 둔다.
 * 시스템관리자가 `localhost` 로 관리 화면을 열어 볼 때, 화면에 `localhost` 주소를 보여 주면
 * 그것을 그대로 선생님들께 알려 주게 되어 아무도 접속하지 못한다. 그래서 서버가 정한 주소를 쓴다.
 */
const SHARE = {
  url: '', // 선생님들께 알려 줄 주소
  altUrl: '', // 위 주소가 안 될 때 쓸 IP 주소
  port: 0,
  wantedHost: '', // 쓰고 싶은 이름 (설정값)
  hostOk: false, // 그 이름이 실제로 이 PC로 풀리는가
  usingIp: false, // 이름이 안 풀려 IP 를 쓰고 있는가
  computerName: '', // 이 PC의 컴퓨터 이름
  isComputerName: false, // 지금 쓰는 주소가 컴퓨터 이름인가
};

/**
 * 주소(URL)로 써도 안전한 이름인가.
 * 컴퓨터 이름에 한글이 들어간 PC 도 있는데, 한글 이름을 주소로 쓰면
 * 브라우저·메신저에서 깨지거나 링크가 안 걸리는 일이 있어 IP 를 쓰는 편이 안전하다.
 */
function isUrlSafeHost(host) {
  return /^[A-Za-z0-9][A-Za-z0-9._-]{0,62}$/.test(String(host || ''));
}

/**
 * 이 PC의 사설망 IPv4 주소들.
 *
 * 랜선과 무선을 함께 쓰는 PC 는 주소가 여러 개다(예 : 유선 10.1.2.3 + 무선 192.168.1.2).
 * 그래서 **선생님들이 실제로 접속하는 망의 주소가 앞에 오도록** 정렬한다.
 *   ① 169.254.x.x 는 맨 뒤로 — DHCP 를 못 받았을 때 윈도우가 붙이는 임시 주소라 접속에 쓸 수 없다
 *   ② 나머지는 찾은 순서를 지킨다(보통 유선이 먼저다)
 * 정렬만 하고 버리지는 않는다. 학교에 망이 여러 개일 수 있어 **전부 보여 주고 고르게** 해야 한다.
 */
function localAddresses() {
  const out = [];
  for (const list of Object.values(os.networkInterfaces())) {
    for (const n of list || []) {
      if (n.family === 'IPv4' && !n.internal) out.push(n.address);
    }
  }
  const usable = out.filter((a) => !a.startsWith('169.254.'));
  const apipa = out.filter((a) => a.startsWith('169.254.'));
  return [...usable, ...apipa];
}

/** 그 이름이 정말 이 PC를 가리키는지 확인한다 */
async function hostPointsHere(host, addrs) {
  if (!isUrlSafeHost(host)) return false;
  try {
    const { address } = await dns.lookup(host, { family: 4 });
    return addrs.includes(address);
  } catch {
    return false;
  }
}

/**
 * 선생님들께 알려 줄 '가장 좋은 주소'를 고른다.
 *
 * 고르는 순서
 *   ① 설정한 이름(`settings.shareHost`) — **사람이 직접 적은 것만** 들어 있다
 *   ② IP 주소
 *
 * **풀리지 않는 이름을 그냥 보여 주면 선생님들이 접속하지 못한다.**
 * 그래서 반드시 `hostPointsHere()` 로 확인한 뒤에만 쓴다.
 *
 * 🔴 **이 PC 의 컴퓨터 이름을 자동으로 쓰지 않는다** (2026-08-24 사용자 지시).
 *   예전에는 ② 단계로 `os.hostname()` 을 썼다. 그 결과 학교 PC 의 컴퓨터 이름이
 *   그대로 «선생님들께 알려 줄 주소» 가 되었고, 그 이름이 사람 이름이면
 *   **검은 창·바로가기 파일·설정 화면·`/api/public-settings` 네 곳으로 성명이 나갔다**
 *   (실제로 그랬다 — 사용자가 검은 창을 보고 신고했다).
 *   이름을 쓰고 싶으면 [설정] 에서 **직접 적는다.** 그건 사람이 고른 것이다.
 * ⚠ 자동으로 컴퓨터 이름을 쓰는 단계를 되살리지 말 것.
 *   «IP 는 재시작 때 바뀌어 즐겨찾기가 깨진다» 는 이유로 넣고 싶어지지만,
 *   컴퓨터 이름은 **라우터를 넘지 못해** 무선·다른 망에서는 어차피 안 된다.
 */
async function pickShareHost(addrs, wantedHost) {
  const ip = addrs[0] || 'localhost';
  SHARE.wantedHost = wantedHost || '';
  SHARE.hostOk = false;
  SHARE.usingIp = false;

  if (wantedHost && (await hostPointsHere(wantedHost, addrs))) {
    SHARE.hostOk = true;
    return wantedHost;
  }

  SHARE.usingIp = true;
  return ip;
}

/**
 * 주소 정보를 다시 계산한다.
 * 설정 화면에서 이름을 바꾸면 **서버를 다시 켜지 않아도** 화면에 바로 반영되게 하려고 쓴다.
 */
async function refreshShare() {
  if (!SHARE.port) return;
  const addrs = localAddresses();
  const s = await loadSettings();
  const wanted = String(process.env.SHARE_HOST || s.shareHost || '').trim();
  const host = await pickShareHost(addrs, wanted);
  SHARE.url = `http://${host}:${SHARE.port}/`;
  SHARE.altUrl = addrs.length && host !== addrs[0] ? `http://${addrs[0]}:${SHARE.port}/` : '';
  await writeShortcut(SHARE.url); // 선생님께 보낼 바로가기도 새 주소로 다시 만든다
}

/**
 * 설정에 저장돼 있는 «이 PC 의 컴퓨터 이름» 을 지운다.
 * 예전 판(1.2.1 이하)이 자동으로 넣어 둔 것이다 — 성명이 남지 않게 정리한다.
 * ⚠ 사람이 손으로 적은 다른 이름은 그대로 둔다.
 */
async function 저장된_컴퓨터이름_지우기() {
  try {
    const s = await loadSettings();
    if (!s.shareHost) return;
    if (s.shareHost.toLowerCase() !== os.hostname().toLowerCase()) return; // 사람이 적은 것
    s.shareHost = '';
    s.updatedAt = nowStamp();
    await writeJson(FILES.settings, s);
    console.log('   (설정에 저장돼 있던 이 PC 의 컴퓨터 이름을 지웠습니다 — 성명이 남지 않게)');
  } catch {
    /* 못 지워도 앱은 그대로 돌아간다 */
  }
}


/**
 * 선생님께 보낼 '바로가기 파일'을 만들어 둔다.
 * 컴퓨터를 잘 다루지 못하는 분도 주소를 타이핑하지 않고 이 파일만 더블클릭하면 된다.
 * (학교 공유폴더에 두거나 메신저로 보내면 됨)
 */
async function writeShortcut(shareUrl) {
  const file = path.join(ROOT, '선생님께_보낼_바로가기.url');
  const body = ['[InternetShortcut]', `URL=${shareUrl}`, 'IconIndex=0', ''].join('\r\n');
  try {
    await fsp.writeFile(file, body, 'utf8');
    return file;
  } catch {
    return null;
  }
}

/**
 * 브라우저를 자동으로 띄운다.
 * 포트가 바뀔 수 있으므로 배치파일이 아니라 포트를 아는 서버가 직접 연다.
 * (`node server.js --no-browser` 로 끌 수 있다)
 */
function openBrowser(url) {
  if (process.argv.includes('--no-browser')) return;
  if (process.platform !== 'win32') return;
  // cmd 의 start 는 첫 인수를 창 제목으로 보므로 빈 제목("")을 먼저 준다
  execFile('cmd', ['/c', 'start', '', url], (err) => {
    if (err) console.log(`   (브라우저를 자동으로 열지 못했습니다. 주소창에 ${url} 를 입력해 주세요)`);
  });
}

/**
 * 포트가 이미 쓰이고 있으면 다음 번호로 넘어가며 빈 포트를 찾는다.
 *
 * 주의 : `server.listen(p, 콜백)` 의 콜백은 'listening' 을 한 번 듣는 리스너로 붙는데,
 * listen 이 실패해도 그 리스너가 그대로 남는다. 그래서 다음 포트로 성공하면
 * **실패한 시도의 콜백까지 함께 불려** 예전 포트 번호가 화면에 찍히는 버그가 있었다.
 * → 콜백을 넘기지 않고 리스너를 직접 붙였다 떼며, 포트는 `server.address()` 에서 읽는다.
 */
function listenWithFallback(port, tries = 10) {
  return new Promise((resolve, reject) => {
    const attempt = (p, left) => {
      const cleanup = () => {
        server.removeListener('listening', onListening);
        server.removeListener('error', onError);
      };
      const onListening = () => {
        cleanup();
        resolve(server.address().port); // 실제로 열린 포트
      };
      const onError = (err) => {
        cleanup();
        if (err.code === 'EADDRINUSE' && left > 0) {
          console.log(`   포트 ${p} 은(는) 이미 쓰이고 있어 ${p + 1} 로 넘어갑니다.`);
          attempt(p + 1, left - 1);
        } else {
          reject(err);
        }
      };
      server.once('listening', onListening);
      server.once('error', onError);
      server.listen(p);
    };
    attempt(port, tries);
  });
}

/**
 * 그 포트에 '이 프로그램'이 이미 켜져 있는지 확인한다.
 * 실행 파일을 두 번 눌러 서버가 두 개 뜨는 일(그리고 바로가기 주소가 엉키는 일)을 막는다.
 */
function existingServerOn(port) {
  return new Promise((resolve) => {
    const req = http.get({ host: '127.0.0.1', port, path: '/api/catalog', timeout: 1500 }, (res) => {
      let body = '';
      res.on('data', (d) => (body += d));
      res.on('end', () => {
        try {
          const j = JSON.parse(body);
          resolve(Array.isArray(j.taskTypes)); // 우리 서버가 맞는지 모양으로 확인
        } catch {
          resolve(false);
        }
      });
    });
    req.on('error', () => resolve(false));
    req.on('timeout', () => {
      req.destroy();
      resolve(false);
    });
  });
}

/**
 * 다른 PC에서 정말 접속되는지 스스로 확인한다.
 * 방화벽에서 [허용] 을 누르지 않으면 이 PC에서는 잘 되는데 다른 선생님 PC에서만 안 되어
 * 원인을 찾기 어렵다. 그래서 켤 때 자동으로 확인해 알려 준다. (읽기만 하고 설정은 바꾸지 않는다)
 */
function checkLanReachable(host, port, timeoutMs = 2500) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    const done = (ok) => {
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => done(true));
    socket.once('timeout', () => done(false));
    socket.once('error', () => done(false));
    socket.connect(port, host);
  });
}

(async () => {
  /* 🔴 업그레이드로 «갈아타는» 중이면 예전 서버가 포트를 놓을 때까지 기다린다.
     이 대비책이 없으면 새로 뜬 서버가 «이미 켜져 있다» 고 판단해 스스로 끝내고,
     예전 서버는 이미 꺼지는 중이라 **아무 서버도 남지 않는다**(실제로 그랬다).
     `/api/update/restart` 가 이 표시를 붙여 새 프로세스를 띄운다. */
  if (process.env.AICODI_RESTART === '1') {
    for (let i = 0; i < 40; i++) {
      if (!(await existingServerOn(PORT))) break;
      await new Promise((r) => setTimeout(r, 300));
    }
  }

  // 이미 켜져 있으면 두 번째 서버를 띄우지 않고 기존 화면만 열어 준다
  if (await existingServerOn(PORT)) {
    console.log('');
    console.log('  ┌──────────────────────────────────────────────────────┐');
    console.log('  │   이미 켜져 있습니다. 화면만 열어 드립니다.          │');
    console.log('  └──────────────────────────────────────────────────────┘');
    console.log('');
    console.log(`   먼저 켜 둔 검은 창이 따로 있습니다. 그 창을 닫지 마세요.`);
    console.log(`   주소 : http://localhost:${PORT}/`);
    console.log('');
    openBrowser(`http://localhost:${PORT}/`);
    setTimeout(() => process.exit(0), 1500); // 브라우저가 뜰 시간을 주고 끝낸다
    return;
  }

  let port;
  try {
    port = await listenWithFallback(PORT);
  } catch (err) {
    console.log('');
    console.log('  [문제] 서버를 켤 수 없습니다.');
    console.log('');
    if (err.code === 'EADDRINUSE') {
      console.log('   포트가 모두 사용 중입니다. 이미 다른 창에서 이 프로그램이 켜져 있을 수 있습니다.');
      console.log('   열려 있는 검은 창을 찾아 닫은 뒤 다시 실행해 주세요.');
    } else if (err.code === 'EACCES') {
      console.log('   포트를 쓸 권한이 없습니다. 다른 포트로 켜 보세요 :  set PORT=5000');
    } else {
      console.log('   ' + (err.message || err.code));
    }
    console.log('');
    process.exitCode = 1;
    return;
  }

  const addrs = localAddresses();
  /* 예전 판이 설정에 넣어 둔 **컴퓨터 이름을 지운다**(2026-08-24 사용자 지시).
     컴퓨터 이름은 사람 이름인 경우가 많아(예 «홍길동») settings.json·백업 zip 에
     성명이 남는다. 이름은 켤 때마다 다시 알아보면 되는 값이라 저장할 필요가 없다.
     ⚠ **사람이 직접 적은 이름은 건드리지 않는다** — 컴퓨터 이름과 똑같을 때만 지운다. */
  await 저장된_컴퓨터이름_지우기();

  /* ⏰ 업데이트 서버를 **하루 한 번** 확인한다 (2026-08-25 사용자 지시).
     ⚠ `await` 하지 않는다 — 학교망이 막혀 있으면 여기서 몇십 초를 기다리게 되고
        그동안 **서버가 켜지지 않는다.** 뒤에서 돌게 두고 실패는 조용히 넘긴다.
     ⚠ `unref()` 로 둔다 — 이 타이머 때문에 프로그램이 안 꺼지면 안 된다
        (업그레이드할 때 스스로 다시 켜는 길이 막힌다). */
  checkUpdateDaily().catch(() => {});
  const 하루타이머 = setInterval(() => {
    checkUpdateDaily().catch(() => {});
  }, 하루);
  if (하루타이머.unref) 하루타이머.unref();
  const 설정 = await loadSettings();
  const wantedHost = String(process.env.SHARE_HOST || 설정.shareHost || '').trim();
  const shareHost = await pickShareHost(addrs, wantedHost);
  const shareUrl = `http://${shareHost}:${port}/`;
  SHARE.url = shareUrl;
  SHARE.altUrl = addrs.length && shareHost !== addrs[0] ? `http://${addrs[0]}:${port}/` : '';
  SHARE.port = port;
  // 포트가 밀렸다면 다른 프로그램이 4000 을 쓰고 있는 임시 상황이므로
  // 선생님들께 이미 나눠 준 바로가기 주소를 덮어쓰지 않는다
  const shortcut = port === PORT ? await writeShortcut(shareUrl) : null;

  console.log('');
  console.log('  ┌──────────────────────────────────────────────────────┐');
  console.log('  │   AI교육 코디네이터 업무 관리 서버가 켜졌습니다      │');
  console.log('  └──────────────────────────────────────────────────────┘');
  console.log('');
  console.log(`   판 ${APP_VERSION}`);
  console.log('');
  console.log('  ● 선생님들께 알려 줄 주소');
  console.log('');
  console.log(`      ${shareUrl}`);
  console.log('');
  if (shareHost !== addrs[0] && addrs.length) {
    console.log(`      (위 주소가 안 되는 PC가 있으면  http://${addrs[0]}:${port}/  를 알려 주세요)`);
    console.log('');
  }

  /* 무선(휴대폰·태블릿)과 다른 망(무선 AP 등)에서 접속하는 경우
     컴퓨터 이름은 라우터를 넘지 못해 풀리지 않는다. 그런 분께는 IP 주소를 드려야 한다.
     랜선·무선을 함께 쓰는 PC 는 주소가 여러 개라 어느 것을 줘야 하는지 알 수 없으므로 전부 보여 준다. */
  if (addrs.length) {
    console.log('  ● 무선(휴대폰·태블릿)이나 다른 망에서 들어오는 분께 드릴 주소');
    console.log('');
    for (const a of addrs) {
      const note = a.startsWith('169.254.') ? '   ← 이 주소는 쓸 수 없습니다(랜선/와이파이 연결 확인 필요)' : '';
      console.log(`      http://${a}:${port}/${note}`);
    }
    console.log('');
    console.log('     이름으로 된 주소는 같은 망 안에서만 통합니다. 무선이나 다른 망에서는');
    console.log('     반드시 위 IP 주소를 쓰셔야 합니다.');
    if (addrs.filter((a) => !a.startsWith('169.254.')).length > 1) {
      console.log('     주소가 여러 개인 것은 이 PC가 랜선과 무선에 함께 연결되어 있기 때문입니다.');
      console.log('     상대방과 같은 망의 주소를 알려 주세요(앞자리가 비슷한 쪽).');
    }
    console.log('');
  }

  // 지금 어떤 이름을 쓰고 있는지, 바꾸고 싶으면 어떻게 하는지 상황에 맞게 알려 준다
  //
  // 순서가 중요하다 : **직접 정한 이름이 안 쓰이고 있는 경우를 가장 먼저** 알려야 한다.
  // (그 경우에도 컴퓨터 이름으로 잘 돌아가지만, 왜 내가 정한 이름이 안 쓰이는지 모르면 답답하다)
  if (wantedHost && !SHARE.hostOk) {
    console.log(`  ● 알려 드립니다 : 설정한 이름 "${wantedHost}" 은(는) 아직 쓸 수 없습니다.`);
    console.log('');
    console.log(`     학교망에서 "${wantedHost}" 라는 이름이 이 PC를 가리키지 않기 때문입니다.`);
    console.log('     그래서 지금은 위에 표시된 주소를 대신 쓰고 있습니다(정상 동작합니다).');
    console.log('');
    console.log(`      방법 1  이 PC의 컴퓨터 이름을 "${wantedHost}" 로 바꾸기`);
    console.log('          설정 → 시스템 → 정보 → [이 PC의 이름 바꾸기] → 다시 시작');
    console.log('');
    console.log('      방법 2  학교 정보 담당자에게 DNS 등록을 요청하기');
    console.log(`          "${wantedHost}" → ${addrs[0] || '이 PC의 IP'} (A 레코드)`);
    console.log('');
    console.log('     ※ 그냥 지금 주소를 쓰시려면 [설정] 에서 이 이름을 지우면 됩니다.');
    console.log('');
  } else if (SHARE.usingIp) {
    /* 🔴 이 PC 의 컴퓨터 이름을 찍지 말 것 (2026-08-24 사용자 지시).
       검은 창은 선생님께 그대로 보여 주는 화면이고, 컴퓨터 이름이 사람 이름이면
       거기에 성명이 찍힌다. 예전에는 «컴퓨터 이름 "…" 이 풀리지 않습니다» 처럼 찍었다. */
    console.log('     ↑ 이 PC 의 IP 주소입니다.');
    console.log('        교무실 PC 의 IP 가 바뀌면 주소도 바뀌니, 바뀐 뒤에는 새 주소를 알려 주세요.');
    console.log('        늘 같은 주소를 쓰고 싶으시면 [설정] → 접속 주소 에서 이름을 정할 수 있습니다');
    console.log('        (학교 정보 담당자에게 그 이름의 DNS 등록을 요청해야 합니다).');
    console.log('');
  } else if (SHARE.hostOk) {
    console.log(`     ↑ 설정한 이름(${wantedHost})으로 정상 작동합니다.`);
    console.log('');
  }
  if (shortcut) {
    console.log('  ● 주소를 타이핑하기 어려운 분께는 이 파일을 보내 주세요');
    console.log('');
    console.log('      ' + shortcut);
    console.log('      (더블클릭하면 바로 접속됩니다. 학교 공유폴더나 메신저로 보내면 됩니다)');
    console.log('');
  } else if (port !== PORT) {
    console.log(`  ● 주의 : 다른 프로그램이 포트 ${PORT} 을 쓰고 있어 ${port} 로 켰습니다.`);
    console.log('     이번에는 임시 주소이므로 바로가기 파일을 새로 만들지 않았습니다.');
    console.log(`     선생님들께 이미 알려 준 주소(:${PORT})로 쓰시려면 이 창을 닫고,`);
    console.log(`     포트 ${PORT} 을 쓰는 프로그램을 끈 뒤 다시 실행해 주세요.`);
    console.log('');
  }
  console.log('  ● 이 PC에서 쓸 화면');
  console.log(`      작업 요청   http://localhost:${port}/`);
  console.log(`      코디네이터  http://localhost:${port}/coordinator.html`);
  console.log(`      점검·설정   http://localhost:${port}/manager.html`);
  console.log(`      문서 출력   http://localhost:${port}/reports.html`);
  console.log('');
  // 다른 PC에서 접속되는지 스스로 확인해 알려 준다
  if (addrs.length) {
    const ok = await checkLanReachable(addrs[0], port);
    if (ok) {
      console.log('  ● 확인 완료 : 다른 선생님 PC에서 접속할 수 있는 상태입니다. ✔');
      console.log('');
    } else {
      console.log('  ┌──────────────────────────────────────────────────────┐');
      console.log('  │  주의 : 다른 선생님 PC에서 접속되지 않는 상태입니다  │');
      console.log('  └──────────────────────────────────────────────────────┘');
      console.log('');
      console.log('   이 PC에서는 되지만 다른 PC에서는 막혀 있습니다.');
      console.log('   Windows 방화벽이 이 프로그램을 아직 허용하지 않았기 때문입니다.');
      console.log('');
      console.log('   해결 : 같은 폴더의  방화벽_허용.bat  을 한 번만 더블클릭해 주세요.');
      console.log('          ("이 앱이 장치를 변경하도록 허용하시겠어요?" → [예])');
      console.log('');
      console.log('   또는 방화벽 창이 다시 뜨면 [개인 네트워크] 를 체크하고 [액세스 허용] 을 누르세요.');
      console.log('');
    }
  }
  console.log('   자료 저장 위치 : ' + DATA_DIR);
  console.log('   이 창을 닫으면 서버가 꺼집니다. 근무일에는 켜 두세요.');
  console.log('');

  // 아직 명단이 없으면 설정 화면으로, 준비가 끝났으면 작업 요청 화면으로 열어 준다
  const members = await loadMembers();
  const landing = members.length ? '/' : '/manager.html';
  if (!members.length) {
    // 처음 켠 사람은 "관리자 코드를 어디서 받나?" 에서 막힌다 — 직접 정하는 것임을 여기서도 알려 준다
    console.log('  ┌──────────────────────────────────────────────────────┐');
    console.log('  │   처음 켜셨습니다 — 관리자 코드를 직접 정하세요       │');
    console.log('  └──────────────────────────────────────────────────────┘');
    console.log('');
    console.log('   방금 열린 화면에 [관리자 코드 정하기] 칸이 있습니다.');
    console.log('   미리 정해진 비밀번호가 없습니다. 앞으로 쓰실 숫자 4~12자리를');
    console.log('   그 칸에 넣고 [시작하기] 를 누르면 그것이 관리자 코드가 됩니다.');
    console.log('');
    console.log('   ※ 꼭 기억해 두거나 적어 두세요. 명단 파일을 잃어버렸을 때 쓰는 통로입니다.');
    console.log('   ※ 자세한 순서는 이 폴더의 사용설명서.txt 5번을 보세요.');
    console.log('');
  }
  openBrowser(`http://localhost:${port}${landing}`);
})();
