/* ================================================================
   ④⑥ 시스템관리자 화면 — 업무 점검·서명 + 설정
   ================================================================ */
'use strict';

let S = null; // 설정
let mySignPad = null;
const rowPads = new Map(); // 기록별 즉석 서명판

let rosterStaged = null; // 확인만 해 둔 명단 파일

start();

async function start() {
  await requireLogin(['manager'], '점검·설정 — 시스템관리자 확인');

  document.getElementById('topbar').innerHTML = renderTopbar(
    '/manager.html',
    '<button class="small ghost" id="logoutBtn" style="margin-left:8px">나가기</button>',
  );
  document.getElementById('logoutBtn').addEventListener('click', logout);
  await fillSchoolName();

  document.querySelectorAll('.tabs button').forEach((b) =>
    b.addEventListener('click', () => {
      document.querySelectorAll('.tabs button').forEach((x) => x.classList.toggle('on', x === b));
      for (const name of ['coord', 'check', 'spend', 'setup']) {
        document.getElementById('tab-' + name).hidden = name !== b.dataset.tab;
      }
      if (b.dataset.tab === 'coord') loadCoordination();
      if (b.dataset.tab === 'spend') loadSpending();
      if (b.dataset.tab === 'check' && mySignPad) mySignPad.resize(); // 숨어 있던 서명판 크기를 맞춘다
    }),
  );

  /* 로그인할 때 받아 둔 «새 판» 알림 — 화면이 다 그려진 뒤에 띄운다.
     `await` 하지 않는다: 사람이 창을 닫을 때까지 나머지 준비가 멈추면 안 된다. */
  showUpdateNotice();

  document.getElementById('month').value = thisMonth();
  document.getElementById('month').addEventListener('change', loadMonth);
  document.getElementById('reload').addEventListener('click', loadMonth);

  mySignPad = makeSignPad(document.getElementById('mySignPad'));
  document.getElementById('clearMySign').addEventListener('click', () => mySignPad.clear());
  document.getElementById('saveMySign').addEventListener('click', saveMySign);

  setupFolds(); // 접히는 설정 항목 — 펼침 상태를 기억하고 [모두 펼치기]·[모두 접기] 를 잇는다
  document.getElementById('saveSetup').addEventListener('click', saveSetup);
  /* 체험판(GitHub Pages)에서는 업그레이드 카드를 통째로 빼므로 이 칸들이 없다.
     `getElementById(...)` 가 null 이면 그 줄에서 화면 전체가 멈춘다 — 그래서 있을 때만 잇는다. */
  const 이으면 = (id, fn) => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('click', fn);
  };
  이으면('updateCheck', checkUpdate);
  이으면('updateApply', applyUpdate);
  이으면('updateRestart', restartServer);
  이으면('updateFileGo', () => applyUpdateFile(false));
  이으면('revertReload', loadRevertList);
  /* 「↩️ 업그레이드 전으로 되돌리기」 를 펼치는 순간에 읽는다 —
     설정 화면을 열 때마다 폴더를 훑으면 느려지고, 대개는 펼치지도 않는다. */
  const rb = document.getElementById('revertBox');
  if (rb) rb.addEventListener('toggle', () => { if (rb.open) loadRevertList(); });
  /* 🔐 학교 보안 인증서 — 펼칠 때 지금 상태를 읽는다 */
  const sb = document.getElementById('sslBox');
  if (sb) sb.addEventListener('toggle', () => { if (sb.open) loadSslCert(); });
  이으면('sslSave', saveSslCert);
  이으면('sslDelete', deleteSslCert);
  document
    .getElementById('schedAutoBreak')
    .addEventListener('click', () => autoFillBreaks('schedTable', 'schedTotal', '#msgSetup'));
  document
    .getElementById('schedExtend')
    .addEventListener('click', () => extendForBreaks('schedTable', 'schedTotal', '#msgSetup'));
  document
    .getElementById('weekExtend')
    .addEventListener('click', () => extendForBreaks('weekTable', 'weekTotal', '#msgWeek'));
  document
    .getElementById('weekAutoBreak')
    .addEventListener('click', () => autoFillBreaks('weekTable', 'weekTotal', '#msgWeek'));
  document.getElementById('reloadSetup').addEventListener('click', loadSetup);
  document.getElementById('rosterPreview').addEventListener('click', () => importRoster(false));
  document.getElementById('rosterApply').addEventListener('click', () => importRoster(true));
  document.getElementById('tplDownload').addEventListener('click', downloadTemplate);

  // 자료 백업
  document.getElementById('backupDownload').addEventListener('click', downloadBackup);
  document.getElementById('restorePreview').addEventListener('click', () => restoreBackup(false));
  document.getElementById('restoreApply').addEventListener('click', async () => {
    // 지금 자료를 통째로 바꾸는 일이라 한 번 더 묻는다
    const ok = await showDialog({
      kind: 'warn',
      title: '정말 되돌릴까요?',
      message: '지금 들어 있는 명단·요청·활동기록이 모두 백업 파일의 내용으로 바뀝니다.',
      detail: '되돌리기 직전 상태는 자동으로 따로 저장되므로, 잘못되면 그것으로 다시 돌아올 수 있습니다.',
      button: '되돌리기',
      cancel: '그만두기',
    });
    if (ok) restoreBackup(true);
  });
  document.getElementById('restoreFile').addEventListener('change', () => {
    restoreStaged = null;
    document.getElementById('restoreApply').disabled = true;
    document.getElementById('restoreResult').innerHTML = '';
  });
  document.getElementById('rosterFile').addEventListener('change', () => {
    rosterStaged = null;
    document.getElementById('rosterApply').disabled = true;
    document.getElementById('rosterResult').innerHTML = '';
    clearSay('#msgRoster');
  });

  await loadSetup();
  initWeekOverrideUI();
  renderWeekList();
  // 타 학교 시간을 고치면 기본 표와 그 주 표의 15시간 판정을 함께 다시 계산한다
  document.getElementById('coOther').addEventListener('input', () => {
    updateScheduleTotals();
    if (document.querySelector('#weekTable tbody tr')) updateWeekTotals();
  });
  initBudgetUI();
  initSpendUI();
  await loadRoster();
  await loadBackupState();
  await loadMonth();
  await loadCoordination();
}

/* ================================================================
   명단 엑셀 올리기
   ================================================================ */
async function loadRoster() {
  const d = await api('/api/members');
  const box = document.getElementById('rosterNow');
  if (!d.members.length) {
    box.innerHTML = '<div class="notice warn">아직 등록된 명단이 없습니다. 위에서 엑셀 파일을 올려 주세요.</div>';
    return;
  }
  const byRole = { manager: [], coordinator: [], teacher: [] };
  for (const m of d.members) (byRole[m.role] || byRole.teacher).push(m);

  const group = (role, title, cls) =>
    byRole[role].length
      ? `<div style="margin-top:12px"><b>${title} (${byRole[role].length}명)</b>
           <div style="margin-top:6px">${byRole[role]
             .map(
               (m) =>
                 `<span class="tag ${cls}" style="margin:3px 4px 0 0">${escapeHtml(m.name)}${m.subject ? ` · ${escapeHtml(m.subject)}` : ''}${m.hasCode ? '' : ' ⚠코드없음'}</span>`,
             )
             .join('')}</div></div>`
      : '';

  box.innerHTML = `
    ${d.rosterInfo ? `<div class="notice ok">${escapeHtml(d.rosterInfo.fileName)} · ${escapeHtml(d.rosterInfo.at)} 등록 · 모두 ${d.members.length}명</div>` : ''}
    ${group('manager', '시스템관리자', 'checked')}
    ${group('coordinator', '코디네이터', 'accepted')}
    ${group('teacher', '교사', 'done')}
    <div style="font-size:15px;color:var(--gray-500);margin-top:12px">
      인증코드는 암호화되어 저장되므로 여기서 볼 수 없습니다. 코드를 바꾸려면 엑셀 파일을 고쳐서 다시 올리세요.
    </div>`;
}

/** 샘플 서식 내려받기 — 인증이 필요한 주소라 토큰을 붙여 받아서 저장한다 */
async function downloadTemplate() {
  clearSay('#msgRoster');
  try {
    const r = await fetch('/api/roster-template', { headers: { 'X-Auth': sessionStorage.getItem('token') || '' } });
    if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || '서식을 받지 못했습니다.');
    const blob = await r.blob();
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = '교사명단_샘플.xlsx';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    say('#msgRoster', 'ok', '샘플 서식을 내려받았습니다. 우리 학교 사람으로 고친 뒤 아래에서 올려 주세요.');
  } catch (e) {
    say('#msgRoster', 'bad', e.message);
  }
}

/**
 * 접속 확인 — "무선에서 보낸 요청이 이 PC까지 오는가" 를 눈으로 가린다.
 *
 * 증상이 똑같아 구분이 안 되는 두 가지를 나눠 주는 것이 목적이다.
 *   · 목록에 다른 망 주소가 **보이면** → 요청은 도착한다. 주소를 잘못 넣었거나 화면 문제다.
 *   · 목록에 **없으면** → 요청이 오지도 못한다. 망 사이가 막혀 있어 정보 담당자가 열어 줘야 한다.
 */
async function loadVisitors() {
  const box = document.getElementById('visitorBox');
  if (!box) return;
  box.innerHTML = '<div style="font-size:16px;color:var(--gray-500)">확인하는 중...</div>';
  let v;
  try {
    v = await api('/api/visitors');
  } catch (e) {
    box.innerHTML = `<div class="notice bad" style="font-size:16px">${escapeHtml(e.message)}</div>`;
    return;
  }
  const others = v.visitors.filter((x) => !x.sameSubnet);
  const rows = v.visitors.length
    ? `<table class="tbl" style="margin-top:8px"><thead><tr><th>기기 주소</th><th>망</th><th>마지막 접속</th><th>횟수</th></tr></thead><tbody>
        ${v.visitors
          .slice(0, 12)
          .map(
            (x) => `<tr><td>${escapeHtml(x.ip)}</td>
              <td>${x.sameSubnet ? '같은 망' : '<b style="color:var(--green)">다른 망 · 무선</b>'}</td>
              <td>${escapeHtml(x.last)}</td><td>${x.count}</td></tr>`,
          )
          .join('')}
      </tbody></table>`
    : '';

  // 판정을 문장으로 알려 준다 (표만 보고는 무슨 뜻인지 알기 어렵다)
  const verdict = others.length
    ? `<b style="color:var(--green)">✔ 다른 망(무선)에서 온 접속이 있습니다.</b>
       망 사이는 열려 있습니다. 접속이 안 된다면 <b>주소를 잘못 넣었을 가능성</b>이 큽니다 —
       컴퓨터 이름이 아니라 위의 <b>IP 주소</b>를 쓰셨는지 확인해 주세요.`
    : v.visitors.length
      ? `<b>같은 망에서 온 접속만 있습니다.</b>
         무선 기기로 <b>위의 IP 주소</b>를 열어 보신 뒤 이 단추를 다시 눌러 주세요.
         그래도 목록에 안 나타나면 <b>망 사이가 막혀 있는 것</b>입니다.`
      : `<b>아직 다른 기기에서 들어온 적이 없습니다.</b>
         무선 기기로 위의 IP 주소를 열어 보신 뒤 이 단추를 다시 눌러 주세요.`;

  box.innerHTML = `<div class="notice ${others.length ? 'ok' : 'warn'}" style="font-size:16px">
      ${verdict}${rows}
      <div style="color:var(--gray-500);margin-top:6px">이 목록은 서버를 켠 뒤의 기록이며 최근 30대까지만 보여 줍니다(파일로 저장하지 않습니다).</div>
    </div>`;
}

/* ================================================================
   업그레이드 — 깃허브에 올려 둔 새 판을 받는다 (2026-08-24 사용자 지시)
   ----------------------------------------------------------------
   서버가 대신 받아 온다. 브라우저에서 직접 깃허브를 부르지 않는다 —
   ① 파일을 이 폴더에 써야 하고 ② 다른 도메인이라 브라우저가 막는다(CORS).
   ================================================================ */
let UPDATE_READY = ''; // 받아 둔 판 이름. 있으면 [다시 시작] 을 보여 준다

/* ================================================================
   ↩️ 업그레이드 전으로 되돌리기 (2026-08-25 사용자 지시)
   ----------------------------------------------------------------
   업그레이드할 때마다 그때의 프로그램이 `data/backup/판갈이전-…` 에 남는다.
   ⚠ 되돌리는 것은 **프로그램뿐**이다. 근무기록·명단·서명은 그대로 있다.
   ================================================================ */

/** 되돌릴 수 있는 백업 목록을 그린다 */
async function loadRevertList() {
  const box = document.getElementById('revertList');
  if (!box) return;
  box.innerHTML = '<div class="empty">불러오는 중…</div>';
  const r = await api('/api/update/backups').catch((e) => ({ error: e.message }));
  if (r && r.error) {
    box.innerHTML = `<div class="notice bad">${escapeHtml(r.error)}</div>`;
    return;
  }
  const list = (r && r.backups) || [];
  if (!list.length) {
    /* 처음 설치하고 한 번도 업그레이드하지 않았으면 되돌릴 것이 없다 —
       «고장났나» 로 읽히지 않게 왜 비어 있는지 적어 준다. */
    box.innerHTML = `<div class="notice info">
      아직 되돌릴 것이 없습니다.
      <span style="font-size:15px">업그레이드를 한 번 하시면 그때의 판이 여기에 쌓입니다.</span></div>`;
    return;
  }
  box.innerHTML =
    `<div class="notice info" style="font-size:16px">지금 쓰는 판은 <b>${escapeHtml(r.current || '')}</b> 입니다.
       아래에서 <b>돌아갈 판</b>을 고르세요.</div>` +
    list
      .map((b) => {
        const 크기 = b.bytes ? Math.round(b.bytes / 1024).toLocaleString('ko-KR') + ' KB' : '';
        const 같은판 = b.ok && b.version && b.version === r.current;
        return `<div class="item">
          <h3>판 ${escapeHtml(b.version || '?')}
            <span class="tag ${b.ok ? 'accepted' : 'cancelled'}">${b.ok ? '되돌릴 수 있음' : '쓸 수 없음'}</span></h3>
          <dl>
            <dt>만든 때</dt><dd>${escapeHtml(b.when || b.name)}</dd>
            <dt>담긴 것</dt><dd>${b.count ? `파일 ${b.count}개 · ${크기}` : '-'}</dd>
            ${b.dataZip ? `<dt>그때 자료</dt><dd>${escapeHtml(b.dataZip)} <span class="hint">(되돌리기는 자료를 건드리지 않습니다)</span></dd>` : ''}
          </dl>
          ${b.why ? `<div class="notice warn" style="margin:10px 0 0">${escapeHtml(b.why)}</div>` : ''}
          ${
            같은판
              ? '<div class="notice" style="margin:10px 0 0;font-size:16px">지금 쓰는 판과 같습니다.</div>'
              : b.ok
                ? `<div class="btnbar" style="margin-top:10px">
                     <button class="ghost small" data-revert="${escapeHtml(b.name)}"
                       data-revert-ver="${escapeHtml(b.version || '')}">↩️ 이 판으로 되돌리기</button>
                   </div>`
                : ''
          }
        </div>`;
      })
      .join('');

  box.querySelectorAll('[data-revert]').forEach((btn) =>
    btn.addEventListener('click', () => revertTo(btn.dataset.revert, btn.dataset.revertVer)),
  );
}

/** 고른 백업으로 되돌린다 */
async function revertTo(name, ver) {
  const ok = await showDialog({
    kind: 'warn',
    title: `판 ${ver || '?'} 로 되돌릴까요?`,
    message: '프로그램 파일만 그때 것으로 바꿉니다.',
    detail:
      '근무기록·명단·서명은 그대로 남습니다.\n' +
      '되돌리기 전에 지금 판도 백업하므로, 다시 앞으로 갈 수 있습니다.\n' +
      '바꾼 뒤에는 [🔄 다시 시작] 을 눌러 주세요.',
    button: '되돌리기',
    cancel: '그만두기',
  });
  if (!ok) return;

  clearSay('#msgRevert');
  try {
    const r = await api('/api/update/revert', { method: 'POST', body: { name } });
    say(
      '#msgRevert',
      'ok',
      `판 ${r.from} → ${r.to || '?'} 로 되돌렸습니다 (파일 ${r.count}개).\n` +
        `지금 판은 ${r.progBackup} 에 남겨 두었습니다 — 다시 앞으로 갈 수 있습니다.\n` +
        '아래 [🔄 다시 시작] 을 눌러야 새 판으로 바뀝니다.',
    );
    /* 다시 시작 단추를 꺼내 준다 — 누르지 않으면 파일만 바뀌고 돌고 있는 것은 예전 판이다 */
    const rs = document.getElementById('updateRestart');
    if (rs) rs.hidden = false;
    loadRevertList();
  } catch (e) {
    say('#msgRevert', 'bad', e.message);
  }
}

/**
 * 로그인할 때 받아 둔 «새 판» 알림을 띄운다 (2026-08-25 사용자 지시).
 * ⚠ **로그인할 때 한 번만** 뜬다 — `takeUpdateNotice()` 가 꺼내면서 지우기 때문이다.
 *   화면을 오갈 때마다 뜨면 매일 아침 같은 창을 여러 번 닫아야 한다.
 * ⚠ 서버는 **하루 한 번**만 인터넷을 다녀온다. 여기서 다시 확인하지 않는다 —
 *   로그인 직후에 인터넷을 다녀오면 학교망이 막힌 곳에서 화면이 멈춘 것처럼 보인다.
 */
async function showUpdateNotice() {
  const u = takeUpdateNotice();
  if (!u) return;

  const 바뀐것 = (u.notes || []).slice(0, 6);
  const 더 = (u.notes || []).length - 바뀐것.length;
  const ok = await showDialog({
    kind: 'info',
    title: '새 판이 나왔습니다',
    message: `지금 쓰시는 판 ${u.current} → 새 판 ${u.latest}${u.date ? ` (${u.date})` : ''}`,
    detail:
      (바뀐것.length ? '바뀐 것\n· ' + 바뀐것.join('\n· ') + (더 > 0 ? `\n· 그 밖에 ${더}가지` : '') + '\n\n' : '') +
      '지금 받으시겠습니까? 근무기록·명단·서명은 그대로 남습니다.',
    button: '⬆ 업그레이드 화면으로',
    cancel: '나중에',
  });
  if (!ok) return;

  /* [설정] 탭 → ⬆ 업그레이드 항목을 펼쳐 그 자리로 데려간다.
     ⚠ 접혀 있으면 화면에 없는 것과 같다 — 반드시 펼쳐 준다. */
  const tab = [...document.querySelectorAll('.tabs button')].find((b) => b.dataset.tab === 'setup');
  if (tab) tab.click();
  const fold = document.getElementById('fold-update');
  if (fold) {
    fold.open = true;
    fold.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
  /* 새 판이 있다는 것을 이미 아니 곧바로 확인까지 해 준다(단추를 한 번 덜 누르게) */
  if (typeof checkUpdate === 'function') checkUpdate();
}

async function checkUpdate() {
  clearSay('#msgUpdate');
  const btn = document.getElementById('updateCheck');
  const box = document.getElementById('updateState');
  btn.disabled = true;
  btn.textContent = '확인하는 중…';
  try {
    const r = await api('/api/update/check');
    if (r.offline) {
      /* 왜 못 받았는지 단계별 진단을 함께 보여 준다 — «fetch failed» 만으로는
         사람이 할 수 있는 것이 없다(2026-08-24 사용자 신고). */
      box.innerHTML =
        `<div class="notice warn">${escapeHtml(r.error).replace(/\n/g, '<br>')}` +
        diagHtml(r.diag) +
        `</div>`;
      document.getElementById('updateApply').hidden = true;
      document.getElementById('fileUpBox').open = true; // 확실한 길을 바로 열어 준다
      return;
    }
    const kb = r.size ? ` · 받을 크기 ${Math.round(r.size / 1024).toLocaleString('ko-KR')} KB` : '';
    if (!r.newer) {
      box.innerHTML = `<div class="notice ok">지금이 최신 판입니다 (<b>${escapeHtml(r.current)}</b>). 받을 것이 없습니다.</div>`;
      foldBadge('fold-update', '', '');
      document.getElementById('updateApply').hidden = true;
      return;
    }
    const notes = (r.notes || []).map((n) => `<li>${escapeHtml(n)}</li>`).join('');
    box.innerHTML = `<div class="notice info">
      <b>새 판이 있습니다 — ${escapeHtml(r.current)} → ${escapeHtml(r.latest)}</b>
      ${r.date ? ` (${escapeHtml(r.date)})` : ''}${kb}
      ${notes ? `<ul style="margin:8px 0 0 18px">${notes}</ul>` : ''}
      <div style="margin-top:8px;font-size:15px">아래 [지금 받기] 를 누르면 프로그램만 갈아집니다.
      <b>근무기록·명단은 그대로 남습니다.</b></div>
    </div>`;
    document.getElementById('updateApply').hidden = false;
    foldBadge('fold-update', `새 판 ${r.latest}`, 'info');
  } catch (e) {
    say('#msgUpdate', 'bad', e.message);
  } finally {
    btn.disabled = false;
    btn.textContent = '🔎 새 판이 있는지 확인';
  }
}

async function applyUpdate() {
  const ok = await showDialog({
    kind: 'warn',
    title: '새 판으로 갈아도 될까요?',
    message: '프로그램 파일만 바뀝니다. 근무기록·명단·서명·사진은 그대로 남습니다.',
    detail:
      '· 받기 전에 자료를 한 번 더 백업합니다.\n' +
      '· 지금 프로그램도 되돌릴 수 있게 보관합니다.\n' +
      '· 다 받으면 [새 판으로 다시 시작] 을 눌러야 반영됩니다.',
    button: '받기',
    cancel: '그만두기',
  });
  if (!ok) return;

  clearSay('#msgUpdate');
  const btn = document.getElementById('updateApply');
  btn.disabled = true;
  btn.textContent = '받는 중…';
  try {
    const r = await api('/api/update/apply', { method: 'POST', body: {} });
    UPDATE_READY = r.to;
    document.getElementById('updateState').innerHTML = `<div class="notice ok">
      <b>새 판을 받았습니다 — ${escapeHtml(r.from)} → ${escapeHtml(r.to)}</b> (파일 ${r.count}개)<br>
      <span style="font-size:15px">아래 <b>[새 판으로 다시 시작]</b> 을 누르면 반영됩니다.
      자료 백업 : ${escapeHtml(r.dataBackup)} · 예전 프로그램 : ${escapeHtml(r.progBackup)}
      (둘 다 data/backup 폴더에 있습니다)</span></div>`;
    btn.hidden = true;
    document.getElementById('updateRestart').hidden = false;
  } catch (e) {
    say('#msgUpdate', 'bad', e.message);
    btn.disabled = false;
    btn.textContent = '⬆ 지금 받기';
  }
}

/** 진단 결과를 사람이 읽을 수 있게 */
function diagHtml(d) {
  if (!d || !d.걸음) return '';
  const rows = d.걸음
    .map((s) => `<li>${s.ok ? '✅' : '⛔'} <b>${escapeHtml(s.이름)}</b> — ${escapeHtml(s.말)}</li>`)
    .join('');
  const 인증 = d.인증서얹기
    ? `<div style="margin-top:8px;font-size:14px;color:var(--gray-700)">인증서 : ${escapeHtml(d.인증서얹기)}</div>`
    : '';
  const 나침반 =
    d.원인 === 'tls'
      ? `<div style="margin-top:8px">이 경고를 없애려면 아래 <b>[🔐 학교 보안 인증서]</b> 를 펼쳐 학교 인증서를 한 번 올려 두세요.</div>`
      : '';
  return `<div style="margin-top:10px;font-size:15px">
    <b>어디서 막히는지 확인했습니다</b>
    <ul style="margin:6px 0 0 18px">${rows}</ul>
    ${d.안내 ? `<div style="margin-top:8px">${escapeHtml(d.안내).replace(/\n/g, '<br>').replace(/\*\*(.+?)\*\*/g, '<b>$1</b>')}</div>` : ''}
    ${인증}${나침반}
  </div>`;
}

/* ================================================================
   🔐 학교 보안 인증서 — SSL 을 가로채는 학교망에서 «새 판 확인» 을 살린다 (2026-09-09)
   ================================================================ */
async function loadSslCert() {
  const now = document.getElementById('sslNow');
  const del = document.getElementById('sslDelete');
  const bat = document.getElementById('sslBatHelp');
  clearSay('#msgSsl');
  now.textContent = '확인하는 중…';
  try {
    const r = await api('/api/ssl-cert');
    if (r.hasCert) {
      const c = r.cert || {};
      now.innerHTML =
        `✅ <b>올려 둔 인증서가 있습니다.</b><br>` +
        `<span style="color:var(--gray-700)">발급자 : ${escapeHtml(c.issuer || '-')}<br>` +
        `유효기간 : ~ ${escapeHtml(c.validTo || '-')}</span><br>` +
        (r.applied
          ? '이 프로그램이 지금 이 인증서를 쓰고 있습니다.'
          : r.autoSupported
            ? '⚠ 아직 적용되지 않았습니다 — <b>검은 창을 닫았다가 다시 켜</b> 주세요.'
            : '⚠ 이 PC 의 Node 가 낡아 자동 적용이 안 됩니다 — 아래 안내대로 <b>서버_실행.bat</b> 을 바꾸고 다시 켜 주세요.');
      del.hidden = false;
    } else {
      now.innerHTML = '아직 올려 둔 인증서가 없습니다. 아래에서 <code>.cer</code> 파일을 골라 저장하세요.';
      del.hidden = true;
    }
    bat.hidden = r.autoSupported;
    if (!r.autoSupported) {
      bat.innerHTML = `<div class="notice warn" style="font-size:15px">
        <b>이 PC 의 Node 가 낡았습니다 (${escapeHtml(r.nodeVersion || '')})</b><br>
        <b>서버_실행.bat</b> 의 <code>%NODE_EXE% server.js</code> 줄 바로 위에 아래 한 줄을 넣고,
        검은 창을 닫았다가 다시 켜 주세요.
        <pre style="white-space:pre-wrap;background:#fff;border:1px solid var(--gray-300);border-radius:6px;padding:8px;margin:8px 0;font-size:13px">${escapeHtml(r.batLine)}</pre>
        ${r.batAvailable ? '<button class="ghost small" id="sslBatDl">📥 고친 서버_실행.bat 받기</button> <span class="hint">받은 뒤 이름을 <b>서버_실행.bat</b> 으로 바꿔 덮어쓰세요</span>' : ''}
      </div>`;
      const dl = document.getElementById('sslBatDl');
      if (dl) dl.addEventListener('click', downloadRunBat);
    }
  } catch (e) {
    now.textContent = '';
    say('#msgSsl', 'bad', e.message);
  }
}

async function saveSslCert() {
  const inp = document.getElementById('sslFile');
  const f = inp.files && inp.files[0];
  if (!f) return say('#msgSsl', 'warn', '올릴 인증서 파일(.cer/.crt/.pem)을 먼저 골라 주세요.');
  if (f.size > 512 * 1024) return say('#msgSsl', 'warn', '파일이 너무 큽니다. 인증서 하나만 올려 주세요.');
  const btn = document.getElementById('sslSave');
  btn.disabled = true;
  btn.textContent = '저장하는 중…';
  clearSay('#msgSsl');
  try {
    const dataBase64 = await fileToBase64(f);
    const r = await api('/api/ssl-cert', { method: 'POST', body: { dataBase64 } });
    inp.value = '';
    await loadSslCert(); // 먼저 다시 그린다(이 안에서 #msgSsl 을 비운다)
    say(
      '#msgSsl',
      r.경고 ? 'warn' : 'ok',
      (r.경고 ? r.경고 + '\n\n' : '') +
        '인증서를 저장했습니다.\n' +
        (r.applied
          ? '지금 바로 적용되었습니다. 다음부터 [새 판이 있는지 확인] 이 잘 됩니다.'
          : r.autoSupported
            ? '검은 창(서버)을 닫았다가 다시 켜면 적용됩니다.'
            : '아래 안내대로 서버_실행.bat 을 바꾸고 다시 켜 주세요.'),
    );
  } catch (e) {
    say('#msgSsl', 'bad', e.message);
  } finally {
    btn.disabled = false;
    btn.textContent = '확인 후 저장';
  }
}

async function deleteSslCert() {
  const ok = await showDialog({
    kind: 'warn',
    title: '올려 둔 인증서를 지울까요?',
    message: '지우면 다시 이 학교망에서 «새 판 확인» 이 막힐 수 있습니다.',
    button: '지우기',
    cancel: '그만두기',
  });
  if (!ok) return;
  try {
    await api('/api/ssl-cert', { method: 'DELETE' });
    await loadSslCert();
    say('#msgSsl', 'ok', '지웠습니다. 검은 창을 닫았다가 다시 켜면 완전히 반영됩니다.');
  } catch (e) {
    say('#msgSsl', 'bad', e.message);
  }
}

/** 고친 서버_실행.bat 을 받아 준다 (낡은 Node 용). downloadTemplate 과 같은 방식. */
async function downloadRunBat() {
  try {
    const res = await fetch('/api/ssl-cert/bat', { headers: { 'X-Auth': sessionStorage.getItem('token') || '' } });
    if (!res.ok) {
      const j = await res.json().catch(() => ({}));
      throw new Error(j.error || `문제가 생겼습니다 (${res.status})`);
    }
    const blob = await res.blob();
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'server_run.bat';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    say('#msgSsl', 'info', '받은 파일 이름을 «서버_실행.bat» 으로 바꿔, 원래 있던 파일에 덮어쓰세요.');
  } catch (e) {
    say('#msgSsl', 'bad', e.message);
  }
}

/**
 * 브라우저로 받은 꾸러미를 올려 업그레이드한다.
 * 학교망에서 프로그램이 github.io 에 닿지 못해도 **브라우저는 된다** —
 * 그 차이를 이용하는 가장 확실한 길이다(2026-08-24).
 */
async function applyUpdateFile(force) {
  clearSay('#msgUpdate');
  const inp = document.getElementById('updateFile');
  const f = inp.files && inp.files[0];
  if (!f) {
    await showDialog({
      kind: 'warn',
      title: '파일을 먼저 골라 주세요',
      message: '배포 페이지에서 내려받은 업데이트 꾸러미(.zip)를 골라 주세요.',
    });
    return;
  }
  if (f.size > 30 * 1024 * 1024) {
    return say('#msgUpdate', 'bad', '파일이 너무 큽니다(30MB 넘음). 업데이트 꾸러미가 맞는지 확인해 주세요.');
  }
  const ok = await showDialog({
    kind: 'warn',
    title: '이 파일로 갈아도 될까요?',
    message: `${f.name} (${Math.round(f.size / 1024).toLocaleString('ko-KR')} KB)`,
    detail:
      '· 프로그램 파일만 바뀝니다. 근무기록·명단·서명은 그대로 남습니다.\n' +
      '· 받기 전에 자료를 한 번 더 백업하고, 지금 프로그램도 되돌릴 수 있게 보관합니다.\n' +
      '· 파일 안을 모두 검사한 뒤에 옮깁니다(경로·필수 파일·문법).',
    button: '올리기',
    cancel: '그만두기',
  });
  if (!ok) return;

  const btn = document.getElementById('updateFileGo');
  btn.disabled = true;
  btn.textContent = '올리는 중…';
  try {
    const dataBase64 = await new Promise((res, rej) => {
      const r = new FileReader();
      r.onerror = () => rej(new Error('파일을 읽지 못했습니다.'));
      r.onload = () => res(String(r.result).split(',').pop());
      r.readAsDataURL(f);
    });
    const r = await api('/api/update/file', { method: 'POST', body: { dataBase64, force: !!force } });
    UPDATE_READY = r.to;
    document.getElementById('updateState').innerHTML = `<div class="notice ok">
      <b>새 판을 올렸습니다 — ${escapeHtml(r.from)} → ${escapeHtml(r.to)}</b> (파일 ${r.count}개)<br>
      <span style="font-size:15px">아래 <b>[새 판으로 다시 시작]</b> 을 누르면 반영됩니다.
      자료 백업 : ${escapeHtml(r.dataBackup)} · 예전 프로그램 : ${escapeHtml(r.progBackup)}</span></div>`;
    document.getElementById('updateApply').hidden = true;
    document.getElementById('updateRestart').hidden = false;
    document.getElementById('fileUpBox').open = false;
  } catch (e) {
    /* 더 예전 판을 골랐을 때는 «그래도 올리기» 를 물어본다 (되돌리기용) */
    if (e.data && e.data.canForce) {
      const yes = await showDialog({
        kind: 'warn',
        title: '더 예전 판입니다',
        message: e.message,
        detail: '되돌리려고 일부러 고르신 것이면 그대로 올릴 수 있습니다.',
        button: '그래도 올리기',
        cancel: '그만두기',
      });
      btn.disabled = false;
      btn.textContent = '📁 이 파일로 업그레이드';
      if (yes) return applyUpdateFile(true);
      return;
    }
    say('#msgUpdate', 'bad', e.message);
  } finally {
    const b2 = document.getElementById('updateFileGo');
    if (b2 && b2.textContent === '올리는 중…') {
      b2.disabled = false;
      b2.textContent = '📁 이 파일로 업그레이드';
    }
  }
}

async function restartServer() {
  const btn = document.getElementById('updateRestart');
  btn.disabled = true;
  btn.textContent = '다시 켜는 중…';
  try {
    await api('/api/update/restart', { method: 'POST', body: {} });
  } catch {
    /* 서버가 곧 꺼지므로 답을 못 받을 수 있다 — 정상이다 */
  }
  /* 새 서버가 뜰 때까지 기다린 뒤 화면을 새로 고친다 */
  say('#msgUpdate', 'info', '서버를 다시 켜고 있습니다. 잠시만 기다려 주세요…');
  for (let i = 0; i < 40; i++) {
    await new Promise((r) => setTimeout(r, 700));
    try {
      const r = await fetch('/api/catalog', { cache: 'no-store' });
      if (r.ok) {
        location.reload();
        return;
      }
    } catch {}
  }
  say(
    '#msgUpdate',
    'warn',
    '자동으로 다시 켜지지 않았습니다.\n교무실 PC 의 검은 창을 닫고 [서버 실행] 을 다시 눌러 주세요.\n(새 판은 이미 받아 두었습니다)',
  );
  btn.disabled = false;
  btn.textContent = '🔄 새 판으로 다시 시작';
}

/* ================================================================
   자료 백업 · 되돌리기

   `data/backup/` 의 자동 백업은 **같은 폴더 안**에 있어서 폴더째 잃어버리면 함께 사라진다.
   그래서 파일 하나로 뽑아 내는 길을 따로 둔다 — PC 밖에 보관하시라는 뜻이다.
   ================================================================ */
let restoreStaged = null; // 미리보기를 끝낸 파일 (base64)

async function loadBackupState() {
  const box = document.getElementById('backupState');
  if (!box) return;
  let st;
  try {
    st = await api('/api/backup/status');
  } catch {
    box.innerHTML = '';
    return;
  }
  const mb = (st.bytes / 1024 / 1024).toFixed(1);
  // 마지막 백업이 오래되었으면 눈에 띄게 알려 준다
  let age = null;
  if (st.lastBackupAt) {
    const d = new Date(st.lastBackupAt.replace(' ', 'T') + ':00');
    if (!isNaN(d)) age = Math.floor((Date.now() - d.getTime()) / 86400000);
  }
  const kind = !st.lastBackupAt ? 'bad' : age >= 30 ? 'warn' : 'ok';
  /* 접혀 있어도 보이게 — 백업은 놓치면 되돌릴 수 없는 종류의 일이다 */
  if (!st.lastBackupAt) foldBadge('fold-backup', '한 번도 안 받음', 'bad');
  else if (age >= 30) foldBadge('fold-backup', `${age}일 전`, '');
  else foldBadge('fold-backup', '', '');
  const when = !st.lastBackupAt
    ? '<b>아직 한 번도 백업하지 않으셨습니다.</b> 지금 한 번 받아 두세요.'
    : age >= 30
      ? `마지막 백업 : <b>${escapeHtml(st.lastBackupAt)}</b> — <b>${age}일 전</b>입니다. 다시 받아 두시는 것이 좋습니다.`
      : `마지막 백업 : <b>${escapeHtml(st.lastBackupAt)}</b>${age > 0 ? ` (${age}일 전)` : ' (오늘)'}`;

  box.innerHTML = `<div class="notice ${kind}">
      ${when}<br>
      <span style="font-size:16px">지금 담길 것 : 명단 ${st.members}명 · 요청 ${st.requests}건 · 활동기록 ${st.logs}건 ·
      파일 ${st.files}개 (약 ${mb}MB)</span>
    </div>`;
}

async function downloadBackup() {
  clearSay('#msgBackup');
  const btn = document.getElementById('backupDownload');
  btn.disabled = true;
  btn.textContent = '만드는 중입니다...';
  try {
    const r = await fetch('/api/backup', { headers: { 'X-Auth': sessionStorage.getItem('token') || '' } });
    if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || '백업을 만들지 못했습니다.');
    const blob = await r.blob();
    const name = `AI코디네이터_백업_${todayStr()}.zip`;
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    await loadBackupState();
    await showDialog({
      kind: 'ok',
      title: '백업 파일을 받았습니다',
      message: `${name}\n크기 ${(blob.size / 1024 / 1024).toFixed(1)}MB`,
      detail: '내려받기 폴더에 있습니다. USB나 학교 클라우드 등 이 PC 밖으로 꼭 옮겨 두세요.',
    });
  } catch (e) {
    await showDialog({ kind: 'bad', title: '백업을 만들지 못했습니다', message: e.message });
  } finally {
    btn.disabled = false;
    btn.textContent = '💾 백업 파일 내려받기';
  }
}

async function restoreBackup(apply) {
  clearSay('#msgBackup');
  const input = document.getElementById('restoreFile');
  const file = input.files[0];
  if (!file && !restoreStaged) {
    await showDialog({ kind: 'warn', title: '백업 파일을 골라 주세요', message: '이 프로그램이 만든 .zip 파일을 고르시면 됩니다.' });
    return;
  }

  let dataBase64 = restoreStaged;
  if (!apply || !dataBase64) {
    dataBase64 = await new Promise((resolve, reject) => {
      const fr = new FileReader();
      fr.onload = () => resolve(String(fr.result).split(',')[1]);
      fr.onerror = () => reject(new Error('파일을 읽지 못했습니다.'));
      fr.readAsDataURL(file);
    });
  }

  const btn = document.getElementById(apply ? 'restoreApply' : 'restorePreview');
  btn.disabled = true;
  try {
    const r = await api('/api/restore', { method: 'POST', body: { dataBase64, apply } });
    const s = r.summary;
    const table = `<table class="tbl" style="margin-top:10px"><tbody>
        <tr><th>만든 날짜</th><td>${escapeHtml(s.madeAt)}</td></tr>
        <tr><th>학교</th><td>${escapeHtml(s.school)}</td></tr>
        <tr><th>시스템관리자</th><td>${escapeHtml(s.managerName || '-')}</td></tr>
        <tr><th>코디네이터</th><td>${escapeHtml(s.coordinatorName || '-')}</td></tr>
        <tr><th>명단</th><td>${s.members}명</td></tr>
        <tr><th>요청</th><td>${s.requests}건</td></tr>
        <tr><th>활동 기록</th><td>${s.logs}건</td></tr>
        <tr><th>사진·서명</th><td>사진 ${s.photos}장 · 서명 ${s.signs}개</td></tr>
      </tbody></table>`;

    if (!apply) {
      restoreStaged = dataBase64;
      document.getElementById('restoreApply').disabled = false;
      document.getElementById('restoreResult').innerHTML =
        `<div class="notice info" style="margin-top:12px"><b>이 백업에 들어 있는 내용입니다</b>${table}
         <div style="font-size:16px;margin-top:8px">맞으면 아래 <b>[2) 이 백업으로 되돌리기]</b> 를 눌러 주세요.
         지금 자료는 <b>이 내용으로 완전히 바뀝니다.</b></div></div>`;
      return;
    }

    restoreStaged = null;
    input.value = '';
    document.getElementById('restoreApply').disabled = true;
    document.getElementById('restoreResult').innerHTML =
      `<div class="notice ok" style="margin-top:12px"><b>되돌렸습니다</b>${table}</div>`;
    await showDialog({
      kind: 'ok',
      title: '자료를 되돌렸습니다',
      message: `${s.school} · 명단 ${s.members}명 · 활동기록 ${s.logs}건`,
      detail: `되돌리기 직전 상태는 ${r.safetyBackup} 로 따로 저장해 두었습니다.\n확인을 누르면 로그인 화면으로 갑니다. 다시 들어와 주세요.`,
    });
    logout();
  } catch (e) {
    await showDialog({ kind: 'bad', title: apply ? '되돌리지 못했습니다' : '백업 파일을 읽지 못했습니다', message: e.message });
  } finally {
    btn.disabled = false;
  }
}

async function importRoster(apply) {
  clearSay('#msgRoster');
  const input = document.getElementById('rosterFile');
  const file = input.files[0];
  if (!file && !(apply && rosterStaged)) return say('#msgRoster', 'warn', '올릴 명단 파일을 먼저 골라 주세요.');
  if (file && file.size > 8 * 1024 * 1024) return say('#msgRoster', 'warn', '파일이 너무 큽니다(최대 8MB).');

  if (apply && !rosterStaged) return say('#msgRoster', 'warn', '먼저 [1) 확인해 보기]를 눌러 내용을 확인해 주세요.');
  if (apply) {
    const ok = await showDialog({
      kind: 'warn',
      title: `명단을 ${rosterStaged.counts.total}명으로 바꿉니다`,
      message: '기존 인증코드는 모두 새 파일의 코드로 바뀝니다.\n지금 접속 중인 다른 분들은 다시 로그인해야 합니다.',
      detail: '인증코드는 해시로만 저장되어 다시 볼 수 없습니다. 엑셀 원본을 꼭 보관해 주세요.',
      button: '이 명단으로 바꾸기',
      cancel: '그만두기',
    });
    if (!ok) return;
  }

  const btn = document.getElementById(apply ? 'rosterApply' : 'rosterPreview');
  btn.disabled = true;
  try {
    const dataBase64 = await fileToBase64(file);
    const r = await api('/api/members/import', {
      method: 'POST',
      body: { fileName: file.name, dataBase64, apply },
    });
    if (apply) {
      rosterStaged = null;
      input.value = '';
      document.getElementById('rosterResult').innerHTML = '';
      say('#msgRoster', 'ok', `명단을 등록했습니다. 시스템관리자 ${r.counts.manager}명 · 코디네이터 ${r.counts.coordinator}명 · 교사 ${r.counts.teacher}명`);
      await loadRoster();
      await loadSetup();
      await fillSchoolName();
    } else {
      rosterStaged = r;
      document.getElementById('rosterApply').disabled = false;
      renderRosterPreview(r);
      say('#msgRoster', 'info', '내용을 확인하신 뒤 [2) 이 명단으로 등록하기]를 눌러 주세요.');
    }
  } catch (e) {
    document.getElementById('rosterResult').innerHTML = e.data && e.data.errors ? renderRosterErrors(e.data.errors) : '';
    say('#msgRoster', 'bad', e.message);
  } finally {
    btn.disabled = apply ? true : false;
  }
}

function renderRosterPreview(r) {
  const rows = r.members
    .map(
      (m, i) =>
        `<tr><td>${i + 1}</td><td>${escapeHtml(m.name)}</td><td>${escapeHtml(m.subject || '-')}</td>
         <td>${'•'.repeat(m.codeLen)}</td><td>${escapeHtml(ROLE_KO[m.role] || m.role)}</td></tr>`,
    )
    .join('');
  document.getElementById('rosterResult').innerHTML = `
    <div class="notice ${r.counts.manager && r.counts.coordinator ? 'ok' : 'warn'}" style="margin-top:14px">
      <b>읽은 결과 : 모두 ${r.counts.total}명</b>
      시스템관리자 ${r.counts.manager}명 · 코디네이터 ${r.counts.coordinator}명 · 교사 ${r.counts.teacher}명
    </div>
    ${renderRosterErrors(r.errors)}
    <div class="scrollx" style="margin-top:10px"><table class="grid">
      <thead><tr><th>순</th><th>이름</th><th>과목</th><th>인증코드</th><th>구분</th></tr></thead>
      <tbody>${rows}</tbody></table></div>`;
}

function renderRosterErrors(errors) {
  if (!errors || !errors.length) return '';
  return `<div class="notice ${errors.some((e) => e.kind !== 'warn') ? 'bad' : 'warn'}" style="margin-top:12px">
    <b>확인이 필요한 부분 ${errors.length}건</b>
    <ul style="margin:6px 0 0;padding-left:22px;font-size:16px">
      ${errors.map((e) => `<li>${e.line ? `${e.line}번째 줄 — ` : ''}${escapeHtml(e.message)}</li>`).join('')}
    </ul></div>`;
}

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onerror = () => reject(new Error('파일을 읽을 수 없습니다.'));
    fr.onload = () => resolve(String(fr.result).split(',')[1] || '');
    fr.readAsDataURL(file);
  });
}

/* ================================================================
   요일별 업무 시간표 (기본 시간표 + 그 주만 다르게)
   두 표가 구조가 같아서 그리기·모으기·합계 계산을 함께 씁니다.
   ================================================================ */

/** 요일 7줄 표를 그린다. tableId 로 어느 표인지 구분한다. */
function renderScheduleTable(tableId, schedule, totalId, onChange) {
  const rows = [];
  for (let d = 0; d <= 6; d++) {
    const v = (schedule || {})[d] || (schedule || {})[String(d)] || { on: false, start: '', end: '', breakStart: '', breakEnd: '' };
    const weekend = d === 0 || d === 6;
    rows.push(`
      <tr data-day="${d}" style="${weekend ? 'background:var(--gray-50)' : ''}">
        <th style="width:64px">${WEEK_KO[d]}요일</th>
        <td style="width:64px"><input type="checkbox" class="sc-on" ${v.on ? 'checked' : ''}></td>
        <td><input type="time" step="300" class="sc-start" value="${escapeHtml(v.start || '')}"></td>
        <td><input type="time" step="300" class="sc-end" value="${escapeHtml(v.end || '')}"></td>
        <td><input type="time" step="300" class="sc-bs" value="${escapeHtml(v.breakStart || '')}"></td>
        <td><input type="time" step="300" class="sc-be" value="${escapeHtml(v.breakEnd || '')}"></td>
        <td style="width:118px" class="sc-hours">—</td>
      </tr>`);
  }
  document.getElementById(tableId).innerHTML = `
    <thead><tr>
      <th>요일</th><th>근무</th><th>출근</th><th>퇴근</th>
      <th>유휴 시작</th><th>유휴 끝</th><th>근무시간</th>
    </tr></thead>
    <tbody>${rows.join('')}</tbody>
    <tfoot><tr><th colspan="6" style="text-align:right">주당 소정근로시간 합계 <span class="hint">(유휴시간 제외)</span></th>
      <th id="${totalId}">—</th></tr></tfoot>`;

  document.querySelectorAll(`#${tableId} input`).forEach((el) => {
    el.addEventListener('change', onChange);
    el.addEventListener('input', onChange);
  });
  onChange();
}

function collectScheduleFrom(tableId) {
  const out = {};
  document.querySelectorAll(`#${tableId} tbody tr`).forEach((tr) => {
    out[tr.dataset.day] = {
      on: tr.querySelector('.sc-on').checked,
      start: tr.querySelector('.sc-start').value,
      end: tr.querySelector('.sc-end').value,
      breakStart: tr.querySelector('.sc-bs').value,
      breakEnd: tr.querySelector('.sc-be').value,
    };
  });
  return out;
}

/**
 * 각 줄의 시간을 다시 계산하고 **근무시간(유휴 제외) 합계**를 돌려준다.
 * 합계가 주 15시간 판정의 기준이므로 유휴시간을 반드시 빼야 한다.
 */
function recalcScheduleTable(tableId, totalId) {
  let total = 0;
  let stay = 0;
  let brk = 0;
  let brkMin = 0; // 유휴 합계는 분으로 모은다(표시용)
  const shortDays = []; // 법정 휴게가 모자란 요일 — 저장을 막는 근거로 쓴다
  document.querySelectorAll(`#${tableId} tbody tr`).forEach((tr) => {
    const on = tr.querySelector('.sc-on').checked;
    const t = on
      ? dayTime(tr.querySelector('.sc-start').value, tr.querySelector('.sc-end').value, tr.querySelector('.sc-bs').value, tr.querySelector('.sc-be').value)
      : { stay: 0, brk: 0, work: 0, error: '' };
    const cell = tr.querySelector('.sc-hours');
    if (!on) {
      cell.textContent = '휴무';
      cell.style.color = '';
    } else if (t.error) {
      cell.textContent = '⚠ 확인';
      cell.title = t.error;
      cell.style.color = 'var(--red)';
    } else if (t.stay <= 0) {
      cell.textContent = '⚠ 시간 확인';
      cell.style.color = 'var(--red)';
    } else if (breakShortage(t)) {
      /* 4시간 이상 근무일에 유휴가 모자라면 **저장이 안 된다**(2026-08-22 사용자 지시).
         저장 눌러 실패하기 전에 그 칸에서 바로 알려 준다. */
      cell.innerHTML = `${t.work}시간<br><span style="font-size:14px">⛔ 유휴 ${requiredBreakMin(t.stay)}분 이상 필요</span>`;
      cell.style.color = 'var(--red)';
      cell.title = breakShortage(t);
      shortDays.push(WEEK_KO[Number(tr.dataset.day)] + '요일');
    } else {
      // 유휴가 있으면 체류시간도 함께 보여 준다 (숫자가 왜 줄었는지 알 수 있게)
      cell.innerHTML = t.brk > 0 ? `${t.work}시간<br><span style="font-size:14px;color:var(--gray-500)">체류 ${t.stay} − 유휴 ${brkText(t)}</span>` : `${t.work}시간`;
      cell.style.color = '';
      cell.title = '';
    }
    for (const cls of ['.sc-start', '.sc-end', '.sc-bs', '.sc-be']) tr.querySelector(cls).disabled = !on;
    total += t.error ? 0 : t.work;
    stay += t.stay;
    brk += t.brk;
    brkMin += t.brkMin || 0;
  });
  total = Math.round(total * 10) / 10;
  brk = Math.round(brk * 10) / 10;
  stay = Math.round(stay * 10) / 10;
  const el = document.getElementById(totalId);
  // 유휴 합계는 «분» 을 모아 두었다가 읽기 좋게 바꾼다(0.3 처럼 반올림한 값을 보여 주지 않는다).
  // ⚠ `total`·`stay` 는 서버의 `sumSchedule()` 과 **같은 방식**(날마다 반올림해서 더하기)이어야 한다.
  if (el) el.innerHTML = brk > 0 ? `${total}시간<br><span style="font-size:14px;color:var(--gray-500)">체류 ${stay} − 유휴 ${brkText({ brkMin })}</span>` : `${total}시간`;
  SHORT_BREAK_DAYS[tableId] = shortDays;
  return total;
}

/* 표마다 «유휴가 모자란 요일» 을 적어 둔다. 저장하기 전에 이것을 보고 막는다.
   (기본 시간표와 주별 예외가 각자 표를 쓰므로 표 이름으로 나눠 둔다) */
const SHORT_BREAK_DAYS = {};

/**
 * 유휴시간이 모자란 날에 **퇴근을 늦춰** 유휴시간을 넣는다.
 * 근무시간(= 체류 − 유휴)이 **그대로 남는다** → 주당 시간·인건비가 바뀌지 않는다.
 *   예) 09:30~13:30 (4시간) → 09:30~14:00 · 유휴 13:30~14:00 → 체류 4.5 · 근무 4
 *
 * 2026-08-24 사용자 지시 : *"퇴근시간을 유휴시간 포함한 시간으로 계산해서"*.
 * 지난 기록을 고치는 `/api/logs/fix-break` 과 **같은 셈법**이다 — 한쪽만 고치면 어긋난다.
 * ⚠ 늘린 뒤 체류시간이 8시간을 넘으면 기준이 60분으로 올라간다. 그래서 한 번 더 확인한다.
 */
function extendForBreaks(tableId, totalId, msgSel) {
  const 고친날 = [];
  let 전 = 0;
  let 후 = 0;
  document.querySelectorAll(`#${tableId} tbody tr`).forEach((tr) => {
    if (!tr.querySelector('.sc-on').checked) return;
    const start = tr.querySelector('.sc-start').value;
    const end = tr.querySelector('.sc-end').value;
    const before = dayTime(start, end, tr.querySelector('.sc-bs').value, tr.querySelector('.sc-be').value);
    전 += before.error ? 0 : before.work;
    if (!breakShortage(before)) {
      후 += before.error ? 0 : before.work;
      return;
    }
    if (before.brkMin > 0) {
      // 유휴가 조금 있는 날은 어디를 늘릴지 기계가 정할 수 없다
      고친날.push(WEEK_KO[Number(tr.dataset.day)] + '요일(유휴가 이미 있어 건너뜀)');
      후 += before.work;
      return;
    }
    // 늘린 뒤의 체류시간으로 기준이 올라갈 수 있다 (7.5시간 + 30분 = 8시간 → 60분 필요)
    let need = requiredBreakMin(before.stay);
    for (let i = 0; i < 3; i++) {
      const again = requiredBreakMin(before.stay + need / 60);
      if (again <= need) break;
      need = again;
    }
    const toMin = (x) => Number(x.split(':')[0]) * 60 + Number(x.split(':')[1]);
    const endMin = toMin(end) + need;
    if (endMin >= 24 * 60) {
      고친날.push(WEEK_KO[Number(tr.dataset.day)] + '요일(퇴근이 자정을 넘어 건너뜀)');
      후 += before.work;
      return;
    }
    const hhmm = (m) => String(Math.floor(m / 60)).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0');
    const 새퇴근 = hhmm(endMin);
    tr.querySelector('.sc-end').value = 새퇴근;
    tr.querySelector('.sc-bs').value = end; // 예전 퇴근시각부터
    tr.querySelector('.sc-be').value = 새퇴근;
    후 += dayTime(start, 새퇴근, end, 새퇴근).work;
    고친날.push(`${WEEK_KO[Number(tr.dataset.day)]}요일 퇴근 ${end} → ${새퇴근} (유휴 ${end}~${새퇴근})`);
  });

  recalcScheduleTable(tableId, totalId);
  if (!고친날.length) return say(msgSel, 'ok', '모든 근무일이 이미 법정 유휴시간을 채우고 있습니다. 넣을 것이 없습니다.');
  const 같음 = Math.round(전 * 10) / 10 === Math.round(후 * 10) / 10;
  say(
    msgSel,
    같음 ? 'ok' : 'warn',
    `퇴근을 늦춰 유휴시간을 넣었습니다 — ${고친날.join(' · ')}\n` +
      `주당 근무시간 ${Math.round(전 * 10) / 10}시간 → ${Math.round(후 * 10) / 10}시간` +
      (같음 ? ' (그대로입니다. 인건비도 바뀌지 않습니다)' : ' ⚠ 달라졌습니다 — 표를 확인해 주세요') +
      '\n체류시간(출근~퇴근)만 늘어납니다. 실제로 그렇게 근무하실 수 있는지 확인해 주세요.' +
      '\n내용을 확인하신 뒤 [설정 저장]을 눌러 주세요.',
  );
}

/**
 * 유휴시간이 모자란 날에 **근무 가운데**로 유휴시간을 넣어 준다.
 * 4시간 이상 근무일에 유휴시간이 필수가 되면서(2026-08-22 사용자 지시)
 * 예전에 만든 시간표는 여러 요일이 한꺼번에 걸린다 — 실제로 여섯 곳이 걸렸다.
 * 열두 칸을 손으로 채우게 하지 않으려고 만든 단추다.
 *
 * ⚠ 근무시간이 줄어든다(4시간 → 3.5시간). 유휴는 무급이므로 인건비도 그만큼 줄어든다.
 *   그래서 «넣었습니다» 로 끝내지 않고 **줄어든 시간을 함께 알려 준다.**
 *   시간을 그대로 유지하려면 퇴근 시각을 30분 늦춰야 하는데, 그건 근로계약 문제라 앱이 정하지 않는다.
 */
function autoFillBreaks(tableId, totalId, msgSel) {
  let 고친날 = [];
  let 전체근무 = 0;
  let 새근무 = 0;
  document.querySelectorAll(`#${tableId} tbody tr`).forEach((tr) => {
    const on = tr.querySelector('.sc-on').checked;
    const start = tr.querySelector('.sc-start').value;
    const end = tr.querySelector('.sc-end').value;
    if (!on) return;
    const before = dayTime(start, end, tr.querySelector('.sc-bs').value, tr.querySelector('.sc-be').value);
    전체근무 += before.error ? 0 : before.work;
    if (!breakShortage(before)) {
      새근무 += before.error ? 0 : before.work;
      return;
    }
    const need = requiredBreakMin(before.stay);
    const toMin = (t) => Number(t.split(':')[0]) * 60 + Number(t.split(':')[1]);
    const s0 = toMin(start);
    const e0 = toMin(end);
    /* 근무 가운데에 놓는다. 5분 단위로 맞춰 시각이 지저분해지지 않게 한다.
       가장자리(출근 직후·퇴근 직전)도 이제 허용되지만(2026-08-24), 자동으로 넣을 때는
       가운데가 실제 근무 모습에 가깝다. 교사가 원하면 손으로 끝으로 옮기면 된다. */
    let bs = Math.round((s0 + (e0 - s0 - need) / 2) / 5) * 5;
    if (bs < s0) bs = s0;
    if (bs + need > e0) bs = e0 - need;
    if (bs < s0 || bs + need > e0) {
      // 근무가 유휴보다 짧다 — 손으로 시간을 늘려야 한다
      고친날.push(WEEK_KO[Number(tr.dataset.day)] + '요일(넣을 자리가 없음)');
      return;
    }
    const hhmm = (m) => String(Math.floor(m / 60)).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0');
    tr.querySelector('.sc-bs').value = hhmm(bs);
    tr.querySelector('.sc-be').value = hhmm(bs + need);
    const after = dayTime(start, end, hhmm(bs), hhmm(bs + need));
    새근무 += after.work;
    고친날.push(`${WEEK_KO[Number(tr.dataset.day)]}요일 ${hhmm(bs)}~${hhmm(bs + need)}`);
  });

  recalcScheduleTable(tableId, totalId);
  if (!고친날.length) return say(msgSel, 'ok', '모든 근무일이 이미 법정 유휴시간을 채우고 있습니다. 넣을 것이 없습니다.');
  const 줄어든 = Math.round((전체근무 - 새근무) * 10) / 10;
  say(
    msgSel,
    'warn',
    `유휴시간을 넣었습니다 — ${고친날.join(' · ')}\n` +
      `주당 근무시간이 ${Math.round(전체근무 * 10) / 10}시간 → ${Math.round(새근무 * 10) / 10}시간 으로 ${줄어든}시간 줄었습니다.\n` +
      '유휴시간은 무급이므로 인건비도 그만큼 줄어듭니다.\n' +
      '지금 시간을 그대로 유지하려면 퇴근 시각을 그만큼 늦춰 주세요(근로계약 변경 사항입니다).\n' +
      '내용을 확인하신 뒤 [설정 저장]을 눌러 주세요.',
  );
}

/** 유휴가 모자란 요일이 있으면 안내 문장, 없으면 '' — 저장 직전에 부른다 */
function breakBlockMessage(tableId) {
  const days = SHORT_BREAK_DAYS[tableId] || [];
  if (!days.length) return '';
  return (
    `${days.join(' · ')} 의 유휴(휴게) 시간이 모자랍니다.\n` +
    '4시간 이상 근무하는 날은 유휴시간을 30분 이상(8시간 이상은 1시간 이상) 넣어야 합니다.\n' +
    '근로기준법 제54조 · 업무편람 Ⅳ-2-마'
  );
}

/* ---- 기본(계약) 시간표 ---- */
function renderSchedule(schedule) {
  renderScheduleTable('schedTable', schedule, 'schedTotal', updateScheduleTotals);
}
const collectSchedule = () => collectScheduleFrom('schedTable');
function updateScheduleTotals() {
  const total = recalcScheduleTable('schedTable', 'schedTotal');
  checkWeekly(total);
  return total;
}

/* ================================================================
   그 주만 다르게 (주별 예외)
   ================================================================ */
function initWeekOverrideUI() {
  const pick = document.getElementById('weekPick');
  pick.value = todayStr();
  document.getElementById('weekPick').addEventListener('change', loadWeekOverride);
  document.getElementById('weekFromBase').addEventListener('click', () => {
    renderScheduleTable('weekTable', collectSchedule(), 'weekTotal', updateWeekTotals);
    say('#msgWeek', 'info', '기본 시간표를 불러왔습니다. 이 주만 고칠 부분을 바꾼 뒤 저장하세요.');
  });
  document.getElementById('weekSave').addEventListener('click', saveWeekOverride);
  document.getElementById('weekDelete').addEventListener('click', deleteWeekOverride);
  loadWeekOverride();
}

function updateWeekTotals() {
  const total = recalcScheduleTable('weekTable', 'weekTotal');
  const other = Number(document.getElementById('coOther').value) || 0;
  const sum = Math.round((total + other) * 10) / 10;
  const box = document.getElementById('weekWarn');
  const detail = other ? `(요일별 ${total}시간 + 타 학교 ${other}시간)` : '';
  if (sum >= 15) {
    box.innerHTML = `<div class="notice bad"><b>이 주 ${sum}시간 — 저장할 수 없습니다</b> 주 15시간 미만이어야 합니다. ${detail}</div>`;
  } else if (sum >= 14) {
    box.innerHTML = `<div class="notice warn">이 주 ${sum}시간입니다. 15시간에 가깝습니다. ${detail}</div>`;
  } else if (sum > 0) {
    box.innerHTML = `<div class="notice ok">이 주 ${sum}시간 — 15시간 미만 원칙에 맞습니다. ${detail}</div>`;
  } else {
    box.innerHTML = '<div class="notice warn">이 주는 근무일이 하나도 없습니다(주 0시간). 그대로 저장하면 그 주는 쉬는 주가 됩니다.</div>';
  }
  const 모자란주 = SHORT_BREAK_DAYS['weekTable'] || [];
  if (sum >= 15) foldBadge('fold-week', `이 주 ${sum}시간 — 저장 안 됨`, 'bad');
  else if (모자란주.length) foldBadge('fold-week', '유휴시간 모자람', 'bad');
  else foldBadge('fold-week', '', '');
  return total;
}

/** 고른 날짜가 속한 주의 예외를 화면에 올린다 (없으면 기본 시간표를 보여 준다) */
function loadWeekOverride() {
  clearSay('#msgWeek');
  const v = document.getElementById('weekPick').value;
  if (!v) return;
  const monday = weekMondayOf(v);
  const sunday = todayStr(new Date(new Date(monday + 'T00:00:00').getTime() + 6 * 86400000));
  const ov = (S.coordinator.weekOverrides || {})[monday];

  document.getElementById('weekRangeLabel').innerHTML = ov
    ? `📌 ${monday} ~ ${sunday} — <span style="color:var(--amber)">이 주는 따로 정해져 있습니다 (주 ${ov.hours}시간)</span>`
    : `${monday} ~ ${sunday} — 지금은 <b>기본 시간표</b>를 쓰는 주입니다`;

  document.getElementById('weekNote').value = ov ? ov.note || '' : '';
  renderScheduleTable('weekTable', ov ? ov.schedule : S.coordinator.schedule, 'weekTotal', updateWeekTotals);
  document.getElementById('weekDelete').disabled = !ov;
}

async function saveWeekOverride() {
  clearSay('#msgWeek');
  const v = document.getElementById('weekPick').value;
  if (!v) return say('#msgWeek', 'warn', '어느 주인지 날짜를 먼저 골라 주세요.');
  const shortMsg = breakBlockMessage('weekTable');
  if (shortMsg) return say('#msgWeek', 'bad', shortMsg);
  const btn = document.getElementById('weekSave');
  btn.disabled = true;
  try {
    await api('/api/settings', {
      method: 'POST',
      body: {
        weekOverride: {
          week: v,
          schedule: collectScheduleFrom('weekTable'),
          note: document.getElementById('weekNote').value.trim(),
        },
      },
    });
    await loadSetup();
    loadWeekOverride();
    renderWeekList();
    say('#msgWeek', 'ok', `${weekMondayOf(v)} 주의 업무 시간을 따로 저장했습니다.`);
  } catch (e) {
    say('#msgWeek', 'bad', e.message);
  } finally {
    btn.disabled = false;
  }
}

async function deleteWeekOverride() {
  const v = document.getElementById('weekPick').value;
  const monday = weekMondayOf(v);
  if (!monday) return;
  const ok = await showDialog({
    kind: 'warn',
    title: `${monday} 주의 예외를 지울까요?`,
    message: '그 주는 기본 시간표로 되돌아갑니다.',
    button: '예외 지우기',
    cancel: '그만두기',
  });
  if (!ok) return;
  try {
    await api('/api/settings', { method: 'POST', body: { removeWeekOverride: monday } });
    await loadSetup();
    loadWeekOverride();
    renderWeekList();
    say('#msgWeek', 'ok', `${monday} 주를 기본 시간표로 되돌렸습니다.`);
  } catch (e) {
    say('#msgWeek', 'bad', e.message);
  }
}

/** 따로 정해 둔 주 목록 */
function renderWeekList() {
  const box = document.getElementById('weekList');
  const all = Object.entries(S.coordinator.weekOverrides || {}).sort((a, b) => a[0].localeCompare(b[0]));
  if (!all.length) {
    box.innerHTML = '<div class="notice info">아직 따로 정해 둔 주가 없습니다. 모든 주가 기본 시간표를 씁니다.</div>';
    return;
  }
  const thisMonday = weekMondayOf(todayStr());
  const rows = all
    .map(([monday, ov]) => {
      const sunday = todayStr(new Date(new Date(monday + 'T00:00:00').getTime() + 6 * 86400000));
      const when = monday === thisMonday ? '<span class="tag accepted">이번 주</span>' : monday < thisMonday ? '<span class="tag done">지난 주</span>' : '<span class="tag requested">앞으로</span>';
      const days = [];
      for (let d = 0; d <= 6; d++) {
        const x = ov.schedule[d] || ov.schedule[String(d)];
        if (x && x.on && hoursBetween(x.start, x.end) > 0) days.push(`${WEEK_KO[d]} ${x.start}~${x.end}`);
      }
      return `<tr>
        <td>${when}</td>
        <td>${monday}<br><span style="font-size:14px;color:var(--gray-500)">~ ${sunday}</span></td>
        <td class="left">${days.length ? escapeHtml(days.join(' · ')) : '<span style="color:var(--red)">근무 없음</span>'}</td>
        <td><b>${ov.hours}시간</b></td>
        <td class="left">${escapeHtml(ov.note || '')}</td>
        <td><button class="ghost small" data-week="${monday}">보기·고치기</button></td>
      </tr>`;
    })
    .join('');
  box.innerHTML = `<div class="scrollx"><table class="grid">
    <thead><tr><th>구분</th><th>주</th><th>근무 시간</th><th>합계</th><th>메모</th><th></th></tr></thead>
    <tbody>${rows}</tbody></table></div>`;
  box.querySelectorAll('[data-week]').forEach((b) =>
    b.addEventListener('click', () => {
      document.getElementById('weekPick').value = b.dataset.week;
      loadWeekOverride();
      document.getElementById('weekPick').scrollIntoView({ behavior: 'smooth', block: 'center' });
    }),
  );
}

/* ================================================================
   조율 결정 — 시스템관리자만 할 수 있는 일

   코디네이터는 선생님의 요청을 직접 거절하지 않는다(2026-08-07 사용자 지시).
   ① 시간이 이미 찬 자리에 선생님이 [조율 요청] 으로 보낸 요청
   ② 코디네이터가 "제가 판단하기 어렵습니다" 하고 올린 요청
   둘 다 **누구를 먼저 도울지 정하는 일**이라 학교가 결정할 몫이다.
   ================================================================ */
async function loadCoordination() {
  const all = await api('/api/requests');
  const waiting = all.filter((r) => r.status === 'coordinating');
  const today = (await api('/api/public-settings')).serverDate || todayStr();

  // 탭에 대기 건수를 배지로 (안 보면 모르고 지나친다)
  const badge = document.getElementById('coordBadge');
  if (badge) {
    badge.innerHTML = waiting.length
      ? ` <span class="tag" style="background:var(--red);color:#fff;margin-left:4px">${waiting.length}</span>`
      : '';
  }

  document.getElementById('coordList').innerHTML = waiting.length
    ? waiting.map(renderCoordItem).join('')
    : '<div class="empty">결정을 기다리는 조율 건이 없습니다.</div>';

  // 참고용 — 앞으로 확정된 일정
  const upcoming = all.filter((r) => r.status === 'accepted' && r.date >= today).sort((a, b) => (a.date + a.startTime).localeCompare(b.date + b.startTime));
  document.getElementById('upcomingList').innerHTML = upcoming.length
    ? upcoming
        .slice(0, 20)
        .map(
          (r) => `<div class="item"><h3>${dateKo(r.date)} ${escapeHtml(r.startTime)}~${escapeHtml(r.endTime)}
            <span class="tag accepted">확정</span></h3>
            <dl><dt>선생님</dt><dd>${escapeHtml(r.teacherName)}</dd>
            <dt>업무</dt><dd>${escapeHtml(r.taskType)}${r.place ? ` · ${escapeHtml(r.place)}` : ''}</dd></dl></div>`,
        )
        .join('')
    : '<div class="empty">앞으로 확정된 일정이 없습니다.</div>';

  wireCoordButtons();
}

function renderCoordItem(r) {
  const clash = r.conflictWith || [];
  const why = (r.reply && r.reply.reason) || r.coordinateReason || '';
  const fromCoordinator = r.reply && r.reply.action === 'coordinate';

  return `
  <div class="item hi">
    <h3>${dateKo(r.date)} ${escapeHtml(r.startTime)}~${escapeHtml(r.endTime)} (${r.hours}시간)
      <span class="tag coordinating">조율 중</span></h3>
    <dl>
      <dt>요청 선생님</dt><dd>${escapeHtml(r.teacherName)}${r.subject ? ` (${escapeHtml(r.subject)})` : ''}</dd>
      <dt>업무</dt><dd>${escapeHtml(r.taskType)}</dd>
      <dt>장소·형태</dt><dd>${escapeHtml(r.place || '-')} · ${escapeHtml(r.operationType || '')}</dd>
      <dt>내용</dt><dd>${escapeHtml(r.content)}</dd>
      <dt>요청번호</dt><dd>${escapeHtml(r.id)} · ${escapeHtml(r.createdAt)}</dd>
    </dl>

    ${
      clash.length
        ? `<div class="notice bad" style="margin:10px 0 0;font-size:16px">
            <b>⛔ 이 시간에 이미 확정된 일정</b><br>
            ${clash.map((c) => `· ${escapeHtml(c.startTime)}~${escapeHtml(c.endTime)} ${escapeHtml(c.teacherName)} 선생님 · ${escapeHtml(c.taskType)}`).join('<br>')}<br>
            <span style="color:var(--gray-700)">둘 다는 어렵습니다. 어느 쪽을 먼저 할지 정해 주세요.</span>
          </div>`
        : ''
    }
    ${
      why
        ? `<div class="notice warn" style="margin:10px 0 0;font-size:16px">
            <b>${fromCoordinator ? '코디네이터가 올린 내용' : '선생님이 적은 사정'}</b><br>${escapeHtml(why)}</div>`
        : ''
    }

    <div class="btnbar" style="margin-top:12px">
      <button class="ok small" data-dec="approve" data-id="${r.id}">✅ 이대로 진행</button>
      <button class="warn small" data-dec="reschedule" data-id="${r.id}">🕘 시간을 바꿔 제안</button>
      <button class="ghost small" data-dec="close" data-id="${r.id}">🙏 이번에는 어렵다고 알리기</button>
    </div>
    <div id="dec-${r.id}"></div>
  </div>`;
}

function wireCoordButtons() {
  document.querySelectorAll('[data-dec]').forEach((btn) =>
    btn.addEventListener('click', () => openDecideForm(btn.dataset.id, btn.dataset.dec)),
  );
}

function openDecideForm(id, act) {
  const box = document.getElementById('dec-' + id);
  if (!box) return;

  if (act === 'approve') {
    box.innerHTML = `
      <div class="notice ok" style="margin-top:10px">
        <b>이 요청을 그대로 진행합니다</b>
        <div style="font-size:16px;color:var(--gray-700);margin:4px 0 8px">
          겹치는 일정이 있어도 진행됩니다. 겹친 사실은 기록에 남습니다 —
          <b>먼저 하기로 밀린 선생님께는 따로 알려 주세요.</b>
        </div>
        <label style="margin-top:0">전할 말 <span class="hint">(선택 · 선생님께 보입니다)</span></label>
        <input type="text" id="dv-${id}" placeholder="예) 이번 주는 2학년 대회 준비가 우선이라 이쪽을 먼저 진행합니다.">
        <div class="btnbar" style="margin-top:10px"><button class="ok small" id="dgo-${id}">이대로 진행하기</button></div>
      </div>`;
    document.getElementById('dgo-' + id).addEventListener('click', () =>
      sendDecision(id, { action: 'approve', reason: document.getElementById('dv-' + id).value }),
    );
  } else if (act === 'close') {
    box.innerHTML = `
      <div class="notice warn" style="margin-top:10px">
        <b>이번에는 진행하지 않기로 합니다</b>
        <div style="font-size:16px;color:var(--gray-700);margin:4px 0 8px">
          적어 주신 내용이 선생님께 그대로 보입니다. 왜 어려운지 알려 주시면 오해가 없습니다.
        </div>
        <label style="margin-top:0">선생님께 전할 말씀 <span class="hint">(필수)</span></label>
        <input type="text" id="dv-${id}" placeholder="예) 같은 시간 3학년 행사 지원이 먼저 확정되어 있습니다. 다음 주로 다시 요청해 주시면 우선 배정하겠습니다.">
        <div class="btnbar" style="margin-top:10px"><button class="warn small" id="dgo-${id}">이대로 알리기</button></div>
      </div>`;
    document.getElementById('dgo-' + id).addEventListener('click', () =>
      sendDecision(id, { action: 'close', reason: document.getElementById('dv-' + id).value }),
    );
  } else {
    box.innerHTML = `
      <div class="notice warn" style="margin-top:10px">
        <b>다른 시간으로 바꿔 제안합니다</b>
        <div style="font-size:16px;color:var(--gray-700);margin:4px 0 8px">
          제안한 시간에 <b>선생님이 동의하면</b> 확정됩니다.
        </div>
        <div class="row">
          <div><label style="margin-top:0">바꿀 날짜</label><input type="date" id="dd-${id}"></div>
          <div><label style="margin-top:0">시작</label><input type="time" step="300" id="ds-${id}"></div>
          <div><label style="margin-top:0">끝</label><input type="time" step="300" id="de-${id}"></div>
        </div>
        <label>전할 말 <span class="hint">(선택)</span></label>
        <input type="text" id="dv-${id}" placeholder="예) 그 시간은 이미 차 있어 다음 날 같은 시간으로 옮겨 드립니다.">
        <div class="btnbar" style="margin-top:10px"><button class="warn small" id="dgo-${id}">이 시간으로 제안하기</button></div>
      </div>`;
    document.getElementById('dgo-' + id).addEventListener('click', () =>
      sendDecision(id, {
        action: 'reschedule',
        newDate: document.getElementById('dd-' + id).value,
        newStartTime: document.getElementById('ds-' + id).value,
        newEndTime: document.getElementById('de-' + id).value,
        reason: document.getElementById('dv-' + id).value,
      }),
    );
  }
}

async function sendDecision(id, body) {
  clearSay('#msgCoord');
  const label = { approve: '진행 결정', reschedule: '시간 변경 제안', close: '결과 안내' }[body.action] || '결정';
  const eul = josa(label, '을', '를'); // "결과 안내를" / "진행 결정을"
  try {
    await api(`/api/requests/${encodeURIComponent(id)}/decide`, { method: 'POST', body });
    await loadCoordination();
    await showDialog({
      kind: 'ok',
      title: `${label}${eul} 보냈습니다`,
      message: '요청하신 선생님과 코디네이터 화면에 함께 표시됩니다.',
      detail: body.action === 'reschedule' ? '선생님이 동의하면 그 시간으로 확정됩니다.' : '',
    });
  } catch (e) {
    await showDialog({ kind: 'bad', title: `${label}${eul} 보내지 못했습니다`, message: e.message });
  }
}

/* ================================================================
   예산 — **편성**(설정 탭)과 **집행**(예산 집행 탭)을 나눠 둔다

   편성 : 비목 · 세목 · 편성액. 학년도 초에 한 번 정하고 거의 안 바뀐다.
   집행 : 언제 · 어느 예산에서 · 얼마를 썼는지 **건별로** 쌓는다.
   정산서(결과보고서 Ⅲ)의 집행액은 **집행 내역의 합**이다 —
   그래서 집행만 적으면 정산서가 저절로 맞고, 같은 숫자를 두 곳에 넣을 일이 없다.
   ================================================================ */

const 원 = (n) => (Number(n) || 0).toLocaleString('ko-KR');

/* ---------------- 예산 편성 (설정 탭) ---------------- */

/** 교육청 지원비 신청 서식 금액 (되돌리기용) */
const BUDGET_PRESET = [
  { id: 'b1', item: '보조인력 인건비', detail: 'AI교육 코디네이터 인건비', planned: 11200000, note: '' },
  { id: 'b2', item: '보조인력 인건비', detail: '고용보험·산재보험·국민연금', planned: 400000, note: '' },
  { id: 'b3', item: '보조인력 인건비', detail: '주휴수당', planned: 2300000, note: '' },
  { id: 'b4', item: '운영비', detail: '교구구입', planned: 3000000, note: '' },
  { id: 'b5', item: '운영비', detail: '행사진행', planned: 1000000, note: '' },
];

function budgetRowHtml(r) {
  return `<tr class="b-row" data-id="${escapeHtml(r.id || '')}">
    <td><input class="b-item" type="text" list="itemList" value="${escapeHtml(r.item || '')}" placeholder="예) 운영비"></td>
    <td><input class="b-detail" type="text" value="${escapeHtml(r.detail || '')}" placeholder="예) 교재·소모품 구입"></td>
    <td><input class="b-planned" type="number" min="0" step="1000" value="${Number(r.planned) || 0}"></td>
    <td><input class="b-note" type="text" value="${escapeHtml(r.note || '')}" placeholder="예) 월 지급"></td>
    <td><button type="button" class="ghost small b-del" style="white-space:nowrap">삭제</button></td>
  </tr>`;
}

function renderBudgetRows(rows) {
  const tb = document.querySelector('#budgetTable tbody');
  if (!tb) return;
  // 처음 쓰는 학교도 서식대로 채워져 있게 한다 (금액만 고치면 되도록)
  const list = rows && rows.length ? rows : BUDGET_PRESET.map((r) => ({ ...r }));
  tb.innerHTML = list.map(budgetRowHtml).join('');
  tb.querySelectorAll('.b-del').forEach((b) =>
    b.addEventListener('click', () => {
      b.closest('tr').remove();
      updateBudgetTotals();
    }),
  );
  tb.querySelectorAll('.b-planned').forEach((i) => i.addEventListener('input', updateBudgetTotals));
  updateBudgetTotals();
}

/** 화면에서 편성 줄을 읽는다. `id` 는 집행 내역이 가리키는 열쇠라 그대로 넘긴다 */
function collectBudgetRows() {
  return [...document.querySelectorAll('#budgetTable tbody tr.b-row')].map((row) => ({
    id: row.dataset.id || '',
    item: row.querySelector('.b-item').value.trim(),
    detail: row.querySelector('.b-detail').value.trim(),
    planned: Number(row.querySelector('.b-planned').value) || 0,
    note: row.querySelector('.b-note').value.trim(),
  }));
}

function updateBudgetTotals() {
  const total = collectBudgetRows().reduce((n, r) => n + r.planned, 0);
  document.getElementById('sumPlanned').textContent = 원(total);
  document.getElementById('sumPlannedTh').textContent = `= 정산서에는 ${원(Math.round(total / 1000))} 천원으로 나갑니다`;
  const hidden = document.getElementById('budgetPlanned');
  if (hidden) hidden.value = total;
}

function initBudgetUI() {
  document.getElementById('budgetAdd').addEventListener('click', () => {
    // 새 줄은 id 를 비워 둔다 — 서버가 붙여 준다
    document.querySelector('#budgetTable tbody').insertAdjacentHTML('beforeend', budgetRowHtml({}));
    renderBudgetRowsRewire();
    const rows = document.querySelectorAll('#budgetTable tbody tr.b-row');
    rows[rows.length - 1].querySelector('.b-item').focus();
  });

  document.getElementById('budgetPreset').addEventListener('click', async () => {
    const ok = await showDialog({
      kind: 'warn',
      title: '교육청 서식 금액으로 되돌릴까요?',
      message: '지금 적은 비목·세목·편성액이 모두 서식 기본값으로 바뀝니다.',
      detail: '집행 내역은 지워지지 않습니다. 저장하기 전이면 [다시 불러오기]로 되돌릴 수 있습니다.',
      button: '되돌리기',
      cancel: '그만두기',
    });
    if (!ok) return;
    renderBudgetRows(BUDGET_PRESET.map((r) => ({ ...r })));
    say('#msgBudget', 'info', '서식 금액으로 되돌렸습니다. 우리 학교 배정액으로 고친 뒤 아래 [설정 저장] 을 눌러 주세요.');
  });
}

/** 줄을 추가한 뒤 이벤트를 다시 걸어 준다 */
function renderBudgetRowsRewire() {
  const tb = document.querySelector('#budgetTable tbody');
  tb.querySelectorAll('.b-del').forEach((b) => {
    if (b.dataset.wired) return;
    b.dataset.wired = '1';
    b.addEventListener('click', () => {
      b.closest('tr').remove();
      updateBudgetTotals();
    });
  });
  tb.querySelectorAll('.b-planned').forEach((i) => {
    if (i.dataset.wired) return;
    i.dataset.wired = '1';
    i.addEventListener('input', updateBudgetTotals);
  });
  updateBudgetTotals();
}

/* ---------------- 예산 집행 (예산 집행 탭) ---------------- */

let SPEND = null; // 마지막으로 받아 온 집행 현황

async function loadSpending() {
  const year = Number(document.getElementById('spendYear').value) || new Date().getFullYear();
  clearSay('#msgSpend');
  try {
    SPEND = await api(`/api/spending?year=${year}`);
  } catch (e) {
    say('#msgSpend', 'bad', e.message);
    return;
  }

  // ① 편성 대비 집행 현황
  const tb = document.querySelector('#spendSummary tbody');
  tb.innerHTML = SPEND.rows.length
    ? SPEND.rows
        .map((r) => {
          const pct = r.planned > 0 ? Math.round((r.spent / r.planned) * 100) : 0;
          const over = r.remain < 0;
          return `<tr>
            <td>${escapeHtml(r.item)}</td>
            <td>${escapeHtml(r.detail || '-')}</td>
            <td style="text-align:right">${원(r.planned)}</td>
            <td style="text-align:right">${원(r.spent)}${r.count ? `<br><span style="font-size:14px;color:var(--gray-500)">${r.count}건</span>` : ''}</td>
            <td style="text-align:right;${over ? 'color:var(--red);font-weight:700' : ''}">${원(r.remain)}</td>
            <td>
              <div class="bar" style="height:14px;background:var(--gray-200);border-radius:999px;overflow:hidden">
                <div style="height:100%;width:${Math.min(100, pct)}%;background:${over ? 'var(--red)' : pct >= 90 ? 'var(--amber)' : 'var(--green)'}"></div>
              </div>
              <span style="font-size:14px">${pct}%</span>
            </td></tr>`;
        })
        .join('')
    : '<tr><td colspan="6" style="text-align:center;color:var(--gray-500)">[설정] 탭에서 예산 편성을 먼저 넣어 주세요.</td></tr>';

  const remain = SPEND.planned - SPEND.spent;
  document.querySelector('#spendSummary tfoot').innerHTML = `<tr class="total-row">
      <td colspan="2"><b>합계</b></td>
      <td style="text-align:right">${원(SPEND.planned)}</td>
      <td style="text-align:right">${원(SPEND.spent)}</td>
      <td style="text-align:right;${remain < 0 ? 'color:var(--red)' : ''}">${원(remain)}</td>
      <td>${SPEND.planned ? Math.round((SPEND.spent / SPEND.planned) * 100) : 0}%</td></tr>`;

  // ② 어느 예산에서 쓸지 고르는 목록
  const sel = document.getElementById('spendRow');
  const keep = sel.value;
  sel.innerHTML =
    // 세목만 보여 준다 — 비목·남은 예산은 위의 현황 표에서 이미 보이므로 목록에서는 걸러 낸다
    '<option value="">— 고르세요 —</option>' +
    SPEND.rows
      .map((r) => `<option value="${escapeHtml(r.id)}">${escapeHtml(r.detail || r.item)}</option>`)
      .join('');
  if (keep) sel.value = keep;

  // ③ 활동기록으로 계산한 인건비 안내 — 아직 집행에 안 넣었으면 넣기 단추를 준다
  renderWageHint();

  // ④ 집행 내역 목록
  const rowName = (id) => {
    const r = SPEND.rows.find((x) => x.id === id);
    return r ? { item: r.item, detail: r.detail } : { item: '(지워진 예산 줄)', detail: '' };
  };
  document.querySelector('#spendList tbody').innerHTML = SPEND.items.length
    ? SPEND.items
        .map((x) => {
          const n = rowName(x.rowId);
          return `<tr>
            <td>${escapeHtml(x.date)}</td>
            <td>${escapeHtml(n.item)}</td>
            <td>${escapeHtml(n.detail || '-')}</td>
            <td style="text-align:right">${원(x.amount)}</td>
            <td class="left">${escapeHtml(x.content || '')}</td>
            <td>${escapeHtml(x.proof || '')}</td>
            <td style="white-space:nowrap">
              <button type="button" class="ghost small" data-edit="${escapeHtml(x.id)}">고치기</button>
              <button type="button" class="ghost small" data-del="${escapeHtml(x.id)}">삭제</button>
            </td></tr>`;
        })
        .join('')
    : '<tr><td colspan="7" style="text-align:center;color:var(--gray-500)">아직 집행 내역이 없습니다.</td></tr>';

  document.querySelectorAll('#spendList [data-edit]').forEach((b) => b.addEventListener('click', () => editSpend(b.dataset.edit)));
  document.querySelectorAll('#spendList [data-del]').forEach((b) => b.addEventListener('click', () => delSpend(b.dataset.del)));
}

/** 활동기록으로 계산한 인건비를 집행에 넣도록 안내한다 */
function renderWageHint() {
  const box = document.getElementById('wageHint');
  if (!SPEND) return;
  const total = SPEND.wageByMonth.reduce((n, m) => n + m.amount, 0);
  if (!total) {
    box.innerHTML = '';
    return;
  }
  const rows = SPEND.wageByMonth
    .map((m) => `${Number(m.month.slice(5, 7))}월 ${m.hours}시간 = ${원(m.amount)}원`)
    .join(' · ');
  box.innerHTML = `<div class="notice info" style="margin-top:14px">
      <b>🧮 활동기록으로 계산한 인건비 : ${원(total)}원</b>
      <div style="font-size:16px">${escapeHtml(rows)}
        <br>시급 ${원(SPEND.hourlyWage)}원 기준입니다.</div>
      <div class="btnbar" style="margin-top:10px">
        <button class="small" id="wageFill">이 금액을 집행 내역에 넣기</button>
      </div>
      <div style="font-size:15px;color:var(--gray-700);margin-top:6px">
        달마다 한 줄씩 들어갑니다. <b>이미 넣은 달은 건너뛰므로</b> 여러 번 눌러도 두 번 들어가지 않습니다.
      </div>
    </div>`;
  document.getElementById('wageFill').addEventListener('click', fillWageFromLogs);
}

async function fillWageFromLogs() {
  // 인건비 줄을 찾는다(세목에 '인건비' 가 들어간 첫 줄) — 없으면 고르게 한다
  const guess = SPEND.rows.find((r) => /인건비/.test(r.detail)) || SPEND.rows.find((r) => /인건비/.test(r.item));
  if (!guess) {
    await showDialog({
      kind: 'warn',
      title: '인건비 예산 줄을 찾지 못했습니다',
      message: '[설정] 탭의 예산 편성에 세목이 «AI교육 코디네이터 인건비» 인 줄이 있어야 합니다.',
    });
    return;
  }
  const ok = await showDialog({
    kind: 'warn',
    title: '활동기록 인건비를 집행 내역에 넣을까요?',
    message: `«${guess.item} · ${guess.detail}» 예산에 달마다 한 줄씩 들어갑니다.`,
    detail: '이미 넣은 달은 건너뜁니다. 잘못 들어가면 집행 내역에서 지울 수 있습니다.',
    button: '넣기',
    cancel: '그만두기',
  });
  if (!ok) return;
  try {
    const r = await api('/api/spending/from-logs', {
      method: 'POST',
      body: { rowId: guess.id, year: Number(document.getElementById('spendYear').value) || new Date().getFullYear() },
    });
    await loadSpending();
    await showDialog({
      kind: 'ok',
      title: r.added ? `${r.added}건을 넣었습니다` : '새로 넣을 것이 없습니다',
      message: r.added ? '정산서의 집행액이 바로 반영됩니다.' : '이미 모두 넣어 두셨습니다.',
      detail: r.skipped.length ? `이미 넣어 둔 달 : ${r.skipped.join(', ')}` : '',
    });
  } catch (e) {
    await showDialog({ kind: 'bad', title: '넣지 못했습니다', message: e.message });
  }
}

function clearSpendForm() {
  document.getElementById('spendId').value = '';
  document.getElementById('spendAmount').value = '';
  document.getElementById('spendContent').value = '';
  document.getElementById('spendProof').value = '';
  document.getElementById('spendSave').textContent = '추가';
  document.getElementById('spendCancel').hidden = true;
  clearSay('#msgSpendForm');
}

function editSpend(id) {
  const x = SPEND.items.find((v) => v.id === id);
  if (!x) return;
  document.getElementById('spendId').value = x.id;
  document.getElementById('spendDate').value = x.date;
  document.getElementById('spendRow').value = x.rowId;
  document.getElementById('spendAmount').value = x.amount;
  document.getElementById('spendContent').value = x.content || '';
  document.getElementById('spendProof').value = x.proof || '';
  document.getElementById('spendSave').textContent = '고치기';
  document.getElementById('spendCancel').hidden = false;
  say('#msgSpendForm', 'info', `${x.date} · ${원(x.amount)}원 을 고치는 중입니다.`);
  document.getElementById('spendAmount').focus();
}

async function saveSpend() {
  const body = {
    id: document.getElementById('spendId').value || undefined,
    date: document.getElementById('spendDate').value,
    rowId: document.getElementById('spendRow').value,
    amount: document.getElementById('spendAmount').value,
    content: document.getElementById('spendContent').value.trim(),
    proof: document.getElementById('spendProof').value.trim(),
  };
  const btn = document.getElementById('spendSave');
  btn.disabled = true;
  try {
    await api('/api/spending', { method: 'POST', body });
    clearSpendForm();
    await loadSpending();
    say('#msgSpend', 'ok', '집행 내역을 저장했습니다. 정산서의 집행액이 함께 바뀌었습니다.');
  } catch (e) {
    await showDialog({ kind: 'bad', title: '저장하지 못했습니다', message: e.message });
  } finally {
    btn.disabled = false;
  }
}

async function delSpend(id) {
  const x = SPEND.items.find((v) => v.id === id);
  if (!x) return;
  const ok = await showDialog({
    kind: 'warn',
    title: '이 집행 내역을 지울까요?',
    message: `${x.date} · ${원(x.amount)}원${x.content ? `\n${x.content}` : ''}`,
    detail: '정산서의 집행액에서도 빠집니다.',
    button: '지우기',
    cancel: '그만두기',
  });
  if (!ok) return;
  try {
    await api(`/api/spending/${encodeURIComponent(id)}`, { method: 'DELETE' });
    await loadSpending();
    say('#msgSpend', 'ok', '지웠습니다.');
  } catch (e) {
    await showDialog({ kind: 'bad', title: '지우지 못했습니다', message: e.message });
  }
}

function initSpendUI() {
  document.getElementById('spendYear').value = new Date().getFullYear();
  document.getElementById('spendDate').value = todayStr();
  document.getElementById('spendReload').addEventListener('click', loadSpending);
  document.getElementById('spendYear').addEventListener('change', loadSpending);
  document.getElementById('spendSave').addEventListener('click', saveSpend);
  document.getElementById('spendCancel').addEventListener('click', clearSpendForm);
}

/* ================================================================
   업무 점검
   ================================================================ */
async function loadMonth() {
  const month = document.getElementById('month').value || thisMonth();
  clearSay('#msgCheck');
  const data = await api(`/api/monthly?month=${month}`);
  /* 점검 목록은 **최신 날짜가 위**로 온다(2026-08-22 사용자 지시).
     점검할 것은 늘 최근 기록이므로 아래로 스크롤하지 않아도 되게 한다.
     ⚠ 서버(`/api/monthly`)의 정렬은 **오래된 것부터**여야 한다 —
     활동일지·출근기록부의 「순」 번호가 그 순서를 그대로 쓴다. 여기서만 뒤집는다. */
  const logs = [...data.logs].reverse();
  const waiting = logs.filter((l) => !l.check || l.check.status !== 'checked').length;

  document.getElementById('summary').innerHTML = `
    <div class="row" style="margin-top:16px">
      <div class="notice info" style="margin:0"><b>${month} 활동</b>${logs.length}일 · ${data.totalHours}시간</div>
      <div class="notice ${waiting ? 'warn' : 'ok'}" style="margin:0"><b>점검</b>${
        waiting ? `${waiting}건이 점검을 기다립니다` : '모두 점검 완료'
      }</div>
      <div class="notice ok" style="margin:0"><b>이 달 인건비</b>${won(data.pay)} <span style="font-size:15px">(${data.totalHours}시간 × ${won(data.coordinator.hourlyWage)})</span></div>
    </div>`;

  document.getElementById('regSign').innerHTML = S && S.manager.signFile
    ? `<div class="notice ok" style="margin-top:0">등록된 서명이 있습니다. <img src="/files/signs/${encodeURIComponent(S.manager.signFile)}" style="max-height:50px;vertical-align:middle;margin-left:8px"></div>`
    : '<div class="notice warn" style="margin-top:0">아직 등록된 서명이 없습니다. 아래 칸에 서명하고 [등록]을 눌러 주세요.</div>';

  const box = document.getElementById('logList');
  if (!logs.length) {
    box.innerHTML = '<div class="card"><div class="empty">이 달에는 활동 기록이 없습니다.</div></div>';
    return;
  }
  rowPads.clear();
  box.innerHTML = logs.map(renderLog).join('');
  loadFixBreak(month); // 유휴가 빠진 기록이 있으면 위에 안내를 띄운다

  // 버튼 연결
  for (const l of logs) {
    const checkBtn = document.getElementById(`chk-${l.id}`);
    if (checkBtn) checkBtn.addEventListener('click', () => doCheck(l.id, 'check', false));
    const drawBtn = document.getElementById(`draw-${l.id}`);
    if (drawBtn) drawBtn.addEventListener('click', () => openRowPad(l.id));
    const retBtn = document.getElementById(`ret-${l.id}`);
    if (retBtn) retBtn.addEventListener('click', () => doCheck(l.id, 'return'));
  }
}

/**
 * 유휴시간이 빠진 기록에 붙이는 안내.
 * 2026-08-22 부터 4시간 이상 근무일에는 유휴시간이 필수가 되었지만,
 * **그 전에 저장한 기록에는 유휴가 없다.** 서식은 그것을 그대로 찍으므로
 * (체류 4 = 근무 4) 시스템관리자가 «왜 4시간인가» 를 알 수 없었다.
 * ⚠ 지난 기록을 저절로 바꾸지는 않는다 — 복무 증빙 문서라 **사람이 정할 일**이다.
 */
function needsBreakNote(l) {
  const t = dayTime(l.clockIn, l.clockOut, l.breakStart, l.breakEnd);
  if (t.error || !breakShortage(t)) return '';
  const need = requiredBreakMin(t.stay);
  const p2 = (n) => String(Math.floor(n / 60)).padStart(2, '0') + ':' + String(n % 60).padStart(2, '0');
  const toMin = (x) => Number(x.split(':')[0]) * 60 + Number(x.split(':')[1]);
  const 늦춘퇴근 = p2(toMin(l.clockOut) + need);
  return `<div class="notice warn" style="margin-top:10px;font-size:16px">
    <b>이 기록에는 유휴(휴게) 시간이 없습니다</b>
    ${t.stay}시간 근무하는 날은 <b>${need}분 이상</b>이 있어야 합니다(근로기준법 제54조).
    유휴시간이 없던 판으로 저장한 기록입니다.<br>
    <span style="font-size:15px">고치시려면 <b>[반송]</b> 한 뒤 코디네이터가 유휴시간을 넣어 다시 올립니다. 두 가지 길이 있습니다 —<br>
    ⓐ <b>근무시간을 지킨다</b> : 퇴근을 <b>${escapeHtml(늦춘퇴근)}</b> 로 늦춰 적고 유휴 ${need}분
      → 체류 ${Math.round((t.stay + need / 60) * 10) / 10} · 근무 ${t.stay} · <b>인건비 그대로</b><br>
    ⓑ <b>체류시간을 지킨다</b> : ${escapeHtml(l.clockIn)}~${escapeHtml(l.clockOut)} 그대로 두고 유휴 ${need}분
      → 체류 ${t.stay} · 근무 ${Math.round((t.stay - need / 60) * 10) / 10} · <b>인건비가 줄어듭니다</b><br>
    실제로 그날 어떻게 근무했는지에 맞춰 고르셔야 합니다. <b>그냥 두셔도 됩니다</b> — 이미 점검·서명이 끝난 달이면
    다음 근무일부터 유휴를 기록하는 편이 낫습니다.</span></div>`;
}

/* ================================================================
   지난 기록에 유휴시간 채우기 (2026-08-24 사용자 지시)
   ----------------------------------------------------------------
   *"이미 8월 19일부터 24일까지 일지가 기록되어 버렸어. 퇴근시간을 유휴시간
     포함한 시간으로 계산해서 출근부와 일지를 수정할 수 없나?"*

   **퇴근시각을 유휴시간만큼 늦춰 적는다.** 근무시간과 인건비는 그대로다.
   유휴는 예전 퇴근시각 뒤에 붙이므로 **활동일지의 지도 구간이 하나도 바뀌지 않는다.**
   ⚠ 고칠 것이 없으면 이 상자는 아예 나타나지 않는다 — 한 번 쓰고 사라지는 도구다.
   ================================================================ */
let FIXABLE = null;

async function loadFixBreak(month) {
  const box = document.getElementById('fixBreakBox');
  if (!box) return;
  box.innerHTML = '';
  FIXABLE = null;
  let r;
  try {
    r = await api('/api/logs/fix-break', { method: 'POST', body: { month, apply: false } });
  } catch {
    return; // 예전 판이면 이 API 가 없다 — 조용히 넘어간다
  }
  const n = r.summary.고칠건수;
  const m = r.manual || [];
  if (!n && !m.length) return;
  FIXABLE = r;

  const rows = (r.items || [])
    .map(
      (x) => `<tr>
        <td>${escapeHtml(dateKo(x.date))}</td>
        <td>${escapeHtml(x.before.clockIn)}~${escapeHtml(x.before.clockOut)}</td>
        <td><b>${escapeHtml(x.after.clockIn)}~${escapeHtml(x.after.clockOut)}</b></td>
        <td>${escapeHtml(x.after.breakStart)}~${escapeHtml(x.after.breakEnd)}</td>
        <td>${x.before.stay} → <b>${x.after.stay}</b></td>
        <td>${x.before.work} → <b>${x.after.work}</b></td>
        <td>${x.checked ? '점검 완료' : '점검 전'}</td></tr>`,
    )
    .join('');

  box.innerHTML = `<div class="notice warn" style="margin-top:16px">
    <b>⏱ 유휴(휴게) 시간이 없는 기록이 ${n}건 있습니다</b>
    유휴시간 기능이 생기기 전에 저장한 기록입니다. <b>퇴근시각을 유휴시간만큼 늦춰 적어</b>
    법정 휴게를 채울 수 있습니다 — <b>근무시간과 인건비는 그대로입니다.</b><br>
    <span style="font-size:15px;color:var(--gray-700)">유휴는 예전 퇴근시각 뒤에 붙이므로
    <b>활동일지의 지도 시간 구간은 하나도 바뀌지 않습니다.</b> 출근기록부의 퇴근시각과
    활동시간(체류)만 늘어납니다.</span>
    ${
      n
        ? `<div class="scrollx" style="margin-top:10px"><table class="grid" style="font-size:15px">
            <thead><tr><th>날짜</th><th>지금</th><th>고친 뒤</th><th>유휴</th><th>체류</th><th>근무</th><th>점검</th></tr></thead>
            <tbody>${rows}</tbody>
            <tfoot><tr><th colspan="4">합계</th>
              <th>${r.summary.체류합_전} → ${r.summary.체류합_후}</th>
              <th>${r.summary.근무합_전} → <b>${r.summary.근무합_후}</b> (그대로)</th><th></th></tr></tfoot>
          </table></div>`
        : ''
    }
    ${
      m.length
        ? `<div class="notice bad" style="margin-top:10px;font-size:15px"><b>손으로 고쳐야 하는 기록 ${m.length}건</b><br>
            ${m.map((x) => `· ${escapeHtml(dateKo(x.date))} — ${escapeHtml(x.why)}`).join('<br>')}</div>`
        : ''
    }
    ${
      n
        ? `<div class="btnbar" style="margin-top:10px">
            <button id="fixBreakGo">⏱ 위 ${n}건을 이렇게 고치기</button>
          </div>
          <span style="font-size:14px;color:var(--gray-700)">고치기 전에 자료를 통째로 백업합니다.
          점검 서명은 그대로 두고, 무엇을 바꿨는지 기록에 남깁니다.</span>`
        : ''
    }
  </div>`;

  const go = document.getElementById('fixBreakGo');
  if (go) go.addEventListener('click', () => applyFixBreak(month));
}

async function applyFixBreak(month) {
  if (!FIXABLE) return;
  const n = FIXABLE.summary.고칠건수;
  const ok = await showDialog({
    kind: 'warn',
    title: `${n}건의 퇴근시각을 늦춰 적을까요?`,
    message:
      `근무시간 합계는 ${FIXABLE.summary.근무합_전}시간 그대로입니다. 인건비도 바뀌지 않습니다.` +
      `\n체류시간 합계는 ${FIXABLE.summary.체류합_전} → ${FIXABLE.summary.체류합_후} 시간이 됩니다.`,
    detail:
      '· 고치기 전에 자료를 통째로 백업합니다(data/backup).\n' +
      '· 점검 서명은 그대로 둡니다. 무엇을 바꿨는지 기록에 남깁니다.\n' +
      '· 활동일지의 지도 시간 구간은 바뀌지 않습니다.\n' +
      '· 실제로 그렇게 근무하신 것이 맞는지 확인해 주세요 — 복무 증빙 문서입니다.',
    button: '고치기',
    cancel: '그만두기',
  });
  if (!ok) return;

  const btn = document.getElementById('fixBreakGo');
  if (btn) {
    btn.disabled = true;
    btn.textContent = '고치는 중…';
  }
  try {
    const r = await api('/api/logs/fix-break', { method: 'POST', body: { month, apply: true } });
    say(
      '#msgCheck',
      'ok',
      `${r.summary.고칠건수}건을 고쳤습니다. 근무시간은 ${r.summary.근무합_후}시간 그대로입니다.` +
        `\n되돌릴 백업 : ${r.backup} (data/backup 폴더)` +
        '\n[문서 출력] 에서 출근기록부를 다시 뽑아 확인해 주세요.',
    );
    await loadMonth();
  } catch (e) {
    say('#msgCheck', 'bad', e.message);
    if (btn) {
      btn.disabled = false;
      btn.textContent = '⏱ 위 기록을 이렇게 고치기';
    }
  }
}

function renderLog(l) {
  const checked = l.check && l.check.status === 'checked';
  const returned = l.check && l.check.status === 'returned';
  const tag = checked
    ? '<span class="tag checked">점검 완료</span>'
    : returned
      ? '<span class="tag returned">반송 — 코디네이터 수정 대기</span>'
      : '<span class="tag unchecked">점검 대기</span>';

  const itemRows = (l.items || [])
    .map(
      (it) => `<tr>
        <td>${escapeHtml(it.classes || '-')}</td>
        <td>${escapeHtml(it.subject || '-')}</td>
        <td>${escapeHtml(it.operationType || '-')}</td>
        <td class="left">${escapeHtml(it.content || '')}</td>
        <td>${it.hours || 0}</td></tr>`,
    )
    .join('');

  const photos = (l.photos || [])
    .map(
      (f) =>
        `<a href="/files/photos/${encodeURIComponent(f)}" target="_blank"><img src="/files/photos/${encodeURIComponent(f)}" alt="활동 사진" loading="lazy"></a>`,
    )
    .join('');

  const actions = checked
    ? `<div class="notice ok" style="margin-top:12px"><b>점검 완료</b>${escapeHtml(l.check.by)} (${escapeHtml(l.check.position || '시스템관리자')}) · ${escapeHtml(l.check.at)}
        ${l.check.signFile ? `<img src="/files/signs/${encodeURIComponent(l.check.signFile)}" style="max-height:44px;vertical-align:middle;margin-left:10px">` : ''}
        ${l.check.comment ? '<br>' + escapeHtml(l.check.comment) : ''}</div>
       <label style="margin-top:12px">반송 사유 <span class="hint">고쳐서 다시 올려야 하는 이유를 적어 주세요</span></label>
       <input type="text" id="cmt-${l.id}" placeholder="예) 유휴(휴게) 시간을 넣어 주세요.">
       <div class="btnbar"><button class="ghost small" id="ret-${l.id}">반송(수정 요청)</button></div>
       ${
         /* 점검이 끝난 기록에도 «유휴가 없는 4시간 이상» 이 있으면 알려 준다.
            2026-08-22 부터 4시간 이상 근무일에는 유휴시간이 필수인데, 그 전에 저장한 기록에는
            유휴가 없다. 반송해서 고치게 하려면 «무엇을 고쳐야 하는지» 가 보여야 한다. */
         needsBreakNote(l)
       }`
    : `<label style="margin-top:14px">점검 의견 <span class="hint">(선택 · 반송할 때는 필수)</span></label>
       <input type="text" id="cmt-${l.id}" placeholder="예) 8/20 활동 시간을 2시간으로 정정해 주세요.">
       <div class="btnbar">
         <button class="ok small" id="chk-${l.id}">✍️ 등록된 서명으로 점검 완료</button>
         <button class="ghost small" id="draw-${l.id}">직접 서명해서 점검</button>
         <button class="danger small" id="ret-${l.id}">반송(수정 요청)</button>
       </div>
       <div id="pad-${l.id}"></div>
       ${returned ? `<div class="notice bad" style="margin-top:10px">반송한 상태입니다 : ${escapeHtml(l.check.comment)}</div>` : ''}
       ${needsBreakNote(l)}`;

  return `
  <div class="card">
    <h2 style="font-size:20px">${dateKo(l.date)} ${escapeHtml(l.clockIn)}~${escapeHtml(l.clockOut)} · ${l.hours}시간 ${tag}</h2>
    <dl class="item" style="border:0;padding:0;display:grid;grid-template-columns:auto 1fr;gap:4px 14px;font-size:16px">
      <dt style="color:var(--gray-500);font-weight:700">활동 장소</dt><dd style="margin:0">${escapeHtml(l.place || '-')}</dd>
      <dt style="color:var(--gray-500);font-weight:700">안전 점검</dt><dd style="margin:0">${l.safetyCheck ? '✅ ' : '⚠️ '}${escapeHtml(l.safetyNote || '-')}</dd>
      <dt style="color:var(--gray-500);font-weight:700">강사 서명</dt><dd style="margin:0">${
        l.signFile ? `<img src="/files/signs/${encodeURIComponent(l.signFile)}" style="max-height:40px">` : '<span style="color:var(--red)">없음</span>'
      }</dd>
    </dl>
    ${itemRows ? `<div class="scrollx" style="margin-top:12px"><table class="grid">
      <thead><tr><th>지도반</th><th>교과</th><th>운영형태</th><th>지도 내용</th><th>시간</th></tr></thead>
      <tbody>${itemRows}</tbody></table></div>` : ''}
    ${l.note ? `<div class="notice info" style="margin-top:12px"><b>특기사항</b>${escapeHtml(l.note).replace(/\n/g, '<br>')}</div>` : ''}
    ${photos ? `<div class="shots">${photos}</div>` : ''}
    ${actions}
  </div>`;
}

/** 그 기록에만 쓸 서명판을 펼친다 */
function openRowPad(id) {
  const box = document.getElementById('pad-' + id);
  if (!box || rowPads.has(id)) return;
  box.innerHTML = `
    <div class="notice info" style="margin-top:12px">
      <b>이 기록에만 쓸 서명</b>
      <canvas class="signpad" id="rowpad-${id}"></canvas>
      <div class="btnbar" style="margin-top:8px">
        <button class="ok small" id="rowok-${id}">이 서명으로 점검 완료</button>
        <button class="ghost small" id="rowclr-${id}">다시 쓰기</button>
      </div>
    </div>`;
  const pad = makeSignPad(document.getElementById(`rowpad-${id}`));
  rowPads.set(id, pad);
  document.getElementById(`rowclr-${id}`).addEventListener('click', () => pad.clear());
  document.getElementById(`rowok-${id}`).addEventListener('click', () => doCheck(id, 'check', true));
}

async function doCheck(id, action, useRowPad) {
  clearSay('#msgCheck');
  const comment = (document.getElementById('cmt-' + id) || {}).value || '';
  if (action === 'return' && !comment.trim()) {
    return say('#msgCheck', 'warn', '반송하려면 어떤 부분을 고쳐야 하는지 [점검 의견]에 적어 주세요.');
  }
  let sign = null;
  if (action === 'check') {
    if (useRowPad) {
      const pad = rowPads.get(id);
      if (!pad || pad.isEmpty()) return say('#msgCheck', 'warn', '서명을 먼저 써 주세요.');
      sign = pad.toDataUrl();
    } else if (!S.manager.signFile) {
      return say('#msgCheck', 'warn', '등록된 서명이 없습니다. [내 서명]에서 먼저 등록하거나 [직접 서명해서 점검]을 눌러 주세요.');
    }
  }
  try {
    await api(`/api/logs/${encodeURIComponent(id)}/check`, { method: 'POST', body: { action, comment, sign } });
    say('#msgCheck', 'ok', action === 'return' ? '반송했습니다. 코디네이터가 고쳐서 다시 올립니다.' : '점검을 완료했습니다.');
    await loadMonth();
  } catch (e) {
    say('#msgCheck', 'bad', e.message);
  }
}

async function saveMySign() {
  if (mySignPad.isEmpty()) return say('#msgCheck', 'warn', '서명을 먼저 써 주세요.');
  try {
    await api('/api/settings', { method: 'POST', body: { managerSign: mySignPad.toDataUrl() } });
    mySignPad.clear();
    say('#msgCheck', 'ok', '서명을 등록했습니다. 이제 기록마다 클릭 한 번으로 점검할 수 있습니다.');
    await loadSetup();
    await loadMonth();
  } catch (e) {
    say('#msgCheck', 'bad', e.message);
  }
}

/* ================================================================
   설정
   ================================================================ */
/* ==========================================================
   접히는 설정 항목 — 펼침 상태 기억 · 손댈 것이 있으면 배지
   ----------------------------------------------------------
   설정이 285줄 한 장이라 아래쪽까지 내려가기가 멀었다(2026-08-24 사용자 지시).
   여닫는 일 자체는 <details>/<summary> 가 하고(JS 가 없어도 된다), 여기서는 셋만 더한다.
     ① 어느 항목을 펼쳐 두었는지 기억한다
     ② [모두 펼치기] · [모두 접기]
     ③ **접혀 있어도 보이는 경고 배지** — 이것이 가장 중요하다.
        접어 두면 「주 15시간 넘음」·「백업을 오래 안 함」·「새 판이 나옴」 같은
        알려야 할 것이 안 보인다. 접기 때문에 놓치는 일이 생기면 안 된다.
   ⚠ 기억은 `sessionStorage` 에 둔다. 창을 닫으면 사라지고, 개인정보가 아니다.
      `localStorage` 에는 명단 번호(`lastMemberId`) 하나만 둔다는 규칙을 지키려는 것이다.
   ========================================================== */
const FOLD_KEY = 'aicodi.setupFolds';

function foldList() {
  return Array.from(document.querySelectorAll('#tab-setup details.fold'));
}

/** 지금 펼쳐진 항목을 기억한다 */
function saveFolds() {
  /* ⚠ 계산은 try 밖에서 한다. 안에 넣으면 프로그램 오류(ReferenceError 등)까지
     `catch` 가 삼켜 «되는데 안 된다» 가 된다 — 실제로 그렇게 헤맸다.
     try 는 **저장소를 만지는 줄만** 감싼다(사생활 보호 모드에서 막힐 수 있다). */
  const open = foldList().filter((d) => d.open).map((d) => d.id);
  const val = JSON.stringify(open);
  try {
    sessionStorage.setItem(FOLD_KEY, val);
  } catch {
    /* 저장이 막힌 브라우저 — 기억만 못 할 뿐 화면은 그대로 쓴다 */
  }
}

/** 기억해 둔 대로 펼친다. 처음 오면 **모두 접은 채** 시작한다(그래야 화면이 짧다). */
function restoreFolds() {
  let raw = null;
  try {
    raw = sessionStorage.getItem(FOLD_KEY);
  } catch {
    raw = null; // 저장이 막힌 브라우저
  }
  let open = [];
  try {
    open = JSON.parse(raw || '[]'); // 값이 깨져 있어도 그냥 «다 접힘» 으로 시작한다
  } catch {
    open = [];
  }
  if (!Array.isArray(open)) open = [];
  for (const d of foldList()) d.open = open.includes(d.id);
}

function setupFolds() {
  for (const d of foldList()) d.addEventListener('toggle', saveFolds);
  const all = (v) => {
    for (const d of foldList()) d.open = v;
    saveFolds();
  };
  const btnAll = document.getElementById('foldAll');
  const btnNone = document.getElementById('foldNone');
  if (btnAll) btnAll.addEventListener('click', () => all(true));
  if (btnNone) btnNone.addEventListener('click', () => all(false));
  restoreFolds();
}

/**
 * 접힌 제목 옆에 붙이는 배지.
 * @param {string} foldId  details 의 id (배지는 `<foldId>-badge`)
 * @param {string} text    보여 줄 짧은 글. 빈 값이면 숨긴다
 * @param {string} kind    '' (주의) · 'bad' (막힘) · 'info' (알림)
 */
function foldBadge(foldId, text, kind) {
  const el = document.getElementById(foldId + '-badge');
  if (!el) return;
  if (!text) {
    el.hidden = true;
    el.textContent = '';
    return;
  }
  el.hidden = false;
  el.textContent = text;
  el.className = 'fold-badge' + (kind ? ' ' + kind : '');
}

async function loadSetup() {
  S = await api('/api/settings');
  const v = (id, val) => (document.getElementById(id).value = val ?? '');

  v('school', S.school);
  v('schoolYear', S.schoolYear);
  v('mgrName', S.manager.name);
  v('mgrPos', S.manager.position);

  v('coName', S.coordinator.name);
  v('coStart', S.coordinator.contractStart);
  v('coEnd', S.coordinator.contractEnd);
  v('coWage', S.coordinator.hourlyWage);
  v('coOther', S.coordinator.otherSchoolHours);
  renderSchedule(S.coordinator.schedule);

  v('budgetNote', S.budget.note);
  // 설정 탭은 **편성만** 다룬다. 집행액은 [예산 집행] 탭의 건별 내역에서 온다.
  renderBudgetRows((S.report && S.report.budgetRows) || []);
  v('places', (S.places || []).join(', '));

  v('repBg', S.report.background);
  v('repPurpose', S.report.purpose);
  v('repOutputs', S.report.outputs);

  document.getElementById('pinMgrState').textContent = S.manager.pinHash ? '(설정됨)' : '(아직 없음)';

  renderAddress();
}

/**
 * 선생님들께 알려 줄 주소 안내.
 * `location.origin` 을 쓰면 안 된다 — 시스템관리자가 localhost 로 열어 보고 있으면
 * 화면에 localhost 가 찍히고, 그걸 그대로 알려 주면 아무도 접속하지 못한다.
 * 서버가 정해 준 주소(`shareUrl`)를 쓴다.
 */
async function renderAddress() {
  const pub = await api('/api/public-settings').catch(() => null);
  const box = document.getElementById('addrBox');
  if (!pub || !pub.shareUrl) {
    box.innerHTML = '<div class="notice warn">주소를 아직 알 수 없습니다. 서버를 다시 켜 주세요.</div>';
    return;
  }

  const notice =
    `[AI교육 코디네이터 업무 요청 안내]\n\n` +
    `아래 주소를 눌러 수업 지원·자료 제작 등을 요청하실 수 있습니다.\n` +
    `${pub.shareUrl}\n\n` +
    `· 처음 들어가면 명단에서 본인 이름을 고르고 인증코드를 넣으시면 됩니다.\n` +
    `· 인증코드는 따로 알려 드립니다.\n` +
    `· 요청하시면 코디네이터가 수락·거절·시간조절을 알려 드립니다.`;

  // 지금 어떤 이름을 쓰는지에 맞춰 안내를 바꾼다
  const wanted = pub.shareHostWanted || '';
  const port = (pub.shareUrl.match(/:(\d+)\/?$/) || [, '4000'])[1];
  /* 🔴 이 PC 의 컴퓨터 이름을 화면에 찍지 말 것 (2026-08-24 사용자 지시).
     학교 PC 의 컴퓨터 이름은 사람 이름인 경우가 많아(예 «홍길동») 그대로 성명이 된다.
     예전에는 «✔ 이 PC의 컴퓨터 이름(…)을 주소로 쓰고 있습니다» 처럼 찍었고,
     그 이름이 주소가 되어 검은 창·바로가기·선생님 공지로도 함께 나갔다.
     서버가 이제 컴퓨터 이름을 자동으로 쓰지 않으므로 안내도 두 갈래로 줄었다. */

  // 순서 주의 : 직접 정한 이름이 안 쓰이는 경우를 가장 먼저 알려야 한다
  let hostBox = '';
  if (wanted && !pub.shareHostOk) {
    hostBox = `<div class="notice warn">
        <b>설정한 이름 “${escapeHtml(wanted)}” 는 아직 쓸 수 없습니다</b>
        <div style="font-size:16px">
          학교망에서 그 이름이 이 PC를 가리키지 않아, 지금은 <b>위 주소</b>를 쓰고 있습니다(정상 동작).<br>
          <code>http://${escapeHtml(wanted)}:${port}/</code> 로 쓰시려면 아래 중 하나만 하시면 됩니다.
          <ol style="margin:8px 0 0;padding-left:24px">
            <li>이 PC 이름을 <b>${escapeHtml(wanted)}</b> 로 바꾸기 —
                설정 → 시스템 → 정보 → <b>[이 PC의 이름 바꾸기]</b> 뒤 이 프로그램을 다시 켜기</li>
            <li>정보 담당자에게 <b>DNS 등록</b> 요청 :
                ${escapeHtml(wanted)} → ${escapeHtml((pub.shareIp || '').replace(/^http:\/\/|:\d+\/?$/g, ''))}</li>
          </ol>
          그냥 지금 주소를 쓰시려면 아래 [주소 이름 직접 정하기] 에서 이 이름을 <b>지우고 저장</b>하세요.
        </div>
      </div>`;
  } else if (pub.shareUsingIp) {
    hostBox = `<div class="notice info">
        <b>지금은 이 PC 의 IP 주소를 쓰고 있습니다</b>
        <div style="font-size:16px">
          그대로 쓰셔도 됩니다. 다만 <b>교무실 PC 의 IP 가 바뀌면 주소도 바뀌므로</b>
          바뀐 뒤에는 선생님들께 새 주소를 알려 주셔야 합니다.<br>
          <span style="color:var(--gray-700)">늘 같은 주소를 쓰고 싶으시면 아래
          [주소 이름 직접 정하기] 에서 이름을 정하고, 학교 정보 담당자에게
          그 이름의 <b>DNS 등록</b>을 요청하세요.</span>
        </div>
      </div>`;
  } else if (wanted && pub.shareHostOk) {
    hostBox = `<div class="notice ok" style="font-size:16px">✔ 설정한 이름 <b>${escapeHtml(wanted)}</b> 이(가) 정상 작동합니다.</div>`;
  }

  /* 무선(휴대폰·태블릿)과 다른 망에서 들어오는 분께 드릴 IP 주소.
     컴퓨터 이름은 브로드캐스트로 푸는 방식이라 라우터를 넘지 못한다 —
     같은 망이 아니면 이름 주소는 반드시 실패하므로 IP 를 따로 안내해야 한다. */
  const ips = (pub.shareAddresses || []).filter((u) => u !== pub.shareUrl);
  const wifiBox = ips.length
    ? `<div class="notice info">
        <b>📶 무선(휴대폰·태블릿)이나 다른 망에서 들어오는 분께</b>
        <div style="font-size:16px;margin-top:4px">
          <b>이름으로 된 주소는 같은 망 안에서만</b> 통합니다.
          무선이나 다른 망(무선 AP 등)에서는 <b>아래 IP 주소</b>를 알려 주세요.
        </div>
        <div style="margin:8px 0">
          ${ips
            .map(
              (u) =>
                `<div style="font-size:20px;font-weight:700;word-break:break-all">${escapeHtml(u)}
                 <button class="ghost small" data-copyip="${escapeHtml(u)}" style="margin-left:6px;vertical-align:middle">복사</button></div>`,
            )
            .join('')}
        </div>
        ${
          ips.length > 1
            ? `<div style="font-size:16px;color:var(--gray-700)">주소가 여러 개인 것은 이 PC가 <b>랜선과 무선에 함께</b> 연결되어 있기 때문입니다.
               상대방과 <b>앞자리가 같은 망</b>의 주소를 알려 주세요.</div>`
            : ''
        }
        <div style="font-size:16px;color:var(--gray-700);margin-top:6px">
          그래도 안 되면 <b>방화벽_허용.bat 을 관리자 권한으로</b> 한 번 실행해 보세요.
          그 다음은 아래 <b>[접속 확인]</b> 으로 원인을 가릴 수 있습니다.
        </div>
        <div id="visitorBox" style="margin-top:12px"></div>
        <div class="btnbar" style="margin-top:8px">
          <button class="ghost small" id="visitorReload">🔎 접속 확인 (누가 들어왔는지 보기)</button>
        </div>
      </div>`
    : '';

  box.innerHTML = `
    <div class="notice ok">
      <b>선생님들께 알려 줄 주소</b>
      <div style="font-size:24px;font-weight:700;word-break:break-all;margin:6px 0">${escapeHtml(pub.shareUrl)}</div>
      ${pub.shareAltUrl ? `<div style="font-size:16px">잘 안 되는 PC가 있으면 : ${escapeHtml(pub.shareAltUrl)}</div>` : ''}
      <div class="btnbar" style="margin-top:12px">
        <button class="small" id="copyAddr">📋 주소 복사</button>
        <button class="ghost small" id="copyNotice">📋 안내문 전체 복사</button>
      </div>
    </div>
    ${wifiBox}
    ${hostBox}
    <details style="margin-top:4px">
      <summary style="cursor:pointer;font-weight:700;color:var(--gray-500)">주소 이름 직접 정하기 (고급)</summary>
      <div class="notice info" style="margin-top:10px">
        <div style="font-size:16px">
          보통은 <b>건드리지 않아도 됩니다</b> — 설치된 PC의 컴퓨터 이름이 자동으로 들어갑니다.<br>
          학교 DNS 에 따로 등록한 이름이 있을 때만 바꾸세요. 그 이름이 이 PC로 풀리지 않으면
          접속되는 주소로 자동으로 되돌립니다.
        </div>
        <div class="row" style="align-items:flex-end;max-width:520px;margin-top:10px">
          <div>
            <label for="shareHost">주소 이름 <span class="hint">영문 소문자·숫자·하이픈</span></label>
            <input id="shareHost" type="text" value="${escapeHtml(wanted)}" placeholder="aicodi">
          </div>
          <div style="flex:0 0 auto"><button class="ghost" id="saveShareHost">이름 저장</button></div>
        </div>
      </div>
    </details>

    <div class="notice info">
      <b>선생님들께 드릴 것은 두 가지입니다</b>
      <div style="font-size:17px">
        ① <b>위 주소</b>(또는 프로그램 폴더에 자동으로 만들어진
        <code>선생님께_보낼_바로가기.url</code> 파일) — 전체 공지·공유폴더로 배포해도 됩니다.<br>
        ② <b>각자의 인증코드</b> — <span style="color:var(--red);font-weight:700">반드시 한 사람씩 따로</span> 알려 주세요.<br>
        <span style="color:var(--gray-500)">※ 선생님들은 아무것도 설치하지 않습니다. 주소만 누르면 됩니다.</span>
      </div>
    </div>

    <div class="notice bad">
      <b>⚠️ 절대 전체에 배포하면 안 되는 것</b>
      <div style="font-size:17px">
        <b>명단 엑셀 파일</b> — 전 직원의 인증코드가 그대로 적혀 있습니다.
        이 파일은 시스템관리자님만 보관하세요.
      </div>
    </div>

    <div>
      <label for="noticeText">메신저에 붙여넣을 안내문 <span class="hint">(고쳐서 쓰셔도 됩니다)</span></label>
      <textarea id="noticeText" style="min-height:170px">${escapeHtml(notice)}</textarea>
    </div>

    <div class="notice warn">
      <b>코디네이터에게는 주소가 다릅니다</b>
      <div style="font-size:17px">
        코디네이터는 <b>요청 처리·활동 기록</b> 화면을 쓰므로 아래 주소를 따로 알려 주세요.
        (위의 선생님용 주소로 들어가면 명단에 이름이 안 보입니다)
      </div>
      <div style="font-size:21px;font-weight:700;word-break:break-all;margin:8px 0">${escapeHtml(pub.shareUrl)}coordinator.html</div>
      <div class="btnbar">
        <button class="small warn" id="copyCoAddr">📋 코디네이터 주소 복사</button>
        <button class="ghost small" id="copyCoNotice">📋 코디네이터용 안내문 복사</button>
      </div>
      <div style="font-size:15px;margin-top:8px;color:var(--gray-700)">
        문서 출력 화면(시스템관리자·코디네이터) : ${escapeHtml(pub.shareUrl)}reports.html
      </div>
    </div>`;

  const copy = async (text, btn) => {
    try {
      await navigator.clipboard.writeText(text);
      const old = btn.textContent;
      btn.textContent = '✅ 복사했습니다';
      setTimeout(() => (btn.textContent = old), 1800);
    } catch {
      alert('복사가 막혔습니다. 아래 안내문 칸을 직접 선택해 Ctrl+C 를 눌러 주세요.');
    }
  };
  const coNotice =
    `[AI교육 코디네이터 업무 화면 안내]\n\n` +
    `아래 주소에서 선생님들의 요청을 확인하고 활동을 기록하실 수 있습니다.\n` +
    `${pub.shareUrl}coordinator.html\n\n` +
    `· 이름을 고르고 인증코드를 넣으면 들어갑니다. (인증코드는 따로 알려 드립니다)\n` +
    `· [요청함] 에서 수락 · 거절 · 시간조절을 고르실 수 있습니다.\n` +
    `· [활동 기록] 에 그날의 출퇴근·활동 내용을 적고 서명하시면\n` +
    `  활동일지와 출근기록부가 자동으로 만들어집니다.\n` +
    `· 주 15시간 미만이 되도록 화면 위쪽 시간 표시를 확인해 주세요.`;

  document.getElementById('copyAddr').addEventListener('click', (e) => copy(pub.shareUrl, e.target));
  document.getElementById('copyNotice').addEventListener('click', (e) =>
    copy(document.getElementById('noticeText').value, e.target),
  );
  document.getElementById('copyCoAddr').addEventListener('click', (e) => copy(pub.shareUrl + 'coordinator.html', e.target));
  document.getElementById('copyCoNotice').addEventListener('click', (e) => copy(coNotice, e.target));
  // 무선용 IP 주소 복사 (주소마다 단추가 하나씩)
  box.querySelectorAll('[data-copyip]').forEach((b) => b.addEventListener('click', (e) => copy(b.dataset.copyip, e.target)));
  const vr = document.getElementById('visitorReload');
  if (vr) {
    vr.addEventListener('click', () => loadVisitors());
    loadVisitors();
  }

  document.getElementById('saveShareHost').addEventListener('click', async (e) => {
    e.target.disabled = true;
    try {
      await api('/api/settings', { method: 'POST', body: { shareHost: document.getElementById('shareHost').value } });
      await showDialog({
        kind: 'ok',
        title: '주소 이름을 저장했습니다',
        message: '프로그램을 다시 켜면 새 이름으로 주소가 만들어집니다.',
        detail: '그 이름이 학교망에서 이 PC를 가리키지 않으면, 접속되는 주소로 자동으로 되돌립니다.',
      });
      await renderAddress();
    } catch (err) {
      await showDialog({ kind: 'bad', title: '저장하지 못했습니다', message: err.message });
    } finally {
      e.target.disabled = false;
    }
  });
}

/** 주 15시간 미만 원칙 점검 (업무편람 Ⅳ-2-다 · 타 학교 근무시간 합산) */
function checkWeekly(weekly) {
  const o = Number(document.getElementById('coOther').value) || 0;
  const sum = Math.round((weekly + o) * 10) / 10;
  const box = document.getElementById('weeklyWarn');
  const detail = o ? `(요일별 합계 ${weekly}시간 + 타 학교 ${o}시간)` : '';
  if (sum >= 15) {
    box.innerHTML = `<div class="notice bad"><b>주당 ${sum}시간 — 저장할 수 없습니다</b>
      AI교육 코디네이터는 <b>주 15시간 미만</b>이어야 합니다. ${detail}<br>
      <span style="font-size:15px">근거 : 업무편람 Ⅳ-2-다 — 동일 교육청 내 타 학교 근무시간까지 합산해 판단합니다.</span></div>`;
  } else if (sum >= 14) {
    box.innerHTML = `<div class="notice warn">주당 ${sum}시간입니다. 15시간에 가깝습니다. ${detail}</div>`;
  } else if (sum > 0) {
    box.innerHTML = `<div class="notice ok">주당 ${sum}시간 — 15시간 미만 원칙에 맞습니다. ${detail}</div>`;
  } else {
    box.innerHTML = '<div class="notice warn">근무하는 요일을 하나 이상 정해 주세요.</div>';
  }
  /* 🔴 접혀 있어도 보이게 — 15시간을 넘기면 저장이 거부되므로 반드시 알려야 한다.
     접기 때문에 놓치는 일이 생기면 안 된다. */
  const 모자란요일 = SHORT_BREAK_DAYS['schedTable'] || [];
  if (sum >= 15) foldBadge('fold-sched', `주 ${sum}시간 — 저장 안 됨`, 'bad');
  else if (모자란요일.length) foldBadge('fold-sched', '유휴시간 모자람', 'bad');
  else if (sum >= 14) foldBadge('fold-sched', `주 ${sum}시간`, '');
  else if (!sum) foldBadge('fold-sched', '근무 요일 없음', '');
  else foldBadge('fold-sched', '', '');
}

async function saveSetup() {
  clearSay('#msgSetup');
  // 4시간 이상 근무일에 유휴시간이 없으면 저장하지 않는다(서버도 한 번 더 막는다)
  const shortMsg = breakBlockMessage('schedTable');
  if (shortMsg) return say('#msgSetup', 'bad', shortMsg);
  const body = {
    school: document.getElementById('school').value.trim(),
    schoolYear: document.getElementById('schoolYear').value,
    manager: { name: document.getElementById('mgrName').value.trim(), position: document.getElementById('mgrPos').value.trim() },
    coordinator: {
      name: document.getElementById('coName').value.trim(),
      contractStart: document.getElementById('coStart').value,
      contractEnd: document.getElementById('coEnd').value,
      hourlyWage: document.getElementById('coWage').value,
      otherSchoolHours: document.getElementById('coOther').value,
      schedule: collectSchedule(),
    },
    budget: {
      planned: document.getElementById('budgetPlanned').value,
      note: document.getElementById('budgetNote').value.trim(),
    },
    places: document.getElementById('places').value.split(',').map((x) => x.trim()).filter(Boolean),
    report: {
      background: document.getElementById('repBg').value,
      purpose: document.getElementById('repPurpose').value,
      outputs: document.getElementById('repOutputs').value,
      budgetRows: collectBudgetRows(),
    },
  };
  const pm = document.getElementById('pinMgr').value;
  if (pm && !/^\d{4,12}$/.test(pm)) return say('#msgSetup', 'warn', '비상 코드는 숫자 4~12자리로 입력해 주세요.');
  if (pm) body.newManagerPin = pm;

  const btn = document.getElementById('saveSetup');
  btn.disabled = true;
  try {
    await api('/api/settings', { method: 'POST', body });
    document.getElementById('pinMgr').value = '';
    say('#msgSetup', 'ok', '저장했습니다.');
    await loadSetup();
    await fillSchoolName();
  } catch (e) {
    say('#msgSetup', 'bad', e.message);
  } finally {
    btn.disabled = false;
  }
}
