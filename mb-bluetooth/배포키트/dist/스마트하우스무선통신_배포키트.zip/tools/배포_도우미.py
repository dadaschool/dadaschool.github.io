# -*- coding: utf-8 -*-
r"""
배포_도우미.py - 처음 배포하는 선생님을 위한 대화형 마법사 (스마트하우스 무선통신)

무엇을 해 주나
  1. 필요한 프로그램(git . GitHub CLI)이 있는지 보고, 없으면 설치법을 안내한다
  2. GitHub 로그인을 열어 준다 (브라우저 버튼 한 번)
  3. 올릴 저장소를 만들어 준다 (또는 이미 있으면 그대로 쓴다)
  4. GitHub Pages 를 켜 준다
  5. 파일을 올린다  ->  주소를 알려 준다

사람이 하는 일 (그때그때 화면이 안내한다)
  . (한 번만) 없는 프로그램 설치
  . (한 번만) 브라우저에서 GitHub 로그인 버튼 누르기
  . "올릴까요?" 에 y 라고 답하기

실행
  . 배포_시작하기.bat 을 더블클릭   (가장 쉬움)
  . 또는  python tools\배포_도우미.py

** 이 파일의 print 에 CP949 밖 글자(- 화살표 . 세모 등)를 쓰지 말 것. **
   한국어 Windows 콘솔은 CP949 라 그런 글자를 만나면 서버가 그 자리에서 죽는다.
"""

import os
import subprocess
import sys
import shutil
import webbrowser

APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # 앱 폴더 (tools 의 부모)

# 사이트에 올릴 것 / 올리지 않을 것 --------------------------------------------
#   올리지 않는 것 : 설치용 문서 . 로컬 도구 . 서버 . 배치파일 . 이 마법사
#   (recipient 의 공개 사이트에 tools/lock-maker.html 같은 것이 노출되지 않게)
SKIP_DIRS = {"tools", "worker", "배포키트", "node_modules", ".git"}
SKIP_FILES = {"server.py", "로컬서버_실행.bat", "배포_시작하기.bat",
              "시작하기.md", ".gitignore", "CLAUDE.md"}


# ----------------------------------------------------------------- 화면 도우미
def line():
    print("=" * 62)

def title(t):
    print("")
    line()
    print("  " + t)
    line()

def box(head, items):
    print("")
    print("  +" + "-" * 56)
    print("  |  " + head)
    print("  |  " + "-" * (len(head) + 1))
    for it in items:
        print("  |  " + it)
    print("  +" + "-" * 56)
    print("")

def ask(prompt, default=""):
    d = (" [" + default + "]") if default else ""
    try:
        v = input("  ? " + prompt + d + " : ").strip()
    except EOFError:
        v = ""
    return v or default

def yn(prompt, default=True):
    d = "Y/n" if default else "y/N"
    try:
        v = input("  ? " + prompt + " (" + d + ") : ").strip().lower()
    except EOFError:
        v = ""
    if not v:
        return default
    return v in ("y", "yes", "예", "네", "ㅇ")

def wait(msg="끝나면 이 창을 눌러 Enter 를 누르세요. "):
    try:
        input("  >> " + msg)
    except EOFError:
        pass

def have(cmd):
    return shutil.which(cmd) is not None

def run(args, cwd=None):
    return subprocess.run(args, cwd=cwd, capture_output=True, text=True,
                          encoding="utf-8", errors="replace")

def run_show(args, cwd=None):
    return subprocess.call(args, cwd=cwd)

def stop(msg):
    print("")
    print("  [멈춤] " + msg)
    print("")
    wait("Enter 를 누르면 창이 닫힙니다. ")
    sys.exit(1)


# ----------------------------------------------------------------- 1. 프로그램 확인
def 프로그램확인():
    title("1단계 / 필요한 프로그램 확인")
    print("  이 마법사를 돌리는 Python 은 이미 있습니다.")
    print("")

    winget = have("winget")

    # git : 필수
    while not have("git"):
        box("Git 이 없습니다 (파일을 올리는 데 꼭 필요)",
            ["설치법 1 : 아래 명령을 새 명령창에 붙여넣기",
             "           winget install --id Git.Git -e" if winget else
             "           (winget 이 없어 자동 설치는 못 합니다)",
             "설치법 2 : https://git-scm.com/download/win 에서 내려받아 설치",
             "",
             "설치한 뒤 이 창을 닫고 배포_시작하기.bat 을 다시 더블클릭하세요."])
        webbrowser.open("https://git-scm.com/download/win")
        wait("설치를 끝냈으면 Enter. (그래도 안 되면 컴퓨터를 다시 켜세요) ")

    print("  [있음] git")

    # gh : 강력 권장 (없으면 손으로 해야 하는 부분이 많아짐)
    if not have("gh"):
        box("GitHub CLI(gh) 가 없습니다",
            ["이게 있으면 로그인 . 저장소 만들기 . Pages 켜기를 마법사가 대신 합니다.",
             "없으면 그 세 가지를 손으로 하셔야 합니다 (안내는 해 드립니다).",
             "",
             "설치 : winget install --id GitHub.cli -e" if winget else
             "설치 : https://cli.github.com/ 에서 내려받기",
             "       또는 https://cli.github.com/"])
        webbrowser.open("https://cli.github.com/")
        if yn("지금 설치하고 오시겠어요? (아니오 = gh 없이 계속)", True):
            wait("설치를 끝냈으면 Enter. ")
    if have("gh"):
        print("  [있음] gh (GitHub CLI)")
        return True
    print("  [없음] gh - 손으로 하는 안내로 진행합니다")
    return False


# ----------------------------------------------------------------- 2. GitHub 로그인
def 로그인(has_gh):
    title("2단계 / GitHub 로그인")
    if not has_gh:
        box("gh 가 없어 로그인을 확인할 수 없습니다",
            ["github.com 에 로그인되어 있는지 브라우저에서 확인만 해 두세요.",
             "저장소를 만들 때 로그인 창이 뜨면 그때 로그인하시면 됩니다."])
        webbrowser.open("https://github.com/login")
        wait("확인했으면 Enter. ")
        return None

    r = run(["gh", "auth", "status"])
    if r.returncode == 0:
        # 사용자 이름 뽑기
        who = run(["gh", "api", "user", "-q", ".login"])
        user = who.stdout.strip()
        print("  [로그인됨] " + (user or "(이름 확인 실패)"))
        return user or None

    box("아직 GitHub 에 로그인되어 있지 않습니다",
        ["잠시 뒤 브라우저가 열리고 8자리 코드가 나옵니다.",
         "그 코드를 브라우저에 넣고 Authorize 를 누르면 됩니다.",
         "명령창의 안내를 그대로 따라가세요."])
    wait("준비됐으면 Enter (로그인 창이 시작됩니다) ")
    run_show(["gh", "auth", "login", "-h", "github.com", "-p", "https",
              "-w", "-s", "repo"])
    r2 = run(["gh", "auth", "status"])
    if r2.returncode != 0:
        stop("로그인이 확인되지 않습니다. 배포_시작하기.bat 을 다시 실행해 주세요.")
    who = run(["gh", "api", "user", "-q", ".login"])
    user = who.stdout.strip()
    print("  [로그인됨] " + (user or ""))
    return user or None


# ----------------------------------------------------------------- 3. 저장소
def 저장소만들기(has_gh, user):
    title("3단계 / 올릴 저장소 정하기")
    name = ask("저장소 이름", "mb-bluetooth")
    if not name:
        stop("저장소 이름이 필요합니다.")

    if not has_gh:
        box("gh 가 없으니 저장소는 손으로 만드세요",
            ["1) https://github.com/new 를 엽니다",
             "2) Repository name 에  " + name + "  을 넣고",
             "3) Public 을 고른 뒤 Create repository",
             "4) 만든 저장소 주소(https://github.com/<계정>/" + name + ".git)를 복사"])
        webbrowser.open("https://github.com/new")
        url = ask("만든 저장소의 주소(.git 로 끝나는 것)를 붙여넣으세요")
        if not url:
            stop("저장소 주소가 필요합니다.")
        return name, url, None

    full = (user + "/" + name) if user else name
    exists = run(["gh", "repo", "view", full]).returncode == 0
    if exists:
        print("  이미 있는 저장소를 씁니다 : " + full)
    else:
        if not yn("저장소 '" + full + "' 를 새로 만들까요?", True):
            stop("저장소가 있어야 올릴 수 있습니다.")
        r = run(["gh", "repo", "create", name, "--public",
                 "--description", "스마트하우스, 선 없이 잇기 (micro:bit 무선통신)"])
        if r.returncode != 0:
            stop("저장소를 만들지 못했습니다:\n" + r.stderr)
        print("  만들었습니다 : " + full)

    url = "https://github.com/" + full + ".git"
    return name, url, user


# ----------------------------------------------------------------- 4. 올리기
def 파일목록():
    """이 앱 폴더에서 사이트에 올릴 파일들 (앱 폴더 기준 상대경로)"""
    out = []
    for dirpath, dirnames, filenames in os.walk(APP):
        rel_dir = os.path.relpath(dirpath, APP)
        parts = [] if rel_dir == "." else rel_dir.replace("\\", "/").split("/")
        if parts and parts[0] in SKIP_DIRS:
            dirnames[:] = []
            continue
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for fn in filenames:
            if rel_dir == "." and fn in SKIP_FILES:
                continue
            rel = fn if rel_dir == "." else (rel_dir.replace("\\", "/") + "/" + fn)
            out.append(rel)
    return sorted(out)


def 올리기(name, url, has_gh):
    title("4단계 / 파일 올리기")

    files = 파일목록()
    dirs = sorted({f.split("/")[0] for f in files if "/" in f})
    box("올라갈 것",
        ["파일 " + str(len(files)) + "개  (" + ", ".join(f for f in files if "/" not in f)[:48] + " ...)",
         "폴더 : " + ", ".join(dirs),
         "",
         "올리지 않는 것 : tools/ . worker/ . 배포키트/ . server.py . *.bat . 시작하기.md",
         "(선생님 컴퓨터에는 그대로 남습니다 - 설치할 때 씁니다)"])

    if not yn("이대로 올릴까요?", True):
        stop("취소했습니다. 다시 실행하면 여기서부터 다시 합니다.")

    git = ["git", "-C", APP]

    # git 준비 (이미 저장소면 그대로)
    if not os.path.isdir(os.path.join(APP, ".git")):
        run(git + ["init"])
        run(git + ["branch", "-M", "main"])
    # 사용자 정보 (없으면 임시로)
    if run(git + ["config", "user.email"]).returncode != 0:
        run(git + ["config", "user.email", "teacher@example.com"])
        run(git + ["config", "user.name", "teacher"])

    # .gitignore 확인 (없으면 만든다 - SKIP 목록과 같게)
    gi = os.path.join(APP, ".gitignore")
    if not os.path.exists(gi):
        with open(gi, "w", encoding="utf-8", newline="\n") as f:
            f.write("\n".join(sorted(SKIP_DIRS - {".git"})) + "/\n" +
                    "\n".join(sorted(SKIP_FILES - {".gitignore"})) + "\n")

    # remote
    if run(git + ["remote", "get-url", "origin"]).returncode == 0:
        run(git + ["remote", "set-url", "origin", url])
    else:
        run(git + ["remote", "add", "origin", url])

    run(git + ["add", "-A"])
    c = run(git + ["commit", "-m", "스마트하우스 무선통신 앱 배포"])
    if c.returncode != 0 and "nothing to commit" not in (c.stdout + c.stderr):
        # 첫 커밋이 아니면 변경이 없을 수 있다 - 그건 정상
        pass

    print("  올리는 중...")
    p = run_show(git + ["push", "-u", "origin", "main"])
    if p != 0:
        # 원격에 이미 다른 커밋이 있으면 강제로 맞춘다 (내 저장소이므로)
        if yn("원격에 다른 내용이 있는 것 같습니다. 이 폴더 내용으로 덮어쓸까요?", True):
            run_show(git + ["push", "-u", "origin", "main", "--force"])
        else:
            stop("올리지 못했습니다. 원격 저장소를 비우고 다시 시도하세요.")

    print("  올렸습니다.")


# ----------------------------------------------------------------- 5. Pages 켜기
def pages켜기(has_gh, user, name):
    title("5단계 / GitHub Pages 켜기")
    full = (user + "/" + name) if user else name

    if not has_gh:
        box("gh 가 없으니 Pages 는 손으로 켜세요",
            ["1) https://github.com/" + full + "/settings/pages 를 엽니다",
             "2) Source : Deploy from a branch",
             "3) Branch : main  /  폴더 : / (root)  ->  Save",
             "4) 1~3분 뒤 위쪽에 주소가 나옵니다"])
        if user:
            webbrowser.open("https://github.com/" + full + "/settings/pages")
        wait("켰으면 Enter. ")
    else:
        r = run(["gh", "api", "-X", "POST",
                 "repos/" + full + "/pages",
                 "-f", "source[branch]=main", "-f", "source[path]=/"])
        msg = (r.stdout + r.stderr)
        if r.returncode == 0 or "already exists" in msg or "409" in msg:
            print("  Pages 켜짐 (또는 이미 켜져 있음).")
        else:
            box("자동으로 못 켰습니다 - 손으로 켜세요",
                ["https://github.com/" + full + "/settings/pages",
                 "Source: Deploy from a branch / main / (root) / Save"])
            webbrowser.open("https://github.com/" + full + "/settings/pages")
            wait("켰으면 Enter. ")

    site = ("https://" + user + ".github.io/" + name + "/") if user else \
           ("https://<내계정>.github.io/" + name + "/")
    box("끝났습니다!",
        ["학생 주소  : " + site,
         "교사 주소  : " + site + "teacher.html",
         "",
         "* 처음엔 1~3분 걸립니다. 안 열리면 Ctrl+F5 로 새로고침.",
         "* 다음부터는 파일을 고친 뒤 배포_시작하기.bat 을 다시 눌러",
         "  4단계(올리기)만 하면 됩니다.",
         "",
         "노션 연결은 아직이면 worker/설치안내.md 를 보세요.",
         "(연결 안 해도 앱은 돌아갑니다 - 복사.CSV.인쇄로 옮기면 됩니다)"])


# ----------------------------------------------------------------- main
def main():
    title("스마트하우스, 선 없이 잇기 : 배포 마법사")
    print("  이 폴더의 앱을 선생님의 GitHub 에 올려 인터넷 주소를 만듭니다.")
    print("  중간에 창을 닫아도, 다시 실행하면 됐던 곳은 건너뜁니다.")
    print("")
    if not yn("시작할까요?", True):
        return

    has_gh = 프로그램확인()
    user = 로그인(has_gh)
    name, url, user = 저장소만들기(has_gh, user)
    올리기(name, url, has_gh)
    pages켜기(has_gh, user, name)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n  중단했습니다.")
    except SystemExit:
        raise
    except Exception as e:
        print("\n  [오류] " + repr(e))
    try:
        input("\n  Enter 를 누르면 창이 닫힙니다. ")
    except EOFError:
        pass
