"""
로컬 서버 — 파이썬 기본 모듈만 쓴다 (설치할 것 없음)

    python server.py

브라우저가 열리고 http://localhost:8300/ 로 접속된다.
다른 앱과 겹치지 않게 8300 번을 쓴다
(binary-converter 8000 · ai-class 8100 · EnergyKeeper 8200).

더블클릭(file://)으로도 열리지만, 실제 수업 환경(http)과 같게 확인하고 싶을 때 쓴다.
"""
import http.server
import os
import socketserver
import webbrowser

PORT = 8300
HERE = os.path.dirname(os.path.abspath(__file__))


class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=HERE, **kwargs)

    def end_headers(self):
        # 코드를 고치고 새로고침했는데 옛 파일이 나오는 일을 막는다
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def log_message(self, fmt, *args):
        pass  # 접속 기록을 찍지 않는다 (수업 중 화면이 지저분해진다)


if __name__ == "__main__":
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("", PORT), Handler) as httpd:
        url = "http://localhost:%d/" % PORT
        print()
        print("  스마트하우스 무선통신 시뮬레이터")
        print("  " + url)
        print()
        print("  끝내려면 이 창에서 Ctrl+C 를 누르세요.")
        print()
        try:
            webbrowser.open(url)
        except Exception:
            pass
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n  서버를 끝냈습니다.")
