/* =========================================================
   notion-proxy.js — Cloudflare Worker (노션 중계 서버)

   왜 필요한가
     ① 노션 API 는 브라우저에서 직접 못 부른다(CORS 차단).
     ② 토큰을 학생이 받는 파일에 넣으면 누구나 꺼내 볼 수 있다.
   → 토큰은 이 Worker 의 비밀 변수에만 두고, 학생 브라우저는 이 주소만 안다.

   이 Worker 가 할 수 있는 일은 **행 추가 하나뿐**이다.
   토큰 자체도 「콘텐츠 삽입」 권한만 갖고 있어 읽기·수정·삭제가 불가능하다.

   설치 방법은 worker/설치안내.md 를 볼 것.
   ========================================================= */

/* 노션 API 버전 — 두 가지를 나눠 쓴다. 버전 헤더는 요청마다 달라도 된다.

   · 행 만들기(/v1/pages) = 2022-06-28
     ⚠ 2025-09-03 이후 버전은 parent 를 database_id 가 아니라 data_source_id 로 받는다.
       올리면 깨지므로 고정한다. (데이터소스가 하나인 표에서는 옛 버전이 계속 동작한다)

   · 파일 올리기(/v1/file_uploads) = 최신
     파일 업로드는 나중에 생긴 기능이라 옛 버전이 모를 수 있다.
     노션이 버전 오류를 내면 Worker 변수 NOTION_FILE_VERSION 으로 바꾸면 된다. */
const PAGE_VERSION = "2022-06-28";
const FILE_VERSION = "2026-03-11";

/* 한 번에 받을 수 있는 줄 수 (학생 한 모둠이 보낼 만한 양) */
const MAX_ROWS = 20;

/* 노션이 정한 글자 수 한계 */
const MAX_TEXT = 2000;

/* 사진 한 장의 최대 크기.
   무료 워크스페이스는 파일당 5 MiB 이다. 학생 화면에서 미리 줄여 보내지만,
   혹시 큰 것이 오면 여기서 막아 노션이 거절하기 전에 알려 준다. */
const MAX_PHOTO = 5 * 1024 * 1024;

/* 한 번에 받을 전체 크기 (사진 여러 장이 한꺼번에 오는 것을 막는다) */
const MAX_BODY = 30 * 1024 * 1024;

export default {
  async fetch(request, env) {
    const origin = request.headers.get("Origin") || "";
    const cors = corsHeaders(origin, env);

    /* 브라우저가 본 요청 전에 보내는 확인 요청 */
    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: cors });
    }
    if (request.method !== "POST") {
      return json({ ok: false, error: "POST 로만 보낼 수 있습니다." }, 405, cors);
    }
    if (!allowed(origin, env)) {
      return json({ ok: false, error: "허용되지 않은 주소에서 온 요청입니다." }, 403, cors);
    }

    /* 설정 확인 — 빠뜨린 것이 있으면 바로 알려 준다 */
    if (!env.NOTION_TOKEN) return json({ ok: false, error: "NOTION_TOKEN 이 설정되지 않았습니다." }, 500, cors);
    if (!env.NOTION_DB_ID) return json({ ok: false, error: "NOTION_DB_ID 가 설정되지 않았습니다." }, 500, cors);

    /* (선택) 제출 키를 정해 두었으면 맞는지 본다 */
    if (env.SUBMIT_KEY) {
      const key = request.headers.get("X-Submit-Key") || "";
      if (key !== env.SUBMIT_KEY) {
        return json({ ok: false, error: "제출 키가 맞지 않습니다." }, 403, cors);
      }
    }

    const len = parseInt(request.headers.get("Content-Length") || "0", 10);
    if (len > MAX_BODY) {
      return json({ ok: false, error: "보낸 내용이 너무 큽니다. 사진 수를 줄여 주세요." }, 413, cors);
    }

    let body;
    try {
      body = await request.json();
    } catch (e) {
      return json({ ok: false, error: "보낸 내용을 읽지 못했습니다." }, 400, cors);
    }

    /* ---- 학습지 PDF 제출 (센서 조사와 다른 표를 쓴다) ---- */
    if (body.action === "check" || body.action === "submit") {
      return await worksheet(body, env, cors);
    }

    const rows = Array.isArray(body && body.rows) ? body.rows : null;
    if (!rows || !rows.length) {
      return json({ ok: false, error: "보낼 줄이 없습니다." }, 400, cors);
    }
    if (rows.length > MAX_ROWS) {
      return json({ ok: false, error: `한 번에 ${MAX_ROWS}줄까지만 보낼 수 있습니다.` }, 400, cors);
    }

    /* 한 줄씩 차례로 넣는다.
       노션은 초당 평균 3회까지만 받으므로 한꺼번에 던지지 않는다. */
    const results = [];
    for (let i = 0; i < rows.length; i++) {
      const r = await createRow(rows[i], env);
      results.push(r);
      if (i < rows.length - 1) await sleep(350);
    }

    const created = results.filter((r) => r.ok).length;
    const failed = results
      .map((r, i) => (r.ok ? null : { 줄: i + 1, 이유: r.error }))
      .filter(Boolean);
    /* 글은 들어갔지만 사진만 못 넣은 줄 */
    const photoFailed = results
      .map((r, i) => (r.ok && r.photoError ? { 줄: i + 1, 이유: r.photoError } : null))
      .filter(Boolean);

    return json({ ok: failed.length === 0, created, failed, photoFailed }, 200, cors);
  }
};

/* =========================================================
   학습지 PDF 제출  (표가 다르다 : NOTION_WORKSHEET_DB_ID)

   두 가지 일을 한다.
     action:"check"   이름+학년이 같은 글이 이미 있는지만 본다 → { found: true/false }
     action:"submit"  PDF 를 올려 행을 만들거나(없으면) 고친다(있고 overwrite 일 때)

   ⚠ 개인정보 때문에 **찾은 내용을 절대 돌려주지 않는다.**
      있다/없다만 알려 준다. 페이지 id 도 밖으로 내보내지 않고 Worker 안에서만 쓴다.
      그러지 않으면 이 주소를 아는 사람이 학생 명단을 캐낼 수 있다.
   ========================================================= */
const WS_MAP = { 이름: "이름", 파일: "파일과 미디어", 학교: "학교", 학년: "학년" };

function wsMap(env) {
  if (!env.WS_PROP_MAP) return WS_MAP;
  try { return Object.assign({}, WS_MAP, JSON.parse(env.WS_PROP_MAP)); } catch (_) { return WS_MAP; }
}

async function worksheet(body, env, cors) {
  const db = env.NOTION_WORKSHEET_DB_ID;
  if (!db) return json({ ok: false, error: "NOTION_WORKSHEET_DB_ID 가 설정되지 않았습니다." }, 500, cors);

  const map = wsMap(env);
  const name = cut(body.이름, 100).trim();
  const grade = parseInt(body.학년, 10);
  if (!name) return json({ ok: false, error: "이름이 없습니다." }, 400, cors);
  if (!isFinite(grade)) return json({ ok: false, error: "학년이 없습니다." }, 400, cors);

  /* 같은 이름·학년이 이미 있는지 */
  let existing;
  try {
    existing = await findWorksheet(db, map, name, grade, env);
  } catch (e) {
    return json({ ok: false, error: e.message }, 200, cors);
  }

  if (body.action === "check") {
    return json({ ok: true, found: !!existing }, 200, cors);
  }

  /* 있는데 덮어쓰라고 하지 않았으면 아무것도 하지 않는다 */
  if (existing && !body.overwrite) {
    return json({ ok: false, duplicate: true }, 200, cors);
  }

  if (!body.pdf || !body.pdf.b64) {
    return json({ ok: false, error: "PDF 가 없습니다." }, 400, cors);
  }

  let uploadId;
  try {
    uploadId = await uploadPhoto(
      { name: body.pdf.name || "학습지.pdf", type: "application/pdf", b64: body.pdf.b64 },
      env
    );
  } catch (e) {
    return json({ ok: false, error: "PDF 를 올리지 못했습니다 — " + e.message }, 200, cors);
  }

  const props = {};
  props[map.이름] = { title: [{ text: { content: name } }] };
  props[map.학년] = { number: grade };
  props[map.학교] = { rich_text: textOf(body.학교) };
  props[map.파일] = {
    files: [{ type: "file_upload", file_upload: { id: uploadId }, name: cut(body.pdf.name, 200) || "학습지.pdf" }]
  };

  const auth = "Bearer " + env.NOTION_TOKEN;
  const ver = env.NOTION_VERSION || PAGE_VERSION;
  const url = existing
    ? "https://api.notion.com/v1/pages/" + existing
    : "https://api.notion.com/v1/pages";
  const payload = existing
    ? { properties: props }
    : { parent: { database_id: db }, properties: props };

  let res;
  try {
    res = await fetch(url, {
      method: existing ? "PATCH" : "POST",
      headers: { "Authorization": auth, "Notion-Version": ver, "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
  } catch (e) {
    return json({ ok: false, error: "노션에 연결하지 못했습니다." }, 200, cors);
  }
  if (!res.ok) return json({ ok: false, error: await errorText(res) }, 200, cors);

  return json({ ok: true, updated: !!existing }, 200, cors);
}

/* 같은 이름·학년인 행의 page id 를 찾는다. 없으면 null. */
async function findWorksheet(db, map, name, grade, env) {
  const filter = {
    and: [
      { property: map.이름, title: { equals: name } },
      { property: map.학년, number: { equals: grade } }
    ]
  };
  let res;
  try {
    res = await fetch("https://api.notion.com/v1/databases/" + db + "/query", {
      method: "POST",
      headers: {
        "Authorization": "Bearer " + env.NOTION_TOKEN,
        "Notion-Version": env.NOTION_VERSION || PAGE_VERSION,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ filter: filter, page_size: 1 })
    });
  } catch (e) {
    throw new Error("노션에 연결하지 못했습니다.");
  }
  if (!res.ok) throw new Error("이미 낸 것이 있는지 확인하지 못했습니다 — " + (await errorText(res)));
  const j = await res.json();
  return (j.results && j.results.length) ? j.results[0].id : null;
}

/* ---------------------------------------------------------
   행 하나 만들기

   사진이 있으면 먼저 올려서 그 id 를 붙인다.
   사진 때문에 실패하면 **사진만 빼고 다시** 넣는다 —
   글까지 통째로 날아가는 것이 학생에게 가장 나쁘기 때문이다.
   --------------------------------------------------------- */
async function createRow(row, env) {
  let uploadId = null;
  let photoError = null;

  if (row.사진 && row.사진.b64) {
    try {
      uploadId = await uploadPhoto(row.사진, env);
    } catch (e) {
      photoError = e.message;
    }
  }

  let res = await postPage(row, env, uploadId);

  /* 사진을 붙인 것이 문제였다면 사진 없이 한 번 더 */
  if (!res.ok && uploadId) {
    const retry = await postPage(row, env, null);
    if (retry.ok) {
      return { ok: true, photoError: "사진을 붙이지 못해 글만 넣었습니다 (" + res.error + ")" };
    }
    return res;
  }

  if (res.ok && photoError) res.photoError = photoError;
  return res;
}

/* /v1/pages 로 행을 만든다 (429 면 잠깐 쉬었다 다시 시도) */
async function postPage(row, env, uploadId) {
  const payload = {
    parent: { database_id: env.NOTION_DB_ID },
    properties: buildProperties(row, env, uploadId)
  };

  for (let attempt = 0; attempt < 4; attempt++) {
    let res;
    try {
      res = await fetch("https://api.notion.com/v1/pages", {
        method: "POST",
        headers: {
          "Authorization": "Bearer " + env.NOTION_TOKEN,
          "Notion-Version": env.NOTION_VERSION || PAGE_VERSION,
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });
    } catch (e) {
      return { ok: false, error: "노션에 연결하지 못했습니다." };
    }

    if (res.ok) return { ok: true };

    /* 너무 빨리 보냈다 → Retry-After 만큼 쉬었다 다시 */
    if (res.status === 429) {
      const wait = parseFloat(res.headers.get("Retry-After") || "1");
      await sleep(Math.min(8000, (isFinite(wait) ? wait : 1) * 1000));
      continue;
    }

    return { ok: false, error: await errorText(res) };
  }
  return { ok: false, error: "노션이 계속 바쁩니다. 잠시 뒤 다시 보내 주세요." };
}

/* ---------------------------------------------------------
   사진 올리기 — 노션은 두 단계다
     ① POST /v1/file_uploads          자리를 만든다 → id 와 upload_url 을 받는다
     ② POST …/send (multipart)        실제 바이트를 보낸다
   그 뒤 행을 만들 때 files 속성에 { type:"file_upload", file_upload:{id} } 로 붙인다.
   --------------------------------------------------------- */
async function uploadPhoto(photo, env) {
  const ver = env.NOTION_FILE_VERSION || FILE_VERSION;
  const auth = "Bearer " + env.NOTION_TOKEN;

  const bytes = b64ToBytes(photo.b64);
  if (bytes.length > MAX_PHOTO) {
    throw new Error("파일이 5MB 를 넘습니다");
  }

  const name = cut(photo.name || "사진.jpg", 200) || "사진.jpg";
  const type = photo.type || "image/jpeg";

  let cr;
  try {
    cr = await fetch("https://api.notion.com/v1/file_uploads", {
      method: "POST",
      headers: { "Authorization": auth, "Notion-Version": ver, "Content-Type": "application/json" },
      body: JSON.stringify({ filename: name, content_type: type })
    });
  } catch (e) {
    throw new Error("노션에 연결하지 못했습니다");
  }
  if (!cr.ok) throw new Error("업로드 자리를 못 만들었습니다 — " + (await errorText(cr)));

  const info = await cr.json();
  const sendUrl = info.upload_url || ("https://api.notion.com/v1/file_uploads/" + info.id + "/send");

  const form = new FormData();
  form.append("file", new Blob([bytes], { type: type }), name);

  let sr;
  try {
    /* Content-Type 은 FormData 가 경계값과 함께 알아서 넣는다. 직접 넣으면 깨진다. */
    sr = await fetch(sendUrl, {
      method: "POST",
      headers: { "Authorization": auth, "Notion-Version": ver },
      body: form
    });
  } catch (e) {
    throw new Error("사진을 보내지 못했습니다");
  }
  if (!sr.ok) throw new Error("사진 업로드 실패 — " + (await errorText(sr)));

  return info.id;
}

/* 노션이 준 설명을 그대로 꺼낸다 */
async function errorText(res) {
  try {
    const e = await res.json();
    if (e && e.message) return e.message;
  } catch (_) { /* JSON 이 아니면 그냥 둔다 */ }
  return "노션이 거절했습니다 (" + res.status + ")";
}

function b64ToBytes(b64) {
  const bin = atob(String(b64).replace(/^data:[^,]*,/, ""));
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

/* ---------------------------------------------------------
   표의 칸 이름 맞추기

   노션 데이터베이스의 칸 이름이 다르면 여기만 고치면 된다.
   Worker 의 변수 PROP_MAP 에 JSON 으로 넣어 덮어쓸 수도 있다. 예)
     {"모둠":"조","센서명":"이름"}
   --------------------------------------------------------- */
const DEFAULT_MAP = {
  모둠: "모둠",
  센서명: "센서명",
  모양: "모양",
  설명: "설명",
  활용분야: "활용분야",
  예시: "예시"
};

function buildProperties(row, env, uploadId) {
  let map = DEFAULT_MAP;
  if (env.PROP_MAP) {
    try { map = Object.assign({}, DEFAULT_MAP, JSON.parse(env.PROP_MAP)); } catch (_) { /* 잘못 적었으면 기본값 */ }
  }

  const props = {};
  /* 제목 칸(센서명)은 반드시 있어야 한다 */
  props[map.센서명] = { title: [{ text: { content: cut(row.센서명) || "(이름 없음)" } }] };

  /* 모둠 칸 —
     노션 표의 「모둠」 열이 «텍스트» 이면 rich_text, «숫자» 이면 number 를 받는다.
     열을 잘못 만들면 "모둠 is expected to be rich_text." 같은 오류로 그 줄이 통째로 실패한다.
     대부분의 학교 표는 텍스트라 **기본을 rich_text 로** 둔다.
     숫자 열로 만들었으면 Worker 변수 MODU_NUMBER=1 을 넣으면 number 로 보낸다. */
  const teamRaw = String(row.모둠 == null ? "" : row.모둠).trim();
  if (env.MODU_NUMBER === "1" || env.MODU_NUMBER === "true") {
    const n = parseInt(teamRaw, 10);
    props[map.모둠] = { number: isFinite(n) ? n : null };
  } else {
    props[map.모둠] = { rich_text: textOf(teamRaw) };
  }

  props[map.설명] = { rich_text: textOf(row.설명) };
  props[map.활용분야] = { rich_text: textOf(row.활용분야) };

  /* URL 칸은 빈 문자열을 받지 않는다. 없으면 null 로 보낸다 */
  const url = (row.예시 || "").trim();
  props[map.예시] = { url: /^https?:\/\//i.test(url) ? cut(url) : null };

  /* 모양(파일) 칸 — 올린 사진이 있으면 그것을, 없으면 이미지 주소를 붙인다 */
  const files = [];
  if (uploadId) {
    files.push({
      type: "file_upload",
      file_upload: { id: uploadId },
      name: cut(row.사진 && row.사진.name, 200) || "사진.jpg"
    });
  } else {
    const img = (row.사진주소 || "").trim();
    if (/^https?:\/\//i.test(img)) {
      files.push({ type: "external", external: { url: cut(img) }, name: "이미지" });
    }
  }
  props[map.모양] = { files: files };

  return props;
}

function textOf(v) {
  const s = cut(v);
  return s ? [{ text: { content: s } }] : [];
}

function cut(v, max) {
  return String(v == null ? "" : v).slice(0, max || MAX_TEXT);
}

/* ---------------------------------------------------------
   접속 허용 주소

   ALLOWED_ORIGINS 에 쉼표로 나열한다. 예)
     https://dadaschool.github.io,http://localhost:8300
   비워 두면 아무 데서나 부를 수 있다(수업 준비 중에만 그렇게 두고,
   배포한 뒤에는 반드시 채울 것).
   --------------------------------------------------------- */
function originList(env) {
  return (env.ALLOWED_ORIGINS || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
}

function allowed(origin, env) {
  const list = originList(env);
  if (!list.length) return true;
  /* 파일을 더블클릭해 연 경우 브라우저가 Origin 을 "null" 로 보낸다 */
  if (origin === "null" && list.includes("null")) return true;
  return list.includes(origin);
}

function corsHeaders(origin, env) {
  const list = originList(env);
  const ok = !list.length || list.includes(origin) || (origin === "null" && list.includes("null"));
  return {
    "Access-Control-Allow-Origin": ok && origin ? origin : (list.length ? list[0] : "*"),
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, X-Submit-Key",
    "Access-Control-Max-Age": "86400",
    "Vary": "Origin"
  };
}

function json(obj, status, headers) {
  return new Response(JSON.stringify(obj), {
    status: status,
    headers: Object.assign({ "Content-Type": "application/json; charset=utf-8" }, headers)
  });
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
