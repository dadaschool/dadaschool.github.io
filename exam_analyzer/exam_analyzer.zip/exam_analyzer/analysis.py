"""통계 계산. 모든 수치는 파이썬이 계산하며 큐웬은 계산에 쓰지 않는다."""
import re

import numpy as np
import pandas as pd

# 점검 기준(이 프로그램의 기본값이며 공식 기준이 아님. 필요하면 조정)
EASY_RATE = 85.0     # 득점률(%)이 이 값 이상이면 '쉬움'
HARD_RATE = 40.0     # 득점률(%)이 이 값 미만이면 '어려움'
LOW_DISC = 0.20      # 변별도가 이 값 미만이면 '변별도 낮음'
LOW_CORR = 0.20      # 문항-총점 상관이 이 값 미만이면 '점검'

STD_CODE = re.compile(r"\d{1,2}[가-힣]{1,3}\d{2}-\d{2}")  # 성취기준 코드(pdf_utils와 같은 규칙)

# 생기부 초안용 학생 수준 구분(성취기준별 득점률, 기본값이며 공식 기준이 아님)
STRONG_RATE = 80.0   # 이 값 이상이면 '잘함'
WEAK_RATE = 50.0     # 이 값 미만이면 '보완 필요', 그 사이는 '보통'


def to_wide(records):
    """records(list of dict) -> (wide DataFrame[sid x item_no], cls Series[sid])"""
    df = pd.DataFrame(records)
    if df.empty:
        return pd.DataFrame(), pd.Series(dtype=str)
    wide = df.pivot(index="sid", columns="item_no", values="score").sort_index(axis=1)
    cls = df.drop_duplicates("sid").set_index("sid")["cls"].reindex(wide.index)
    return wide, cls


def drop_absent(wide):
    """모든 문항이 공란인 학생은 결시로 보고 제외"""
    absent = wide.index[wide.isna().all(axis=1)]
    return wide.drop(index=absent), list(absent)


def totals(wide):
    return wide.fillna(0).sum(axis=1)


def item_stats(wide, max_pts):
    """wide: 공란은 NaN. 공란은 0점으로 계산하되 미응답 비율을 따로 표시."""
    w = wide.fillna(0)
    tot = w.sum(axis=1)
    n = len(w)
    n27 = max(1, int(round(n * 0.27)))
    order = tot.sort_values(kind="mergesort").index
    low, up = order[:n27], order[-n27:]
    rows = []
    for k in wide.columns:
        mx = float(max_pts[k])
        s = w[k]
        rate = s.mean() / mx * 100 if mx else np.nan
        disc = (s.loc[up].mean() - s.loc[low].mean()) / mx if mx else np.nan
        rest = tot - s
        corr = s.corr(rest) if s.std() > 0 and rest.std() > 0 else np.nan
        rows.append({
            "문항": int(k), "배점": mx, "평균": round(s.mean(), 2),
            "득점률(%)": round(rate, 1),
            "만점(%)": round((s >= mx).mean() * 100, 1),
            "부분점수(%)": round(((s > 0) & (s < mx)).mean() * 100, 1),
            "0점(%)": round((s <= 0).mean() * 100, 1),
            "미응답(%)": round(wide[k].isna().mean() * 100, 1),
            "변별도": round(disc, 2),
            "문항-총점상관": None if pd.isna(corr) else round(corr, 2),
        })
    out = pd.DataFrame(rows)
    out["점검"] = out.apply(flags, axis=1)
    return out


def flags(r):
    f = []
    if r["득점률(%)"] < HARD_RATE:
        f.append("어려움")
    if r["득점률(%)"] >= EASY_RATE:
        f.append("쉬움")
    if r["변별도"] < LOW_DISC:
        f.append("변별도 낮음")
    c = r["문항-총점상관"]
    if c is not None and not pd.isna(c) and c < LOW_CORR:
        f.append("상관 낮음")
    return ", ".join(f)


def total_summary(wide, max_pts):
    tot = totals(wide)
    full = float(sum(max_pts[k] for k in wide.columns))
    return {"학생 수": int(len(tot)), "만점": full, "평균": round(tot.mean(), 2),
            "표준편차": round(tot.std(ddof=0), 2), "중앙값": float(tot.median()),
            "최저": float(tot.min()), "최고": float(tot.max())}


def distribution(wide, max_pts, bins=10):
    """총점 득점률 구간별 학생 수"""
    full = sum(max_pts[k] for k in wide.columns)
    pct = totals(wide) / full * 100
    edges = list(range(0, 101, bins))
    labels = [f"{a}~{a + bins - 1}" if b < 100 else f"{a}~100" for a, b in zip(edges[:-1], edges[1:])]
    cat = pd.cut(pct, bins=edges, labels=labels, right=False, include_lowest=True)
    cat = cat.fillna(labels[-1])  # 100%는 마지막 구간
    return cat.value_counts().reindex(labels).fillna(0).astype(int).rename("학생 수")


def class_compare(wide, cls, max_pts):
    rates = wide.fillna(0).div(pd.Series(max_pts)[wide.columns], axis=1) * 100
    g = rates.groupby(cls.reindex(rates.index)).mean().round(1)
    g.insert(0, "학생 수", cls.reindex(rates.index).value_counts().reindex(g.index))
    g.columns = ["학생 수"] + [f"문항{c}" for c in wide.columns]
    return g


def standard_summary(wide, max_pts, standards):
    rates = wide.fillna(0).div(pd.Series(max_pts)[wide.columns], axis=1) * 100
    rows = {}
    for k in wide.columns:
        std = (standards.get(k) or "").strip() or "(미입력)"
        rows.setdefault(std, []).append(k)
    out = []
    for std, ks in rows.items():
        out.append({"성취기준": std, "문항": ", ".join(map(str, ks)),
                    "평균 득점률(%)": round(rates[ks].mean(axis=1).mean(), 1)})
    return pd.DataFrame(out).sort_values("평균 득점률(%)")


def student_profile(wide, cls, max_pts, sid):
    rates = wide.fillna(0).div(pd.Series(max_pts)[wide.columns], axis=1) * 100
    me = rates.loc[sid]
    c = cls.get(sid, "")
    peers = rates[cls.reindex(rates.index) == c] if c else rates
    df = pd.DataFrame({"문항": wide.columns, "득점": wide.loc[sid].values,
                       "배점": [max_pts[k] for k in wide.columns],
                       "득점률(%)": me.round(1).values,
                       "학급 평균(%)": peers.mean().round(1).values,
                       "학년 평균(%)": rates.mean().round(1).values})
    df["학급 대비"] = (df["득점률(%)"] - df["학급 평균(%)"]).round(1)
    return df


def level_of(rate):
    return "잘함" if rate >= STRONG_RATE else ("보완 필요" if rate < WEAK_RATE else "보통")


def result_rows(exam_id, exam_name, wide, cls, max_pts, standards, texts):
    """한 시험의 학생 결과 기록 행을 만든다(학생 결과 기록 표에 저장할 것).
    wide는 결시(모든 문항 공란) 학생을 뺀 것. 같은 성취기준의 문항은 묶어 득점 합·배점 합을 낸다.
    묶음 키: 성취기준 코드(예: 9정04-03)가 있으면 코드, 없으면 성취기준 글. 성취기준이 빈 문항은 그 문항 하나."""
    groups = {}
    for k in wide.columns:
        std = (standards.get(k) or "").strip()
        if std:
            m = STD_CODE.search(std)
            key, label = (m.group() if m else std), std
        else:
            key, label = f"시험{exam_id}-문항{k}", f"{exam_name} 문항{k}: {(texts.get(k) or '').strip()[:60]}"
        g = groups.setdefault(key, {"label": label, "items": []})
        g["items"].append(k)
    w = wide.fillna(0)
    rows = []
    for sid in w.index:
        for key, g in groups.items():
            rows.append({"sid": sid, "cls": cls.get(sid, "") or "", "std_key": key, "std_label": g["label"],
                         "got": float(w.loc[sid, g["items"]].sum()),
                         "full": float(sum(max_pts[k] for k in g["items"]))})
    return rows


def combine_results(results):
    """학생 결과 기록(여러 시험)을 학번으로 합쳐 성취기준별 수준을 정한다.
    같은 성취기준이 여러 시험에 있으면 (득점 합)/(배점 합)으로 묶는다(배점이 큰 시험이 더 크게 반영됨).
    반환: (levels {학번: [{"기준", "수준"}]}, table DataFrame[학번, 성취기준, 시험, 득점률(%), 수준])"""
    if not results:
        return {}, pd.DataFrame()
    df = pd.DataFrame(results)
    # 코드만 적은 시험과 설명까지 적은 시험이 섞이면 긴 글을 보여 준다
    label = df.groupby("std_key")["std_label"].agg(lambda x: max(x, key=len))
    g = df.groupby(["sid", "std_key"], sort=False).agg(
        got=("got", "sum"), full=("full", "sum"), exams=("exam", lambda x: ", ".join(dict.fromkeys(x))))
    g = g[g["full"] > 0].reset_index()
    g["rate"] = g["got"] / g["full"] * 100
    g["수준"] = g["rate"].map(level_of)
    g["성취기준"] = g["std_key"].map(label)
    levels = {sid: [{"기준": r["성취기준"], "수준": r["수준"]} for _, r in sub.iterrows()]
              for sid, sub in g.groupby("sid", sort=False)}
    table = g.rename(columns={"sid": "학번", "exams": "시험"})[["학번", "성취기준", "시험", "rate", "수준"]]
    table = table.assign(rate=table["rate"].round(1)).rename(columns={"rate": "득점률(%)"})
    return levels, table
