@echo off
cd /d "%~dp0"
rem --- Running from inside the zip (Windows temp folder) loses saved data. Stop and ask to extract first.
echo "%~dp0" | find /i "\AppData\Local\Temp\" >nul
if not errorlevel 1 (
  echo This file is running from inside the zip file.
  echo Right-click the zip file, choose "Extract All", and run it from the extracted folder.
  pause
  exit /b 1
)
rem --- Find Python: "python" first, then the "py" launcher (works even if "Add python.exe to PATH" was not checked)
set "PY="
python --version >nul 2>&1
if not errorlevel 1 set "PY=python"
if not defined PY (
  py -3 --version >nul 2>&1
  if not errorlevel 1 set "PY=py -3"
)
if not defined PY (
  echo Python was not found. Install Python from python.org first
  echo and check "Add python.exe to PATH" on the first installer screen.
  pause
  exit /b 1
)
echo Starting the exam analyzer. Keep this black window open while you use it.
echo To quit: close this window or press Ctrl+C.
%PY% -m streamlit run app.py --server.address localhost --browser.gatherUsageStats false --server.showEmailPrompt false
pause
