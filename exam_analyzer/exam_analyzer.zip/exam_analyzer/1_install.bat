@echo off
cd /d "%~dp0"
rem --- Running from inside the zip (Windows temp folder) loses saved data. Stop and ask to extract first.
echo "%~dp0" | find /i "\AppData\Local\Temp\" >nul
if not errorlevel 1 (
  echo This file is running from inside the zip file.
  echo Right-click the zip file, choose "Extract All", and run it from the extracted folder.
  pause
  exit /b 1
)
rem --- Find Python: "python" first, then the "py" launcher (works even if "Add python.exe to PATH" was not checked)
set "PY="
python --version >nul 2>&1
if not errorlevel 1 set "PY=python"
if not defined PY (
  py -3 --version >nul 2>&1
  if not errorlevel 1 set "PY=py -3"
)
if not defined PY (
  echo Python was not found. Install Python from python.org first
  echo and check "Add python.exe to PATH" on the first installer screen.
  pause
  exit /b 1
)
echo [1/2] Python version:
%PY% --version
echo [2/2] Installing libraries... (needs internet, about 100 MB, takes a few minutes)
%PY% -m pip install -r requirements.txt
if errorlevel 1 (
  echo Install failed. Check the internet connection and try again.
  pause
  exit /b 1
)
echo.
echo Done. Next time, just double-click 2_run.bat
pause
