Exam analyzer (for a single teacher, runs only on this PC)
1) Install Python (check "Add python.exe to PATH") and LM Studio first.
2) Double-click 1_install.bat  (once)
3) Start the Qwen server in LM Studio (Developer tab -> Start Server)
4) Double-click 2_run.bat  -> the browser opens the app
Sample files: sample folder (fictional data)
Data is stored in data\exam.db  (student ID only; names are never saved)
