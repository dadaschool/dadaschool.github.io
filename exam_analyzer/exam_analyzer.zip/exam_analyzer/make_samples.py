"""연수용 샘플 파일 생성 (가상 데이터). 실행: python make_samples.py"""
import numpy as np, pandas as pd
from pathlib import Path
out = Path(__file__).parent / "sample"
out.mkdir(exist_ok=True)

ITEMS = [
 (1, 4, "[샘플] 알고리즘을 순서도로 표현한다", "문제 상황을 해결하는 알고리즘을 순서도로 나타내고 각 기호의 의미를 설명하시오."),
 (2, 3, "[샘플] 변수의 개념을 이해한다", "변수와 상수의 차이를 예를 들어 서술하시오."),
 (3, 5, "[샘플] 반복 구조를 활용한다", "1부터 10까지의 합을 구하는 프로그램을 반복문으로 작성하고 동작 과정을 설명하시오."),
 (4, 4, "[샘플] 정렬 알고리즘을 이해한다", "선택 정렬로 5, 2, 9, 1 을 오름차순 정렬하는 과정을 단계별로 서술하시오."),
 (5, 4, "[샘플] 개인정보 보호 방법을 안다", "개인정보를 안전하게 보호하기 위한 방법을 두 가지 서술하시오."),
 (6, 3, "[샘플] 인공지능의 학습 방식을 구분한다", "지도학습과 비지도학습의 차이를 서술하시오."),
]

# 1) 시험지 PDF (글자 선택이 되는 PDF)
html = "<html><meta charset='utf-8'><body style='font-family:\"Noto Sans CJK KR\";font-size:13pt;line-height:1.7'>"
html += "<h2>샘플중학교 1학년 정보 서술형 평가 (연수용 가상 문항)</h2><p>※ 실제 시험이 아닙니다.</p>"
for no, pt, _, q in ITEMS:
    html += f"<p><b>서술형 {no}.</b> {q} [{pt}점]</p><br>"
html += "</body></html>"
(out / "_exam.html").write_text(html, encoding="utf-8")
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page()
    pg.goto((out / "_exam.html").resolve().as_uri())
    pg.pdf(path=str(out / "sample_exam.pdf"), format="A4")
    b.close()
(out / "_exam.html").unlink()

# 1-2) 성취기준표 PDF (표 모양, 같은 성취기준이 두 문항에 걸친 병합 칸 포함)
rows = ""
for i, (n, pt, s_, _) in enumerate(ITEMS):
    rows += f"<tr><td>{n}</td><td>{pt}</td><td>{s_}</td></tr>"
(out / "_std.html").write_text(
    "<html><meta charset='utf-8'><body style='font-family:\"Noto Sans CJK KR\";font-size:12pt'>"
    "<h3>서술형 평가 계획 (연수용 가상 자료)</h3><table border=1 cellspacing=0 cellpadding=6 "
    "style='border-collapse:collapse;width:100%'><tr><th>문항 번호</th><th>배점</th><th>성취기준</th></tr>"
    + rows + "</table></body></html>", encoding="utf-8")
with sync_playwright() as p2:
    b2 = p2.chromium.launch(); pg2 = b2.new_page()
    pg2.goto((out / "_std.html").resolve().as_uri())
    pg2.pdf(path=str(out / "sample_standards.pdf"), format="A4"); b2.close()
(out / "_std.html").unlink()

# 2) 성취기준표
pd.DataFrame([(n, pt, s) for n, pt, s, _ in ITEMS], columns=["문항번호", "배점", "성취기준"]).to_excel(
    out / "sample_standards.xlsx", index=False)

# 3) 점수표 (NEIS 형식은 확인하지 못해 '제목 줄이 위에 있는 일반 표'로 가정한 가상 데이터)
rng = np.random.default_rng(2026)
rows = []
for cl in (1, 2, 3):
    for no in range(1, 21):
        ability = rng.normal(0.62 if cl != 3 else 0.55, 0.18)
        sc = []
        for i, (_, pt, _, _) in enumerate(ITEMS):
            diff = [0.0, -0.1, -0.05, -0.25, 0.15, -0.05][i]
            p = np.clip(ability + diff + rng.normal(0, 0.12), 0, 1)
            if i == 4:                       # 5번은 변별이 약한 문항
                p = np.clip(0.8 + rng.normal(0, 0.1), 0, 1)
            sc.append(float(np.clip(round(p * pt * 2) / 2, 0, pt)))
        rows.append([cl, no, 10000 + cl * 100 + no, f"학생{cl}{no:02d}"] + sc)
df = pd.DataFrame(rows, columns=["반", "번호", "학번", "성명"] + [f"서술형{n}" for n, *_ in ITEMS])
df.loc[5, "서술형4"] = np.nan                  # 일부 공란(미응답)
df.loc[17, [f"서술형{n}" for n, *_ in ITEMS]] = np.nan   # 결시 학생
df["합계"] = df[[f"서술형{n}" for n, *_ in ITEMS]].sum(axis=1)
with pd.ExcelWriter(out / "sample_scores.xlsx") as w:
    pre = pd.DataFrame([["샘플중학교 1학년 정보 서술형 문항별 점수표 (가상 데이터)"], [""]])
    pre.to_excel(w, header=False, index=False, startrow=0)
    df.to_excel(w, index=False, startrow=2)
print("samples ok")
