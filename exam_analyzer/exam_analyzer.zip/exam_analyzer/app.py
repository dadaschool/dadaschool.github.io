"""서술형 시험 분석 프로그램 (교사 1인용, 이 컴퓨터에서만 실행)"""
import io
import sqlite3

import pandas as pd
import streamlit as st

import analysis
import db
import llm
import pdf_utils

st.set_page_config(page_title="서술형 시험 분석", layout="wide")
db.init()

NON_ITEM_WORDS = ["학번", "번호", "반", "성명", "이름", "합계", "총점", "평균", "석차", "등급", "학년", "비고"]


# ---------- 공통 함수 ----------
def read_table(uploaded):
    name = uploaded.name.lower()
    data = uploaded.getvalue()
    if name.endswith(".csv"):
        for enc in ("utf-8-sig", "cp949"):
            try:
                return pd.read_csv(io.BytesIO(data), header=None, encoding=enc)
            except UnicodeDecodeError:
                continue
        raise ValueError("CSV 글자 인코딩을 읽지 못했습니다. 엑셀(.xlsx)로 저장해서 올려 주세요.")
    return pd.read_excel(io.BytesIO(data), header=None)


def guess_header_row(raw):
    for i in range(min(len(raw), 15)):
        vals = [str(v) for v in raw.iloc[i].tolist()]
        if any("학번" in v for v in vals):
            return i
    return 0


def to_excel_bytes(sheets):
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as w:
        for name, df in sheets.items():
            df.to_excel(w, sheet_name=name[:30], index=True if df.index.name else False)
    return buf.getvalue()


def drafts_excel_bytes(df):
    """생기부 초안 엑셀: 긴 글이 보이도록 열 너비와 줄 바꿈을 맞춘다."""
    from openpyxl.styles import Alignment
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as w:
        df.to_excel(w, sheet_name="생기부 초안", index=False)
        ws = w.sheets["생기부 초안"]
        widths = {"반": 6, "학번": 10, "생기부 초안": 90, "글자 수": 8, "근거 시험": 30, "작성일": 17}
        for i, col in enumerate(df.columns, start=1):
            ws.column_dimensions[ws.cell(1, i).column_letter].width = widths.get(col, 12)
        for row in ws.iter_rows(min_row=2):
            for cell in row:
                cell.alignment = Alignment(wrap_text=True, vertical="top")
    return buf.getvalue()


def llm_base():
    return db.get_setting("llm_base", "http://localhost:1234/v1")


def llm_models():
    try:
        return llm.list_models(llm_base())
    except Exception:
        return []


def refresh_results(exam_id, exam_name):
    """이 시험의 학생 결과 기록(학번·성취기준별 득점/배점)을 다시 계산해 저장한다."""
    items, recs = db.load_items(exam_id), db.load_scores(exam_id)
    rows = []
    if items and recs:
        max_pts = {i["no"]: i["max_pt"] for i in items}
        wide, cls = analysis.to_wide(recs)
        wide, _ = analysis.drop_absent(wide)
        wide = wide[[k for k in wide.columns if k in max_pts]]
        rows = analysis.result_rows(exam_id, exam_name, wide, cls.reindex(wide.index).fillna(""), max_pts,
                                    {i["no"]: i["standard"] for i in items}, {i["no"]: i["text"] for i in items})
    db.replace_results(exam_id, rows)


def school_year(created):
    """학년도: 3월~다음 해 2월. created 예: '2026-10-27 10:48'"""
    y, m = int(created[:4]), int(created[5:7])
    return y if m >= 3 else y - 1


NO_LLM = "큐웬 서버에 연결되지 않았습니다. LM Studio에서 모델을 로드하고 서버를 켠 뒤 왼쪽 '연결 확인'을 눌러 보세요."


# ---------- 사이드바: 시험 선택 / 설정 ----------
st.sidebar.title("서술형 시험 분석")
exams = db.list_exams()
names = [e["name"] for e in exams]
if "pending_sel" in st.session_state:
    st.session_state["sel_exam"] = st.session_state.pop("pending_sel")
sel = st.sidebar.selectbox("시험 선택", ["(새 시험 만들기)"] + names, key="sel_exam")
if sel == "(새 시험 만들기)":
    new_name = st.sidebar.text_input("새 시험 이름", placeholder="예: 2026-2학기 1학년 정보 수행평가")
    if st.sidebar.button("시험 만들기") and new_name.strip():
        try:
            db.create_exam(new_name.strip())
            st.session_state["pending_sel"] = new_name.strip()
            st.rerun()
        except sqlite3.IntegrityError:
            st.sidebar.error("같은 이름의 시험이 이미 있습니다.")
    st.info("왼쪽에서 새 시험 이름을 입력하고 [시험 만들기]를 누르세요.")
    st.stop()

exam = next(e for e in exams if e["name"] == sel)
eid = exam["id"]

with st.sidebar.expander("큐웬(LM Studio) 연결 설정"):
    base = st.text_input("서버 주소", db.get_setting("llm_base", "http://localhost:1234/v1"))
    if st.button("연결 확인"):
        try:
            ms = llm.list_models(base)
            db.set_setting("llm_base", base)
            if ms:
                st.success("연결됨. 불러온 모델: " + ", ".join(ms))
            else:
                st.warning("서버는 켜져 있으나 불러온 모델이 없습니다. LM Studio에서 모델을 로드하세요.")
        except Exception as e:
            st.error(f"연결 실패: {e}")

with st.sidebar.expander("시험 삭제"):
    if st.checkbox("이 시험의 모든 자료를 삭제합니다"):
        if st.button("삭제 실행"):
            db.delete_exam(eid)
            st.rerun()

st.title(sel)
tab1, tab2, tab3, tab4, tab5 = st.tabs(["① 시험 문항", "② 점수표", "③ 분석 결과", "④ 결과 피드백", "⑤ 생기부 초안"])

# ---------- ① 시험 문항 ----------
with tab1:
    st.write("시험지 PDF에서 문항과 배점(예: '(6점)')을 읽어 오거나, 표에 직접 입력합니다. 성취기준표는 엑셀 또는 PDF로 불러올 수 있습니다.")
    pdf = st.file_uploader("시험지 PDF (선택)", type=["pdf"], key="pdf")
    stdx = st.file_uploader("성취기준표 (선택: 엑셀 또는 PDF. 엑셀은 열 이름 '문항번호','배점','성취기준')",
                            type=["xlsx", "pdf"], key="std")

    items = db.load_items(eid)
    base_df = pd.DataFrame(items, columns=["no", "max_pt", "standard", "text"]) if items else \
        pd.DataFrame({"no": pd.Series(dtype=int), "max_pt": pd.Series(dtype=float),
                      "standard": pd.Series(dtype=str), "text": pd.Series(dtype=str)})
    msgs = st.session_state.setdefault(f"msgs_{eid}", [])

    if pdf is not None and st.button("PDF에서 문항 읽기"):
        msgs.clear()
        try:
            text, pages = pdf_utils.extract_text(pdf.getvalue())
            qs = pdf_utils.split_questions(text)
        except ValueError as e:
            text, pages, qs = None, 0, []
            st.error(str(e))
        if text is None:
            pass  # 손상·암호 PDF: 위에서 안내함
        elif not text.strip():
            st.error("PDF에서 글자를 읽지 못했습니다. 스캔한 이미지 PDF일 수 있습니다. 문항 내용은 표에 직접 입력하세요.")
        elif not qs:
            st.warning(f"{pages}쪽에서 글자는 읽었지만 문항 번호를 찾지 못했습니다. 문항을 표에 직접 입력하세요.")
        else:
            old = {r["no"]: r for r in items}
            rows = []
            for q in qs:
                o = old.get(q["no"], {})
                pt = q["max_pt"] if q["max_pt"] is not None else o.get("max_pt", 0.0)
                rows.append({"no": q["no"], "max_pt": pt,
                             "standard": q["standard"] or o.get("standard", ""), "text": q["text"]})
                if q["note"]:
                    msgs.append(f"문항 {q['no']}: {q['note']}")
            base_df = pd.DataFrame(rows)
            st.session_state[f"items_{eid}"] = base_df
            got = sum(1 for q in qs if q["max_pt"] is not None)
            st.success(f"{len(qs)}개 문항을 읽었고, 그중 {got}개 문항의 배점을 글에서 찾았습니다.")
        warn = pdf_utils.text_warning(text) if text else None
        if warn:
            msgs.insert(0, warn)

    if stdx is not None and st.button("성취기준표 불러오기"):
        std_rows, notes = [], []
        if stdx.name.lower().endswith(".pdf"):
            try:
                std_rows, notes = pdf_utils.parse_standard_pdf(stdx.getvalue())
            except ValueError as e:
                st.error(str(e))
        else:
            sx = pd.read_excel(stdx)
            need = {"문항번호", "배점", "성취기준"}
            if not need.issubset(sx.columns):
                st.error("열 이름이 '문항번호', '배점', '성취기준'이어야 합니다.")
            else:
                for _, r in sx.iterrows():
                    pt = pd.to_numeric(r["배점"], errors="coerce")
                    std_rows.append({"no": int(r["문항번호"]), "max_pt": None if pd.isna(pt) else float(pt),
                                     "standard": "" if pd.isna(r["성취기준"]) else str(r["성취기준"])})
        if std_rows:
            cur = st.session_state.get(f"items_{eid}", base_df).set_index("no")
            for r in std_rows:
                if r["no"] not in cur.index:
                    cur.loc[r["no"]] = [0.0, "", ""]
                if r["max_pt"] is not None:
                    cur.loc[r["no"], "max_pt"] = r["max_pt"]
                if r["standard"]:
                    cur.loc[r["no"], "standard"] = r["standard"]
            st.session_state[f"items_{eid}"] = cur.reset_index().rename(columns={"index": "no"})
            st.success(f"성취기준표에서 {len(std_rows)}개 문항을 반영했습니다. " + " ".join(notes))
        elif notes:
            st.warning(" ".join(notes))

    cur_df = st.session_state.get(f"items_{eid}", base_df)
    edited = st.data_editor(
        cur_df, num_rows="dynamic", width="stretch", key=f"ed_{eid}_{len(cur_df)}",
        column_config={"no": st.column_config.NumberColumn("문항번호", step=1, format="%d"),
                       "max_pt": st.column_config.NumberColumn("배점", min_value=0.0),
                       "standard": st.column_config.TextColumn("성취기준"),
                       "text": st.column_config.TextColumn("문항 내용", width="large")})
    if msgs:
        st.warning("확인이 필요한 문항이 있습니다:\n\n" + "\n".join(f"- {m}" for m in msgs))
    try:
        st.caption(f"배점 합계: {pd.to_numeric(edited['max_pt'], errors='coerce').fillna(0).sum():g}점 (시험 계획의 총점과 맞는지 확인하세요)")
    except Exception:
        pass
    if st.button("문항 저장", type="primary"):
        ok = edited.dropna(subset=["no", "max_pt"])
        if ok.empty or (ok["max_pt"] <= 0).any():
            st.error("모든 문항에 문항번호와 0보다 큰 배점을 입력하세요.")
        elif ok["no"].duplicated().any():
            st.error("문항번호가 중복되었습니다.")
        else:
            db.save_items(eid, ok.fillna("").to_dict("records"))
            refresh_results(eid, sel)
            st.session_state.pop(f"items_{eid}", None)
            st.success(f"{len(ok)}개 문항을 저장했습니다.")
            st.rerun()

# ---------- ② 점수표 ----------
with tab2:
    items = db.load_items(eid)
    if not items:
        st.warning("먼저 ① 시험 문항을 저장하세요.")
    else:
        st.write("NEIS에서 내려받은 문항별 점수표(엑셀 또는 CSV)를 올립니다. **성명 열은 저장하지 않고 학번만 저장합니다.**")
        up = st.file_uploader("점수표 파일", type=["xlsx", "csv"], key="score")
        if up is not None:
            try:
                raw = read_table(up)
            except Exception as e:
                st.error(f"파일을 읽지 못했습니다: {e}")
                st.stop()
            hdr = st.number_input("제목(열 이름)이 있는 줄 번호 (맨 윗줄 = 1)", 1, len(raw), guess_header_row(raw) + 1) - 1
            df = raw.iloc[hdr + 1:].copy()
            df.columns = [str(c).strip() for c in raw.iloc[hdr].tolist()]
            df = df.dropna(how="all").reset_index(drop=True)
            st.dataframe(df.head(8), width="stretch")

            cols = list(df.columns)
            sid_default = next((i for i, c in enumerate(cols) if "학번" in c), 0)
            sid_col = st.selectbox("학번 열", cols, index=sid_default)
            cls_opts = ["(없음)"] + cols
            cls_default = next((i + 1 for i, c in enumerate(cols) if c.endswith("반") or c == "반"), 0)
            cls_col = st.selectbox("반 열 (반별 비교용, 선택)", cls_opts, index=cls_default)

            def looks_item(c):
                if c in (sid_col, cls_col) or any(w in c for w in NON_ITEM_WORDS):
                    return False
                return pd.to_numeric(df[c], errors="coerce").notna().mean() > 0.3
            item_cols = st.multiselect("문항 점수 열 (문항 번호 순서대로)", cols,
                                       default=[c for c in cols if looks_item(c)])
            st.caption(f"저장된 문항 {len(items)}개 / 선택한 열 {len(item_cols)}개 → 순서대로 문항 "
                       + ", ".join(str(i['no']) for i in items) + "에 대응합니다.")

            if st.button("점수표 저장", type="primary"):
                if len(item_cols) != len(items):
                    st.error("선택한 열의 개수가 문항 수와 다릅니다.")
                else:
                    nums = [i["no"] for i in items]
                    recs, bad = [], []
                    for _, r in df.iterrows():
                        sid = str(r[sid_col]).strip()
                        if not sid or sid.lower() == "nan":
                            continue
                        if sid.endswith(".0"):
                            sid = sid[:-2]
                        cl = "" if cls_col == "(없음)" else str(r[cls_col]).strip()
                        if cl.endswith(".0"):
                            cl = cl[:-2]
                        for no, c, mx in zip(nums, item_cols, [i["max_pt"] for i in items]):
                            v = pd.to_numeric(r[c], errors="coerce")
                            v = None if pd.isna(v) else float(v)
                            if v is not None and (v < 0 or v > mx):
                                bad.append(f"학번 {sid} 문항{no}: {v} (배점 {mx})")
                            recs.append((sid, cl, no, v))
                    if bad:
                        st.error("배점을 벗어난 점수가 있어 저장하지 않았습니다. 원본을 확인하세요.\n\n" + "\n".join(bad[:10]))
                    elif len({r[0] for r in recs}) != len(recs) // len(nums):
                        st.error("학번이 중복되었습니다. 학번 열을 확인하세요.")
                    else:
                        db.save_scores(eid, recs)
                        refresh_results(eid, sel)
                        st.success(f"학생 {len(recs) // len(nums)}명의 점수를 저장했습니다. ③ 분석 결과 탭으로 이동하세요.")
        else:
            n = len({r['sid'] for r in db.load_scores(eid)})
            if n:
                st.info(f"저장된 점수표: 학생 {n}명. 새 파일을 올리면 덮어씁니다.")

# ---------- ③ 분석 결과 ----------
with tab3:
    items = db.load_items(eid)
    recs = db.load_scores(eid)
    if not items or not recs:
        st.warning("문항과 점수표를 먼저 저장하세요.")
    else:
        max_pts = {i["no"]: i["max_pt"] for i in items}
        standards = {i["no"]: i["standard"] for i in items}
        wide, cls = analysis.to_wide(recs)
        wide, absent = analysis.drop_absent(wide)
        cls = cls.reindex(wide.index)
        if absent:
            st.caption(f"모든 문항이 공란인 {len(absent)}명은 결시로 보고 제외했습니다. 그 밖의 공란은 0점으로 계산하고 '미응답(%)'에 따로 표시합니다.")

        summ = analysis.total_summary(wide, max_pts)
        st.subheader("전체 요약")
        st.dataframe(pd.DataFrame([summ]), hide_index=True, width="stretch")
        st.bar_chart(analysis.distribution(wide, max_pts))
        st.caption("가로축: 총점 득점률(%) 구간, 세로축: 학생 수")

        st.subheader("문항별 분석")
        stats = analysis.item_stats(wide, max_pts)
        st.dataframe(stats, hide_index=True, width="stretch")
        st.caption(f"점검 표시는 이 프로그램의 기본 기준입니다: 득점률 {analysis.HARD_RATE:.0f}% 미만 '어려움', "
                   f"{analysis.EASY_RATE:.0f}% 이상 '쉬움', 변별도 {analysis.LOW_DISC} 미만, 문항-총점상관 {analysis.LOW_CORR} 미만. "
                   "변별도 = 총점 상·하위 27% 집단의 득점률 차이.")
        st.bar_chart(stats.set_index("문항")["득점률(%)"])

        st.subheader("성취기준별 평균 득점률")
        std_df = analysis.standard_summary(wide, max_pts, standards)
        st.dataframe(std_df, hide_index=True, width="stretch")

        cmp_df = None
        if cls.astype(str).str.len().gt(0).any():
            st.subheader("반별 문항 득점률(%)")
            cmp_df = analysis.class_compare(wide, cls, max_pts)
            st.dataframe(cmp_df, width="stretch")

        st.subheader("학생 개인 확인")
        sid = st.selectbox("학번", list(wide.index))
        prof = analysis.student_profile(wide, cls, max_pts, sid)
        st.dataframe(prof, hide_index=True, width="stretch")

        sheets = {"요약": pd.DataFrame([summ]), "문항별": stats, "성취기준별": std_df}
        if cmp_df is not None:
            sheets["반별"] = cmp_df
        st.download_button("분석 결과 엑셀로 저장", to_excel_bytes(sheets),
                           file_name=f"{sel}_분석결과.xlsx",
                           mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

# ---------- ④ 결과 피드백 ----------
with tab4:
    items = db.load_items(eid)
    recs = db.load_scores(eid)
    if not items or not recs:
        st.warning("문항과 점수표를 먼저 저장하세요.")
    else:
        st.write("큐웬이 통계표와 문항 내용만 보고 결과 피드백 초안을 씁니다. **학생 답안을 보지 못하므로 원인은 추정이며, 교사가 확인하고 고쳐 쓰세요.**")
        models = llm_models()
        if not models:
            st.error(NO_LLM)
        else:
            model = st.selectbox("사용할 모델", models, key="model_fb")
            if st.button("결과 피드백 만들기", type="primary"):
                max_pts = {i["no"]: i["max_pt"] for i in items}
                wide, _ = analysis.to_wide(recs)
                wide, _ = analysis.drop_absent(wide)
                stats = analysis.item_stats(wide, max_pts)
                prompt = llm.build_prompt(stats, items, analysis.total_summary(wide, max_pts))
                with st.spinner("큐웬이 작성 중입니다. CPU 노트북에서는 몇 분 걸릴 수 있습니다."):
                    try:
                        out = llm.chat(llm_base(), model, llm.SYSTEM, prompt)
                        db.save_note(eid, "결과 피드백", out)
                        st.rerun()
                    except Exception as e:
                        st.error(f"큐웬 호출 실패: {e}")
        for n in db.load_notes(eid):
            with st.expander(f"{n['kind']} · {n['created']}", expanded=False):
                st.write(n["body"])

# ---------- ⑤ 생기부 초안 ----------
with tab5:
    st.write("학생 결과 기록에서 **같은 학번의 여러 시험 결과를 합쳐** 성취기준별 수준(잘함·보통·보완 필요)을 정하고, "
             "큐웬이 교과 세부능력 및 특기사항 초안을 학생마다 하나씩 씁니다. "
             "**시험 점수만 근거로 한 초안이므로 수업 중 관찰 내용을 더해 교사가 반드시 고쳐 쓰세요.**")
    st.caption(f"큐웬에는 학번과 점수를 보내지 않고 성취기준과 수준만 보냅니다. 수준 기준(기본값): 성취기준별 (득점 합)÷(배점 합)이 "
               f"{analysis.STRONG_RATE:.0f}% 이상 잘함, {analysis.WEAK_RATE:.0f}% 미만 보완 필요, 그 사이 보통. "
               "성취기준 코드(예: 9정04-03)가 같으면 시험이 달라도 같은 성취기준으로 합칩니다.")
    all_exams = db.list_exams()
    have = db.result_exam_ids()
    for e in all_exams:  # 이전 판에서 만든 시험처럼 결과 기록이 없는 시험은 지금 만든다
        if e["id"] not in have:
            refresh_results(e["id"], e["name"])
    have = db.result_exam_ids()
    rex = [e for e in all_exams if e["id"] in have]
    exam_name = {e["id"]: e["name"] for e in all_exams}
    if not rex:
        st.warning("문항과 점수표를 저장한 시험이 없습니다.")
    else:
        latest = max(school_year(e["created"]) for e in rex)
        pick = st.multiselect(
            "합칠 시험 (같은 학번의 결과를 합칩니다)", [e["id"] for e in rex],
            default=[e["id"] for e in rex if school_year(e["created"]) == latest],
            format_func=lambda i: f"{exam_name[i]} ({school_year(next(e['created'] for e in rex if e['id'] == i))}학년도)",
            key="sg_exams_" + ",".join(str(e["id"]) for e in rex))  # 시험이 늘거나 줄면 기본 선택을 다시 적용
        st.caption("학번(예: 10101)은 해마다 다른 학생에게 다시 쓰이므로 다른 학년도 시험은 함께 고르지 마세요. "
                   "처음에는 가장 최근 학년도 시험만 골라 둡니다.")
        if not pick:
            st.warning("합칠 시험을 하나 이상 고르세요.")
        else:
            basis = ",".join(str(i) for i in sorted(pick))
            results = db.load_results(pick)
            levels, table = analysis.combine_results(results)
            cls = {}
            for r in results:  # 학번·시험 순서라 나중 시험의 반이 남는다
                cls[r["sid"]] = r["cls"] or cls.get(r["sid"], "")
            sids = sorted(levels)
            st.caption(f"합친 시험 {len(pick)}개, 학생 {len(sids)}명(한 시험 이상 응시).")
            if any(r["std_key"].startswith("시험") for r in results):
                st.warning("성취기준이 비어 있는 문항은 문항 내용 앞부분으로 대신하며 다른 시험과 합쳐지지 않습니다. "
                           "① 탭에 성취기준을 넣으면 초안이 더 구체적입니다.")
            with st.expander("학생 결과 기록 보기 (학번별 합친 결과)"):
                sid_v = st.selectbox("학번", sids, key="sg_view")
                st.dataframe(table[table["학번"] == sid_v].drop(columns="학번"), hide_index=True, width="stretch")

            drafts = {d["sid"]: d for d in db.load_drafts(set(sids))}
            c1, c2, c3 = st.columns(3)
            subject = c1.text_input("교과명", db.get_setting("subject", "정보"))
            length = c2.number_input("글자 수(공백 포함, 안팎)", min_value=100, max_value=500, value=300, step=50)
            cls_list = sorted({c for c in cls.values() if c})
            cls_sel = c3.selectbox("반", ["(전체)"] + cls_list, key="sg_cls")
            in_cls = [s for s in sids if cls_sel == "(전체)" or cls[s] == cls_sel]
            only_new = st.checkbox("초안이 없거나 근거 시험이 바뀐 학생만", value=True)
            target = [s for s in in_cls if not only_new or s not in drafts or drafts[s]["basis"] != basis]
            st.caption(f"대상 학생 {len(target)}명. 학생 수만큼 시간이 걸립니다. 한 명씩 바로 저장되므로 "
                       "중간에 다른 단추를 눌러 멈추더라도 그때까지 만든 초안은 남습니다. "
                       "이미 있는 초안을 다시 만들면 고친 글도 새 초안으로 바뀝니다.")

            models = llm_models()
            if not models:
                st.error(NO_LLM)
            else:
                model = st.selectbox("사용할 모델", models, key="model_sg")
                if st.button("생기부 초안 만들기", type="primary", disabled=not target):
                    db.set_setting("subject", subject)
                    bar = st.progress(0.0)
                    fails = []
                    for i, sid in enumerate(target):
                        bar.progress(i / len(target), text=f"{i + 1}/{len(target)}번째 학생 작성 중")
                        try:
                            out = llm.chat(llm_base(), model, llm.STUDENT_SYSTEM,
                                           llm.build_student_prompt(levels[sid], subject, int(length)), max_tokens=1000)
                            db.save_draft(sid, cls[sid], out, basis)
                        except Exception as e:
                            fails.append(f"학번 {sid}: {e}")
                    st.session_state["draft_result"] = (len(target) - len(fails), fails)
                    st.rerun()
            res = st.session_state.pop("draft_result", None)
            if res:
                st.success(f"완료: {res[0]}명의 초안을 만들어 저장했습니다.")
                if res[1]:
                    st.error("작성하지 못한 학생이 있습니다. 다시 누르면 이 학생들만 이어서 만듭니다.\n\n"
                             + "\n".join(f"- {f}" for f in res[1][:10]))

            shown = db.load_drafts(set(in_cls))
            if shown:
                st.subheader(f"저장된 초안 ({len(shown)}명)")
                df = pd.DataFrame(shown)
                df["근거 시험"] = df["basis"].map(lambda b: ", ".join(
                    exam_name.get(int(x), "(삭제된 시험)") for x in b.split(",") if x))
                df["선택한 시험과 같음"] = (df["basis"] == basis).map({True: "예", False: "아니요"})
                df = df.rename(columns={"cls": "반", "sid": "학번", "body": "생기부 초안", "created": "작성일"})
                df.insert(3, "글자 수", df["생기부 초안"].str.len())
                df = df[["반", "학번", "생기부 초안", "글자 수", "근거 시험", "선택한 시험과 같음", "작성일"]]
                ed = st.data_editor(df, hide_index=True, width="stretch", key=f"dr_{basis}_{cls_sel}_{len(df)}",
                                    disabled=["반", "학번", "글자 수", "근거 시험", "선택한 시험과 같음", "작성일"],
                                    column_config={"생기부 초안": st.column_config.TextColumn("생기부 초안", width="large")})
                ed = ed.assign(**{"글자 수": ed["생기부 초안"].fillna("").str.len()})
                b1, b2 = st.columns(2)
                if b1.button("고친 내용 저장"):
                    db.update_drafts(list(zip(ed["학번"], ed["생기부 초안"].fillna(""))))
                    st.success("고친 내용을 저장했습니다.")
                b2.download_button("엑셀로 내려받기", drafts_excel_bytes(ed.drop(columns="선택한 시험과 같음")),
                                   file_name="student_drafts.xlsx",
                                   mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                st.caption("엑셀에는 화면의 내용이 그대로 들어갑니다(저장하지 않은 수정 포함). 성명은 들어가지 않으니 학번으로 맞춰 쓰세요.")
                with st.expander("화면의 초안 지우기"):
                    if st.checkbox(f"위 표의 학생 {len(df)}명의 초안을 지웁니다"):
                        if st.button("지우기 실행"):
                            db.delete_drafts(list(df["학번"]))
                            st.rerun()
