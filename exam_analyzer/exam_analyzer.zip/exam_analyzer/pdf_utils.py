"""시험지 PDF·성취기준표 PDF에서 글자를 꺼내 문항·배점·성취기준을 찾는다.
스캔본(이미지) PDF는 글자가 없어 빈 결과가 나온다."""
import re

import pymupdf  # PyMuPDF

_TYPE = r"(?:서술형|서답형|논술형)"
_PAT = re.compile(
    rf"(?m)^[ \t]*\[?[ \t]*{_TYPE}[ \t]*(\d{{1,2}})[ \t]*\]?[\.\)]?|^[ \t]*(\d{{1,2}})[ \t]*[\.\)번]")

# 2022 개정 교육과정 성취기준 코드 예: 9정04-03, 9수01-02
STD_CODE = re.compile(r"\d{1,2}[가-힣]{1,3}\d{2}-\d{2}")
_NUM = r"(\d+(?:\.\d+)?)"
_PT_BRACKET = re.compile(rf"[\(\[（【]\s*{_NUM}\s*점\s*[\)\]）】]")
_PT_EACH = re.compile(rf"각\s*{_NUM}\s*점")
_PT_BARE = re.compile(rf"{_NUM}\s*점")


# ---------- 글자 꺼내기 ----------
def _norm(line):
    return re.sub(r"\d+", "#", line.strip())


def open_pdf(pdf_bytes):
    """PDF를 연다. 손상·암호 PDF는 교사가 읽을 수 있는 안내와 함께 ValueError를 낸다."""
    try:
        doc = pymupdf.open(stream=pdf_bytes, filetype="pdf")
        if doc.page_count == 0:
            raise ValueError
    except Exception:
        raise ValueError("PDF 파일을 열지 못했습니다. 파일이 손상되었거나 PDF가 아닐 수 있습니다. "
                         "원본에서 PDF로 다시 저장해 올리거나, 문항을 표에 직접 입력하세요.")
    if doc.needs_pass:
        raise ValueError("암호가 걸린 PDF입니다. 암호를 푼 PDF로 다시 저장해 올리거나, 문항을 표에 직접 입력하세요.")
    return doc


# 글자가 깨졌을 때 흔히 나오는 문자: 사용자 영역(U+E000~F8FF), 대체 문자(U+FFFD), 빈 네모(□),
# 낱자모(ㄱ~ㅣ, 옛한글 자모), 제어 문자
_BAD_CH = re.compile(r"[\ue000-\uf8ff\ufffd\u25a1\u3131-\u318e\u1100-\u11ff\x00-\x08\x0b\x0c\x0e-\x1f]")
_HANGUL = re.compile(r"[가-힣]")


def text_warning(text):
    """추출한 글자가 깨져 보이면 안내 문장을, 괜찮으면 None을 돌려준다."""
    body = re.sub(r"\s", "", text)
    if len(body) < 50:
        return None
    bad = len(_BAD_CH.findall(body)) / len(body)
    if bad > 0.03:
        return (f"읽어 온 글자의 {bad * 100:.0f}%가 깨진 문자(□, 낱자모, 알 수 없는 기호)입니다. "
                "한글에서 'PDF로 저장하기'로 다시 저장해 올려 보시고, 그래도 같으면 문항 내용을 표에 직접 입력하세요.")
    if len(_HANGUL.findall(body)) / len(body) < 0.05:
        return ("읽어 온 글자에 한글이 거의 없습니다. 글자가 깨졌을 수 있으니 아래 표의 '문항 내용'을 "
                "원본 시험지와 비교해 확인하세요.")
    return None


def extract_text(pdf_bytes):
    """쪽마다 반복되는 머리말·꼬리말(예: '2026학년도 ... 시험', '다음장에 계속')은 지운다."""
    doc = open_pdf(pdf_bytes)
    pages = [[ln for ln in p.get_text().splitlines()] for p in doc]
    if len(pages) >= 2:
        seen = {}
        for lines in pages:
            nz = [i for i, ln in enumerate(lines) if ln.strip()]
            edge = set(nz[:3] + nz[-3:])
            for key in {_norm(lines[i]) for i in edge}:
                seen[key] = seen.get(key, 0) + 1
        repeated = {k for k, v in seen.items() if v >= 2 and len(k) >= 3}
        cleaned = []
        for lines in pages:
            nz = [i for i, ln in enumerate(lines) if ln.strip()]
            edge = set(nz[:3] + nz[-3:])
            cleaned.append([ln for i, ln in enumerate(lines) if not (i in edge and _norm(ln) in repeated)])
        pages = cleaned
    return "\n".join("\n".join(p) for p in pages), len(doc)


# ---------- 배점 찾기 ----------
def find_points(text):
    """문항 글 속의 '(6점)' 같은 표시에서 배점을 찾는다. 반환: (배점 또는 None, 확인 메모)"""
    vals = [float(v) for v in _PT_BRACKET.findall(text)]
    if len(vals) == 1:
        return vals[0], ""
    if len(vals) > 1:
        if abs(vals[0] - sum(vals[1:])) < 1e-9:       # 첫 값이 나머지의 합 = 총점 표기
            return vals[0], f"배점 {len(vals)}개 발견({', '.join(_fmt(v) for v in vals)}): 첫 값을 총점으로 봤습니다"
        return sum(vals), f"배점 {len(vals)}개 발견({', '.join(_fmt(v) for v in vals)}): 합계 {_fmt(sum(vals))}점을 넣었습니다"
    m = _PT_EACH.search(text)
    if m:
        return None, f"'각 {m.group(1)}점'으로 적혀 있어 총 배점은 직접 입력하세요"
    bare = _PT_BARE.findall(text)
    if bare:
        return float(bare[0]), f"괄호 없이 적힌 {_fmt(float(bare[0]))}점을 사용했습니다"
    return None, "배점을 찾지 못했습니다"


def _fmt(v):
    return str(int(v)) if float(v).is_integer() else str(v)


# ---------- 문항 나누기 ----------
def _pick_starts(cands):
    starts, last = [], None
    for pos, no, typed in cands:
        if last is None:
            ok = no == 1 or typed or no <= 3 or not starts
        else:
            ok = last < no <= last + 2 or (typed and no > last)
        if ok:
            starts.append((pos, no))
            last = no
    return starts


def split_questions(text):
    """문항 번호는 차례대로(앞 번호보다 크고 +2 이내) 나올 때만 새 문항으로 봅니다.
    시험지가 '1.' 처럼 점(.)으로 문항을 쓰고 '1)' 로 작은 문항을 쓰는 경우가 많아,
    먼저 점(.) 표기만으로 나누어 보고(2개 이상 찾으면 채택), 안 되면 ')'·'번' 표기까지 함께 봅니다."""
    text = re.sub(r"(?m)^[ \t]*[→➜]?[ \t]*다음\s*장에\s*계속[ \t]*$", "", text)
    cut = re.search(r"수고\s*하셨습니다", text)
    if cut:
        text = text[:cut.start()]
    allc = []
    for m in _PAT.finditer(text):
        typed = bool(m.group(1))
        mark = text[m.end() - 1:m.end()] if not typed else "."
        allc.append((m.start(), int(m.group(1) or m.group(2)), typed, mark))
    if not allc:
        return []
    dot = [(p_, n_, t_) for p_, n_, t_, mk in allc if mk == "." or t_]
    starts = _pick_starts(dot)
    if len(starts) < 2:
        starts = _pick_starts([(p_, n_, t_) for p_, n_, t_, _ in allc])
    out = []
    for i, (pos, no) in enumerate(starts):
        end = starts[i + 1][0] if i + 1 < len(starts) else len(text)
        body = text[pos:end].strip()
        pt, note = find_points(body)
        codes = list(dict.fromkeys(STD_CODE.findall(body)))
        out.append({"no": no, "text": body, "max_pt": pt, "note": note,
                    "standard": ", ".join(codes)})
    return out


# ---------- 성취기준표 PDF ----------
def _cell(v):
    return re.sub(r"\s+", " ", str(v)).strip() if v is not None else None


def _as_no(s):
    if not s:
        return None
    m = re.fullmatch(rf"(?:{_TYPE}\s*)?(\d{{1,2}})\s*(?:번|\.|\))?", s.strip())
    return int(m.group(1)) if m else None


def _as_pt(s):
    if not s:
        return None
    m = re.fullmatch(rf"{_NUM}\s*점?", s.strip())
    return float(m.group(1)) if m else None


def parse_standard_pdf(pdf_bytes):
    """성취기준표(평가계획서·이원목적분류표 등) PDF에서 문항번호·배점·성취기준을 찾는다.
    ① 표(table)를 찾아 읽고, ② 표를 못 찾으면 글 줄 단위로 읽는다. 반환: (rows, notes)"""
    doc = open_pdf(pdf_bytes)
    rows, notes = {}, []
    if not any(p.get_text().strip() for p in doc):
        return [], ["PDF에서 글자를 읽지 못했습니다(스캔본일 수 있음)."]

    # ① 표
    for page in doc:
        try:
            tables = page.find_tables().tables
        except Exception:
            tables = []
        for tb in tables:
            data = []
            for row in tb.rows:
                # extract()의 글자는 '-' 같은 기호가 깨지는 경우가 있어, 칸 영역의 글자를 직접 읽는다
                data.append([_cell(page.get_text("text", clip=pymupdf.Rect(c)).strip()) if c else None
                             for c in row.cells])
            if not data:
                continue
            col_no = col_pt = col_std = None
            body_start = 0
            for ri, r in enumerate(data[:4]):
                found = False
                for ci, c in enumerate(r):
                    t = (c or "").replace(" ", "")
                    if col_no is None and ("문항" in t and "번호" in t or t in ("번호", "문항", "문항번호")):
                        col_no, found = ci, True
                    if col_pt is None and "배점" in t:
                        col_pt, found = ci, True
                    if col_std is None and "성취기준" in t:
                        col_std, found = ci, True
                if found:
                    body_start = ri + 1
                    break
            last_std = ""
            for r in data[body_start:]:
                if col_no is not None:
                    no = _as_no(r[col_no] if col_no < len(r) else None)
                else:
                    no = next((_as_no(c) for c in r[:2] if _as_no(c) is not None), None)
                if no is None:
                    continue
                std = ""
                if col_std is not None and col_std < len(r):
                    v = r[col_std]
                    std = v if v is not None else last_std        # None = 병합된 칸 → 위 칸 내용을 따름
                    last_std = std or last_std
                else:
                    cell_hit = next((c for c in r if c and STD_CODE.search(c)), "")
                    std = cell_hit
                pt = None
                if col_pt is not None and col_pt < len(r):
                    pt = _as_pt(r[col_pt])
                if pt is None and col_pt is None:
                    nums = [_as_pt(c) for c in r[1:] if c and re.fullmatch(rf"{_NUM}\s*점", c.strip())]
                    pt = nums[0] if nums else None
                rows[no] = {"no": no, "max_pt": pt, "standard": std or ""}
    if rows:
        notes.append(f"표에서 {len(rows)}개 문항을 읽었습니다.")
        return [rows[k] for k in sorted(rows)], notes

    # ② 글 줄 단위: '5  ...(6점) ... 9정04-03' 처럼 한 줄(또는 이어진 줄)에 있는 경우
    text = "\n".join(p.get_text() for p in doc)
    qs = split_questions(text)
    for q in qs:
        codes = list(dict.fromkeys(STD_CODE.findall(q["text"])))
        if codes or q["max_pt"] is not None:
            rows[q["no"]] = {"no": q["no"], "max_pt": q["max_pt"], "standard": ", ".join(codes)}
    if rows:
        notes.append("표 모양을 찾지 못해 글 줄 단위로 읽었습니다. 결과를 꼭 확인하세요.")
    else:
        notes.append("문항번호와 성취기준(예: 9정04-03)을 찾지 못했습니다. 표에 직접 입력하세요.")
    return [rows[k] for k in sorted(rows)], notes
