"""LM Studio(OpenAI 호환 API)로 큐웬을 호출한다."""
import re
import requests


def list_models(base):
    r = requests.get(base.rstrip("/") + "/models", timeout=5)
    r.raise_for_status()
    return [m["id"] for m in r.json().get("data", [])]


def chat(base, model, system, user, max_tokens=1500, timeout=900):
    payload = {
        "model": model,
        "messages": [{"role": "system", "content": system},
                     {"role": "user", "content": user}],
        "temperature": 0.4,
        "max_tokens": max_tokens,
    }
    r = requests.post(base.rstrip("/") + "/chat/completions", json=payload, timeout=timeout)
    r.raise_for_status()
    text = r.json()["choices"][0]["message"]["content"] or ""
    # Qwen3의 생각(<think>) 구간이 섞여 나오면 제거
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.S).strip()
    return text


SYSTEM = ("너는 중학교 교사를 돕는 평가 분석 보조자다. 제공된 통계표와 문항 내용만 근거로 말한다. "
          "학생이 실제로 쓴 답안은 보지 못했으므로 원인은 반드시 '추정'이라고 표시한다. "
          "숫자를 새로 계산하지 말고 표의 숫자를 그대로 인용한다. 한국어 존댓말, 간결하게 쓴다.")


def build_prompt(stats_df, items, summary):
    lines = ["[전체 요약]", ", ".join(f"{k} {v}" for k, v in summary.items()), "", "[문항별 통계]"]
    for _, r in stats_df.iterrows():
        it = next((i for i in items if i["no"] == r["문항"]), {})
        lines.append(
            f"- 문항{r['문항']} (배점 {r['배점']}) 득점률 {r['득점률(%)']}%, 만점 {r['만점(%)']}%, "
            f"부분점수 {r['부분점수(%)']}%, 0점 {r['0점(%)']}%, 변별도 {r['변별도']}, "
            f"점검: {r['점검'] or '없음'}\n  성취기준: {it.get('standard') or '미입력'}\n"
            f"  문항 내용: {(it.get('text') or '')[:300]}")
    lines += ["", "[요청] 득점률이 낮거나 점검 표시가 있는 문항을 중심으로 (1) 예상 원인(추정) "
              "(2) 재지도 방안 (3) 다음 평가에서 고칠 점을 문항별로 3줄 이내로 써 주세요. /no_think"]
    return "\n".join(lines)


STUDENT_SYSTEM = ("너는 중학교 교사의 학교생활기록부 교과 세부능력 및 특기사항 초안 작성을 돕는다. "
                  "제공된 성취기준별 수준만 근거로 쓰고, 없는 활동·태도·사례를 지어내지 않는다. "
                  "점수, 득점률, 등수, 등급 같은 숫자와 '시험', '평가 결과' 같은 말은 쓰지 않는다. "
                  "학생 이름이나 '이 학생', '학생은' 같은 주어 없이 쓴다. "
                  "문장은 '~함', '~임', '~보임' 같은 명사형으로 끝낸다. 과장하거나 부정적으로 단정하지 않는다.")


def build_student_prompt(levels, subject, length):
    """levels: [{"기준", "수준"}]. 학번·점수는 넣지 않는다."""
    lines = [f"[교과] {subject or '정보'}", "[성취기준별 수준]"]
    lines += [f"- {r['수준']}: {r['기준']}" for r in levels]
    lines += ["", f"[요청] 위 내용을 바탕으로 세부능력 및 특기사항 초안을 한 문단, 공백 포함 {length}자 안팎으로 써 주세요. "
              "'잘함'인 성취기준은 구체적인 역량으로 서술하고, '보완 필요'는 앞으로의 성장 방향으로 부드럽게 한 문장 이내로만 씁니다. "
              "초안 본문만 쓰세요. /no_think"]
    return "\n".join(lines)
