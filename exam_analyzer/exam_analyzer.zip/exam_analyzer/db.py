"""SQLite 저장소. 학번만 저장하며 이름은 저장하지 않는다."""
import sqlite3
from pathlib import Path
from datetime import datetime

DB_PATH = Path(__file__).parent / "data" / "exam.db"


def _conn():
    DB_PATH.parent.mkdir(exist_ok=True)
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c


def init():
    with _conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS exams(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE, created TEXT);
        CREATE TABLE IF NOT EXISTS items(
            exam_id INTEGER, no INTEGER, max_pt REAL, standard TEXT, text TEXT,
            PRIMARY KEY(exam_id, no));
        CREATE TABLE IF NOT EXISTS scores(
            exam_id INTEGER, sid TEXT, cls TEXT, item_no INTEGER, score REAL,
            PRIMARY KEY(exam_id, sid, item_no));
        CREATE TABLE IF NOT EXISTS notes(
            id INTEGER PRIMARY KEY AUTOINCREMENT, exam_id INTEGER, kind TEXT,
            body TEXT, created TEXT);
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
        -- 학생 결과 기록: 학번·시험·성취기준마다 득점 합과 배점 합(점수표·문항을 저장할 때 다시 계산)
        CREATE TABLE IF NOT EXISTS student_results(
            sid TEXT, exam_id INTEGER, cls TEXT, std_key TEXT, std_label TEXT,
            got REAL, full REAL, PRIMARY KEY(sid, exam_id, std_key));
        -- 생기부 초안: 학생 1명당 1개. basis = 근거로 합친 시험 번호(예: '1,3')
        CREATE TABLE IF NOT EXISTS student_drafts(
            sid TEXT PRIMARY KEY, cls TEXT, body TEXT, basis TEXT, created TEXT);
        """)
        # 이전 판(시험마다 따로 저장한 drafts 표)의 초안을 옮긴다. 같은 학번이면 나중 시험 것을 남긴다.
        if c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='drafts'").fetchone():
            c.execute("INSERT OR REPLACE INTO student_drafts "
                      "SELECT sid, cls, body, CAST(exam_id AS TEXT), created FROM drafts ORDER BY exam_id")
            c.execute("DROP TABLE drafts")


def list_exams():
    with _conn() as c:
        return [dict(r) for r in c.execute("SELECT * FROM exams ORDER BY id DESC")]


def create_exam(name):
    with _conn() as c:
        cur = c.execute("INSERT INTO exams(name, created) VALUES(?,?)",
                        (name, datetime.now().strftime("%Y-%m-%d %H:%M")))
        return cur.lastrowid


def delete_exam(exam_id):
    with _conn() as c:
        for t in ("items", "scores", "notes", "student_results"):
            c.execute(f"DELETE FROM {t} WHERE exam_id=?", (exam_id,))
        # 생기부 초안은 교사가 고친 글일 수 있어 지우지 않는다(근거 시험이 바뀐 것으로 표시됨)
        c.execute("DELETE FROM exams WHERE id=?", (exam_id,))


def save_items(exam_id, rows):
    """rows: list of dict(no, max_pt, standard, text)"""
    with _conn() as c:
        c.execute("DELETE FROM items WHERE exam_id=?", (exam_id,))
        c.executemany("INSERT INTO items VALUES(?,?,?,?,?)",
                      [(exam_id, int(r["no"]), float(r["max_pt"]),
                        r.get("standard") or "", r.get("text") or "") for r in rows])


def load_items(exam_id):
    with _conn() as c:
        return [dict(r) for r in c.execute(
            "SELECT no, max_pt, standard, text FROM items WHERE exam_id=? ORDER BY no", (exam_id,))]


def save_scores(exam_id, records):
    """records: list of (sid, cls, item_no, score or None)"""
    with _conn() as c:
        c.execute("DELETE FROM scores WHERE exam_id=?", (exam_id,))
        c.executemany("INSERT INTO scores VALUES(?,?,?,?,?)",
                      [(exam_id, s, k or "", int(n), v) for s, k, n, v in records])


def load_scores(exam_id):
    with _conn() as c:
        return [dict(r) for r in c.execute(
            "SELECT sid, cls, item_no, score FROM scores WHERE exam_id=?", (exam_id,))]


def save_note(exam_id, kind, body):
    with _conn() as c:
        c.execute("INSERT INTO notes(exam_id, kind, body, created) VALUES(?,?,?,?)",
                  (exam_id, kind, body, datetime.now().strftime("%Y-%m-%d %H:%M")))


def load_notes(exam_id):
    with _conn() as c:
        return [dict(r) for r in c.execute(
            "SELECT id, kind, body, created FROM notes WHERE exam_id=? ORDER BY id DESC", (exam_id,))]


def replace_results(exam_id, rows):
    """rows: list of dict(sid, cls, std_key, std_label, got, full). 이 시험의 학생 결과 기록을 새로 바꾼다."""
    with _conn() as c:
        c.execute("DELETE FROM student_results WHERE exam_id=?", (exam_id,))
        c.executemany("INSERT INTO student_results VALUES(?,?,?,?,?,?,?)",
                      [(r["sid"], exam_id, r["cls"], r["std_key"], r["std_label"], r["got"], r["full"]) for r in rows])


def result_exam_ids():
    with _conn() as c:
        return {r[0] for r in c.execute("SELECT DISTINCT exam_id FROM student_results")}


def load_results(exam_ids):
    if not exam_ids:
        return []
    q = ",".join("?" * len(exam_ids))
    with _conn() as c:
        return [dict(r) for r in c.execute(
            f"SELECT r.sid, r.exam_id, e.name AS exam, r.cls, r.std_key, r.std_label, r.got, r.full "
            f"FROM student_results r JOIN exams e ON e.id = r.exam_id WHERE r.exam_id IN ({q}) "
            f"ORDER BY r.sid, r.exam_id", list(exam_ids))]


def save_draft(sid, cls, body, basis):
    """학생 1명의 생기부 초안을 저장(같은 학번이 있으면 덮어씀). basis: 합친 시험 번호 문자열."""
    with _conn() as c:
        c.execute("INSERT OR REPLACE INTO student_drafts VALUES(?,?,?,?,?)",
                  (sid, cls or "", body, basis, datetime.now().strftime("%Y-%m-%d %H:%M")))


def update_drafts(rows):
    """rows: list of (sid, body). 교사가 고친 글을 저장."""
    with _conn() as c:
        c.executemany("UPDATE student_drafts SET body=? WHERE sid=?", [(b, s) for s, b in rows])


def load_drafts(sids=None):
    with _conn() as c:
        rows = [dict(r) for r in c.execute(
            "SELECT cls, sid, body, basis, created FROM student_drafts ORDER BY cls, sid")]
    return rows if sids is None else [r for r in rows if r["sid"] in sids]


def delete_drafts(sids):
    with _conn() as c:
        c.executemany("DELETE FROM student_drafts WHERE sid=?", [(s,) for s in sids])


def get_setting(key, default=""):
    with _conn() as c:
        r = c.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return r["value"] if r else default


def set_setting(key, value):
    with _conn() as c:
        c.execute("INSERT INTO settings VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                  (key, value))
