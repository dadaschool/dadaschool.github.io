# lesson-designer — 수업 설계 도우미 (AI 업그레이드판)

> **이 파일이 이 앱의 단일 출처다.** 루트 `C:\project_AI\CLAUDE.md` 의 모든 규칙을 따른다.
> 이 문서는 참고 원본 앱을 고쳐 만든 설계 근거 + 개발 상태다.
> **1차 완성 (2026-08-29)** — §8 [개발 상태] 참고. 아래 §3~§7 은 «무엇을 왜 이렇게 만들었나» 다.

---

## 1. 앱 개요

| 항목 | 내용 |
|---|---|
| 폴더 | `C:\project_AI\lesson-designer\` (새 앱) |
| 앱 이름 | **수업 설계 도우미** (참고 앱과 같은 이름) |
| 성격 | **교사 업무용 도구** (`ai-coordinator`·`pdf-split`·`launcher` 와 같은 성격 · 학생 화면·로그인 없음) |
| 대상 | 중학교 정보 교사. 2022 개정 정보과 성취기준 25개(`[9정01-01]`~`[9정05-03]`) 전체를 다룬다 |
| 실행 | `index.html` 더블클릭 / `로컬서버_실행.bat` → `http://localhost:9300/` |
| 기술 | 바닐라 JS. 외부 런타임 의존성 0개(빌드 때 tailwind CLI 1회만). AI 호출만 `fetch` |
| 배포 | ① `배포본\dadaschool.github.io\geoje\lesson-designer\` 점검 → ② **「메인으로 배포해」** 를 들었을 때만 `dadaschool.github.io/lesson-designer/` (첫 화면 **업무용** 열에 한 줄 추가) |
| 개인정보 | 수집 0. 학생 이름칸은 **인쇄물의 손글씨 자리**뿐. `localStorage` 에는 **교사 설정(성취기준 편집본·AI 설정)** 만 |

### 성취기준 비공개 (루트 규칙)

- 학생이 받는 **인쇄 활동지·`.hwp`** 에 성취기준 코드·문장을 **넣지 않는다.**
- 교사 화면·교사용 인쇄물·과정안 Markdown 에는 넣어도 된다.
- ⚠ **참고 원본에 버그가 있다** — 4단계 학생 활동지 미리보기·HWP 가 `${plan.standard}`(성취기준)를 그대로 찍는다(`renderFinalPlans` 원본 725행, `downloadHWP` 원본에도). **고칠 때 학생 배부본에서 반드시 뺀다.** §6-F 참고.

---

## 2. 이 앱의 뿌리 — 참고 원본

| | |
|---|---|
| 원본 주소 | https://gnbuilders.github.io/lesson-designer/ (경남 교육 builders 로 추정 · 공개 교육 도구) |
| 원본 소스 | https://raw.githubusercontent.com/gnbuilders/lesson-designer/main/index.html |
| 로컬 사본 | **`참고_원본_index.html`** (이 폴더에 저장해 둠 · 843행 · 2026-08-29 받음) |

**이 앱은 원본의 파생물이다.** 원본의 4단계 뼈대·행동용어표·문장 분해 방식·용어를 그대로 물려받고,
그 위에 **실제 AI 생성**과 **성취기준 25개 + 편집기**를 얹는다. 새로 만들 `index.html` 머리에
`<!-- 원본: gnbuilders/lesson-designer 기반 · 수업 설계 방법론(백워드 설계)은 원저작자 -->` 주석을 남긴다.

### 원본이 하는 일 (단일 HTML · Tailwind CDN + 바닐라 JS)

| 단계 | 화면 id | 하는 일 |
|---|---|---|
| 1 | `step-1-view` | `<select id="standard-select">` 에서 성취기준 1개 선택 → `standardsData[id].sentences` 를 **문장 카드**로. 드래그 정렬(HTML5 DnD) + 평가방식 체크박스(지필/수행/관찰) |
| 2 | `step-2-view` | 체크된 평가방식별로 문장 그룹화(`groupedData`) + **행동용어 참고표**(고정 HTML 표) + `예상 수업 차시` 입력 → 차시 수만큼 `.objective-input` 칸 생성 |
| 3 | `step-3-view` | `generateDefaultLessonPlan(id, 목표문장)` 로 차시별 과정안 객체 생성 → `renderStep3Plans()` 가 편집 textarea 로 그림 → `downloadMarkdown(index)` |
| 4 | `step-4-view` | `renderFinalPlans()` 가 차시별 요약 + 학생 활동지 미리보기 → `downloadHWP(index)` (HTML 을 `.hwp` 로 저장) |

**원본 주요 코드 위치** (`참고_원본_index.html` 기준)

| 이름 | 행 | 역할 |
|---|---|---|
| `<script src="https://cdn.tailwindcss.com">` | 7 | **제거 대상** (§6-A) |
| `@import ... Pretendard` | 9 | **제거 대상** (§6-A) |
| `standardsData` | 246–324 | 성취기준 8개. **25개로 교체 + 외부화** (§6-B) |
| `<select id="standard-select">` + `<optgroup>` | 88–102 | 하드코딩 목록. **동적 생성으로** (§6-B) |
| `generateDefaultLessonPlan()` | 326–397 | id별 하드코딩 템플릿. **AI 생성으로, 템플릿은 폴백으로 유지** (§6-E) |
| `btnNextStep2` click | 592–604 | `generatedPlans` 채움. **AI 비동기 호출로 감쌈** (§6-E) |
| `renderStep3Plans()` | 614–663 | 과정안 편집 UI. 유지 + `[AI로 다시 생성]` 버튼 추가 |
| `downloadMarkdown()` | 665–700 | 과정안 → `.md`. **유지** (과정안 산출물은 md 만) |
| `renderFinalPlans()` | 710–774 | 4단계 미리보기. **성취기준 제거 + AI 버튼 + 인쇄** (§6-F) |
| `downloadHWP()` | 776–821 | HTML→`.hwp`. 유지하되 문항·이름칸 반영 (§6-F) |
| `switchView` / `updateSidebar` | 524–839 | 화면 전환·사이드바. 유지 + 나중에 `⚙ AI 설정` 항목 추가 |
| 상태 변수 | 242–244 | `currentStandardId` · `currentStandardText` · `generatedPlans` |

---

## 3. 바꾸는 것 — 한눈에

| # | 무엇 | 원본 | 바뀐 뒤 |
|---|---|---|---|
| A | 기반 정비 | Tailwind CDN + Google Fonts `@import` | **빌드 시 tailwind CLI 1회 → `css/app.css` 로 vendor**, 폰트는 시스템 스택. `server.py`·`.bat`·포트 9300·`.nojekyll` 추가 |
| B | 성취기준 | 8개 하드코딩 | **정보과 25개 전체 내장** + **교사가 추가·편집·삭제**(localStorage) + **JSON 가져오기/내보내기**(교사끼리 공유) |
| C | AI 설정 화면 | 없음 | 제공자(Claude·ChatGPT·Gemini·Upstage) 택1 + API 키(localStorage) + 모델명 편집칸 + **[연결 테스트]**. 키 없으면 **템플릿 모드로 전부 동작** |
| D | AI 어댑터 | 없음 | `callAI(provider, key, model, system, user)` — 제공자별 엔드포인트/헤더 분기 |
| E | 3단계 과정안 | id별 고정 문구 | **AI 생성**(키 있을 때) / 기존 템플릿(키 없을 때). 결과는 편집 가능. `[AI로 다시 생성]` 버튼. Markdown 다운로드 유지 |
| F | 4단계 활동지 | 고정 양식 + HWP | 차시마다 **[AI로 문항 생성]/[루브릭]/[수준별 하·중·상]**. **🖨 학생 배부용 인쇄**(성취기준·정답·루브릭 제외) / **🖨 교사용 인쇄**(포함) / **⬇ .hwp**(가벼운 방식 유지) |
| G | 사이드바 | 1~4단계 | 머리말에 **⚙ AI 설정** 버튼(모달) 추가 |

---

## 4. 결정 로그 (사용자와 정한 것 · 2026-08-29)

1. **새 앱 + 공개 배포** — `lesson-designer/` 새로 만들고 로컬 확인 후 geoje → 메인.
2. **API 키는 교사가 브라우저에 직접 입력** — Cloudflare Worker·중계 서버 **안 만든다.** 각자 키를 붙여넣어 `localStorage` 저장.
3. **AI 제공자 4종 중 교사가 고름** — **Claude(Anthropic) · ChatGPT(OpenAI) · Gemini(Google) · Upstage(Solar).**
4. **AI 넣는 곳** — ① **3단계 과정안 생성**(키 있으면 상시) ② **4단계 활동지·평가문항·루브릭**(교사가 「AI로 생성」 눌렀을 때만). **1·2단계는 규칙 기반 유지.**
5. **범위 밖** — 성취기준 자동 분해 AI · 교사 초안 첨삭 AI · Cloudflare Worker · **과정안 HWP** · 학생 제출·채점.
6. **성취기준** — 정보과 2022 개정 전체 25개 내장 + **교사가 직접 추가·편집**(다른 교과도 가능).
7. **산출물** — **과정안 = Markdown 만.** 활동지 = **브라우저 인쇄(PDF)** + **가벼운 `.hwp`**(원본 방식).

### 2차 답변 (2026-08-29) — 이렇게 확정해 구현함

- **AI 제공자 4종** : Claude · ChatGPT(OpenAI) · Gemini · **Upstage(Solar)** 중 교사가 고름.
- **성취기준** : 정보과 25개 전체 + 교사가 직접 추가·편집(다른 교과 가능 · JSON 반출입).
- **과정안(3단계) 산출물 = Markdown 만.** HWP 안 만듦 (`downloadMd` · `downloadAllMd`).
- 활동지(4단계) = **학생 배부용 인쇄 / 교사용 인쇄(정답·루브릭·성취기준) / 가벼운 `.hwp`** 셋 다.
- `js/print.js` **재사용함** (mb-noise 에서 복제 · md5 `51e2ea54029bc109589a19913982fb63` · 이제 10곳).

### 모델 기본값 (2026-08 자리표시자 · 설정 화면에서 편집 가능 · [연결 테스트] 로 확인)

| 제공자 | 기본값 | 엔드포인트 |
|---|---|---|
| claude  | `claude-sonnet-5` | `api.anthropic.com/v1/messages` (헤더 `anthropic-dangerous-direct-browser-access:true`) |
| openai  | `gpt-5.2` | `api.openai.com/v1/chat/completions` |
| gemini  | `gemini-3.7-flash` | `generativelanguage.googleapis.com/.../:generateContent?key=` |
| upstage | `solar-pro4` | `api.upstage.ai/v1/chat/completions` (OpenAI 호환) |

⚠ 값이 틀리면 교사가 설정에서 고치면 된다. 확정본은 각 제공자 문서에서 확인(`claude-api` 스킬).

---

## 5. 화면 명세

```
┌ 사이드바 ────────┐  ┌ 본문 (원본 그대로 absolute 전환) ─────────────────┐
│ 수업 설계 도우미   │  │ 1단계 성취기준 분해   → 문장 카드·평가방식 체크        │
│ [⚙ AI 설정]       │  │ 2단계 수업 목표 만들기 → 그룹화·행동용어표·차시 입력    │
│ 1 성취기준 분해    │  │ 3단계 수업 설계      → [AI로 과정안 생성]·편집·MD 저장  │
│ 2 수업 목표       │  │ 4단계 학습 활동지    → [AI로 문항/루브릭/수준별]·인쇄   │
│ 3 수업 설계       │  └────────────────────────────────────────────────┘
│ 4 학습 활동지     │
└─────────────────┘
```

### ⚙ AI 설정 (모달 · localStorage 키 `ld.ai.v1`)

- **제공자** 라디오: `claude` · `openai` · `gemini` · `upstage`
- **API 키** 입력(`type=password`, 붙여넣기) — localStorage 에만. "공용 PC 에서는 쓰고 나서 [키 지우기] 를 누르세요" 안내 + **[키 지우기]** 버튼
- **모델명** 텍스트 입력 — 제공자 바꾸면 기본값이 채워지되 **편집 가능**
- **[연결 테스트]** — `callAI(provider, key, model, "", "핑. '퐁' 이라고만 답해.")` 호출해 성공/실패·지연시간 표시
- 키가 없으면 3단계는 **템플릿 모드**, 4단계 AI 버튼은 비활성 + "AI 설정에서 키를 먼저 넣으세요"
- ⚠ 배포되는 `index.html`·`js/*` 에 **키 문자열이 절대 들어가면 안 된다.** 기본값은 빈 문자열.

### 1단계 (문장 카드 편집 + 성취기준 편집기)

🔴 **문장 분해는 확정이 아니라 예시다** (2026-08-30 사용자 지시 —
*"이 성취 기준의 분해가 지금처럼 확정이 아니라 사용자가 수정을 할 수 있도록"*) :
- 카드의 `.text` 는 **`contenteditable`** — 그 자리에서 고친다. `data-ph` 로 빈 칸 안내.
- 카드마다 **`✕` 삭제**, 아래에 **`＋ 문장 추가`**. **Enter = 아래에 새 문장**, 빈 칸에서 **Backspace = 삭제**.
- **`💾 이 분해를 성취기준에 저장`** → `Standards.put` (localStorage · 「(수정됨)」 표시 · 다음에도 그대로).
- **`↺ 원래 분해로 되돌리기`** → 저장본까지 지우고(`Standards.restore`) 프로그램 기본으로.
- 순서 바꾸기는 **손잡이(≡)만 draggable** — 카드 전체를 draggable 로 두면 글자 편집이 안 된다.
  `getDragAfter` 는 그대로. `dragstart` 에서 `card.classList.add("dragging")` + `setDragImage(card)`.
- `goStep2` 는 **화면에 적힌 문장**(`currentSentences()`)을 읽는다 — 원본 `std.sentences` 를 고정으로 쓰지 않는다.
  빈 칸은 걸러 내고, 하나도 없으면 알린다.
- 「(학생) 인공지능의 개념…」처럼 **성취기준 원문**은 3단계 「2. 성취 기준」 칸에 그대로 나온다 —
  편집하는 것은 «분해» 지 성취기준 문장이 아니다.

- `<select id="standard-select">` 를 `js/standards.js` 의 데이터로 **동적 생성**(영역 5개 `<optgroup>`).
- 선택 목록 아래 **[＋ 성취기준 추가·편집]** → 작은 편집 패널:
  - 코드 · 성취기준 문장 · **문장 분해 목록**(줄바꿈으로 여러 개) 입력
  - **[문장 단위로 자동 나누기]** — 규칙 기반(`, ` / `하고 ` / `하며 ` / `및 ` 등 연결어에서 분리 후 `~한다./~ㄴ다.` 종결 붙이기). AI 안 씀.
  - **[JSON 내보내기]/[JSON 가져오기]** — 편집본을 파일로. 다른 교사와 공유·다른 교과 반입.
  - 내장 25개는 **삭제 대신 "숨김"**, 편집하면 `(수정됨)` 표시하고 원본은 "되돌리기" 로 복구.
- 카드·드래그·체크박스 로직(`createCard`·`getDragAfterElement` 등)은 **그대로**.
- ⚠ 원본 `selectElement` change 핸들러가 `requestAnimationFrame` 으로 카드 등장 애니메이션을 한다(원본 510행). **`setTimeout` 으로 바꿀 것** — 이 프로젝트의 미리보기 브라우저는 프레임을 안 그려서 rAF 가 안 돌고, 좌표 검사가 깨진다(루트 규칙 [Browser pane 은 프레임을 그리지 않는다]).

### 2단계 (원본 그대로)

행동용어 참고표(원본 146–165행 고정 표)·그룹화·`btn-generate-hours`·`.objective-input` 전부 유지.

### 3단계 (AI 과정안)

- 헤더에 **[AI로 전체 생성]** 버튼(키 있을 때만 활성).
- `btnNextStep2` click 흐름(원본 592–604): 각 `.objective-input` 에 대해
  - 키 있음 → `await callAI(...)` 로 과정안 JSON 받기 → `generatedPlans[i]` 채우기
  - 키 없음 → 기존 `generateDefaultLessonPlan()` 그대로
  - 생성 중 스피너/진행표시. 실패한 차시는 템플릿으로 폴백하고 "AI 실패 → 템플릿" 배지.
- `renderStep3Plans()` 는 유지(편집 textarea). 카드마다 **[이 차시만 AI로 다시]** 버튼.
- `downloadMarkdown(index)` 유지. **전체를 한 파일로** 받는 `[전체 Markdown 저장]` 도 추가.
- 과정안 객체 필드는 원본과 호환: `{ standard, objective, intro, dev, conclusion, prep, ai }`.
  AI 프롬프트가 이 7칸을 채우게 한다(§7).

### 4단계 (AI 활동지 · 인쇄)

- `renderFinalPlans()` 개편. 차시 카드마다:
  - **[AI로 문항 생성]** → 그 차시 `objective` + 1단계에서 체크한 평가방식에 맞는 문항 N개(기본 5개, 조절)
  - **[채점 루브릭]** → 수행·서술 문항용 3~4수준 루브릭
  - **[수준별 하·중·상]** → 같은 목표의 난이도 변형
  - 결과는 편집 가능한 목록으로. 문항 유형: `choice`(선택형) · `short`(단답) · `text`(서술) · `perform`(수행 과제)
- 산출:
  - **🖨 학생 배부용 인쇄** — 제목·이름칸·문항·답 쓰는 빈칸/빈 상자만. **성취기준·정답·루브릭 없음.**
  - **🖨 교사용 인쇄** — 위 + 정답 + 루브릭 + 성취기준.
  - **⬇ .hwp** — 원본 `downloadHWP` 방식(HTML blob, `application/vnd.hancom.hwp`, `﻿`(BOM) 접두). 학생 배부용 내용으로.
- ⚠ **원본의 성취기준 노출 버그 제거**: `renderFinalPlans` 에서 `plan.standard` 를 학생 미리보기·`.hwp` 에서 뺀다. 요약 카드의 "성취 기준" 칸은 **교사 화면에만**(인쇄 `@media print` 에서 `display:none`).

---

## 5-1. 5단계 「학습 도움 자료 제작하기」 (2026-08-29 신설 · 사용자 지시)

> *"여기에서 만들어지는 마크다운 파일로 수업시간에 수업자료로 활용할 시뮬레이터를 만들어 주는 기능"*
> *"5단계 메뉴를 「학습 도움 자료 제작하기」 로 하나 더 만들어서 기능을 구현해"*

차시 과정안 → **수업용 시뮬레이터 HTML 파일 하나**. 사이드바 5번째 항목.

### 🔴 가장 중요한 설계 결정 — AI 는 HTML 을 쓰지 않는다

사용자가 **"유형 고르기 + AI가 내용 채움"** 을 골랐다(자유 생성 아님).

- **화면·손잡이·그래프·채점은 `js/sim.js` 의 검증된 뼈대**가 만든다.
- **AI 는 «설정값 + 순수 계산식(함수 본문)» 만** 준다.
- 그래서 **주제는 자유로우면서 화면이 절대 깨지지 않는다.**

🚨 **자유 생성으로 되돌리지 말 것.** AI 에게 HTML 전체를 맡기면
「움직이는 인포그래픽」이나 「하얀 화면」이 나온다. 교사가 수업 직전에 그것을 발견한다.

### 유형 4종 (`Sim.TYPES`)

| 키 | 이름 | 무엇을 깨닫게 하나 | AI 가 주는 것 |
|---|---|---|---|
| `tradeoff` | ⚖️ 값 바꿔 맞바꿈 보기 | 하나를 얻으면 하나를 잃는다 | controls 1~3 · metrics **정확히 2** · `compute(a,b,c)→[수,수]` · presets |
| `steps` | ▶️ 한 단계씩 실행 | 과정이 어떻게 흘러가는가 | input 1 · `compute(x)→[{label,state,note}…]` · examples |
| `compare` | ⚔️ 나란히 비교 | 두 방법의 차이 | input 1 · sides **정확히 2** · `compute(x)→[A,B]` |
| `classify` | 🧠 분류·학습 실험 | 데이터가 결과를 정한다 | **계산식 없음** — featureNames 2 · labels 2 · samples 8~12 · tests 4~6 |

⚠ **`classify` 만 계산식을 받지 않는다.** 분류기(가장 가까운 무게중심)를 `Sim.classifyAll` 이 갖고 있다.
가장 안전한 유형이다. 다른 유형에도 이런 «뼈대가 계산까지 갖는» 방식을 늘리면 더 안전해진다.

### 🔴 「반대로 움직이는가」는 값이 아니라 **좋아지는 방향**으로 본다

`tradeoff` 검사에서 처음엔 두 지표 값의 상관만 봤는데, 그러면
**「파일 크기(작을수록 좋음)」와 「음질(클수록 좋음)」이 둘 다 줄어드는 진짜 맞바꿈을 놓친다.**
지금은 `better:"low"` 인 지표에 −1 을 곱해 **goodness** 로 바꾼 뒤 상관을 본다(`dir0*dir1`).
`verify_sim.cjs` 가 두 경우를 모두 못 박아 두었다 — **되돌리지 말 것.**

### 자동 검사 (`Sim.validate`) — 만들자마자 실제로 돌려 본다

1. **금지 낱말** — `document`·`window`·`fetch`·`eval`·`Function`·`setTimeout`·`localStorage` 등이 계산식에 있으면 거부(`BAN`)
2. **격자 시험 호출** — tradeoff 25점×나머지, steps 12입력, compare 30점. **NaN·무한대·예외**를 잡는다
3. **유형별 뜻 검사** — tradeoff 는 맞바꿈이 보이는지, compare 는 차이가 벌어지는지, classify 는 전부 켠 정확도가 75% 이상인지
4. **문항 검사** — 선택지에 `<b>`·★·✓·(정답) 금지(`mb-noise` 사고), 정답 번호 범위
5. 실패하면 **오류 목록을 프롬프트에 붙여 1회 재생성**, 그래도 안 되면 이유를 화면에 보여 준다

### 화면 흐름

차시 카드마다 : 유형 4개 버튼(**학습목표 낱말로 «추천» 배지** · `Sim.recommend`, 규칙 기반이라 AI 를 부르지 않는다)
→ `[✨ 시뮬레이터 만들기]` → 검사 결과 → **`<iframe sandbox="allow-scripts" srcdoc>` 미리보기**
→ `[⬇ HTML 내려받기]` / `[새 창에서 크게 보기]`

🚨 **미리보기를 빼지 말 것.** 「수업 직전에 열었더니 하얀 화면」을 막는 유일한 장치다.

### 만들어지는 파일

자체 완결 HTML 1개(약 22KB) · **외부 CDN 0** · 더블클릭 실행 · **rAF 안 씀**(상태가 바뀔 때 곧바로 그림) ·
**성취기준 없음**(루트 규칙) · 학습목표·활동안내 + 확인문제(눌러서 정답 확인) + 교사용 안내(`<details>`).
**결론(insight)은 4번 만져 본 뒤에 나타난다** — 먼저 읽어 버리면 조작할 이유가 없어진다.

⚠ **교사용 안내는 같은 파일의 접힌 칸이라 학생도 펼칠 수 있다**(사용자가 알고 고름).
프롬프트에 «teacherNote 에 정답을 적지 마라» 를 못박아 두었다.

⚠ **`js/ai.js` 의 `max_tokens` 를 4096 으로 되돌리지 말 것** — 시뮬 설정이 중간에 잘린다. 지금 16000.

---

## 6. 상세 수정 지침

### A. 기반 정비

1. **Tailwind 제거** — 원본은 마크업 전체가 Tailwind 유틸 클래스다. 두 갈래:
   - **(권장·저위험)** 원본 클래스를 그대로 두고, 빌드 때 `npx tailwindcss -i src.css -o css/app.css --content ./index.html --minify` **1회** 실행해 쓰인 클래스만 담은 정적 CSS 를 vendor. 런타임 CDN 0. `file://` 더블클릭·오프라인 OK. (Node 는 개발 PC 에만 필요 · `data-convert` 등이 이미 npm 사용)
   - (더 깔끔) `css/app.css` 를 손으로 쓰고 마크업을 의미 클래스로 재작성 — 다른 프로젝트 앱 방식이지만 품이 크다.
2. **폰트** — `@import` 삭제. `body { font-family: 'Pretendard Variable', Pretendard, -apple-system, 'Malgun Gothic', '맑은 고딕', sans-serif; }` (네트워크 의존 0 · 한국 Win 은 맑은 고딕으로 폴백).
3. **글자·버튼 크게** (루트 규칙) — 교실 TV 대비. 본문 최소 15px, 버튼 큼직하게.
4. **파일 나누기(선택)** — 원본 단일 파일 유지해도 되나, 권장 구조:
   ```
   lesson-designer/
   ├─ index.html
   ├─ css/app.css              (vendor 된 tailwind 또는 손 css)
   ├─ js/standards.js          (★ 성취기준 25개 + 편집기 — 단일 출처)
   ├─ js/ai.js                 (★ AI 설정 모달 + callAI 어댑터 + 프롬프트)
   ├─ js/lesson.js             (3·4단계 생성/렌더 — 원본 <script> 를 옮긴 것)
   ├─ js/print.js              (프로젝트 공용 복제 — §6-F)
   ├─ server.py  로컬서버_실행.bat
   ├─ .nojekyll
   ├─ CLAUDE.md  참고_원본_index.html
   └─ tools/사이트에_올리기.py  (배포 · 나중에)
   ```
5. **`server.py`** — 다른 앱(`mb-noise` 등)의 `server.py` 복제. **포트 9300.** `ThreadingHTTPServer`.
   `data/`·`CLAUDE.md`·`tools/`·`*.bat`·`참고_원본_index.html` 은 정적으로 내주지 않는다.
   `print` 문에 `—`(em dash)·`✗` 쓰지 말 것(CP949 콘솔에서 죽는다 · 루트 규칙).
6. **`로컬서버_실행.bat`** — **CP949(ANSI) + CRLF** 로 저장(루트 [산출물 규칙]).
   편집 도구는 UTF-8+LF 라 저장 후 `[System.IO.File]::WriteAllText($f,$t,[Text.Encoding]::GetEncoding(949))` 로 변환.
7. **launcher 등록** — `C:\project_AI\launcher\server.js` 의 `APPS` 에 한 줄:
   `{ key:'lesson-designer', group:'업무용', port:9300, run:['python','server.py'], file:'index.html', name:'수업 설계 도우미', desc:'성취기준→과정안→활동지, AI 생성' }`
8. **루트 `CLAUDE.md`** — [앱 목록] · [폴더 배치 규칙] · launcher 포트표(9300)에 한 줄씩 추가.
   여러 창이 루트를 함께 고치니 `Edit` 로만, 고치기 전·후 `grep` 확인(루트 규칙).

### B. 성취기준 25개 + 편집기 (`js/standards.js`)

- **출처**: `C:\project_AI\01. 교육과정\중학교교육과정_성취기준.md` (25개 · 5영역 3/5/9/5/3).
  영역명은 **2022 개정 공식 명칭**: (1) 컴퓨팅 시스템 (2) 데이터 (3) 알고리즘과 프로그래밍 (4) 인공지능 **(5) 디지털 문화** ← 원본은 "디지털 사회와 시민" 으로 적음, 공식은 "디지털 문화".
- 데이터 모양(원본 `standardsData` 확장):
  ```js
  window.STANDARDS = {
    "9정01-01": {
      area: "컴퓨팅 시스템",
      text: "[9정01-01] 컴퓨팅 시스템의 구성요소와 동작 원리를 이해하고, 운영 체제의 기능을 분석한다.",
      sentences: [ "(학생은) 컴퓨팅 시스템의 구성요소를 이해한다.", "(학생은) 동작 원리를 이해한다.", "(학생은) 운영 체제의 기능을 분석한다." ]
    },
    // … 25개
  };
  ```
  `sentences` 는 원본 8개의 문체(`(학생은) ~한다.` / 배경 문장은 `~한다.`)를 따라 **사람이 작성**한다(AI 분해 안 씀 — 결정 로그 5).
  원본에 이미 있는 `9정04-01`~`9정05-03` 8개는 원본 문장을 **그대로 재사용**.
- **편집기**: 내장본 + 사용자 편집본을 병합. 사용자 편집본은 `localStorage['ld.standards.v1']`(JSON).
  추가/수정/숨김/되돌리기 + JSON 파일 가져오기·내보내기. 잘못된 JSON 은 이유를 말하고 **기존 편집본을 지우지 않는다**.
- `<select>` 옵션과 1단계 카드가 이 병합 결과를 읽도록 원본 `selectElement.change` 를 수정.

### C·D. AI 설정 + 어댑터 (`js/ai.js`)

```js
// 제공자별 호출. 성공 시 생성 텍스트(string) 반환, 실패 시 throw.
async function callAI(provider, key, model, system, user) {
  if (provider === "claude") {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": key,
        "anthropic-version": "2023-06-01",
        "anthropic-dangerous-direct-browser-access": "true"   // ← 브라우저 CORS 허용에 필수
      },
      body: JSON.stringify({
        model, max_tokens: 4096,
        system: system || undefined,
        messages: [{ role: "user", content: user }]
      })
    });
    if (!r.ok) throw new Error("claude " + r.status + " " + await r.text());
    const j = await r.json();
    return j.content.map(b => b.text || "").join("");
  }

  if (provider === "openai" || provider === "upstage") {
    const base = provider === "openai"
      ? "https://api.openai.com/v1/chat/completions"
      : "https://api.upstage.ai/v1/chat/completions";        // Solar · OpenAI 호환
    const r = await fetch(base, {
      method: "POST",
      headers: { "content-type": "application/json", "authorization": "Bearer " + key },
      body: JSON.stringify({
        model,
        messages: [
          ...(system ? [{ role: "system", content: system }] : []),
          { role: "user", content: user }
        ]
      })
    });
    if (!r.ok) throw new Error(provider + " " + r.status + " " + await r.text());
    const j = await r.json();
    return j.choices[0].message.content;
  }

  if (provider === "gemini") {
    const url = "https://generativelanguage.googleapis.com/v1beta/models/"
      + encodeURIComponent(model) + ":generateContent?key=" + encodeURIComponent(key);
    const r = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        systemInstruction: system ? { parts: [{ text: system }] } : undefined,
        contents: [{ role: "user", parts: [{ text: user }] }]
      })
    });
    if (!r.ok) throw new Error("gemini " + r.status + " " + await r.text());
    const j = await r.json();
    return (j.candidates?.[0]?.content?.parts || []).map(p => p.text || "").join("");
  }
  throw new Error("알 수 없는 제공자: " + provider);
}
```

- **CORS 상태**:
  - Claude — `anthropic-dangerous-direct-browser-access: true` 헤더로 브라우저 직접 호출 허용됨.
  - OpenAI · Gemini — 브라우저 직접 호출 허용됨(널리 쓰임).
  - **Upstage — 미확인.** 브라우저에서 막히면(응답에 `Access-Control-Allow-Origin` 없음) `server.py` 에 `/proxy/upstage` 중계를 두어 **로컬 서버 모드에서만** 되게 한다. 공개 배포(GitHub Pages)에서 Upstage 가 CORS 를 막으면 그 제공자만 "이 제공자는 로컬 서버로 여실 때만 됩니다" 안내.
- **모델 기본값** — 확정 전에 사용자에게 물을 것. 임시 자리표시자:
  | 제공자 | 자리표시자(확인 필요) |
  |---|---|
  | claude | `claude-sonnet-5` (비용 아끼려면 `claude-haiku-4-5-20251001`) |
  | openai | (최신 chat 모델 · 문서 확인) |
  | gemini | (최신 flash 모델 · 문서 확인) |
  | upstage | (`solar-pro` 계열 · 문서 확인) |
- **JSON 응답 파싱** — 모델이 코드펜스(```` ```json ````)로 감쌀 수 있으니 `text.replace(/^```(json)?/,'').replace(/```$/,'').trim()` 후 `JSON.parse`. 실패하면 1회 재요청("JSON 만, 코드펜스 없이").
- **비용/지연 안내** — 3단계 전체 생성은 차시 수만큼 호출한다. 화면에 "차시 N개 → 호출 N회" 를 미리 알린다.

### E. 3단계 — AI 과정안 (`js/lesson.js`)

- `generateDefaultLessonPlan()` 은 **그대로 둔다**(키 없을 때 폴백 + AI 실패 폴백).
- 새 함수 `async function aiLessonPlan(std, evalMethods, objective, hour, totalHours)`:
  - `system` / `user` 프롬프트는 §7.
  - 반환 JSON 을 `{ standard: std.text, objective, intro, dev, conclusion, prep, ai }` 로 매핑.
- 원본 `btnNextStep2` 핸들러를 `async` 로 바꿔 순차(또는 3개씩 병렬) 호출. 진행률 표시.
- ⚠ `standard` 칸은 **AI 가 만들지 않는다** — 성취기준 원문(`std.text`)을 그대로 넣는다(환각 방지).

### F. 4단계 — AI 활동지 (`js/lesson.js` + `js/print.js`)

- **`js/print.js` 재사용을 권장한다.** 프로젝트 8개 앱이 같은 파일을 쓰고, A4 인쇄 문서를 만들어
  주며 **정답 칸(`a`·`ans`·`answer`·`key`)을 자동으로 지운다.** 복제해 오고 md5 를 맞춘다:
  ```bash
  cd C:\project_AI && md5sum */js/print.js | sort   # 9곳이 같은 값이어야 함
  ```
- AI 가 문항을 **print.js 스키마**로 반환하게 한다(§7). 유형: `choice` · `multi` · `ox` · `short`/`num` · `text` · `perform`(→ `text` 로 렌더) · `info`.
- **학생 배부용** = `Print.sheet(items, { title: hour+"차시 활동지", nameLine: true })` — print.js 가 `ans`/`key` 를 지운다.
  🚨 **print.js 는 `q`·`opts` 안의 내용은 안 지운다** — AI 프롬프트에서 **선택지에 `<b>`·★·✓·"(정답)" 을 넣지 말라**고 못박는다(루트 규칙 · `mb-noise` 에서 "굵은 글씨만 고르면 다 맞는" 학습지가 나간 사고).
- **교사용** = 같은 items 를 별도 렌더러로(정답·루브릭·성취기준 포함). `@media print` 로 학생/교사 전환.
- **`.hwp`** = 원본 `downloadHWP` 를 문항 반영하도록 고침. 성취기준 뺀다.
- **검사** — `tools/검사/verify_sheet.cjs` 를 `mb-noise` 에서 복제해 넣는다(선택지 강조·정답 쏠림·"가장 긴 선택지가 정답" 탐지).

### G. 사이드바

머리말(`<aside>` 상단, 원본 39–46행)에 `[⚙ AI 설정]` 버튼. 모달은 `js/ai.js` 가 그린다.

---

## 7. AI 프롬프트 설계 (초안 · `js/ai.js` 에 상수로)

### 3단계 — 과정안

**system**
```
당신은 대한민국 중학교 「정보」 교과 수석교사다. 2022 개정 정보과 교육과정에 맞춘
차시별 수업 과정안을 만든다. 학생 활동 중심, 실습 가능, 학교 현장에서 바로 쓸 수 있게.
반드시 아래 키만 가진 JSON 하나로만 답한다(코드펜스 금지):
{"intro": "...", "dev": "...", "conclusion": "...", "prep": "...", "ai": "..."}
- intro: 도입(동기유발·학습목표 안내). "▶ " 로 시작하는 줄들.
- dev: 전개. "[활동 1] ...", "[활동 2] ..." 형식. 각 활동에 학생이 실제로 하는 행동을 구체적으로.
- conclusion: 정리·형성평가·차시 예고.
- prep: 교사 준비물. "- " 목록.
- ai: 이 차시에서 생성형 AI/AI 도구를 학습 도구로 쓰는 구체적 방법 1~2가지. "▶ " 로 시작.
성취기준 코드·문장은 넣지 마라(따로 관리한다).
```

**user** (치환)
```
성취기준: {std.text}
이 차시 학습목표: {objective}
전체 {totalHours}차시 중 {hour}차시.
1단계에서 교사가 고른 평가 방식: {evalMethods join ", "}   // 예: 지필, 수행
학생 수준: 중학교 1~3학년. 45분 수업.
```

### 4단계 — 문항

**system**
```
당신은 중학교 「정보」 평가 문항 출제자다. 주어진 차시 학습목표와 평가 방식에 맞는 문항을 만든다.
아래 스키마의 JSON 배열 하나로만 답한다(코드펜스 금지). 각 원소:
{"k":"choice|multi|ox|short|text|perform", "q":"문두", "opts":["...","..."](choice/multi만),
 "a": 정답(choice=정답 인덱스, ox=true/false, short=모범답안 문자열, text/perform=채점 포인트 배열),
 "why":"해설"}
규칙:
- opts(선택지) 안에 굵게·별표·"(정답)" 같은 정답 힌트를 절대 넣지 마라.
- 정답이 항상 같은 위치에 오지 않게 섞어라. 가장 긴 선택지를 정답으로 만들지 마라.
- 학습목표에 정확히 맞추고, 중학생 어휘로.
개수: {count}개. 난이도: {level}.   // level = 하|중|상|혼합
```

**user**: `학습목표: {objective}\n평가 방식: {evalMethods}\n성취기준(참고, 문항에 코드 노출 금지): {std.text}`

### 루브릭

**system**: `수행·서술형 문항의 3수준(상·중·하) 분석적 루브릭을 JSON 으로. {"criteria":[{"name":"...", "levels":{"상":"...","중":"...","하":"..."}}]}`

---

## 8. 개발 상태 / 다음 할 일

### 상태 : 1차 완성 (2026-08-29) — 화면 4개 + AI 어댑터 + 성취기준 편집기 · 콘솔 오류 0

**만든 것**

| 파일 | 내용 |
|---|---|
| `index.html` | 사이드바(4단계 + ⚙ AI 설정) · 4개 `.step-view` · 행동용어표(원본 13행 이식) |
| `css/app.css` | 손으로 쓴 CSS (Tailwind 제거) · 시스템 폰트 스택 · 인쇄 CSS 는 없음(print.js·교사창이 각자) |
| `js/standards.js` | `window.Standards` — 내장 25개(원본 8개 재사용 + 17개 신규) + 편집·숨김·되돌리기 + `autoSplit` + JSON 반출입 · `localStorage['ld.standards.v1']` |
| `js/ai.js` | `window.AI` — 설정 모달(제공자 4종·키·모델·[연결 테스트]·[키 지우기]) + `rawCall`(claude/openai/gemini/upstage) + `call({json})` + 프롬프트 6종 · `localStorage['ld.ai.v1']` |
| `js/lesson.js` | 1~5단계 전체 흐름 · 템플릿 8종(원본 이식) + `aiLessonPlan`/`genItems`/`genRubric`/`genLevels`/`genSim` · Markdown · 학생/교사 인쇄 · `.hwp` · 시뮬 미리보기·내려받기 |
| `js/sim.js` | **5단계 시뮬레이터 뼈대 4종** + 프롬프트 + `validate` + `buildHTML` (아래 §5-1) |
| `js/print.js` | 프로젝트 공용 복제 (md5 `51e2ea54029bc109589a19913982fb63` · 10곳) |
| `server.py` | 포트 9300 · `ThreadingTCPServer` · `CLAUDE.md`·`server.py`·`참고_원본_index.html`·`*.bat`·`tools/` 차단 |
| `로컬서버_실행.bat` | CP949 + CRLF (35 CRLF · LF-only 0) |
| `.nojekyll` | 빈 파일 |
| `배포_시작하기.bat` | 초보자용 배포 마법사 실행 (CP949+CRLF · 파이썬 없으면 안내) |
| `tools/배포_도우미.py` | 대화형 마법사 — 도구 점검·설치안내 · `gh auth login`·`gh repo create`·Pages · `배포설정.json` 작성 · 미리보기 후 push. 모든 `input()` 은 EOF 안전 |
| `tools/사이트에_올리기.py` | **설정 파일 기반** 배포 — `tools/배포설정.json` 에서 repo_url·app_path·stage_prefix 읽음 · 빈 저장소/루트 배포/단일·두단계 처리 · 검사 먼저(node 없으면 안내) · 남의 커밋 확인 · `?v=` 새김 |
| `tools/배포설정.example.json` | 위를 복사해 `배포설정.json` 으로. `_` 로 시작하는 키는 설명(스크립트가 무시) |
| `tools/검사/verify_deploy.cjs` | 배포 전 안전검사 **32건** — API 키 누수 · `print.js` md5 · 외부 의존성 0 · 학생 인쇄물에 성취기준/정답 미전달 · 성취기준 25개 · [키 지우기] 유지 · 5단계(sim.js 배포 목록·rAF 없음·BAN 목록·프롬프트 규칙·max_tokens≥8000) · **1단계 문장 카드 편집 가능(contenteditable·추가/저장/되돌리기 버튼·화면 문장을 읽음)** |
| `tools/검사/verify_sim.cjs` | 시뮬레이터 검사 **60건** — 견본 4종 통과 · 나쁜 계산식 차단 · 분류기 동작 · 만들어진 HTML (AI 키 없이 돈다) |

**브라우저에서 확인한 것** (`http://localhost:9300` · Chrome)

| 확인 | 결과 |
|---|---|
| 콘솔 오류 | 1→2→3→4단계 전 과정 · 모달 · 편집기 · 커스텀 성취기준 추가/삭제 = **0건** |
| 단계 전환 | `.step-view` 중 `.active` 하나만 `display:flex`, 나머지 `none` |
| 1단계 | 25개 성취기준이 영역 5개 optgroup 으로 · 선택 시 문장 카드 생성 · 드래그·체크박스 |
| 1→2단계 | 평가방식 그룹화(지필/수행/관찰) · 예상 차시 입력칸 자동 생성 · footer 표시 |
| 2→3단계 | 템플릿 모드 : 9정04-02 선택 시 intro/dev/conclusion/prep/ai 가 원본 템플릿으로 채워짐 · `#btn-ai-all` 은 키 없어 disabled |
| 3→4단계 | ws-card 차시 수만큼 · AI 버튼 3개 disabled(키 없음) · 인쇄/hwp/빈문항 버튼은 활성 · 「성취 기준 (교사용 · 학생 배부본 제외)」 라벨 |
| 성취기준 편집기 | 목록 25행 · `autoSplit` 2문장 정상 · 커스텀(TEST-01) 추가 → select 27옵션 → 카드 렌더 → 삭제 → 26옵션 |
| Markdown 저장 | `정보과_수업과정안_1차시.md` · `text/markdown` · 879B · 오류 0 |
| `.hwp` 저장 | `학생활동지_1차시.hwp` · `application/vnd.hancom.hwp` · 오류 0 |
| 학생 인쇄 누수 | `Print.build` 결과에 해설(`why`)·정답 번호 **없음** (선택지 텍스트는 남음 → 프롬프트가 «선택지에 정답 힌트 금지» 로 막음) |
| 반응형 | 1280 · mobile 375 둘 다 가로 스크롤 없음 · 375 에서 사이드바가 가로 nav 로 |
| launcher | `.claude/launch.json` + `launcher/server.js` APPS 에 9300 등록 |
| **5단계 화면** | 1→5단계 통과 · 「인공지능 학습 데이터」 목표에 **classify 를 정확히 추천** · 유형 전환 · 키 없으면 생성 버튼 disabled |
| **5단계 생성 전 과정** | AI 를 가짜로 바꿔 시험 : 검사 통과(계산 12회) → iframe `sandbox="allow-scripts"` 미리보기(22,645자) → 내려받기 `학습도움자료_1차시_….html` 23KB · 성취기준·CDN 누수 0 |
| **만들어진 시뮬 4종 실제 동작** | `tradeoff` 캔버스 잉크 1847 · 손잡이 최소/최대에서 지표 반대로(800↔40 / 96.5↔30) · 프리셋 · 결론이 4번 만진 뒤 나타남<br>`steps` 13→**1101** · 7→**111** · 예시 100 은 8단계 · 진행표시 정확<br>`compare` 10개→5 vs 3.32, 1000개→500 vs 9.97 · 「더 좋음」 배지 이동 · 캔버스 잉크 1891<br>`classify` 전부 켜면 100% · 고양이 빼면 **50% + 편향 경고** · 전부 빼면 «판단 불가» ❔❔❔❔ · 되돌리면 100% |
| 확인 문제 | 선택지 클릭 → `opt right` + 해설 표시 |
| **1단계 문장 편집** | contenteditable 편집 · `✕` 삭제 · `＋ 문장 추가` · Enter 로 새 문장 · 편집한 문장이 2단계 그룹화로 그대로 넘어감 · `💾 저장` 뒤 재선택해도 유지 · `↺ 되돌리기` 로 기본 3문장 복구 · 손잡이(≡) 드래그로 순서 바꾸기 |
| **AI 키를 중간 단계에서 넣기** | 5단계에 머문 채 키 저장 → 3·4·5단계 버튼이 모두 활성 · 토스트 「모든 단계에 적용」 · 손으로 고친 3단계 글·만들어 둔 시뮬 유지 · 생성 중 저장해도 진행 중 카드 안 날아감 · 키 지우면 3단계만 템플릿으로 |

### 아직 못 한 것 / 다음 할 일

- [ ] **실제 AI 키로 4개 제공자 [연결 테스트] 1회씩** — 이 환경은 외부 fetch 를 하지 않았다.
      특히 **Upstage 브라우저 CORS** 가 되는지 미확인(막히면 로컬 서버 모드 안내가 뜨게 되어 있음).
- [ ] **3·4·5단계 AI 실제 생성 1회** — JSON 파싱·`stripFence`·폴백 경로는 코드로만 확인.
      **5단계는 특히 «AI 가 정말 쓸 만한 맞바꿈을 찾아내는가»** 를 봐야 한다(뼈대는 확인 끝).
      실패하면 프롬프트의 «반드시 반대로 움직여야 한다» 를 더 강하게 쓰거나 유형별 예시를 넣는다.
- [ ] **`.hwp`·`.md` 가 실제로 파일로 떨어지는지** + 한글에서 열리는지 1회.
- [ ] **인쇄 대화상자가 실제로 뜨는지** (이 환경은 팝업·인쇄를 안 띄운다 · HTML 은 `Print.build` 로 확인).
- [x] **`tools/검사/verify_deploy.cjs`** (16건) — API 키 누수 · `print.js` md5 · 외부 의존성 0 · 학생 인쇄물에 성취기준/정답 미전달 · 성취기준 25개.
- [x] **`tools/사이트에_올리기.py`** (화이트리스트 · mb-noise 판박이) — 검사 먼저 돌리고 실패 시 중단 · 남의 커밋 확인 · `?v=` 새김 · 점검/메인 두 단계.
- [x] **`geoje/lesson-designer/` 점검 배포 완료** (2026-08-30) — https://dadaschool.github.io/geoje/lesson-designer/
      라이브에서 1→5단계 전 과정·성취기준 25개·문장 편집·시뮬 유형 4종·유형 추천 확인, 콘솔 오류 0.
- [x] **업그레이드 채널 공개** (2026-08-30) — https://dadaschool.github.io/lesson-designer-dist/
      `latest.json` 1.0.0 · zip 122,661 bytes · sha256 `d8fd3b7e…`.
      **실제 인터넷 채널로** 0.9.0 → 업그레이드 → 되돌리기 → 다시 앞으로 전 과정 통과.
- [x] 루트 `CLAUDE.md` [앱 목록]·[폴더 배치 규칙]·launcher 포트표(9300)·[배포 스크립트] 표 반영.
- [ ] `dadaschool.github.io` 첫 화면 **업무용** 열에 추가 (메인 배포 때).
- [ ] `mb-noise/tools/검사/verify_sheet.cjs` 도 복제할지 검토 (문항 강조·정답 쏠림 검사 — AI 생성 문항에도 유용).
- [ ] **선생님 검토** — 25개 중 신규 17개의 `sentences` 문체·분해 단위가 적절한지, 템플릿 8종이 실제 수업과 맞는지.
- [ ] 사용자가 **「메인으로 배포해」** 하면 루트로.

---

## 8-3. 자체 업그레이드 / 되돌리기 (2026-08-30 사용자 지시 · 코디네이터 방식)

*"업그레이드 메뉴도 만들어서 처리할 수 있나? 코디네이터 앱 형태로 …
깃허브에 업그레이드 자료 올리고 업데이트 확인해서 자료 있으면 링크 클릭해서 업그레이드 하고,
이전 버전 백업하고, 업그레이드 이전 버전으로 돌리는것까지 모두 포함하게"*

### 두 방향을 헷갈리지 말 것

| | 무엇 | 도구 |
|---|---|---|
| **내보내기** | 이 폴더의 앱 파일 → **그 사람의 GitHub Pages** | `tools/사이트에_올리기.py` (메뉴 1) |
| **받아오기** | **dadaschool 이 낸 새 버전** → 그 사람의 폴더 | `tools/upgrade.py` (메뉴 2·3) |

**업데이트 채널은 언제나 dadaschool 소유다**(`MANIFEST_URL`).
배포 대상만 그 사람 계정이다. 이 분리를 뒤집지 말 것 — 그 사람은 채널에 쓸 권한이 없다.

### 파일

| 파일 | 역할 |
|---|---|
| `tools/version.txt` | 지금 버전 (`1.0.0`). **화면 왼쪽 아래 `#app-ver` 와 같아야 한다**(검사가 잡는다) |
| `tools/upgrade.py` | `check` / `apply_update` / `revert` / `list_backups` / `verify_tree` |
| `tools/꾸러미_만들기.py` | (개발자 전용) zip + `latest.json` + 안내 페이지를 만든다. **검사를 먼저 돌리고** `index.html` 버전 표시까지 맞춘다 |
| `배포_안내.md` | 초보자용 안내 (0~11장) — 꾸러미에 함께 들어간다 |

### 업그레이드 순서 (`apply_update`)

`latest.json` 확인 → 내려받기 → **크기 · sha256** 대조 → zip 경로 안전성(`..`·절대경로) →
풀어서 **`verify_tree`**(필수 파일 14개 · 모든 `.py` 컴파일 · 모든 `.js` `node --check` · `.bat` CP949) →
**지금 것을 `업그레이드백업\판갈이전-<시각>\` 에 통째 백업** → 덮어쓰기 → **새 꾸러미에 없는 옛 파일 정리**.
하나라도 실패하면 **파일을 하나도 건드리지 않는다.**

### 되돌리기 (`revert`)

백업도 **같은 `verify_tree` 로 검사** → **되돌리기 직전의 지금 것도 먼저 백업**(`되돌리기전-…`,
다시 앞으로 갈 수 있게) → 복원.

### 🔴 절대 건드리지 않는 것

```python
KEEP_TOP   = {"업그레이드백업", "__pycache__", ".git", "배포본", ".claude", "node_modules"}
KEEP_FILES = {"tools/배포설정.json", "참고_원본_index.html"}
SKIP_SUFFIX= (".zip", ".pyc", ".log", ".tmp", ".bak")
```
**`tools/배포설정.json`(그 사람의 저장소 설정)과 `배포본\`(저장소 사본)이 살아남아야**
업그레이드 뒤에 다시 설정하지 않고 바로 배포할 수 있다. 이것이 이 기능의 핵심이다.
`.zip` 을 거르는 이유 : 폴더에 zip 을 두면 꾸러미가 자기 자신을 삼켜 크기가 두 배가 된다(실제로 겪음).

### 새 버전 내는 법 (개발자)

```bash
cd C:\project_AI\lesson-designer
python tools/꾸러미_만들기.py --버전 1.1.0 --메모 "무엇을 고쳤는지"
cd C:\project_AI\배포본\dadaschool.github.io
git pull --rebase && git add lesson-designer-dist && git commit -m "..." && git push
```
🚨 **이미 공개한 번호를 덮지 말 것** — 그 PC 가 「이미 최신」이라고 답해 그 수정을 영원히 못 받는다
(`--덮어쓰기` 없이는 스크립트가 막는다).
⚠ `lesson-designer-dist/` 는 **사이트 첫 화면 목록에 넣지 않는다** — 사람이 볼 앱이 아니라
프로그램이 읽는 채널이다(`ai-coordinator/update/` 와 같은 성격). [사이트 아카이빙 규칙]의 예외.

---

## 8-2. AI 설정을 «아무 단계에서나» 바꿔도 모두 적용된다 (2026-08-29 사용자 신고)

*"처음에 API키를 설정하고 시작하지 않으면 … 해당 단계에서는 적용되지 않아.
어느 단계에서든지 API키를 설정하고 나면 모두 적용된 상태로 보이게 해."*

- 원인 : `AI.onChange` 가 **사이드바 배지만** 바꾸고, 이미 그려진 3·4·5단계 화면은 그대로였다.
- 고침 : `refreshAiState()` 가 `AI.onChange` 에 걸려 **3·4·5단계 중 그려져 있는 것을 모두 다시 그린다**
  (`renderStep3/4/5`). 화면의 값(과정안 글·문항·시뮬)은 전부 `generatedPlans` 에 있으므로 잃는 것이 없다.
  키가 새로 생기면/지워지면 **토스트**로 알린다(`lastReady` 로 «바뀜» 을 판정).
- 🔴 **생성 중에는 다시 그리지 않는다** — `aiBusy` 카운터. 여섯 생성 함수(`regenOne`·`regenAll`·
  `genItems`·`genRubric`·`genLevels`·`genSim`)를 `busy(async …)` 로 감쌌다. 안 그러면 생성 도중
  설정을 저장하는 순간 진행 표시·미리보기가 붙어 있던 카드가 통째로 날아간다(브라우저로 확인).
- 사이드바로 3·4·5단계에 **들어갈 때도** 다시 그린다(`navitem` 클릭 핸들러). ⚠ 3단계는
  `renderStep3()` 만 — `goStep3()` 는 학습목표 칸에서 과정안을 새로 만들어 AI 생성분을 지운다.

---

## 8-1. 배포 — **dadaschool 이 아닌 다른 계정/저장소 · 다른 PC · 초보자** (사용자 결정 2026-08-29)

### 처음이면 : `배포_시작하기.bat` 더블클릭 (대화형 마법사)

`tools/배포_도우미.py` 가 대신 해 준다 :
1. `git`·`node`·`gh`(GitHub CLI) 가 있는지 보고, 없으면 **설치 명령·링크를 화면에 띄우고** winget 설치를 제안
2. `gh auth login` 을 열어 **브라우저 로그인**을 안내 (device code 방식)
3. `gh repo create` 로 **저장소를 만들어 준다** (기본 추천 `<ID>.github.io` = Pages 자동)
4. `<ID>.github.io` 가 아니면 Pages 설정 페이지를 **열어 주고** 켜라고 안내
5. `tools/배포설정.json` 을 **대신 작성**
6. `verify_deploy.cjs` 실행 → **미리보기** → "올릴까요? y" → `git push`
- 사람이 하는 일은 **① 없는 프로그램 설치 ② 브라우저에서 로그인 버튼 ③ 미리보기 보고 y** 뿐.
- 매번 «지금 하실 일» 박스로 안내. 잘못 눌러도 다시 실행하면 됨(설정 기억).
- 두 번째부터는 "그대로 바로 올릴까요?" 로 시작 → 한 번에 재배포.

### 손으로 (마법사 없이)

올릴 곳을 **`tools/배포설정.json`** 에서 읽는다(git 아님 · `tools/` 라 배포에도 안 올라감).

```bash
cd C:\project_AI\lesson-designer
copy tools\배포설정.example.json tools\배포설정.json   # 값 채우기 (repo_url 등)
python tools/사이트에_올리기.py                # 저장소를 배포본\<local_dir>\ 에 클론 + 미리보기
python tools/사이트에_올리기.py --push         # 점검 폴더(stage_prefix)로  ※ stage_prefix:"" 면 이게 실배포
python tools/사이트에_올리기.py --push --메인   # 실제 위치(app_path)로  ← 「메인으로 배포해」 후
```

### 배포설정.json 키

| 키 | 뜻 |
|---|---|
| `repo_url` | 올릴 저장소. `https://<ID>@github.com/<ID>/<REPO>.git` — **`<ID>@` 를 넣어야** dadaschool 계정과 안 섞이고 그 계정으로 인증됨 |
| `local_dir` | `배포본\` 아래 클론될 폴더명 (비우면 repo_url 에서 자동) |
| `site_base` | 완료 후 화면에 찍을 주소 (기능 무관) |
| `app_path` | 앱을 둘 하위 폴더. `""` = 저장소 루트에 바로 |
| `stage_prefix` | 점검 배포 폴더(`geoje`). `""` = 점검 단계 없이 한 번에 |
| `branch` | Pages 소스 브랜치 |

### 동작

- **올리는 것** : `index.html` · `css/app.css` · `js/{standards,ai,lesson,print}.js` — **6개뿐**.
- **안 올리는 것** : `server.py` · `*.bat` · `CLAUDE.md` · `.nojekyll` · `tools/`(설정 포함) · **`참고_원본_index.html`**.
  `guard()` 가 하나라도 섞이면 **멈춘다.**
- **올리기 전 `tools/검사/verify_deploy.cjs` (16건)** — 하나라도 실패하면 배포 안 함.
  핵심은 **배포 파일에 API 키 문자열이 없는지**(교사가 키를 브라우저에 넣는 앱).
- `?v=날짜시각` 을 HTML 안의 `js`·`css` 주소에 새김 (Pages 10분 캐시 대비).
- **빈 저장소**(새로 만든 개인 repo)면 첫 배포로 초기 커밋 + `git push -u origin <branch>`.
- **루트 배포**(`app_path=""`)는 `rmtree` 를 안 하고 `git add index.html css js` 로 우리 파일만 교체.
- **인증** : 이 스크립트는 자격증명을 다루지 않는다.
  `gh auth login`(그 계정) → `gh auth setup-git`, 또는 자격증명 관리자가 첫 push 때 로그인 창을 띄운다.
  두 계정을 오가면 push 직전에 `gh auth switch`.
- 커밋 이름을 바꾸려면 클론 폴더에서 : `git -C 배포본\<local_dir> config user.name/user.email`.
- ⚠ 이 앱은 **dadaschool.github.io 아카이빙 규칙(첫 화면 목록)과 무관**하다. `update_root_index` 없음.

---

## 9. 규칙 준수 체크리스트 (루트 CLAUDE.md 근거)

- [ ] 배포되는 파일에 **API 키 문자열 0** (기본값 빈 문자열 · localStorage 만).
- [ ] 학생이 받는 인쇄물·`.hwp` 에 **성취기준·정답·루브릭 없음** (교사용은 포함).
- [ ] 학생 개인정보 수집 0 (이름칸은 인쇄물의 손글씨 자리뿐 · localStorage 에 학생 정보 안 넣음).
- [ ] 화면 문구 전부 한국어 · 글자/버튼 크게 · 코드 주석 한국어.
- [ ] `.bat` = CP949(ANSI) + CRLF · `chcp` 쓰지 않음 · `server.py` `print` 에 CP949 밖 글자 금지.
- [ ] 외부 런타임 의존성 0 (tailwind 는 빌드 때 1회 · CDN `<script>` 없음) · `file://` 더블클릭 동작.
- [ ] `requestAnimationFrame` 안 씀(미리보기 브라우저가 프레임 안 그림) · 확인은 좌표 재는 텍스트 검사.
- [ ] 배포는 **geoje 먼저**, 루트는 **「메인으로 배포해」** 를 들었을 때만. push 전 `git log origin/main..HEAD` 로 남의 커밋 확인.
- [ ] `js/print.js` 복제 시 9곳 md5 일치 확인. 고치면 9곳 모두.
- [ ] `참고_원본_index.html`·`CLAUDE.md`·`tools/`·`server.py`·`*.bat` 은 배포에서 제외.

## 10. 검증 방법

- **AI 어댑터** — 각 제공자에 실제 키로 [연결 테스트] 1회씩(개발자 로컬). 키 없을 때 템플릿 모드가 끝까지 동작하는지.
- **성취기준** — 병합/숨김/되돌리기/JSON 반출입. 잘못된 JSON 8종에 하던 작업 안 지우는지.
- **문항** — `verify_sheet.cjs`(선택지 강조·정답 쏠림·최장=정답). 학생 인쇄물에 성취기준·정답 문자열이 없는지 `grep`.
- **인쇄 레이아웃** — 창 높이 900·768 에서 좌표 재는 텍스트 검사(스크린샷 불가). `@media print` 로 학생/교사 전환 확인.
- **CP949** — `.bat` 을 `Get-Content -Encoding Default` 로 읽어 한글 안 깨지는지. `server.py` 켜서 콘솔 출력 정상인지.
