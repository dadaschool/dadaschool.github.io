# -*- coding: utf-8 -*-
"""
수업 설계 도우미 · 로컬 서버 실행 도우미

- 파이썬 기본 모듈만 사용한다. 추가 설치나 인터넷 연결이 필요 없다.
  (AI 호출은 브라우저가 직접 하며, 이 서버를 거치지 않는다.)
- 이 파일이 있는 폴더(lesson-designer)를 웹 루트로 삼아 서버를 켜고,
  브라우저에서 index.html 을 자동으로 열어 준다.
- 9300번 포트가 이미 쓰이고 있으면 9301, 9302 ... 순서로 빈 포트를 찾는다.
  (다른 앱들의 포트 목록은 루트 CLAUDE.md 의 [launcher] 항목을 볼 것.)

실행 방법
  1) 로컬서버_실행.bat 을 더블클릭          (가장 쉬움)
  2) 또는 명령창에서  python server.py
     브라우저를 자동으로 열지 않으려면  python server.py --no-browser
  종료 : 명령창에서 Ctrl + C

※ index.html 을 그냥 더블클릭해도 모든 기능이 동작한다(외부 의존성 0개).

⚠ 이 파일의 print 문에는 CP949 에 없는 글자를 쓰지 말 것.
  한국어 Windows 콘솔은 CP949 라서 가로줄(em dash)이나 체크표를 찍으면
  UnicodeEncodeError 로 서버가 켜지자마자 죽는다.
"""

import functools
import http.server
import os
import socket
import socketserver
import sys
import threading
import webbrowser

ROOT = os.path.dirname(os.path.abspath(__file__))   # 이 파일이 있는 폴더 = 웹 루트
FIRST_PORT = 9300                                   # 처음 시도할 포트
TRY_COUNT = 20                                      # 몇 개까지 찾아볼지

# 학생/외부에 내줄 필요가 없는 것 (개발 문서 · 원본 참고본 · 검사 도구 · 배치파일)
BLOCK = ("claude.md", "server.py", "참고_원본_index.html")
BLOCK_DIR = ("tools/",)


def find_free_port(first, count):
    """빈 포트를 찾아 번호를 돌려준다. 못 찾으면 None."""
    for port in range(first, first + count):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
            probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                probe.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue          # 이미 쓰이는 포트 -> 다음 번호로
    return None


class Handler(http.server.SimpleHTTPRequestHandler):
    """수업 중 파일을 고쳐도 새로고침하면 바로 반영되도록 캐시를 끈다."""

    def end_headers(self):
        self.send_header("Cache-Control", "no-store, must-revalidate")
        super().end_headers()

    def do_GET(self):
        if self._blocked():
            self.send_error(404, "Not Found")
            return
        super().do_GET()

    def _blocked(self):
        path = self.path.split("?")[0].split("#")[0].lstrip("/").lower()
        if path.endswith(".bat"):
            return True
        if path in BLOCK:
            return True
        for d in BLOCK_DIR:
            if path.startswith(d):
                return True
        return False

    def log_message(self, fmt, *args):
        sys.stdout.write("  %s\n" % (fmt % args))


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


def main():
    index = os.path.join(ROOT, "index.html")
    if not os.path.exists(index):
        print("[오류] index.html 을 찾을 수 없습니다:", index)
        return 1

    port = find_free_port(FIRST_PORT, TRY_COUNT)
    if port is None:
        print("[오류] %d ~ %d 사이에 빈 포트가 없습니다." % (FIRST_PORT, FIRST_PORT + TRY_COUNT - 1))
        return 1

    url = "http://localhost:%d/index.html" % port
    handler = functools.partial(Handler, directory=ROOT)

    print("=" * 56)
    print("  수업 설계 도우미 · 로컬 서버")
    print("=" * 56)
    print("  주소   : %s" % url)
    print("  폴더   : %s" % ROOT)
    print("  종료   : 이 창에서 Ctrl + C  (또는 창 닫기)")
    print("=" * 56)

    with Server(("127.0.0.1", port), handler) as httpd:
        if "--no-browser" not in sys.argv:
            threading.Timer(0.7, lambda: webbrowser.open(url)).start()
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n서버를 종료합니다.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
