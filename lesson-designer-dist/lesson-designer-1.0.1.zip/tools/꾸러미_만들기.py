# -*- coding: utf-8 -*-
r"""
꾸러미_만들기.py — (개발자 전용) 업그레이드 꾸러미 + latest.json 을 만든다

  개발 PC 에서 앱을 고친 뒤 이것을 돌린다.
  결과 : 배포본\dadaschool.github.io\lesson-designer-dist\ 아래에
           lesson-designer-<버전>.zip
           latest.json
           index.html  (그 폴더가 무엇인지 알려 주는 짧은 페이지)
  그 뒤 사람이 손으로 :  cd 배포본\dadaschool.github.io  ->  git add/commit/push

쓰기
  python tools\꾸러미_만들기.py --버전 1.1.0 --메모 "무엇을 고쳤는지"
  (--버전 을 안 주면 tools\version.txt 의 끝자리를 +1 한다)

ai-coordinator 의 tools\업데이트_만들기.js 에 해당한다.
"""

import argparse
import datetime
import hashlib
import json
import os
import re
import subprocess
import sys
import zipfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import upgrade  # program_files · verify_tree · REQUIRED · vtuple

APP = upgrade.APP
ROOT = os.path.dirname(APP)
DIST = os.path.join(ROOT, "배포본", "dadaschool.github.io", "lesson-designer-dist")
DIST_URL = "https://dadaschool.github.io/lesson-designer-dist"


def die(*m):
    for x in m:
        print(x)
    sys.exit(1)


def run_checks():
    """올리기 전에 회귀 검사를 돌린다. 실패하면 꾸러미를 만들지 않는다."""
    if not __import__("shutil").which("node"):
        die("[멈춤] node 가 없어 검사를 돌릴 수 없습니다.")
    for name in ("verify_deploy.cjs", "verify_sim.cjs"):
        p = os.path.join(APP, "tools", "검사", name)
        r = subprocess.run(["node", p], cwd=APP, capture_output=True, text=True,
                           encoding="utf-8", errors="replace")
        last = [l for l in (r.stdout or "").strip().split("\n") if l.strip()]
        if r.returncode != 0:
            print(r.stdout)
            die("[멈춤] 검사 실패: " + name)
        print("  검사 통과 : %-20s %s" % (name, last[-1] if last else ""))


def next_version(cur):
    a, b, c = upgrade.vtuple(cur)
    return "%d.%d.%d" % (a, b, c + 1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--버전", "--version", dest="ver", default="")
    ap.add_argument("--메모", "--notes", dest="notes", default="")
    ap.add_argument("--덮어쓰기", "--force", dest="force", action="store_true")
    a = ap.parse_args()

    cur = upgrade.cur_version()
    첫배포 = not os.path.exists(os.path.join(DIST, "latest.json"))
    ver = a.ver.strip() or (cur if 첫배포 else next_version(cur))
    if not re.match(r"^\d+\.\d+\.\d+$", ver):
        die("버전은 1.2.3 모양이어야 합니다: " + ver)
    if upgrade.vtuple(ver) < upgrade.vtuple(cur):
        die("버전(" + ver + ")이 지금(" + cur + ")보다 낮습니다. --버전 으로 지정하세요.")
    if upgrade.vtuple(ver) == upgrade.vtuple(cur) and not 첫배포 and not a.force:
        die("이미 공개한 버전 " + ver + " 을 덮으려 합니다. 번호를 올리거나 --덮어쓰기.")
    zpath = os.path.join(DIST, "lesson-designer-" + ver + ".zip")
    if os.path.exists(zpath) and not a.force:
        die("이미 " + os.path.basename(zpath) + " 가 있습니다. 번호를 올리거나 --덮어쓰기.")

    print("")
    print("  검사 먼저 :")
    run_checks()

    # version.txt 를 새 버전으로 (꾸러미 안에 이 값이 들어간다)
    with open(upgrade.VERSION_FILE, "w", encoding="utf-8", newline="\n") as f:
        f.write(ver + "\n")

    # 앱 화면 왼쪽 아래의 버전 표시도 같이 맞춘다 (배포가 반영됐는지 눈으로 확인하는 자리)
    idx = os.path.join(APP, "index.html")
    t = open(idx, encoding="utf-8").read()
    pat = re.compile(r'(<div class="ver" id="app-ver">)v[\d.]+(</div>)')
    if not pat.search(t):
        die("[멈춤] index.html 에서 버전 표시(id=app-ver)를 찾지 못했습니다. "
            "화면에 버전이 안 나오면 배포가 반영됐는지 확인할 수 없습니다.")
    t2 = pat.sub(r"\g<1>v" + ver + r"\g<2>", t)
    if t2 != t:
        open(idx, "w", encoding="utf-8", newline="\n").write(t2)
        print("  index.html 의 버전 표시를 v" + ver + " 로 맞췄습니다.")
    else:
        print("  index.html 의 버전 표시는 이미 v" + ver + " 입니다.")

    os.makedirs(DIST, exist_ok=True)
    zip_name = "lesson-designer-" + ver + ".zip"
    zip_path = os.path.join(DIST, zip_name)

    files = upgrade.program_files(APP)
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for full, rel in files:
            z.write(full, rel)     # 최상위 폴더 없이 rel 그대로

    data = open(zip_path, "rb").read()
    sha = hashlib.sha256(data).hexdigest()
    size = len(data)

    manifest = {
        "version": ver,
        "date": datetime.date.today().isoformat(),
        "notes": a.notes.strip() or ("버전 " + ver),
        "url": DIST_URL + "/" + zip_name,
        "sha256": sha,
        "size": size,
    }
    with open(os.path.join(DIST, "latest.json"), "w", encoding="utf-8", newline="\n") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)

    # 그 폴더가 무엇인지 알려 주는 짧은 페이지 (사람이 주소로 들어왔을 때)
    with open(os.path.join(DIST, "index.html"), "w", encoding="utf-8", newline="\n") as f:
        f.write('<!doctype html><meta charset="utf-8"><title>수업 설계 도우미 · 배포 도구 업데이트</title>'
                '<body style="font-family:sans-serif;max-width:640px;margin:60px auto;padding:0 16px;line-height:1.7">'
                '<h1>수업 설계 도우미 — 배포 도구 업데이트 보관소</h1>'
                '<p>여기에는 「수업 설계 도우미」를 GitHub Pages 에 올리는 <b>배포 도구</b>의 새 버전 파일이 있습니다.</p>'
                '<p>배포 도구 폴더에서 <code>배포_시작하기.bat</code> 을 실행하고 메뉴에서 '
                '<b>「새 버전 확인 / 업그레이드」</b> 를 고르면 이 파일들을 자동으로 받아 갈아치웁니다.</p>'
                '<p>현재 최신 : <b>' + ver + '</b> (' + manifest["date"] + ')</p>'
                '<p><a href="latest.json">latest.json</a> · <a href="' + zip_name + '">' + zip_name + '</a></p>'
                '</body>')

    print("")
    print("  만들었습니다 -> " + DIST)
    print("     " + zip_name + "  (%d KB)" % (size // 1024))
    print("     latest.json   version=%s  sha256=%s..." % (ver, sha[:12]))
    print("     index.html")
    print("")
    print("  이제 손으로 올리세요 :")
    print("     cd " + os.path.join(ROOT, "배포본", "dadaschool.github.io"))
    print("     git pull --rebase")
    print("     git add lesson-designer-dist")
    print('     git commit -m "lesson-designer 배포 도구 %s"' % ver)
    print("     git push")
    print("")
    print("  ※ tools\\version.txt 도 " + ver + " 로 바꿔 두었습니다 (이 개발 폴더 = 최신).")


if __name__ == "__main__":
    main()
