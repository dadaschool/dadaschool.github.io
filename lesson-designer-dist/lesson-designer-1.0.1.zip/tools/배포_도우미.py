# -*- coding: utf-8 -*-
r"""
배포_도우미.py — 처음 배포하는 사람을 위한 대화형 도구 (메뉴)

메뉴
  1) 인터넷에 올리기 (배포)
       · 필요한 프로그램 확인 / 설치 안내
       · GitHub 로그인 (브라우저) / 저장소 만들기 / Pages 켜기
       · 설정 파일(tools/배포설정.json) 대신 작성
       · 검사 -> 미리보기 -> 올리기
       · 이미 예전 버전이 올라가 있으면 「새 버전으로 바꿉니다」 라고 알려 준다
  2) 새 버전 확인 / 업그레이드
       · 깃허브에서 새 버전이 있는지 보고, 있으면 받아서 갈아치운다
       · 지금 버전을 먼저 백업한다 (업그레이드백업\판갈이전-...)
  3) 업그레이드 이전 버전으로 되돌리기
       · 백업을 골라 그 버전으로 되돌린다 (되돌리기 직전 것도 먼저 백업)
  4) 그만두기

실행
  · 배포_시작하기.bat 을 더블클릭   (가장 쉬움)
  · 또는  python tools\배포_도우미.py

이 파일의 print 에 CP949 밖 글자(가로줄·세모 등)를 쓰지 말 것.
"""

import json
import os
import shutil
import subprocess
import sys
import webbrowser

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    import upgrade
except Exception:
    upgrade = None

APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # lesson-designer
CFG_PATH = os.path.join(APP, "tools", "배포설정.json")
DEPLOY_SCRIPT = os.path.join(APP, "tools", "사이트에_올리기.py")
VERSION_FILE = os.path.join(APP, "tools", "version.txt")

# ------------------------------------------------------------------ 화면 도우미
def line():
    print("=" * 64)

def title(t):
    print("")
    line()
    print("  " + t)
    line()

def box(head, items):
    print("")
    print("  +" + "-" * 58)
    print("  |  " + head)
    print("  |  " + "-" * (len(head) + 2))
    for it in items:
        print("  |  " + it)
    print("  +" + "-" * 58)
    print("")

def wait(msg="끝나면 이 창을 눌러 Enter 키를 누르세요. "):
    try:
        input("  >> " + msg)
    except EOFError:
        pass

def ask(prompt, default=""):
    d = (" [" + default + "]") if default else ""
    try:
        v = input("  ? " + prompt + d + " : ").strip()
    except EOFError:
        v = ""
    return v or default

def yn(prompt, default=True):
    d = "Y/n" if default else "y/N"
    try:
        v = input("  ? " + prompt + " (" + d + ") : ").strip().lower()
    except EOFError:
        v = ""
    if not v:
        return default
    return v in ("y", "yes", "ㅛ", "예", "네", "ㅇ")

def have(cmd):
    return shutil.which(cmd) is not None

def run(args, **kw):
    return subprocess.run(args, capture_output=True, text=True,
                          encoding="utf-8", errors="replace", **kw)

def run_show(args):
    """출력을 이 창에 그대로 흘려보낸다 (미리보기·배포 진행 상황용)"""
    return subprocess.call(args)

def stop(msg):
    print("")
    print("  [멈춤] " + msg)
    print("")
    wait("Enter 를 누르면 메뉴로 돌아갑니다. ")
    sys.exit(1)   # main() 의 메뉴 루프가 잡아서 메뉴로 돌아간다

# ------------------------------------------------------------------ 0. 환경 점검
def 환경점검():
    title("1단계 / 필요한 프로그램 확인")

    파이썬 = sys.version.split()[0]
    print("  [있음] Python " + 파이썬 + "  (이 마법사를 돌리는 중)")

    필수 = [
        ("git",  "Git",          "Git.Git",          "https://git-scm.com/download/win",
         "저장소를 내려받고 올리는 데 필요합니다."),
        ("node", "Node.js (LTS)", "OpenJS.NodeJS.LTS", "https://nodejs.org/ko",
         "올리기 전 안전 검사(verify_deploy)를 돌리는 데 필요합니다."),
    ]
    권장 = [
        ("gh",   "GitHub CLI",    "GitHub.cli",       "https://cli.github.com/",
         "이게 있으면 로그인·저장소 만들기·Pages 켜기를 마법사가 대신 합니다. 없으면 손으로 해야 합니다."),
    ]

    winget = have("winget")

    for cmd, name, wid, url, why in 필수:
        while not have(cmd):
            box("지금 하실 일 - " + name + " 설치",
                [why,
                 "",
                 ("방법 A) 이 창에 다음을 붙여넣고 Enter :" if winget else "설치 파일을 받아 설치하세요 :"),
                 ("   winget install --id " + wid + " -e --source winget" if winget
                  else "   " + url),
                 ("방법 B) " + url + " 에서 받아 설치" if winget else ""),
                 "",
                 "설치가 끝나면 이 창을 닫고 배포_시작하기.bat 을 다시 더블클릭하세요",
                 "(새 창이어야 방금 설치한 프로그램을 인식합니다)."])
            if winget and yn("지금 이 마법사가 winget 으로 설치를 시도할까요?", True):
                run_show(["winget", "install", "--id", wid, "-e", "--source", "winget"])
                print("")
                print("  설치가 끝났다면 이 창을 닫고 배포_시작하기.bat 을 다시 더블클릭하세요.")
                wait("Enter 를 누르면 다시 확인합니다. ")
            else:
                wait("설치를 끝냈으면 Enter (그래도 안 되면 창을 새로 열어 다시 실행). ")
            if not have(cmd):
                if not yn(name + " 을 아직 못 찾았습니다. 그래도 계속할까요? (권장하지 않음)", False):
                    stop(name + " 이 필요합니다. 설치 후 다시 실행하세요.")
                break
        if have(cmd):
            print("  [있음] " + name)

    for cmd, name, wid, url, why in 권장:
        if have(cmd):
            print("  [있음] " + name)
            continue
        box("선택 - " + name + " (강력 권장)",
            [why,
             "",
             ("설치 :  winget install --id " + wid + " -e --source winget" if winget
              else "설치 :  " + url),
             "",
             "설치하면 훨씬 쉬워집니다. 지금 설치하고 창을 새로 열어 다시 실행하는 것을 권합니다."])
        if winget and yn("지금 winget 으로 GitHub CLI 를 설치할까요?", True):
            run_show(["winget", "install", "--id", wid, "-e", "--source", "winget"])
            print("")
            print("  설치가 끝났으면 이 창을 닫고 배포_시작하기.bat 을 다시 더블클릭하세요.")
            wait("Enter 를 누르면 계속(설치했다면 창을 새로 여는 게 좋습니다). ")

    return have("gh")

# ------------------------------------------------------------------ 1. GitHub 로그인
def 깃허브로그인(gh_있음):
    title("2단계 / GitHub 로그인")
    if not gh_있음:
        box("GitHub CLI 없이 진행합니다",
            ["로그인·저장소 만들기를 손으로 하셔야 합니다.",
             "GitHub CLI(gh)를 설치하고 다시 실행하시는 것을 강력히 권합니다.",
             "계속하면, 배포할 때 자격증명 관리자 창에서 한 번 로그인하게 됩니다."])
        wait("이해했으면 Enter. ")
        return None

    r = run(["gh", "auth", "status"])
    if r.returncode == 0 and "Logged in to github.com" in (r.stdout + r.stderr):
        who = run(["gh", "api", "user", "-q", ".login"])
        name = who.stdout.strip()
        print("  이미 로그인되어 있습니다 : " + (name or "(확인 중)"))
        if name and not yn("이 계정(" + name + ")으로 배포할까요?", True):
            box("계정 바꾸기",
                ["이 창에서 다음을 실행하세요 :",
                 "   gh auth switch",
                 "또는 새 계정으로 로그인 :",
                 "   gh auth login"])
            wait("계정을 바꿨으면 Enter. ")
            who = run(["gh", "api", "user", "-q", ".login"])
            name = who.stdout.strip()
        return name or None

    box("지금 하실 일 - GitHub 로그인",
        ["곧 로그인 절차가 시작됩니다. 화면 안내대로 하시면 됩니다 :",
         "  1. 'GitHub.com' 을 고르세요 (화살표 + Enter)",
         "  2. 'HTTPS' 를 고르세요",
         "  3. 'Login with a web browser' 를 고르세요",
         "  4. 화면에 나오는 8자리 코드를 적어두고 Enter",
         "  5. 열리는 브라우저에 그 코드를 넣고 'Authorize' 를 누르세요",
         "끝나면 이 창으로 돌아옵니다."])
    wait("준비됐으면 Enter 를 눌러 로그인을 시작하세요. ")
    run_show(["gh", "auth", "login"])

    r = run(["gh", "auth", "status"])
    if r.returncode != 0:
        stop("로그인이 확인되지 않았습니다. 배포_시작하기.bat 을 다시 실행해 주세요.")
    who = run(["gh", "api", "user", "-q", ".login"])
    name = who.stdout.strip()
    print("  로그인 완료 : " + name)
    return name or None

# ------------------------------------------------------------------ 2. 저장소
def 저장소준비(gh_있음, username):
    title("3단계 / 올릴 저장소 정하기")

    if not username:
        username = ask("GitHub 사용자 이름(ID)")
        if not username:
            stop("사용자 이름이 필요합니다.")

    추천 = username + ".github.io"
    box("저장소 이름",
        [추천 + " 로 만들면 :",
         "  · 주소가 https://" + username + ".github.io/ 로 깔끔합니다",
         "  · GitHub Pages 가 저절로 켜집니다 (설정할 게 없음)",
         "다른 이름을 써도 되지만 Pages 를 손으로 켜야 할 수 있습니다."])
    repo = ask("저장소 이름", 추천)
    owner = username
    사용자사이트 = repo.lower() == (username + ".github.io").lower()

    있음 = False
    if gh_있음:
        v = run(["gh", "repo", "view", owner + "/" + repo])
        있음 = v.returncode == 0

    if 있음:
        print("  저장소가 이미 있습니다 : " + owner + "/" + repo)
    else:
        if gh_있음 and yn("'" + owner + "/" + repo + "' 저장소를 지금 만들까요? (공개)", True):
            c = run(["gh", "repo", "create", owner + "/" + repo,
                     "--public", "--description", "수업 설계 도우미"])
            if c.returncode != 0:
                print(c.stdout); print(c.stderr)
                box("저장소를 손으로 만들어 주세요",
                    ["github.com/new 를 엽니다",
                     "  Repository name : " + repo,
                     "  Public 선택",
                     "  'Create repository' 클릭"])
                webbrowser.open("https://github.com/new")
                wait("만들었으면 Enter. ")
            else:
                print("  저장소를 만들었습니다 : " + owner + "/" + repo)
        else:
            box("지금 하실 일 - 저장소 만들기",
                ["github.com/new 를 엽니다 (브라우저가 열립니다)",
                 "  Repository name : " + repo,
                 "  Public 선택",
                 "  README 등은 체크하지 않아도 됩니다",
                 "  'Create repository' 클릭"])
            webbrowser.open("https://github.com/new")
            wait("만들었으면 Enter. ")

    # Pages
    if 사용자사이트:
        print("  Pages : 사용자 사이트라 main 브랜치에 올리면 저절로 켜집니다.")
    else:
        켜짐 = False
        if gh_있음:
            p = run(["gh", "api", "repos/" + owner + "/" + repo + "/pages"])
            if p.returncode == 0:
                켜짐 = True
                print("  Pages : 이미 켜져 있습니다.")
        if not 켜짐:
            box("지금 하실 일 - GitHub Pages 켜기",
                ["아래 주소가 열립니다 :",
                 "  https://github.com/" + owner + "/" + repo + "/settings/pages",
                 "",
                 "  Source : 'Deploy from a branch'",
                 "  Branch : main  /  (root)   -> Save",
                 "",
                 "(저장소가 비어 있으면 먼저 이 마법사로 한 번 올린 뒤 켜도 됩니다)"])
            webbrowser.open("https://github.com/" + owner + "/" + repo + "/settings/pages")
            wait("켰거나, 나중에 켜기로 했으면 Enter. ")

    return username, owner, repo, 사용자사이트

# ------------------------------------------------------------------ 3. 배치
def 배치정하기(사용자사이트, repo):
    title("4단계 / 어디에 올릴지")

    질문 = ("이 앱을 사이트 첫 화면(주소 그대로)으로 할까요?"
            if 사용자사이트 else
            "이 앱을 저장소의 첫 화면으로 할까요?")
    루트 = yn(질문 + "  (아니오 = /lesson-designer/ 하위 주소)", 사용자사이트)
    app_path = "" if 루트 else "lesson-designer"

    box("점검 단계",
        ["'점검 단계' 를 켜면 : 먼저 숨은 주소(geoje/...)에 올려 확인하고,",
         "괜찮으면 실제 주소로 다시 올립니다. (안전하지만 두 번 해야 함)",
         "초보자는 '아니오'(한 번에 올리기)를 권합니다."])
    점검 = yn("점검 단계를 쓸까요?", False)
    stage_prefix = "geoje" if 점검 else ""
    return app_path, stage_prefix, 점검

# ------------------------------------------------------------------ 4. 설정 + 배포
def 설정쓰기(username, owner, repo, 사용자사이트, app_path, stage_prefix):
    site_base = "https://" + username + ".github.io"
    if not 사용자사이트:
        site_base += "/" + repo
    cfg = {
        "repo_url": "https://" + username + "@github.com/" + owner + "/" + repo + ".git",
        "local_dir": "",
        "site_base": site_base,
        "app_path": app_path,
        "stage_prefix": stage_prefix,
        "branch": "main",
        "commit_prefix": ("lesson-designer:" if app_path else "site:"),
    }
    with open(CFG_PATH, "w", encoding="utf-8", newline="\n") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    print("")
    print("  설정을 저장했습니다 -> tools\\배포설정.json")
    for k in ("repo_url", "app_path", "stage_prefix"):
        print("     " + k + " = " + repr(cfg[k]))
    return cfg


def 배포하기(cfg, 점검):
    title("5단계 / 미리보기")
    print("  (실제로 올리지 않고, 무엇이 올라갈지·검사 결과만 봅니다)")
    print("")
    rc = run_show([sys.executable, DEPLOY_SCRIPT])
    if rc != 0:
        stop("미리보기(또는 검사)에서 문제가 있었습니다. 위 내용을 확인하세요.")

    if not yn("위 6개 파일을 올릴까요?", True):
        stop("올리지 않았습니다. 나중에 다시 실행하면 됩니다.")

    title("6단계 / 올리는 중")
    print("  처음에는 GitHub 로그인 창이 한 번 더 뜰 수 있습니다.")
    print("")
    step = [sys.executable, DEPLOY_SCRIPT, "--push"]
    rc = run_show(step)
    if rc != 0:
        stop("올리다가 문제가 생겼습니다. 위 내용을 확인하고 다시 실행하세요.")

    if 점검:
        stage_url = cfg["site_base"] + "/" + cfg["stage_prefix"] + "/" + (cfg["app_path"] or "")
        box("점검본을 확인하세요",
            ["브라우저에서 아래 주소를 열어 화면이 정상인지 보세요 :",
             "  " + stage_url.rstrip("/") + "/",
             "(반영에 1~3분 걸릴 수 있습니다)"])
        webbrowser.open(stage_url.rstrip("/") + "/")
        if yn("확인했고, 실제 주소로 올릴까요?", False):
            rc = run_show([sys.executable, DEPLOY_SCRIPT, "--push", "--메인"])
            if rc != 0:
                stop("실제 주소로 올리다가 문제가 생겼습니다.")
        else:
            print("  점검본만 올렸습니다. 나중에 실제 주소로 올리려면 :")
            print("     python tools\\사이트에_올리기.py --push --메인")
            return

    final = cfg["site_base"] + ("/" + cfg["app_path"] if cfg["app_path"] else "") + "/"
    재배포 = "python tools\\사이트에_올리기.py --push" + (" --메인" if 점검 else "")
    box("끝났습니다",
        ["주소 : " + final,
         "  (GitHub Pages 반영에 1~3분, 첫 배포는 더 걸릴 수 있습니다)",
         "",
         "다음에 앱을 고쳐서 다시 올릴 때는, 이 폴더에서 :",
         "   " + 재배포,
         "또는 배포_시작하기.bat 을 다시 더블클릭하세요 (설정은 기억됩니다)."])
    webbrowser.open(final)


# ------------------------------------------------------------------ 메뉴 1 : 배포
def do_deploy():
    title("인터넷에 올리기 (배포)")
    print("  안내를 따라가면 GitHub Pages 에 올릴 수 있습니다.")
    print("  중간에 '지금 하실 일' 박스가 나오면 그것만 하시면 됩니다.")
    print("  잘못 눌러도 다시 실행하면 됩니다. (아무것도 망가지지 않습니다)")

    if os.path.exists(CFG_PATH):
        print("")
        if yn("이미 배포 설정이 있습니다. 그대로 바로 올릴까요? (아니오 = 설정 다시)", True):
            try:
                cfg = json.load(open(CFG_PATH, encoding="utf-8"))
            except Exception:
                cfg = None
            if cfg:
                배포하기(cfg, bool(cfg.get("stage_prefix")))
                return

    gh_있음 = 환경점검()
    username = 깃허브로그인(gh_있음)
    username, owner, repo, 사용자사이트 = 저장소준비(gh_있음, username)
    app_path, stage_prefix, 점검 = 배치정하기(사용자사이트, repo)
    cfg = 설정쓰기(username, owner, repo, 사용자사이트, app_path, stage_prefix)
    배포하기(cfg, 점검)


# ------------------------------------------------------------------ 메뉴 2 : 업그레이드
def do_upgrade():
    title("새 버전 확인 / 업그레이드")
    if upgrade is None:
        stop("upgrade.py 를 불러오지 못했습니다. 배포 도구가 손상된 것 같습니다.")
    print("  지금 이 PC 의 배포 도구 버전 : " + upgrade.cur_version())
    print("  깃허브에서 새 버전이 있는지 확인합니다...")
    have, m, msg = upgrade.check()
    print("")
    print("  " + msg.replace("\n", "\n  "))
    if not have:
        return
    box("새 버전 안내",
        [(m.get("version", "") + "  (" + m.get("date", "") + ")"),
         "",
         "바뀐 점 :",
         "  " + (m.get("notes", "") or "").replace("\n", "\n  "),
         "",
         "업그레이드하면 : 새 파일을 받아 검사한 뒤,",
         "  지금 버전을 '업그레이드백업\\판갈이전-...' 에 통째로 백업하고 갈아치웁니다.",
         "  ★ 내 저장소 설정(tools\\배포설정.json)과 배포본\\ 폴더는 건드리지 않습니다.",
         "  ★ 마음에 안 들면 메뉴 3 번으로 되돌릴 수 있습니다."])
    if not yn("지금 업그레이드할까요?", True):
        print("  업그레이드하지 않았습니다.")
        return
    print("")
    ok = upgrade.apply_update(on_log=lambda s: print("  " + str(s)))
    if ok:
        box("업그레이드 끝",
            ["이 창을 닫고 배포_시작하기.bat 을 다시 더블클릭하세요.",
             "새 버전의 도구로 다시 시작됩니다.",
             "그 다음 메뉴에서 '1) 인터넷에 올리기' 로 새 버전을 배포하면 됩니다."])
    else:
        print("")
        print("  업그레이드하지 않았습니다. 위 내용을 확인하세요. (기존 상태 그대로입니다)")


# ------------------------------------------------------------------ 메뉴 3 : 되돌리기
def do_revert():
    title("업그레이드 이전 버전으로 되돌리기")
    if upgrade is None:
        stop("upgrade.py 를 불러오지 못했습니다.")
    bs = upgrade.list_backups()
    if not bs:
        print("  되돌릴 백업이 없습니다. (업그레이드를 한 번도 안 했거나 백업이 지워졌습니다)")
        return
    print("  되돌릴 수 있는 백업 (최근 것이 위) :")
    for i, b in enumerate(bs):
        kind = "업그레이드 직전" if b["name"].startswith("판갈이전-") else "되돌리기 직전"
        print("    %d) %s  ·  버전 %s  ·  %s" % (i + 1, b["name"], b["version"], kind))
    print("    0) 그만두기")
    try:
        k = int(ask("되돌릴 번호", "0"))
    except Exception:
        k = 0
    if not (1 <= k <= len(bs)):
        print("  되돌리지 않았습니다.")
        return
    pick = bs[k - 1]
    box("되돌리기 안내",
        ["'" + pick["name"] + "' (버전 " + pick["version"] + ") 로 되돌립니다.",
         "",
         "되돌리기 직전의 지금 상태도 먼저 백업합니다 (다시 앞으로 갈 수 있게).",
         "내 저장소 설정과 배포본\\ 폴더는 건드리지 않습니다."])
    if not yn("되돌릴까요?", False):
        print("  되돌리지 않았습니다.")
        return
    print("")
    upgrade.revert(pick["name"], on_log=lambda s: print("  " + str(s)))
    box("되돌리기 끝",
        ["이 창을 닫고 배포_시작하기.bat 을 다시 더블클릭하세요."])


# ------------------------------------------------------------------ main
def main():
    title("수업 설계 도우미 - 배포 도구")
    ver = "?"
    try:
        ver = open(VERSION_FILE, encoding="utf-8").read().strip()
    except Exception:
        pass
    print("  이 PC 의 배포 도구 버전 : " + ver)

    # 시작하면서 새 버전이 있는지 슬쩍 확인 (실패해도 조용히 넘어감)
    새버전 = False
    if upgrade is not None:
        try:
            새버전, m, _ = upgrade.check()
        except Exception:
            새버전, m = False, None
        if 새버전:
            box("새 버전이 있습니다",
                [m.get("version", "") + "  (" + m.get("date", "") + ")",
                 (m.get("notes", "") or "")[:180],
                 "아래에서 '2) 새 버전 확인 / 업그레이드' 를 고르세요."])

    while True:
        print("")
        print("  무엇을 하시겠어요?")
        print("    1) 인터넷에 올리기 (배포)")
        print("    2) 새 버전 확인 / 업그레이드" + ("      <-- 새 버전 있음!" if 새버전 else ""))
        print("    3) 업그레이드 이전 버전으로 되돌리기")
        print("    4) 그만두기")
        sel = ask("번호", "1")
        try:
            if sel == "1":
                do_deploy()
            elif sel == "2":
                do_upgrade()
                새버전 = False
            elif sel == "3":
                do_revert()
            else:
                print("  안녕히 가세요.")
                return
        except SystemExit:
            # stop() 이 부른 것 — 메뉴로 돌아온다
            pass
        print("")
        if not yn("메뉴로 돌아갈까요? (아니오 = 창 닫기)", True):
            return


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n  취소했습니다.")
