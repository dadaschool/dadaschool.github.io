# -*- coding: utf-8 -*-
r"""
upgrade.py — 「수업 설계 도우미」 배포 도구의 자체 업그레이드 / 되돌리기

ai-coordinator(코디네이터) 앱의 방식을 웹앱 배포 도구에 맞춘 것이다.

  · 확인     : 깃허브의 latest.json 을 읽어 새 버전이 있는지 본다
  · 업그레이드 : 꾸러미(zip)를 받아 검사 -> 지금 것을 백업 -> 갈아치운다
  · 되돌리기  : 백업을 골라 그 버전으로 되돌린다 (되돌리기 직전 것도 먼저 백업)

절대 건드리지 않는 것 (KEEP) :
  tools/배포설정.json   <- 내 GitHub 저장소 설정 (이게 사라지면 배포를 다시 설정해야 함)
  참고_원본_index.html
  업그레이드백업/         <- 백업들
  (배포본\ 은 이 폴더 밖이라 애초에 대상이 아니다)

혼자 실행 :  python tools\upgrade.py 확인|업그레이드|되돌리기
배포_도우미.py 의 메뉴에서도 부른다.

CP949 콘솔이라 print 에는 한글·ASCII·「」·->·※ 만 쓴다.
"""

import datetime
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import urllib.request
import zipfile

APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TOOLS = os.path.join(APP, "tools")
VERSION_FILE = os.path.join(TOOLS, "version.txt")
BACKUP_DIR = os.path.join(APP, "업그레이드백업")
MANIFEST_URL = "https://dadaschool.github.io/lesson-designer-dist/latest.json"

# 이 폴더 안에서 «건드리지 않을» 최상위 폴더 / 파일
KEEP_TOP = {"업그레이드백업", "__pycache__", ".git", "배포본", ".claude", "node_modules"}
KEEP_FILES = {"tools/배포설정.json", "참고_원본_index.html"}
# 프로그램 파일이 아닌 것 (임시·산출물) — 꾸러미에도 백업에도 안 들어간다
SKIP_SUFFIX = (".zip", ".pyc", ".log", ".tmp", ".bak")
SKIP_NAMES = {"_판.txt", "_메모.txt"}

# 꾸러미에 꼭 들어 있어야 하는 파일 (없으면 그 꾸러미를 거부한다)
REQUIRED = [
    "index.html", "css/app.css",
    "js/ai.js", "js/lesson.js", "js/sim.js", "js/standards.js", "js/print.js",
    "server.py",
    "tools/사이트에_올리기.py", "tools/배포_도우미.py", "tools/upgrade.py",
    "tools/version.txt",
    "tools/검사/verify_deploy.cjs", "tools/검사/verify_sim.cjs",
]


# ------------------------------------------------------------------ 작은 도구
def cur_version():
    try:
        v = open(VERSION_FILE, encoding="utf-8").read().strip()
        return v if re.match(r"^\d+\.\d+\.\d+$", v) else "0.0.0"
    except Exception:
        return "0.0.0"


def vtuple(v):
    n = re.findall(r"\d+", v or "")
    n = (n + ["0", "0", "0"])[:3]
    return tuple(int(x) for x in n)


def ts_now():
    return datetime.datetime.now().strftime("%Y%m%d-%H%M%S")


def program_files(root):
    """업그레이드/되돌리기 대상 파일 (절대경로, 슬래시 상대경로) 목록"""
    out = []
    for dp, dns, fns in os.walk(root):
        dns[:] = [d for d in dns if d not in KEEP_TOP]
        for fn in fns:
            full = os.path.join(dp, fn)
            rel = os.path.relpath(full, root).replace("\\", "/")
            if rel in KEEP_FILES or fn in SKIP_NAMES:
                continue
            if fn.lower().endswith(SKIP_SUFFIX):
                continue
            out.append((full, rel))
    return sorted(out, key=lambda x: x[1])


def _fetch(url, timeout=15):
    req = urllib.request.Request(url, headers={"User-Agent": "lesson-designer-upgrade"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def _copy(src, dst):
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.copy2(src, dst)


# ------------------------------------------------------------------ 검사
def _js_ok(path):
    if shutil.which("node"):
        r = subprocess.run(["node", "--check", path], capture_output=True, text=True,
                           encoding="utf-8", errors="replace")
        return (r.returncode == 0, (r.stderr or "").strip().split("\n")[-1])
    src = open(path, encoding="utf-8", errors="replace").read()
    if not src.strip():
        return (False, "빈 파일")
    for a, b in (("{", "}"), ("(", ")"), ("[", "]")):
        if src.count(a) != src.count(b):
            return (False, a + b + " 짝이 안 맞음 (node 가 없어 느슨하게 검사함)")
    return (True, "")


def verify_tree(root, label="꾸러미"):
    """풀어 놓은 폴더(또는 백업 폴더)가 온전한지 본다. 문제 목록을 돌려준다(빈 목록이면 통과)."""
    errs = []
    for rel in REQUIRED:
        if not os.path.exists(os.path.join(root, rel.replace("/", os.sep))):
            errs.append(label + " 에 필수 파일이 없습니다: " + rel)
    v = os.path.join(root, "tools", "version.txt")
    if os.path.exists(v):
        if not re.match(r"^\d+\.\d+\.\d+\s*$", open(v, encoding="utf-8", errors="replace").read()):
            errs.append("tools/version.txt 모양이 이상합니다.")
    for dp, dns, fns in os.walk(root):
        dns[:] = [d for d in dns if d not in ("__pycache__", ".git")]
        for fn in fns:
            p = os.path.join(dp, fn)
            low = fn.lower()
            if low.endswith(".py"):
                try:
                    compile(open(p, encoding="utf-8", errors="replace").read(), fn, "exec")
                except SyntaxError as e:
                    errs.append("파이썬 오류 " + fn + " : " + str(e))
            elif low.endswith(".js") or low.endswith(".cjs"):
                ok, why = _js_ok(p)
                if not ok:
                    errs.append("자바스크립트 오류 " + fn + " : " + why)
            elif low.endswith(".bat"):
                try:
                    open(p, "rb").read().decode("cp949")
                except Exception:
                    errs.append(".bat 이 CP949 로 안 읽힙니다: " + fn)
    return errs


def _safe_names(zf):
    bad = []
    for n in zf.namelist():
        if n.startswith("/") or ".." in n.replace("\\", "/").split("/") or ":" in n:
            bad.append(n)
    return bad


# ------------------------------------------------------------------ 백업
def _backup_current(kind):
    r"""지금 상태를 업그레이드백업\<kind>-<시각>\ 에 통째로 복사한다. 폴더 경로를 돌려준다."""
    os.makedirs(BACKUP_DIR, exist_ok=True)
    name = kind + "-" + ts_now()
    dst_root = os.path.join(BACKUP_DIR, name)
    while os.path.exists(dst_root):     # 같은 초에 두 번 -> 숫자를 붙여 비켜간다
        dst_root += "_"
    for full, rel in program_files(APP):
        _copy(full, os.path.join(dst_root, rel.replace("/", os.sep)))
    with open(os.path.join(dst_root, "_판.txt"), "w", encoding="utf-8") as f:
        f.write(cur_version())
    return dst_root


def list_backups():
    if not os.path.isdir(BACKUP_DIR):
        return []
    out = []
    for name in sorted(os.listdir(BACKUP_DIR), reverse=True):
        d = os.path.join(BACKUP_DIR, name)
        if not os.path.isdir(d):
            continue
        if not (name.startswith("판갈이전-") or name.startswith("되돌리기전-")):
            continue
        ver = "?"
        vp = os.path.join(d, "_판.txt")
        if os.path.exists(vp):
            ver = open(vp, encoding="utf-8", errors="replace").read().strip()
        out.append({"name": name, "path": d, "version": ver})
    return out


# ------------------------------------------------------------------ 확인
def check():
    """(새버전있음?, 매니페스트 dict 또는 None, 사람이 읽을 메시지)"""
    try:
        m = json.loads(_fetch(MANIFEST_URL).decode("utf-8"))
    except Exception as e:
        return (False, None, "업데이트 서버에 연결하지 못했습니다. 인터넷 연결을 확인하세요.\n  (" + str(e) + ")")
    remote = str(m.get("version", "0.0.0"))
    if vtuple(remote) > vtuple(cur_version()):
        return (True, m, "새 버전 " + remote + " 이 있습니다. (지금 이 PC 는 " + cur_version() + ")")
    return (False, m, "이미 최신입니다. (" + cur_version() + ")")


# ------------------------------------------------------------------ 업그레이드
def apply_update(on_log=print):
    have, m, msg = check()
    on_log(msg)
    if m is None:
        return False
    if not have:
        return False

    url = m["url"]
    on_log("꾸러미를 받습니다: " + url)
    try:
        data = _fetch(url, timeout=60)
    except Exception as e:
        on_log("[멈춤] 내려받기 실패: " + str(e))
        return False

    if "size" in m and len(data) != int(m["size"]):
        on_log("[멈춤] 파일 크기가 안내와 다릅니다 (%d != %d). 받다 끊긴 것 같습니다." % (len(data), int(m["size"])))
        return False
    if "sha256" in m and hashlib.sha256(data).hexdigest() != m["sha256"]:
        on_log("[멈춤] 파일 해시가 안내와 다릅니다. 파일이 손상되었을 수 있어 설치하지 않습니다.")
        return False

    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except Exception as e:
        on_log("[멈춤] zip 파일이 아닙니다: " + str(e))
        return False
    bad = _safe_names(zf)
    if bad:
        on_log("[멈춤] 꾸러미 안에 위험한 경로가 있습니다: " + ", ".join(bad[:5]))
        return False

    os.makedirs(BACKUP_DIR, exist_ok=True)
    tmp = os.path.join(BACKUP_DIR, "_받은것-" + ts_now())
    zf.extractall(tmp)

    errs = verify_tree(tmp, "새 꾸러미")
    if errs:
        on_log("[멈춤] 받은 꾸러미에 문제가 있어 설치하지 않습니다:")
        for e in errs[:12]:
            on_log("   " + e)
        shutil.rmtree(tmp, ignore_errors=True)
        return False

    old = cur_version()
    new = str(m["version"])
    on_log("검사 통과. 지금 버전(" + old + ")을 백업합니다...")
    bdir = _backup_current("판갈이전")
    try:
        with open(os.path.join(bdir, "_메모.txt"), "w", encoding="utf-8") as f:
            f.write("업그레이드 " + old + " -> " + new + " 직전 백업\n" + (m.get("notes", "") or ""))
    except Exception:
        pass
    on_log("  백업 -> " + os.path.relpath(bdir, APP))

    # 적용
    before = set(rel for _, rel in program_files(APP))
    after = set()
    for dp, dns, fns in os.walk(tmp):
        dns[:] = [d for d in dns if d not in ("__pycache__",)]
        for fn in fns:
            src = os.path.join(dp, fn)
            rel = os.path.relpath(src, tmp).replace("\\", "/")
            after.add(rel)
            _copy(src, os.path.join(APP, rel.replace("/", os.sep)))
    # 새 꾸러미에 없어진 옛 파일은 지운다 (KEEP 은 program_files 가 이미 뺐다)
    removed = 0
    for rel in (before - after):
        p = os.path.join(APP, rel.replace("/", os.sep))
        try:
            os.remove(p)
            removed += 1
        except Exception:
            pass

    shutil.rmtree(tmp, ignore_errors=True)
    on_log("")
    on_log("업그레이드 완료 : " + old + " -> " + new + (("  (옛 파일 %d개 정리)" % removed) if removed else ""))
    on_log("※ 배포_도우미.py 등 도구 스크립트는 「다음에 실행할 때부터」 새 것으로 동작합니다.")
    on_log("※ 되돌리려면 메뉴의 '되돌리기' 를 쓰세요. 백업은 " + os.path.relpath(bdir, APP) + " 에 있습니다.")
    return True


# ------------------------------------------------------------------ 되돌리기
def revert(backup_name, on_log=print):
    d = os.path.join(BACKUP_DIR, backup_name)
    if not os.path.isdir(d):
        on_log("[멈춤] 그 백업이 없습니다: " + backup_name)
        return False

    errs = verify_tree(d, "백업")
    if errs:
        on_log("[멈춤] 이 백업이 온전하지 않아 되돌리지 않습니다:")
        for e in errs[:12]:
            on_log("   " + e)
        return False

    on_log("되돌리기 직전의 지금 상태부터 백업합니다 (다시 앞으로 갈 수 있게)...")
    safe = _backup_current("되돌리기전")
    on_log("  백업 -> " + os.path.relpath(safe, APP))

    before = set(rel for _, rel in program_files(APP))
    after = set()
    SKIP = {"_판.txt", "_메모.txt"}
    for dp, dns, fns in os.walk(d):
        dns[:] = [x for x in dns if x not in ("__pycache__",)]
        for fn in fns:
            if fn in SKIP:
                continue
            src = os.path.join(dp, fn)
            rel = os.path.relpath(src, d).replace("\\", "/")
            after.add(rel)
            _copy(src, os.path.join(APP, rel.replace("/", os.sep)))
    removed = 0
    for rel in (before - after):
        try:
            os.remove(os.path.join(APP, rel.replace("/", os.sep)))
            removed += 1
        except Exception:
            pass

    bv = "?"
    vp = os.path.join(d, "_판.txt")
    if os.path.exists(vp):
        bv = open(vp, encoding="utf-8", errors="replace").read().strip()
    on_log("")
    on_log("되돌렸습니다 -> 버전 " + bv + (("  (옛 파일 %d개 정리)" % removed) if removed else ""))
    on_log("※ 도구 스크립트는 다음 실행부터 그 버전으로 동작합니다.")
    return True


# ------------------------------------------------------------------ 혼자 실행
def _cli():
    what = sys.argv[1] if len(sys.argv) > 1 else "확인"
    if what in ("확인", "check"):
        _, _, msg = check()
        print(msg)
    elif what in ("업그레이드", "apply", "실행"):
        apply_update()
    elif what in ("되돌리기", "revert"):
        bs = list_backups()
        if not bs:
            print("되돌릴 백업이 없습니다.")
            return
        for i, b in enumerate(bs):
            print("  %d) %s  (버전 %s)" % (i + 1, b["name"], b["version"]))
        try:
            k = int(input("  되돌릴 번호 : ").strip())
        except Exception:
            print("취소했습니다.")
            return
        if 1 <= k <= len(bs):
            revert(bs[k - 1]["name"])
    else:
        print("쓰기 : python tools\\upgrade.py [확인|업그레이드|되돌리기]")


if __name__ == "__main__":
    _cli()
