/* =========================================================
   verify_sim.cjs — 5단계 시뮬레이터 뼈대 검사
   ---------------------------------------------------------
   AI 키 없이 돈다. 사람이 만든 «좋은 설정» 과 «나쁜 설정» 을 넣어
   Sim.validate 가 통과시킬 것은 통과시키고, 잡아야 할 것은 잡는지 본다.

   🚨 이 검사가 지키는 것
     · AI 가 준 계산식에 document·fetch 같은 것이 섞이면 반드시 막는다
     · NaN·무한대가 나오는 계산식을 통과시키지 않는다
     · 맞바꿈 유형에서 두 지표가 같이 움직이면 경고한다 (그게 이 유형의 존재 이유)
     · 만들어진 HTML 에 성취기준·정답이 새지 않는다
     · 만들어진 HTML 이 외부 CDN 을 쓰지 않는다 (교실망·더블클릭)

   실행 : node tools/검사/verify_sim.cjs   (cwd = 앱 폴더)
   ========================================================= */
"use strict";
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const APP = path.resolve(__dirname, "..", "..");

/* sim.js 는 브라우저용이라 window 를 만들어 준다 */
const sandbox = { window: {}, console: console, Math: Math, JSON: JSON, Function: Function, isFinite: isFinite };
sandbox.globalThis = sandbox;
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(path.join(APP, "js", "sim.js"), "utf8"), sandbox, { filename: "sim.js" });
const Sim = sandbox.window.Sim;

let pass = 0, fail = 0;
const ok = (m) => { pass++; console.log("  [통과] " + m); };
const bad = (m) => { fail++; console.log("  [실패] " + m); };
const check = (c, m) => (c ? ok(m) : bad(m));

/* ---------------------------------------------------------
   견본 설정 4종 (AI 가 만들어야 할 모양의 본보기)
   --------------------------------------------------------- */
const QUIZ = [{ q: "간격을 넓히면 어떻게 되나요?", opts: ["용량이 준다", "용량이 는다", "그대로다"], a: 1, why: "표본 수가 줄기 때문입니다." }];

const GOOD = {
  tradeoff: {
    title: "소리를 얼마나 자주 잴까",
    objective: "표본화 간격과 음질의 관계를 설명할 수 있다.",
    howto: "간격을 넓혔다 좁혔다 해 보세요.",
    insight: "자주 잴수록 원음에 가깝지만 용량이 커집니다.",
    controls: [{ key: "a", name: "표본화 간격", min: 1, max: 20, step: 1, value: 5, unit: "ms" }],
    metrics: [{ key: "m1", name: "파일 크기", unit: "KB", better: "low" },
              { key: "m2", name: "원음과 닮은 정도", unit: "%", better: "high" }],
    compute: "return [ 1000/a*0.8, 100 - a*3.5 ];",
    presets: [{ name: "촘촘히", values: [2] }, { name: "듬성듬성", values: [18] }],
    quiz: QUIZ, teacherNote: "간격을 극단으로 밀어 보게 하세요."
  },
  steps: {
    title: "10진수를 2진수로",
    objective: "10진수를 2진수로 바꾸는 과정을 설명할 수 있다.",
    howto: "숫자를 넣고 [다음 ▶] 을 눌러 보세요.",
    insight: "2로 나눈 나머지를 거꾸로 읽으면 2진수가 됩니다.",
    input: { name: "바꿀 10진수", kind: "number", value: 13, min: 1, max: 255 },
    compute: "var n=Math.max(1,Math.round(x)),out=[],r=[];" +
             "while(n>1){var q=Math.floor(n/2),m=n%2;r.push(m);" +
             "out.push({label:n+' \\u00f7 2',state:'몫 '+q+' · 나머지 '+m,note:'나머지를 적어 둡니다.'});n=q;}" +
             "r.push(n);out.push({label:'마지막 몫',state:String(n),note:'몫이 1이 되면 멈춥니다.'});" +
             "out.push({label:'거꾸로 읽기',state:r.slice().reverse().join(''),note:'아래에서 위로 읽습니다.'});" +
             "return out;",
    examples: [13, 25, 100],
    quiz: QUIZ, teacherNote: "13 을 먼저 함께 해 보세요."
  },
  compare: {
    title: "하나씩 찾기 vs 반씩 줄이기",
    objective: "두 탐색 알고리즘의 효율을 비교할 수 있다.",
    howto: "자료의 개수를 늘려 보세요.",
    insight: "자료가 많아질수록 반씩 줄이기가 압도적으로 빨라집니다.",
    input: { name: "자료의 개수", min: 10, max: 1000, step: 10, value: 100, unit: "개" },
    sides: [{ name: "하나씩 찾기", desc: "앞에서부터 차례로" },
            { name: "반씩 줄이기", desc: "가운데를 보고 반을 버림" }],
    metricName: "비교 횟수", metricUnit: "번", better: "low",
    compute: "return [ x/2, Math.log(x)/Math.log(2) ];",
    quiz: QUIZ, teacherNote: "1000개일 때 숫자를 함께 읽어 보세요."
  },
  classify: {
    title: "무엇을 배웠느냐가 판단을 정한다",
    objective: "학습 데이터가 인공지능의 판단에 미치는 영향을 설명할 수 있다.",
    howto: "카드를 눌러 빼 보세요.",
    insight: "배운 적이 없는 것은 절대 맞힐 수 없습니다.",
    featureNames: ["귀의 뾰족함", "소리의 높낮이"],
    labels: ["고양이", "강아지"],
    samples: [
      { name: "치즈", label: "고양이", features: [9, 8] },
      { name: "나비", label: "고양이", features: [8, 9] },
      { name: "야옹이", label: "고양이", features: [9, 7] },
      { name: "삼색이", label: "고양이", features: [8, 8] },
      { name: "뭉치", label: "강아지", features: [3, 3] },
      { name: "초코", label: "강아지", features: [2, 2] },
      { name: "바둑이", label: "강아지", features: [3, 2] },
      { name: "복실이", label: "강아지", features: [2, 4] }
    ],
    tests: [
      { name: "처음 보는 고양이", label: "고양이", features: [9, 9] },
      { name: "처음 보는 강아지", label: "강아지", features: [2, 3] },
      { name: "귀가 뾰족한 고양이", label: "고양이", features: [8, 7] },
      { name: "조용한 강아지", label: "강아지", features: [3, 1] }
    ],
    quiz: QUIZ, teacherNote: "고양이 카드를 모두 빼 보게 하세요."
  }
};

/* ---------------------------------------------------------
   1. 견본 4종이 검사를 통과하는가
   --------------------------------------------------------- */
console.log("\n-- 1. 견본 설정 4종 --");
Object.keys(GOOD).forEach((t) => {
  const v = Sim.validate(t, JSON.parse(JSON.stringify(GOOD[t])));
  check(v.ok, t + " 견본 통과 (계산 " + v.trials + "회)" + (v.ok ? "" : " -> " + v.errors.join(" / ")));
  check(v.warns.length === 0, t + " 견본에 경고 없음" + (v.warns.length ? " -> " + v.warns.join(" / ") : ""));
});

/* ---------------------------------------------------------
   2. 잡아야 할 나쁜 설정
   --------------------------------------------------------- */
console.log("\n-- 2. 잡아내야 할 것 --");
function mut(t, fn) { const s = JSON.parse(JSON.stringify(GOOD[t])); fn(s); return Sim.validate(t, s); }

check(!mut("tradeoff", s => s.compute = "document.body.innerHTML='x'; return [1,2];").ok,
      "compute 안의 document 를 막는다");
check(!mut("tradeoff", s => s.compute = "return [fetch('http://x'),2];").ok,
      "compute 안의 fetch 를 막는다");
check(!mut("tradeoff", s => s.compute = "return [eval('1'),2];").ok,
      "compute 안의 eval 을 막는다");
check(!mut("tradeoff", s => s.compute = "return [1/(a-a), 2];").ok,
      "0 으로 나눠 무한대가 나오면 막는다");
check(!mut("tradeoff", s => s.compute = "return [Math.sqrt(-a), 2];").ok,
      "NaN 이 나오면 막는다");
check(!mut("tradeoff", s => s.compute = "return [1];").ok,
      "지표 개수가 안 맞으면 막는다");
check(!mut("tradeoff", s => s.metrics = [s.metrics[0]]).ok,
      "metrics 가 2개가 아니면 막는다");
check(!mut("tradeoff", s => s.compute = "throw new Error('x');").ok,
      "예외를 던지는 계산식을 막는다");

/* 🔴 «반대» 는 값이 아니라 좋아지는 방향으로 본다.
   둘 다 better:"high" 인데 둘 다 커지면 = 둘 다 좋아짐 = 맞바꿈이 아니다. */
const sameDir = mut("tradeoff", s => {
  s.metrics[0].better = "high"; s.metrics[1].better = "high";
  s.compute = "return [a*2, a*3];";
});
check(sameDir.ok && sameDir.warns.length > 0,
      "두 지표가 «함께 좋아지면» 맞바꿈이 안 보인다고 경고한다");

/* 값은 둘 다 줄지만 좋아지는 방향은 반대인 경우 = 진짜 맞바꿈 -> 경고 없어야 한다 */
const realTrade = mut("tradeoff", s => s.compute = "return [ 500/a, 100 - a*4 ];");
check(realTrade.ok && realTrade.warns.length === 0,
      "값이 둘 다 줄어도 좋아지는 방향이 반대면 맞바꿈으로 인정한다");

check(!mut("steps", s => s.compute = "return 5;").ok,
      "steps 가 배열을 안 돌려주면 막는다");
check(!mut("steps", s => s.compute = "var o=[];for(var i=0;i<100;i++)o.push({label:'x'});return o;").ok,
      "단계가 40개를 넘으면 막는다");

check(!mut("classify", s => s.samples = s.samples.filter(x => x.label === "고양이")).ok,
      "한쪽 label 의 학습 카드가 없으면 막는다");
check(!mut("classify", s => s.samples[0].features = [1]).ok,
      "features 가 숫자 2개가 아니면 막는다");
check(!mut("classify", s => s.labels = ["A", "B", "C"]).ok,
      "labels 가 2개가 아니면 막는다");
check(!mut("classify", s => s.samples[0].label = "없는라벨").ok,
      "labels 에 없는 label 을 막는다");

check(!mut("tradeoff", s => s.quiz = [{ q: "?", opts: ["<b>정답</b>", "오답"], a: 1, why: "" }]).ok,
      "선택지에 <b> 로 정답을 표시하면 막는다 (mb-noise 사고)");
check(!mut("tradeoff", s => s.quiz = [{ q: "?", opts: ["가", "나"], a: 5, why: "" }]).ok,
      "정답 번호가 범위를 벗어나면 막는다");
check(!mut("tradeoff", s => s.insight = "").ok, "결론(insight)이 없으면 막는다");

/* ---------------------------------------------------------
   3. classify 분류기 — 편향을 실제로 보여 주는가
   --------------------------------------------------------- */
console.log("\n-- 3. 분류기 동작 --");
const cs = GOOD.classify;
const all = Sim.classifyAll(cs, cs.samples.map(() => true));
check(all.rate === 1, "모든 카드를 켜면 정확도 100% (실제 " + Math.round(all.rate * 100) + "%)");

const onlyDog = Sim.classifyAll(cs, cs.samples.map(s => s.label === "강아지"));
check(onlyDog.rate < all.rate,
      "고양이 카드를 모두 빼면 정확도가 떨어진다 (" + Math.round(all.rate * 100) + "% -> " + Math.round(onlyDog.rate * 100) + "%)");
check(onlyDog.results.every(r => r.got === "강아지"),
      "배운 적 없는 종류는 절대 답으로 나오지 않는다");

const none = Sim.classifyAll(cs, cs.samples.map(() => false));
check(none.results.every(r => r.got === null), "카드를 모두 빼면 «판단 불가» 가 된다");

/* ---------------------------------------------------------
   4. 만들어진 HTML
   --------------------------------------------------------- */
console.log("\n-- 4. 만들어진 HTML --");
const plan = {
  hour: 3,
  objective: "표본화 간격과 음질의 관계를 설명할 수 있다.",
  standard: "[9정02-01] 실생활의 데이터가 디지털 형태로 변환되어 활용되는 긍정적 가치를 탐색하고, 다양한 데이터를 디지털 형태로 표현한다.",
  dev: "[활동 1] ..."
};
Object.keys(GOOD).forEach((t) => {
  const html = Sim.buildHTML(t, GOOD[t], plan);
  check(html.startsWith("<!DOCTYPE html>") && html.trim().endsWith("</html>"), t + ": 온전한 HTML 문서");
  check(!/9정\d\d-\d\d/.test(html), t + ": 성취기준 코드가 없다 (학생이 보는 파일)");
  check(!/src\s*=\s*["']https?:/i.test(html) && !/@import\s+url\(\s*["']?https?:/i.test(html),
        t + ": 외부 CDN 을 쓰지 않는다 (교실망·더블클릭)");
  check(html.indexOf("requestAnimationFrame") < 0, t + ": rAF 를 쓰지 않는다");
  check(html.indexOf("window.SPEC=") > 0, t + ": 설정이 들어 있다");
  check(html.length > 8000 && html.length < 400000, t + ": 크기가 알맞다 (" + Math.round(html.length / 1024) + "KB)");
});

/* 정답이 파일 안에 있는 것은 «눌러서 확인» 용이라 의도된 것이지만,
   교사용 안내에는 정답을 적지 말라고 프롬프트가 못박고 있다. 그 문구가 살아 있는지 본다. */
check(Sim.systemPrompt("tradeoff").indexOf("teacherNote") > 0 &&
      /정답을 적지 마라/.test(Sim.systemPrompt("tradeoff")),
      "프롬프트가 «교사용 안내에 정답을 적지 마라» 를 담고 있다");
check(/선택지에 굵게·별표/.test(Sim.systemPrompt("steps")),
      "프롬프트가 «선택지에 정답 힌트 금지» 를 담고 있다");
check(Sim.TYPE_ORDER.length === 4, "유형이 4종이다");

/* ---------------------------------------------------------
   5. 유형 추천
   --------------------------------------------------------- */
console.log("\n-- 5. 유형 추천 --");
check(Sim.recommend({ objective: "인공지능 학습에 필요한 데이터를 수집하여 분류할 수 있다.", standard: "" }) === "classify",
      "인공지능·데이터 목표 -> classify 추천");
check(["steps", "compare"].indexOf(
      Sim.recommend({ objective: "문제를 해결하는 다양한 알고리즘을 비교·분석할 수 있다.", standard: "" })) >= 0,
      "알고리즘 비교 목표 -> steps/compare 추천");

/* ---------------------------------------------------------
   결과
   --------------------------------------------------------- */
console.log("");
if (fail) {
  console.log("시뮬레이터 검사 실패 : " + fail + "건 (통과 " + pass + "건)");
  process.exit(1);
}
console.log("시뮬레이터 검사 모두 통과 (" + pass + "건)");

/* 다른 검사 도구가 견본을 재사용할 수 있게 내보낸다 (직접 실행에는 영향 없음) */
module.exports = { Sim, GOOD };
