# -*- coding: utf-8 -*-
"""
사이트에_올리기.py — lesson-designer(수업 설계 도우미)를
설정 파일(tools/배포설정.json)에 적힌 GitHub 저장소에 안전하게 올린다

이 앱은 dadaschool 이 아닌 «다른 계정 / 다른 저장소» 로 배포한다.
그래서 올릴 곳을 tools/배포설정.json 에서 읽는다.

  1) tools/배포설정.example.json 을 tools/배포설정.json 으로 복사
  2) repo_url 등 값을 채운다 (자세한 건 example 파일의 _설명 줄)
  3) python tools/사이트에_올리기.py            -> 저장소를 배포본\\ 아래에 클론 + 미리보기
  4) python tools/사이트에_올리기.py --push     -> 점검 폴더(stage_prefix)로
  5) python tools/사이트에_올리기.py --push --메인  -> 실제 위치(app_path)로

  ※ stage_prefix 를 "" 로 두면 3~5가 한 단계가 된다(--메인 불필요).
  ※ 인증(자격증명)은 이 스크립트가 하지 않는다. git / gh 가 한다 — 아래 [인증] 참고.

무엇이 올라가는가 (화이트리스트)
  index.html · css/ · js/   -> 6개
무엇이 안 올라가는가
  server.py · *.bat · CLAUDE.md · .nojekyll · tools/ · 참고_원본_index.html
  (섞이면 guard() 가 아예 멈춘다)

배포 전에 tools/검사/verify_deploy.cjs (16건) 를 돌린다. 하나라도 실패하면 배포하지 않는다.
  가장 중요한 것 : 배포 파일에 API 키 문자열이 없는지 (교사가 키를 브라우저에 넣는 앱이다).

[인증] — 다른 계정으로 push 하려면 (셋 중 하나)
  · gh 사용     : gh auth login  (그 계정으로) → gh auth setup-git
                 두 계정을 오가면 push 직전에 gh auth switch
  · 자격증명 관리자 : repo_url 에 'YOUR_ID@' 를 넣어 두면 첫 push 때 그 계정 로그인 창이 뜬다
                 (git config credential.helper manager)
  · SSH        : repo_url 을 git@github.com:... 로 하고 그 계정 SSH 키 등록

이 파일의 print 문에 쓰면 안 되는 글자
  한국어 Windows 콘솔은 CP949 다. em dash·세모·겹화살괄호를 찍으면
  UnicodeEncodeError 로 스크립트가 마지막에 죽는다. 한글·ASCII 와 「」··->※★ 만 쓴다.
"""

import datetime
import json
import os
import re
import shutil
import subprocess
import sys

APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # lesson-designer
ROOT = os.path.dirname(APP)                                         # C:\project_AI
DEPLOY_ROOT = os.path.join(ROOT, "배포본")
CFG_PATH = os.path.join(APP, "tools", "배포설정.json")

# 올릴 것 (verify_deploy.cjs 의 DEPLOY_FILES 와 같아야 한다)
FILES = ["index.html"]
DIRS = ["css", "js"]
NEVER = {"tools", "node_modules", ".git", "vendor"}


def die(*msg):
    for m in msg:
        print(m)
    sys.exit(1)


def load_cfg():
    if not os.path.exists(CFG_PATH):
        die("",
            "[멈춤] tools/배포설정.json 이 없습니다. (아직 배포 설정을 안 했습니다)",
            "",
            "  ★ 처음이면  배포_시작하기.bat  을 더블클릭하세요.",
            "    (필요한 프로그램 확인 -> GitHub 로그인 -> 저장소 만들기 -> 배포까지 안내합니다)",
            "",
            "  직접 하려면 : tools/배포설정.example.json 을 tools/배포설정.json 으로 복사하고",
            "               repo_url 등 값을 채운 뒤 다시 실행하세요.",
            "")
    try:
        with open(CFG_PATH, "r", encoding="utf-8") as f:
            raw = json.load(f)
    except Exception as e:
        die("[멈춤] tools/배포설정.json 을 읽을 수 없습니다: " + str(e))
    cfg = {k: v for k, v in raw.items() if not k.startswith("_")}

    repo_url = (cfg.get("repo_url") or "").strip()
    if not repo_url or "YOUR_" in repo_url or "example.com" in repo_url:
        die("[멈춤] repo_url 을 실제 저장소 주소로 채우세요. (지금: " + repr(repo_url) + ")")
    if "github.com" in repo_url and "@github.com" not in repo_url and repo_url.startswith("https://"):
        print("  [참고] repo_url 에 'YOUR_ID@' 가 없습니다. 여러 계정을 쓰는 PC 라면")
        print("         https://YOUR_ID@github.com/... 로 두면 그 계정으로 인증되어 dadaschool 과 섞이지 않습니다.")

    local_dir = (cfg.get("local_dir") or "").strip()
    if not local_dir:
        tail = repo_url.rstrip("/").split("/")[-1]
        local_dir = tail[:-4] if tail.endswith(".git") else tail
    if not local_dir or local_dir in (".", "..") or "/" in local_dir or "\\" in local_dir:
        die("[멈춤] local_dir 이 이상합니다: " + repr(local_dir))

    return {
        "repo_url": repo_url,
        "local_dir": local_dir,
        "site_base": (cfg.get("site_base") or "").strip().rstrip("/"),
        "app_path": (cfg.get("app_path") or "").strip().strip("/"),
        "stage_prefix": (cfg.get("stage_prefix") or "").strip().strip("/"),
        "branch": (cfg.get("branch") or "main").strip(),
        "commit_prefix": (cfg.get("commit_prefix") or "lesson-designer:").strip(),
    }


CFG = load_cfg()
SITE = os.path.join(DEPLOY_ROOT, CFG["local_dir"])
STAGED = bool(CFG["stage_prefix"])
메인배포 = (not STAGED) or ("--메인" in sys.argv) or ("--main" in sys.argv)

# 어디에 올릴지 (저장소 안에서의 상대 경로). "" 이면 저장소 루트.
if 메인배포:
    SUBDIR = CFG["app_path"]
else:
    SUBDIR = (CFG["stage_prefix"] + "/" + CFG["app_path"]).strip("/")
ROOT_DEPLOY = (SUBDIR == "")
DEST = SITE if ROOT_DEPLOY else os.path.join(SITE, *SUBDIR.split("/"))

EMPTY_REPO = False


def 점검표시():
    return "" if 메인배포 else "[점검] "


# ── 어디로 올리는지 먼저 알려 준다 ──────────────────────────────
print("")
_where = "/" + SUBDIR + "/" if SUBDIR else "/ (저장소 루트)"
if not STAGED:
    print("  [단일 배포] " + CFG["local_dir"] + " 저장소의 " + _where + " 로 올립니다.")
elif 메인배포:
    print("  [메인 배포] " + CFG["local_dir"] + " 저장소의 " + _where + " 로 올립니다.")
    print("  ※ 쓰고 있던 사람에게 곧바로 영향이 갈 수 있습니다.")
else:
    print("  [점검 배포] " + CFG["local_dir"] + " 저장소의 " + _where + " 로 올립니다.")
    print("  ※ 확인이 끝나고 「메인으로 배포해」 라고 하면 --메인 을 붙여 다시 실행하세요.")
print("")


def run(args, cwd=None, check=True):
    r = subprocess.run(args, cwd=cwd, capture_output=True, text=True,
                       encoding="utf-8", errors="replace")
    if check and r.returncode != 0:
        print("[오류] " + " ".join(args))
        print(r.stdout)
        print(r.stderr)
        sys.exit(1)
    return r


def collect():
    out = []
    for f in FILES:
        p = os.path.join(APP, f)
        if os.path.exists(p):
            out.append((p, f))
        else:
            print("  [건너뜀] " + f + " (없음)")
    for d in DIRS:
        base = os.path.join(APP, d)
        if not os.path.isdir(base):
            print("  [건너뜀] " + d + "/ (없음)")
            continue
        for dirpath, dirnames, filenames in os.walk(base):
            dirnames[:] = [x for x in dirnames if x not in NEVER]
            for fn in filenames:
                full = os.path.join(dirpath, fn)
                out.append((full, os.path.relpath(full, APP).replace("\\", "/")))
    return sorted(out, key=lambda x: x[1])


def guard(pairs):
    bad = []
    for _, rel in pairs:
        low = rel.lower()
        if (rel.startswith("tools/")
                or low.endswith(".py") or low.endswith(".bat")
                or low.endswith(".md") or low.endswith(".cjs")
                or low == ".gitignore" or low == ".nojekyll"
                or "참고_원본" in rel):
            bad.append(rel)
    if bad:
        die("", "[멈춤] 올려서는 안 되는 파일이 목록에 있습니다 :", *["   " + f for f in bad])


def 검사돌리기():
    if not shutil.which("node"):
        die("",
            "[멈춤] Node.js 가 없어 배포 전 안전 검사를 돌릴 수 없습니다.",
            "  https://nodejs.org/ko 에서 LTS 를 설치하거나,",
            "  처음이면 배포_시작하기.bat 을 더블클릭해 마법사로 진행하세요.",
            "")
    for name in ("verify_deploy.cjs", "verify_sim.cjs"):
        t = os.path.join(APP, "tools", "검사", name)
        if not os.path.exists(t):
            die("[멈춤] 검사 파일이 없습니다 : " + t)
        r = subprocess.run(["node", t], cwd=APP, capture_output=True, text=True,
                           encoding="utf-8", errors="replace")
        lines = [l for l in (r.stdout or "").strip().split("\n") if l.strip()]
        last = lines[-1].strip() if lines else "(출력 없음)"
        if r.returncode != 0:
            print("[멈춤] 배포 검사 실패 : " + name)
            print(r.stdout)
            print(r.stderr)
            sys.exit(1)
        print("  검사 통과 : %-20s %s" % (name, last))


def 남의커밋확인():
    if EMPTY_REPO:
        return
    r = run(["git", "log", "origin/" + CFG["branch"] + "..HEAD", "--oneline"], cwd=SITE, check=False)
    lines = [l for l in (r.stdout or "").strip().split("\n") if l.strip()]
    if not lines:
        return
    print("")
    print("[멈춤] 아직 푸시되지 않은 커밋이 있습니다 :")
    for l in lines:
        print("   " + l)
    print("")
    print("  이 커밋들은 내 것이 아닐 수 있습니다(여러 창이 이 저장소를 함께 쓸 수 있음).")
    print("  내 커밋을 밀면 이것들도 함께 공개됩니다.")
    print("  확인되면 --남의커밋포함 을 붙여 다시 실행하세요.")
    sys.exit(1)


def 버전새기기(dest_html_paths):
    """올린 HTML 안의 js/*.js·css/*.css 주소 끝에 ?v=날짜시각 을 붙인다.
    GitHub Pages 10분 캐시 때문에 새 HTML + 예전 JS 가 섞이는 것을 막는다."""
    stamp = datetime.datetime.now().strftime("%Y%m%d%H%M")
    패턴 = re.compile(r'(["\'])((?:\./)?(?:js/|css/)?[A-Za-z0-9_-]+\.(?:js|mjs|css))\1')

    def 붙이기(m):
        q, p = m.group(1), m.group(2)
        if "vendor/" in p or "?" in p:
            return m.group(0)
        return q + p + "?v=" + stamp + q

    n = 0
    for f in dest_html_paths:
        with open(f, "r", encoding="utf-8") as fh:
            t = fh.read()
        새것 = 패턴.sub(붙이기, t)
        if 새것 != t:
            with open(f, "w", encoding="utf-8", newline="\n") as fh:
                fh.write(새것)
            n += 1
    return stamp, n


def ensure_site():
    global EMPTY_REPO
    if os.path.isdir(os.path.join(SITE, ".git")):
        r = run(["git", "rev-parse", "--verify", "HEAD"], cwd=SITE, check=False)
        if r.returncode != 0:
            EMPTY_REPO = True
            print("사이트 저장소가 비어 있습니다(첫 배포).")
            return
        print("사이트 저장소 최신화 중...")
        run(["git", "checkout", CFG["branch"]], cwd=SITE, check=False)
        run(["git", "pull", "--rebase", "--autostash"], cwd=SITE, check=False)
        return
    os.makedirs(DEPLOY_ROOT, exist_ok=True)
    print("저장소를 클론합니다 -> " + SITE)
    run(["git", "clone", CFG["repo_url"], SITE])
    r = run(["git", "rev-parse", "--verify", "HEAD"], cwd=SITE, check=False)
    if r.returncode != 0:
        EMPTY_REPO = True
        run(["git", "checkout", "-B", CFG["branch"]], cwd=SITE, check=False)
        print("(빈 저장소입니다. 첫 배포로 초기 커밋을 만듭니다.)")


def main():
    push = "--push" in sys.argv
    ensure_site()

    print("")
    검사돌리기()
    print("")

    pairs = collect()
    guard(pairs)

    old = set()
    if os.path.isdir(DEST):
        for dirpath, dirnames, filenames in os.walk(DEST):
            dirnames[:] = [x for x in dirnames if x != ".git"]
            for fn in filenames:
                rel = os.path.relpath(os.path.join(dirpath, fn), DEST).replace("\\", "/")
                if ROOT_DEPLOY and (rel.startswith(".git/") or rel in ("index.html",) or
                                    rel.startswith("css/") or rel.startswith("js/")):
                    old.add(rel)
                elif not ROOT_DEPLOY:
                    old.add(rel)

    new = set(rel for _, rel in pairs)
    added = sorted(new - old)
    removed = sorted(old - new)
    total_kb = sum(os.path.getsize(src) for src, _ in pairs) // 1024

    print("올릴 파일 %d개 (%d KB)" % (len(pairs), total_kb))
    for _, rel in pairs:
        print("     " + rel)
    print("  새로 생기는 것 : %d개" % len(added))
    if removed:
        print("  " + ("사이트 루트에서 지울 것" if ROOT_DEPLOY else "지울 것") + " : %d개" % len(removed))
        for f in removed[:14]:
            print("     - " + f)

    if not push:
        print("")
        print("(미리 보기만 했습니다. 실제로 올리려면 --push 를 붙이세요)")
        return

    if "--남의커밋포함" not in sys.argv:
        남의커밋확인()

    # 복사
    if not ROOT_DEPLOY and os.path.isdir(DEST):
        shutil.rmtree(DEST)   # 하위 폴더 통째 교체
    copied_html = []
    for src, rel in pairs:
        dst = os.path.join(DEST, *rel.split("/"))
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(src, dst)
        if dst.endswith(".html"):
            copied_html.append(dst)
    # 루트 배포일 때, 이전에 있던 우리 파일 중 지금 목록에 없는 것 삭제
    if ROOT_DEPLOY:
        for rel in removed:
            p = os.path.join(DEST, *rel.split("/"))
            if os.path.exists(p):
                os.remove(p)
    print("")
    print("복사 완료 -> " + DEST)

    stamp, n = 버전새기기(copied_html)
    print("버전 새김 : ?v=%s  (HTML %d개)" % (stamp, n))

    r = run(["git", "status", "--porcelain"], cwd=SITE)
    if not r.stdout.strip():
        print("바뀐 것이 없습니다.")
        return

    if ROOT_DEPLOY:
        run(["git", "add", "index.html", "css", "js"], cwd=SITE)
    else:
        run(["git", "add", "-A", SUBDIR.split("/")[0]], cwd=SITE)
    run(["git", "commit", "-m", 점검표시() + CFG["commit_prefix"] + " 수업 설계 도우미 배포"], cwd=SITE)

    if EMPTY_REPO:
        run(["git", "push", "-u", "origin", CFG["branch"]], cwd=SITE)
    else:
        run(["git", "push"], cwd=SITE)

    base = (CFG["site_base"] or "https://<계정>.github.io")
    url = base + ("/" + SUBDIR if SUBDIR else "") + "/"
    print("")
    print("푸시했습니다. GitHub Pages 반영에 1~3분 걸립니다(첫 배포는 더 걸릴 수 있음).")
    print("  주소 : " + url)
    if STAGED and not 메인배포:
        print("")
        print("  ※ 여기는 점검용입니다. 확인하신 뒤 「메인으로 배포해」 라고 하시면")
        print("    --메인 을 붙여 " + (CFG["app_path"] or "저장소 루트") + " 로 옮깁니다.")
    if EMPTY_REPO:
        print("")
        print("  ※ 첫 배포입니다. GitHub 저장소 Settings -> Pages 에서")
        print("     Source = 'Deploy from a branch', Branch = " + CFG["branch"] + " / (root) 로 켜세요.")


if __name__ == "__main__":
    main()
