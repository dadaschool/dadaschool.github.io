/* =========================================================
   verify_deploy.cjs — 배포 직전 안전 검사 (lesson-designer)
   ---------------------------------------------------------
   이 앱은 «교사가 자기 API 키를 브라우저에 넣는» 구조다.
   그래서 배포되는 파일에 키가 새어 들어가면 공개 주소로 남의 키가 나간다.
   그 사고를 막는 것이 이 검사의 첫 번째 목적이다.

   사이트에_올리기.py 가 --push 전에 이 파일을 돌리고,
   하나라도 실패하면 배포하지 않는다.

   실행 : node tools/검사/verify_deploy.cjs   (cwd = 앱 폴더)
   ========================================================= */
"use strict";
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const APP = path.resolve(__dirname, "..", "..");
const rd = (p) => fs.readFileSync(path.join(APP, p), "utf8");

let pass = 0, fail = 0;
function ok(msg) { pass++; console.log("  [통과] " + msg); }
function bad(msg) { fail++; console.log("  [실패] " + msg); }
function check(cond, msg) { cond ? ok(msg) : bad(msg); }

/* 배포되는 파일 목록 (사이트에_올리기.py 의 FILES/DIRS 와 같아야 한다) */
const DEPLOY_FILES = ["index.html", "css/app.css"];
for (const d of ["js"]) {
  for (const fn of fs.readdirSync(path.join(APP, d))) {
    if (fn.endsWith(".js")) DEPLOY_FILES.push(d + "/" + fn);
  }
}

/* ---- 1. API 키·자격증명 누수 ---- */
// 진짜 키 모양만 잡는다. ai.js 의 안내 문구 "sk-ant-…"(말줄임표) 는 걸리지 않는다.
const KEY_PATTERNS = [
  [/sk-ant-[A-Za-z0-9_\-]{20,}/, "Anthropic 키(sk-ant-…)"],
  [/sk-proj-[A-Za-z0-9_\-]{20,}/, "OpenAI 프로젝트 키(sk-proj-…)"],
  [/sk-[A-Za-z0-9]{32,}/, "OpenAI 키(sk-…)"],
  [/AIza[A-Za-z0-9_\-]{30,}/, "Google API 키(AIza…)"],
  [/\bup_[A-Za-z0-9]{20,}/, "Upstage 키(up_…)"],
  [/(api[_-]?key|apikey|secret|token|password)\s*[:=]\s*["'][A-Za-z0-9_\-]{20,}["']/i, "키처럼 보이는 문자열 대입"]
];
let leak = false;
for (const rel of DEPLOY_FILES) {
  const txt = rd(rel);
  for (const [re, label] of KEY_PATTERNS) {
    const m = txt.match(re);
    if (m) { bad("키 누수 의심: " + rel + " -> " + label + " : " + m[0].slice(0, 40)); leak = true; }
  }
}
if (!leak) ok("배포 파일 " + DEPLOY_FILES.length + "개에 API 키·자격증명 문자열 없음");

/* ---- 2. ai.js 기본 키는 빈 문자열이어야 한다 ---- */
const ai = rd("js/ai.js");
check(/keys:\s*o\.keys\s*\|\|\s*\{\}/.test(ai), "ai.js: 저장 키의 기본값이 빈 객체({})");
check(!/\bkeys?\s*:\s*\{\s*[a-z]+\s*:\s*["'][^"']{8,}/i.test(ai), "ai.js: keys 에 미리 채워진 값이 없음");
check(/키는 <b>이 브라우저에만<\/b>/.test(ai) || /localStorage 에만/.test(ai),
      "ai.js: '키는 이 브라우저에만' 안내 문구 유지");
check(/data-clear/.test(ai) && /키 지우기/.test(ai), "ai.js: [키 지우기] 버튼 유지");

/* ---- 3. js/print.js 는 프로젝트 공용본과 같아야 한다 ---- */
const SHARED_MD5 = "51e2ea54029bc109589a19913982fb63";
const printMd5 = crypto.createHash("md5").update(fs.readFileSync(path.join(APP, "js/print.js"))).digest("hex");
check(printMd5 === SHARED_MD5, "js/print.js md5 = 공용본(" + SHARED_MD5.slice(0, 8) + "…)  실제=" + printMd5.slice(0, 8));

/* ---- 4. 외부 런타임 의존성 0 (오프라인·file:// 유지) ---- */
const html = rd("index.html");
check(!/<script[^>]+src\s*=\s*["']https?:/i.test(html), "index.html: 외부 <script src=http> 없음");
check(!/<link[^>]+href\s*=\s*["']https?:/i.test(html), "index.html: 외부 <link href=http> 없음 (Google Fonts 등)");
check(!/@import\s+url\(\s*["']?https?:/i.test(rd("css/app.css")), "app.css: @import url(http…) 없음");
check(!/\bfetch\s*\(\s*["']https?:\/\/(?!api\.|generativelanguage)/i.test(ai.replace(/\s+/g, " ")) , "ai.js: AI 제공자 외의 외부 fetch 없음");

/* ---- 5. 원본 참고본이 배포 목록에 없다 ---- */
check(!DEPLOY_FILES.some((f) => f.includes("참고_원본")), "배포 목록에 참고_원본_index.html 없음");
check(!/참고_원본/.test(html), "index.html 이 참고_원본 파일을 참조하지 않음");

/* ---- 6. 학생 인쇄물에 성취기준·정답을 넘기지 않는다 ---- */
const lesson = rd("js/lesson.js");
// 학생 인쇄 경로(printItems)는 objective 만 받고 standard 를 넘기지 않아야 한다
check(/function printItems\(items, title, objective\)/.test(lesson), "lesson.js: printItems 는 objective 만 받음 (성취기준 미전달)");
check(/function toPrintItems\(items\)/.test(lesson) && !/toPrintItems[\s\S]{0,400}standard/.test(lesson),
      "lesson.js: toPrintItems 가 정답/성취기준 필드를 넘기지 않음");
// Print.sheet 호출에 standard: 가 없어야 한다
check(!/Print\.sheet\(\{[\s\S]*?standard:/.test(lesson), "lesson.js: 학생 인쇄(Print.sheet) 호출에 standard 없음");

/* ---- 7. 성취기준 25개가 다 들어 있다 ---- */
const std = rd("js/standards.js");
const codes = (std.match(/"9정0[1-5]-0[0-9]":/g) || []).length;
check(codes === 25, "standards.js: 내장 성취기준 25개 (실제 " + codes + ")");

/* ---- 7-0. 업그레이드 도구가 배포에 새지 않는다 ---- */
const badInDeploy = DEPLOY_FILES.filter((f) =>
  /version\.txt$|upgrade\.py$|꾸러미_만들기|업그레이드백업/.test(f));
check(badInDeploy.length === 0, "업그레이드 도구(version.txt·upgrade.py·백업)가 배포 목록에 없다");
check(fs.existsSync(path.join(APP, "tools/version.txt")) &&
      /^\d+\.\d+\.\d+\s*$/.test(rd("tools/version.txt")), "tools/version.txt 가 있고 x.y.z 모양");
check(fs.existsSync(path.join(APP, "tools/upgrade.py")), "tools/upgrade.py 가 있다 (자체 업그레이드/되돌리기)");
{
  // 화면의 버전 표시가 version.txt 와 같아야 «올린 것이 반영됐나» 를 눈으로 알 수 있다
  const vtxt = rd("tools/version.txt").trim();
  const m = html.match(/<div class="ver" id="app-ver">v([\d.]+)<\/div>/);
  check(!!m, "index.html 에 버전 표시(id=app-ver)가 있다");
  check(m && m[1] === vtxt, "화면 버전 표시(v" + (m ? m[1] : "?") + ") = version.txt(" + vtxt + ")");
}
{
  const dw = rd("tools/배포_도우미.py");
  check(/새 버전 확인 \/ 업그레이드/.test(dw) && /되돌리기/.test(dw) && /import upgrade/.test(dw),
        "배포_도우미.py 에 업그레이드/되돌리기 메뉴가 있다");
  const up = rd("tools/upgrade.py");
  check(/배포설정\.json/.test(up) && /KEEP_FILES/.test(up),
        "upgrade.py 가 배포설정.json 을 보존 목록에 둔다");
  check(/sha256/.test(up) && /verify_tree/.test(up),
        "upgrade.py 가 받은 꾸러미의 해시·내용을 검사한다");
}

/* ---- 7-1. 1단계 문장 카드가 편집 가능하다 ---- */
const lj = rd("js/lesson.js");
check(/class="text" contenteditable="true"/.test(lj), "lesson.js: 문장 카드가 contenteditable");
check(/id="btn-add-sent"/.test(html) && /id="btn-reset-sents"/.test(html) && /id="btn-save-sents"/.test(html),
      "index.html: 문장 추가·저장·되돌리기 버튼이 있다");
check(/function currentSentences\(\)/.test(lj) && /currentSentences\(\)/.test(lj),
      "lesson.js: goStep2 가 화면에 적힌 문장을 읽는다 (원본 고정 아님)");
check(/id="card-edit-hint"/.test(html) && /정답이 아니라 예시/.test(html),
      "index.html: «정답이 아니라 예시» 안내가 있다");

/* ---- 8. 5단계 시뮬레이터 ---- */
const simRaw = rd("js/sim.js");
// 주석(설명글)에는 금지어가 «쓰지 않는다» 처럼 적혀 있으므로 코드만 본다
const sim = simRaw.replace(/\/\*[\s\S]*?\*\//g, "").replace(/^\s*\/\/.*$/gm, "");
check(DEPLOY_FILES.indexOf("js/sim.js") >= 0, "js/sim.js 가 배포 목록에 있다");
check(/<script src="js\/sim\.js">/.test(html), "index.html 이 js/sim.js 를 읽는다");
check(/data-step="5"/.test(html) && /학습 도움 자료 제작하기/.test(html), "index.html 에 5단계가 있다");
// 만들어지는 파일이 외부를 부르지 않는다 (교실망·더블클릭)
check(!/https?:\/\/(?!www\.w3\.org)/.test(sim), "sim.js 가 만드는 HTML 에 외부 주소가 없다");
check(sim.indexOf("requestAnimationFrame") < 0, "sim.js: rAF 를 쓰지 않는다");
// 계산식 차단 목록이 살아 있다
["document", "fetch", "eval", "localStorage"].forEach(function (w) {
  check(new RegExp("\\b" + w + "\\b").test(simRaw.match(/var BAN\s*=\s*\/[^\n]*/)[0]),
        "sim.js BAN 목록에 " + w + " 가 있다");
});
// 프롬프트가 규칙을 담고 있다
check(/성취기준 코드·문장을 넣지 마라/.test(simRaw), "sim.js 프롬프트: 성취기준 노출 금지");
check(/선택지에 굵게·별표/.test(simRaw), "sim.js 프롬프트: 선택지 정답 힌트 금지");
// AI 응답 상한 (4096 이면 시뮬 설정이 잘린다)
var mt = ai.match(/max_tokens:\s*(\d+)/);
check(mt && Number(mt[1]) >= 8000, "ai.js: max_tokens 가 8000 이상 (실제 " + (mt ? mt[1] : "없음") + ")");

/* ---- 결과 ---- */
console.log("");
if (fail) {
  console.log("배포 검사 실패 : " + fail + "건 (통과 " + pass + "건) — 배포하지 않습니다.");
  process.exit(1);
}
console.log("배포 검사 모두 통과 (" + pass + "건)");
